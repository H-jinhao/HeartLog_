"""HeartLog — local-first emotional diary and traceable long-term memory."""

__version__ = "0.1.0"
