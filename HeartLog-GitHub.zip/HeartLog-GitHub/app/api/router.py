"""Top-level API router.

Authentication is applied once here: when ``HEARTLOG_API_TOKEN`` is configured
every versioned endpoint requires a bearer token.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends

from app.api.routes import conversations, diaries, export, insights, memories, persons, search
from app.core.security import require_api_access

api_router = APIRouter(dependencies=[Depends(require_api_access)])
api_router.include_router(diaries.router)
api_router.include_router(memories.router)
api_router.include_router(search.router)
api_router.include_router(conversations.router)
api_router.include_router(insights.router)
api_router.include_router(persons.router)
api_router.include_router(export.router)
