"""Traceable long-term memory API routes.

The routes stay deliberately thin: they validate transport input, delegate to
:class:`app.services.memory_service.MemoryService`, and return schemas.

Endpoints
---------
``POST /memories/extract``
    Asynchronously extract candidate memories from one exact, immutable diary
    revision.  Only candidates whose evidence is verified against that revision
    are persisted (as ``pending``, ``created_by="model"``); rejected candidates
    are returned with structured reason codes and create no rows.  If every
    candidate is invalid the request fails with ``422`` and nothing is written.
    AI disabled/unconfigured yields ``503 ai_not_configured`` with no writes.

``GET /memories``
    Paginated listing.  Deleted/revoked/superseded rows are hidden by default:
    the default view is "active only" (``is_active=1`` and status not
    ``revoked``/``superseded``).  ``active=false`` lists inactive rows only, and
    an explicit ``verification_status`` selects that exact status (useful for
    inspecting revoked history deliberately).

``GET /memories/{id}``
    Detail including every evidence source and the source revision version.

``GET /memories/{id}/sources``
    Evidence rows with the diary revision/version they were verified against.

``POST /memories/{id}/confirm``
    pending -> confirmed, ``confirmed_by="user"``.  Never changes
    ``memory_type``: a model inference stays a model inference.

``POST /memories/{id}/correct``
    Creates a NEW confirmed memory (``source_type="user_correction"``) that
    supersedes the old one; old content is never rewritten.

``POST /memories/{id}/revoke``
    revoked + inactive; hidden from normal lists, still retrievable by id.

``DELETE /memories/{id}``
    Irreversibly purge (or anonymize) content and evidence.  Requires the
    ``X-Confirm-Memory-Delete`` header.  Once all memories referencing a
    soft-deleted diary are purged, that diary can be permanently deleted.
"""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, Header, Query, status

from app.api.deps import AIServiceDep, DBSession, SettingsDep
from app.core.exceptions import ValidationError
from app.models.enums import MemoryType, VerificationStatus
from app.schemas.common import Page
from app.schemas.memory import (
    ExtractionReport,
    ExtractionRequest,
    ForgetMode,
    MemoryCorrectionRequest,
    MemoryForgetResponse,
    MemoryOut,
    MemoryRevokeRequest,
    MemorySourceList,
)
from app.services.memory_service import MemoryService

router = APIRouter(prefix="/memories", tags=["memories"])


def get_memory_service(
    db: DBSession,
    settings: SettingsDep,
    ai_service: AIServiceDep,
) -> MemoryService:
    return MemoryService(session=db, settings=settings, ai_service=ai_service)


MemoryServiceDep = Annotated[MemoryService, Depends(get_memory_service)]

# Query metadata is declared once at module level: FastAPI forbids defaults
# inside ``Query`` when it appears in ``Annotated``; the parameter default is
# supplied with ``=`` instead.
_MEMORY_TYPE_QUERY = Query(description="Filter by memory type.")
_VERIFICATION_STATUS_QUERY = Query(
    description="Exact verification status; useful for inspecting revoked history.",
)
_ENTRY_ID_QUERY = Query(description="Filter by source diary entry id.")
_ACTIVE_QUERY = Query(
    description=(
        "true/omitted: active only (default); false: inactive only. "
        "Ignored when verification_status is given."
    ),
)
_LIMIT_QUERY = Query(ge=1, description="Page size (capped by settings.max_page_size).")
_OFFSET_QUERY = Query(ge=0, description="Page offset.")
_INCLUDE_DELETED_SOURCES_QUERY = Query(
    description=(
        "Include memories whose source diary is soft-deleted. Default false: "
        "derived memories follow the diary's soft-delete visibility."
    ),
)


@router.post(
    "/extract",
    response_model=ExtractionReport,
    status_code=status.HTTP_200_OK,
    summary="Extract pending memories from an exact diary revision",
    responses={
        422: {"description": "No candidate could be verified against the revision"},
        503: {"description": "AI is disabled or not configured"},
    },
)
async def extract_memories(
    payload: ExtractionRequest,
    service: MemoryServiceDep,
) -> ExtractionReport:
    return await service.extract(
        entry_id=payload.entry_id,
        revision_id=payload.revision_id,
        version=payload.version,
    )


@router.get(
    "",
    response_model=Page[MemoryOut],
    summary="List memories (active only by default)",
)
def list_memories(
    service: MemoryServiceDep,
    memory_type: Annotated[MemoryType | None, _MEMORY_TYPE_QUERY] = None,
    verification_status: Annotated[VerificationStatus | None, _VERIFICATION_STATUS_QUERY] = None,
    entry_id: Annotated[str | None, _ENTRY_ID_QUERY] = None,
    active: Annotated[bool | None, _ACTIVE_QUERY] = None,
    include_deleted_sources: Annotated[bool, _INCLUDE_DELETED_SOURCES_QUERY] = False,
    limit: Annotated[int | None, _LIMIT_QUERY] = None,
    offset: Annotated[int, _OFFSET_QUERY] = 0,
) -> Page[MemoryOut]:
    return service.list_memories(
        memory_type=memory_type,
        verification_status=verification_status,
        entry_id=entry_id,
        active=active,
        include_deleted_sources=include_deleted_sources,
        limit=limit,
        offset=offset,
    )


@router.get(
    "/{memory_id}",
    response_model=MemoryOut,
    summary="Get one memory with its exact evidence",
    responses={404: {"description": "Memory not found or its source diary is soft-deleted"}},
)
def get_memory(
    memory_id: str,
    service: MemoryServiceDep,
    include_deleted_sources: Annotated[bool, _INCLUDE_DELETED_SOURCES_QUERY] = False,
) -> MemoryOut:
    return service.get_memory(memory_id, include_deleted_sources=include_deleted_sources)


@router.get(
    "/{memory_id}/sources",
    response_model=MemorySourceList,
    summary="List the immutable evidence sources of a memory",
    responses={404: {"description": "Memory not found or its source diary is soft-deleted"}},
)
def get_memory_sources(
    memory_id: str,
    service: MemoryServiceDep,
    include_deleted_sources: Annotated[bool, _INCLUDE_DELETED_SOURCES_QUERY] = False,
) -> MemorySourceList:
    return service.list_sources(memory_id, include_deleted_sources=include_deleted_sources)


@router.post(
    "/{memory_id}/confirm",
    response_model=MemoryOut,
    summary="Confirm a pending memory as the user",
    responses={
        404: {"description": "Memory not found"},
        409: {"description": "Invalid review-state transition"},
    },
)
def confirm_memory(memory_id: str, service: MemoryServiceDep) -> MemoryOut:
    return service.confirm(memory_id)


@router.post(
    "/{memory_id}/correct",
    response_model=MemoryOut,
    status_code=status.HTTP_201_CREATED,
    summary="Create a superseding correction (never rewrites the old memory)",
    responses={
        404: {"description": "Memory not found"},
        409: {"description": "Invalid state or duplicate corrected content"},
        422: {"description": "Invalid correction payload"},
    },
)
def correct_memory(
    memory_id: str,
    payload: MemoryCorrectionRequest,
    service: MemoryServiceDep,
) -> MemoryOut:
    return service.correct(
        memory_id,
        content=payload.content,
        change_reason=payload.change_reason,
    )


@router.post(
    "/{memory_id}/revoke",
    response_model=MemoryOut,
    summary="Revoke a memory (hidden from normal lists, still traceable)",
    responses={
        404: {"description": "Memory not found"},
        409: {"description": "Invalid review-state transition"},
    },
)
def revoke_memory(
    memory_id: str,
    service: MemoryServiceDep,
    payload: MemoryRevokeRequest | None = None,
) -> MemoryOut:
    return service.revoke(memory_id, reason=payload.reason if payload is not None else None)


@router.delete(
    "/{memory_id}",
    response_model=MemoryForgetResponse,
    summary="Permanently purge/anonymize one memory and its evidence",
    responses={
        404: {"description": "Memory not found"},
        422: {"description": "Missing/invalid X-Confirm-Memory-Delete header"},
    },
)
def forget_memory(
    memory_id: str,
    service: MemoryServiceDep,
    mode: ForgetMode = "purge",
    confirm: Annotated[str | None, Header(alias="X-Confirm-Memory-Delete")] = None,
) -> MemoryForgetResponse:
    if confirm not in (memory_id, "true", "confirm"):
        raise ValidationError(
            "Permanent memory deletion requires X-Confirm-Memory-Delete: <memory_id> or 'true'",
            code="confirmation_required",
        )
    return service.forget(memory_id, mode=mode)
