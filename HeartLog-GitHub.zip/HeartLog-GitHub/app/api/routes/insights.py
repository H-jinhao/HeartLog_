"""Weekly / monthly insight API routes.

Disabled-AI behaviour (chosen deliberately)
-------------------------------------------
When AI is disabled or not configured, ``GET /api/v1/insights/weekly`` and
``/monthly`` still return **HTTP 200**, but with ``mode="local_statistics"`` and
``ai_used=false``:

* deterministic counts (diary entries, memories, per-memory-type counts),
* UTC period boundaries,
* real source references (entry/revision/memory IDs),
* ``narrative=null`` and an explicit note that no AI narrative was generated.

This is deliberately not a 503: local statistics are genuinely useful, and the
response labels the absence of AI loudly instead of faking a narrative.
"""

from __future__ import annotations

from datetime import date
from typing import Annotated

from fastapi import APIRouter, Query

from app.api.deps import AIServiceDep, DBSession
from app.schemas.insight import InsightResponse
from app.services import insight_service

router = APIRouter(prefix="/insights", tags=["insights"])

_DATE_QUERY = Query(
    alias="date",
    description="Optional reference date (ISO 8601, e.g. 2026-03-11). Defaults to today (UTC).",
)


@router.get(
    "/weekly",
    response_model=InsightResponse,
    summary="Weekly review",
)
async def weekly_insight(
    session: DBSession,
    ai_service: AIServiceDep,
    reference_date: Annotated[date | None, _DATE_QUERY] = None,
) -> InsightResponse:
    return await insight_service.build_insight(
        ai_service=ai_service,
        session=session,
        period="weekly",
        reference_date=reference_date,
    )


@router.get(
    "/monthly",
    response_model=InsightResponse,
    summary="Monthly review",
)
async def monthly_insight(
    session: DBSession,
    ai_service: AIServiceDep,
    reference_date: Annotated[date | None, _DATE_QUERY] = None,
) -> InsightResponse:
    return await insight_service.build_insight(
        ai_service=ai_service,
        session=session,
        period="monthly",
        reference_date=reference_date,
    )
