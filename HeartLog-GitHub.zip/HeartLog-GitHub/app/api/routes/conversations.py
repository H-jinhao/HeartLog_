"""Conversation API routes.

Endpoints
---------
* ``POST /api/v1/conversations`` — create a conversation (``title`` optional).
* ``POST /api/v1/conversations/{conversation_id}/messages`` — store a user
  message and return the reply exchange.
* ``GET  /api/v1/conversations/{conversation_id}`` — read back the conversation
  with its stored messages (useful for local audit/UI).

Disabled-AI behaviour (chosen deliberately)
-------------------------------------------
When AI is disabled or not fully configured, posting a message still returns
**HTTP 200** but the exchange is ``mode="placeholder"`` / ``ai_used=false``:

* the assistant message is stored with ``mode="placeholder"``;
* its content is an explicitly labelled local notice stating no model was called
  and no data left the device;
* ``citations`` is empty.

HeartLog never fakes an AI reply, and this keeps the user's own message stored
locally so nothing is lost.  When AI *is* configured, a provider/validation
failure is returned as an honest error (502/503), and the user message remains
stored without a fabricated assistant message.
"""

from __future__ import annotations

from fastapi import APIRouter, Request, status

from app.api.deps import AIServiceDep, DBSession
from app.models.conversation import Conversation, Message
from app.schemas.conversation import (
    Citation,
    ConversationCreate,
    ConversationDetail,
    ConversationOut,
    MessageCreate,
    MessageExchange,
    MessageOut,
)
from app.services import conversation_service

router = APIRouter(prefix="/conversations", tags=["conversations"])


def _conversation_out(conversation: Conversation, *, message_count: int = 0) -> ConversationOut:
    return ConversationOut(
        id=conversation.id,
        title=conversation.title,
        created_at=conversation.created_at,
        updated_at=conversation.updated_at,
        message_count=message_count,
    )


@router.post(
    "",
    response_model=ConversationOut,
    status_code=status.HTTP_201_CREATED,
    summary="Create a conversation",
)
def create_conversation(
    payload: ConversationCreate,
    session: DBSession,
) -> ConversationOut:
    conversation = conversation_service.create_conversation(session, payload.title)
    return _conversation_out(conversation)


@router.get(
    "/{conversation_id}",
    response_model=ConversationDetail,
    summary="Get a conversation with its messages",
)
def get_conversation(conversation_id: str, session: DBSession) -> ConversationDetail:
    conversation = conversation_service.get_conversation(session, conversation_id)
    messages: list[Message] = conversation_service.list_messages(session, conversation_id)
    base = _conversation_out(conversation, message_count=len(messages))
    return ConversationDetail(
        **base.model_dump(),
        messages=[MessageOut.model_validate(message) for message in messages],
    )


@router.post(
    "/{conversation_id}/messages",
    response_model=MessageExchange,
    summary="Send a message to the companion",
)
async def post_message(
    conversation_id: str,
    payload: MessageCreate,
    request: Request,
    ai_service: AIServiceDep,
) -> MessageExchange:
    data = await conversation_service.send_message(
        ai_service=ai_service,
        session_factory=request.app.state.session_factory,
        conversation_id=conversation_id,
        content=payload.content,
    )
    return MessageExchange(
        conversation_id=data["conversation_id"],
        user_message=MessageOut.model_validate(data["user_message"]),
        assistant_message=MessageOut.model_validate(data["assistant_message"]),
        mode=data["mode"],
        ai_used=data["ai_used"],
        citations=[Citation.model_validate(item) for item in data["citations"]],
        provider=data["provider"],
        model=data["model"],
        notice=data["notice"],
    )
