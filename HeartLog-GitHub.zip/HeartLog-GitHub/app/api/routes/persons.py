"""Person endpoints.  No automatic merging is performed."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Header, Query, status

from app.api.deps import DBSession, SettingsDep
from app.core.exceptions import ValidationError
from app.schemas.person import (
    PersonCreate,
    PersonForgetResponse,
    PersonList,
    PersonOut,
    PersonTimeline,
)
from app.services.person_service import PersonService

router = APIRouter(prefix="/persons", tags=["persons"])

_INCLUDE_DELETED_SOURCES_QUERY = Query(
    description="Include people whose source diary is soft-deleted (default false)."
)


@router.post("", response_model=PersonOut, status_code=status.HTTP_201_CREATED)
def create_person(payload: PersonCreate, db: DBSession, settings: SettingsDep) -> PersonOut:
    return PersonService(db, settings).create(payload)


@router.get("", response_model=PersonList)
def list_persons(
    db: DBSession,
    settings: SettingsDep,
    q: Annotated[str | None, Query(max_length=200)] = None,
    limit: Annotated[int, Query(ge=1, le=100)] = 20,
    offset: Annotated[int, Query(ge=0)] = 0,
    include_deleted_sources: Annotated[bool, _INCLUDE_DELETED_SOURCES_QUERY] = False,
) -> PersonList:
    return PersonService(db, settings).list(
        q=q,
        limit=limit,
        offset=offset,
        include_deleted_sources=include_deleted_sources,
    )


@router.get("/{person_id}", response_model=PersonOut)
def get_person(
    person_id: str,
    db: DBSession,
    settings: SettingsDep,
    include_deleted_sources: Annotated[bool, _INCLUDE_DELETED_SOURCES_QUERY] = False,
) -> PersonOut:
    return PersonService(db, settings).get(person_id, include_deleted_sources=include_deleted_sources)


@router.get("/{person_id}/timeline", response_model=PersonTimeline)
def person_timeline(
    person_id: str,
    db: DBSession,
    settings: SettingsDep,
    limit: Annotated[int, Query(ge=1, le=100)] = 50,
    offset: Annotated[int, Query(ge=0)] = 0,
    include_deleted_sources: Annotated[bool, _INCLUDE_DELETED_SOURCES_QUERY] = False,
) -> PersonTimeline:
    return PersonService(db, settings).timeline(
        person_id,
        limit=limit,
        offset=offset,
        include_deleted_sources=include_deleted_sources,
    )


@router.delete(
    "/{person_id}",
    response_model=PersonForgetResponse,
    summary="Permanently remove a person record (contentless audit remains)",
    responses={
        404: {"description": "Person not found"},
        422: {"description": "Missing/invalid X-Confirm-Person-Delete header"},
    },
)
def forget_person(
    person_id: str,
    db: DBSession,
    settings: SettingsDep,
    confirm: Annotated[str | None, Header(alias="X-Confirm-Person-Delete")] = None,
) -> PersonForgetResponse:
    if confirm not in (person_id, "true", "confirm"):
        raise ValidationError(
            "Permanent person deletion requires X-Confirm-Person-Delete: <person_id> or 'true'",
            code="confirmation_required",
        )
    return PersonService(db, settings).forget(person_id)
