"""Diary HTTP endpoints.

Routes are intentionally thin: validation lives in Pydantic schemas, business
rules in :class:`app.services.diary_service.DiaryService`, and persistence in
the repository.  All responses distinguish the immutable original text from the
current content and revision history.
"""

from __future__ import annotations

from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, Depends, Header, Query, status

from app.api.deps import DBSession, SettingsDep
from app.core.exceptions import ValidationError
from app.core.security import require_admin
from app.schemas.common import DeletedResponse, Page
from app.schemas.diary import (
    DiaryCreate,
    DiaryDetail,
    DiaryListItem,
    DiaryReferences,
    DiaryUpdate,
    IntegrityReport,
    RevisionList,
    RevisionOut,
)
from app.services.diary_service import DiaryService

router = APIRouter(prefix="/diaries", tags=["diaries"])


def _service(db: DBSession, settings: SettingsDep) -> DiaryService:
    return DiaryService(db, settings)


@router.post(
    "",
    response_model=DiaryDetail,
    status_code=status.HTTP_201_CREATED,
    summary="Create a diary entry and its initial immutable revision",
)
def create_diary(payload: DiaryCreate, db: DBSession, settings: SettingsDep) -> DiaryDetail:
    return _service(db, settings).create(content=payload.content, metadata=payload.metadata)


@router.get("", response_model=Page[DiaryListItem], summary="List non-deleted diaries")
def list_diaries(
    db: DBSession,
    settings: SettingsDep,
    q: Annotated[str | None, Query(max_length=200)] = None,
    date_from: datetime | None = None,
    date_to: datetime | None = None,
    limit: Annotated[int | None, Query(ge=1, le=500)] = None,
    offset: Annotated[int, Query(ge=0)] = 0,
) -> Page[DiaryListItem]:
    return _service(db, settings).list(
        q=q,
        date_from=date_from,
        date_to=date_to,
        limit=limit,
        offset=offset,
    )


@router.get("/{diary_id}", response_model=DiaryDetail, summary="Read one diary and its current content")
def get_diary(diary_id: str, db: DBSession, settings: SettingsDep) -> DiaryDetail:
    return _service(db, settings).get(diary_id)


@router.put(
    "/{diary_id}", response_model=DiaryDetail, summary="Append a new revision (original is preserved)"
)
def update_diary(
    diary_id: str,
    payload: DiaryUpdate,
    db: DBSession,
    settings: SettingsDep,
) -> DiaryDetail:
    return _service(db, settings).update(
        diary_id,
        content=payload.content,
        expected_version=payload.expected_version,
        change_reason=payload.change_reason,
    )


@router.get(
    "/{diary_id}/revisions",
    response_model=RevisionList,
    summary="Read the full immutable revision history",
)
def list_revisions(diary_id: str, db: DBSession, settings: SettingsDep) -> RevisionList:
    entry_id, versions = _service(db, settings).revisions(diary_id)
    return RevisionList(entry_id=entry_id, total=len(versions), versions=versions)


@router.get(
    "/{diary_id}/revisions/{version}",
    response_model=RevisionOut,
    summary="Read one revision by version number",
)
def get_revision(diary_id: str, version: int, db: DBSession, settings: SettingsDep) -> RevisionOut:
    return _service(db, settings).revision(diary_id, version)


@router.get(
    "/{diary_id}/integrity",
    response_model=IntegrityReport,
    summary="Verify original hash and revision hash chain",
)
def diary_integrity(diary_id: str, db: DBSession, settings: SettingsDep) -> IntegrityReport:
    return _service(db, settings).integrity(diary_id)


@router.get(
    "/{diary_id}/references",
    response_model=DiaryReferences,
    summary="Inspect memories/persons that block permanent diary deletion",
)
def diary_references(diary_id: str, db: DBSession, settings: SettingsDep) -> DiaryReferences:
    return _service(db, settings).references(diary_id)


@router.delete(
    "/{diary_id}",
    response_model=DeletedResponse,
    summary="Soft-delete a diary; revisions are retained",
)
def delete_diary(diary_id: str, db: DBSession, settings: SettingsDep) -> DeletedResponse:
    entry = _service(db, settings).soft_delete(diary_id)
    assert entry.deleted_at is not None
    return DeletedResponse(id=entry.id, deleted_at=entry.deleted_at)


@router.post(
    "/{diary_id}/restore",
    response_model=DiaryDetail,
    summary="Restore a soft-deleted diary",
)
def restore_diary(diary_id: str, db: DBSession, settings: SettingsDep) -> DiaryDetail:
    return _service(db, settings).restore(diary_id)


@router.delete(
    "/{diary_id}/permanent",
    dependencies=[Depends(require_admin)],
    summary="Irreversibly delete an unreferenced diary (admin only)",
)
def permanently_delete_diary(
    diary_id: str,
    db: DBSession,
    settings: SettingsDep,
    confirm: Annotated[str | None, Header(alias="X-Confirm-Permanent-Delete")] = None,
) -> dict[str, object]:
    if confirm not in (diary_id, "true", "confirm"):
        raise ValidationError(
            "Permanent deletion requires X-Confirm-Permanent-Delete: <diary_id> or 'true'",
            code="confirmation_required",
        )
    _service(db, settings).permanent_delete(diary_id)
    return {"deleted": True, "id": diary_id, "permanent": True}
