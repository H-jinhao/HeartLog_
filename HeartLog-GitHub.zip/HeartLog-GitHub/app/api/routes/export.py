"""Data export endpoint (downloadable JSON archive)."""

from __future__ import annotations

import json

from fastapi import APIRouter, Response

from app.api.deps import DBSession
from app.services.export_service import export_and_audit

router = APIRouter(prefix="/export", tags=["export"])


@router.get(
    "",
    summary="Export all diaries, revisions, memories, sources, people and conversations as JSON",
    response_class=Response,
)
def export_all(db: DBSession) -> Response:
    payload = export_and_audit(db)
    filename = f"heartlog-export-{payload['exported_at'].replace(':', '').replace('-', '')}.json"
    return Response(
        content=json.dumps(payload, ensure_ascii=False),
        media_type="application/json; charset=utf-8",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Cache-Control": "no-store",
        },
    )
