"""Health check endpoint (unauthenticated by design)."""

from __future__ import annotations

from datetime import UTC, datetime

from fastapi import APIRouter, Request
from sqlalchemy import text

from app import __version__
from app.schemas.common import HealthResponse

router = APIRouter(tags=["health"])


@router.get("/health", response_model=HealthResponse, summary="Service health")
def health(request: Request) -> HealthResponse:
    settings = request.app.state.settings
    database_status = "ok"
    session_factory = request.app.state.session_factory
    try:
        with session_factory() as session:
            session.execute(text("SELECT 1"))
    except Exception:  # pragma: no cover - covered by a dedicated failure test if needed
        database_status = "error"

    ai = request.app.state.ai_service
    return HealthResponse(
        status="ok" if database_status == "ok" else "degraded",
        app=settings.app_name,
        version=__version__,
        environment=settings.environment,
        database=database_status,
        ai_enabled=settings.ai_enabled,
        ai_ready=ai.configured,
        time=datetime.now(UTC),
    )
