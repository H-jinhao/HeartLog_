"""Keyword search endpoint."""

from __future__ import annotations

from typing import Annotated, Literal

from fastapi import APIRouter, Query

from app.api.deps import DBSession, SettingsDep
from app.schemas.search import SearchResponse
from app.services.search_service import SearchService

router = APIRouter(prefix="/search", tags=["search"])


@router.get("", response_model=SearchResponse, summary="Search diary revisions and active memories")
def search(
    db: DBSession,
    settings: SettingsDep,
    q: Annotated[str, Query(min_length=1, max_length=200)],
    scope: Literal["all", "diaries", "memories"] = "all",
    include_history: bool = True,
    include_deleted_sources: bool = False,
    limit: Annotated[int | None, Query(ge=1, le=500)] = None,
    offset: Annotated[int, Query(ge=0)] = 0,
) -> SearchResponse:
    return SearchService(db, settings).search(
        query=q,
        scope=scope,
        include_history=include_history,
        include_deleted_sources=include_deleted_sources,
        limit=limit,
        offset=offset,
    )
