"""FastAPI dependencies shared by route modules."""

from __future__ import annotations

from collections.abc import Iterator
from typing import Annotated

from fastapi import Depends, Request
from sqlalchemy.orm import Session

from app.core.config import Settings
from app.services.ai_service import AIService


def get_app_settings(request: Request) -> Settings:
    return request.app.state.settings


def get_db(request: Request) -> Iterator[Session]:
    session_factory = request.app.state.session_factory
    session: Session = session_factory()
    try:
        yield session
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def get_ai_service(request: Request) -> AIService:
    return request.app.state.ai_service


SettingsDep = Annotated[Settings, Depends(get_app_settings)]
DBSession = Annotated[Session, Depends(get_db)]
AIServiceDep = Annotated[AIService, Depends(get_ai_service)]
