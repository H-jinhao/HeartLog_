"""Shared response schemas and pagination helpers."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Generic, TypeVar

from pydantic import BaseModel, ConfigDict, Field

T = TypeVar("T")


class ORMModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class ErrorBody(BaseModel):
    code: str
    message: str
    details: dict[str, Any] = Field(default_factory=dict)


class ErrorEnvelope(BaseModel):
    error: ErrorBody


class Page(BaseModel, Generic[T]):
    items: list[T]
    total: int = Field(ge=0)
    limit: int = Field(ge=1)
    offset: int = Field(ge=0)
    has_more: bool


class HealthResponse(BaseModel):
    status: str
    app: str
    version: str
    environment: str
    database: str
    ai_enabled: bool
    ai_ready: bool
    time: datetime


class DeletedResponse(BaseModel):
    id: str
    deleted_at: datetime
    message: str = "Soft-deleted. Revisions are retained and the entry can be restored."
