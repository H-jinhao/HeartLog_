"""Insight (weekly / monthly review) API schemas.

An insight response always tells the truth about how it was produced: either a
real AI narrative (``mode="ai"``) or local statistics only
(``mode="local_statistics"``, ``ai_used=false``).  It never presents fabricated
content as a generated review.
"""

from __future__ import annotations

from datetime import date, datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

#: Returned with every insight so the feature is never mistaken for therapy.
DISCLAIMER = (
    "HeartLog 不是心理治疗、医疗诊断或危机干预工具；本回顾仅供参考。"
    "若你处于危险中，请联系当地紧急服务或可信任的专业心理支持。"
)


class InsightPeriod(BaseModel):
    model_config = ConfigDict(extra="forbid")

    period: Literal["weekly", "monthly"]
    start: datetime = Field(description="Inclusive start of the period (UTC).")
    end: datetime = Field(description="Exclusive end of the period (UTC).")
    reference_date: date
    timezone: str = "UTC"


class MemoryTypeCount(BaseModel):
    model_config = ConfigDict(extra="forbid")

    memory_type: str
    count: int = Field(ge=0)


class InsightStatistics(BaseModel):
    model_config = ConfigDict(extra="forbid")

    diary_entries: int = Field(ge=0)
    memories: int = Field(ge=0)
    memory_type_counts: list[MemoryTypeCount] = Field(default_factory=list)


class InsightSource(BaseModel):
    """A real stored record the review is based on (never model-generated)."""

    model_config = ConfigDict(extra="forbid")

    memory_id: str | None = None
    entry_id: str
    revision_id: str | None = None
    version: int | None = None
    snippet: str | None = None
    memory_type: str | None = None
    created_at: datetime | None = None


class InsightResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    mode: Literal["ai", "local_statistics"]
    ai_used: bool
    period: InsightPeriod
    statistics: InsightStatistics
    narrative: str | None = Field(
        default=None,
        description="AI narrative; null in local_statistics mode.",
    )
    sources: list[InsightSource] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    disclaimer: str = DISCLAIMER
    provider: str | None = None
    model: str | None = None
