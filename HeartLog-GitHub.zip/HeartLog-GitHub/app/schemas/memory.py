"""API schemas for the traceable long-term memory subsystem.

A persisted memory is only meaningful together with the exact diary evidence
that produced it.  Responses therefore always carry the source entry/revision,
the revision version and the immutable evidence snippet(s).  Rejected model
candidates never echo candidate or diary text back to the client: only stable
reason codes are returned, because the extracted text is private data.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.models.enums import (
    CreatedBy,
    MemorySourceType,
    MemoryType,
    VerificationStatus,
)
from app.schemas.common import ORMModel

# Hard upper bound shared with ``app.schemas.ai.CandidateMemory``; the runtime
# ``settings.max_evidence_chars`` value can only make this stricter.
MAX_MEMORY_CONTENT_CHARS = 4_000
MAX_CORRECTION_REASON_CHARS = 500
MAX_REVOKE_REASON_CHARS = 200

ForgetMode = Literal["purge", "anonymize"]


class ExtractionRequest(BaseModel):
    """Request an extraction for one exact diary revision.

    ``revision_id`` wins over ``version``; when both are supplied they must
    identify the same revision.  When neither is supplied the entry's current
    revision is used.  Extraction is always performed against immutable
    revision content, never against a mutable "current text" cache.
    """

    model_config = ConfigDict(extra="forbid")

    entry_id: str = Field(min_length=1, max_length=36, description="Diary entry id.")
    revision_id: str | None = Field(
        default=None,
        min_length=1,
        max_length=36,
        description="Exact diary revision id. Defaults to the entry's current revision.",
    )
    version: int | None = Field(
        default=None,
        ge=1,
        description="Revision version; must match revision_id when both are provided.",
    )


class MemoryCorrectionRequest(BaseModel):
    """User-authored correction.

    The original memory is never rewritten: a new memory row with the corrected
    content supersedes it and copies the (re-validated) evidence sources.
    """

    model_config = ConfigDict(extra="forbid")

    content: str = Field(
        min_length=1,
        max_length=MAX_MEMORY_CONTENT_CHARS,
        description="Corrected memory content. Must differ from the current content.",
    )
    change_reason: str | None = Field(
        default=None,
        max_length=MAX_CORRECTION_REASON_CHARS,
        description="Optional structural note stored in metadata and the audit trail.",
    )

    @field_validator("content")
    @classmethod
    def _content_not_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("content must not be empty or whitespace only")
        return value


class MemoryRevokeRequest(BaseModel):
    """Optional body for revoking a memory."""

    model_config = ConfigDict(extra="forbid")

    reason: str | None = Field(default=None, max_length=MAX_REVOKE_REASON_CHARS)

    @field_validator("reason")
    @classmethod
    def _normalise_reason(cls, value: str | None) -> str | None:
        if value is not None and not value.strip():
            return None
        return value


class MemorySourceOut(ORMModel):
    """One immutable evidence row belonging to a memory."""

    id: str
    memory_id: str
    entry_id: str
    revision_id: str
    evidence_text: str
    start_offset: int | None = None
    end_offset: int | None = None
    created_at: datetime


class MemorySourceDetail(MemorySourceOut):
    """Evidence plus the version of the diary revision it was verified against."""

    revision_version: int | None = None


class MemorySourceList(BaseModel):
    memory_id: str
    total: int = Field(ge=0)
    sources: list[MemorySourceDetail] = Field(default_factory=list)


class MemoryForgetResponse(BaseModel):
    """Result of an irreversible memory purge/anonymization operation.

    ``anonymize`` removes the same content-bearing rows as ``purge`` but writes a
    distinct audit event.  Neither mode retains the memory content or evidence;
    the append-only audit event is a contentless tombstone.
    """

    memory_id: str
    mode: ForgetMode
    forgotten_at: datetime
    source_entry_id: str
    source_revision_id: str
    memory_type: str
    purged_sources: int = Field(ge=0)
    audit_event_id: str
    note: str = (
        "Content and evidence were permanently removed. An append-only audit event "
        "remains without memory content. Existing backups/exports are not modified."
    )


class MemoryOut(ORMModel):
    """A memory with its verification state and its complete evidence trail."""

    id: str
    content: str
    content_hash: str
    memory_type: MemoryType
    source_type: MemorySourceType
    confidence: float | None = None
    verification_status: VerificationStatus
    is_active: bool
    created_by: CreatedBy
    confirmed_by: CreatedBy | None = None
    confirmed_at: datetime | None = None
    revoked_at: datetime | None = None
    supersedes_memory_id: str | None = None
    source_entry_id: str
    source_revision_id: str
    source_version: int | None = None
    source_entry_deleted: bool = False
    created_at: datetime
    updated_at: datetime
    metadata: dict[str, Any] = Field(default_factory=dict)
    sources: list[MemorySourceOut] = Field(default_factory=list)


class RejectedCandidate(BaseModel):
    """Structured reason why one model candidate was not persisted.

    Deliberately contains no candidate content or evidence text.
    """

    model_config = ConfigDict(extra="forbid")

    index: int = Field(ge=0, description="Zero-based position in the model output.")
    reason: str = Field(description="Stable machine-readable rejection code.")
    message: str = Field(description="Human-readable explanation.")
    memory_type: str | None = None


class ExtractionReport(BaseModel):
    """Outcome of one extraction run.

    ``created`` contains only pending memories that passed evidence validation
    and were committed atomically with their sources and audit events.
    """

    entry_id: str
    revision_id: str
    version: int
    provider: str
    model: str
    candidate_count: int = Field(ge=0)
    created: list[MemoryOut] = Field(default_factory=list)
    rejected: list[RejectedCandidate] = Field(default_factory=list)
    created_count: int = Field(ge=0)
    rejected_count: int = Field(ge=0)
