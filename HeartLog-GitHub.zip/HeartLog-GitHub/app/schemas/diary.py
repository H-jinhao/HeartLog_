"""Diary API schemas."""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.core.text import has_forbidden_control_chars
from app.schemas.common import ORMModel


def _validate_metadata(value: dict[str, Any]) -> dict[str, Any]:
    """Keep metadata deliberately small, flat-ish and JSON-safe.

    Metadata is not a second home for diary text.  A 4 KiB budget, limited depth
    and string/scalar values keep exports and queries predictable.
    """

    if len(value) > 50:
        raise ValueError("metadata may contain at most 50 top-level keys")

    def walk(item: Any, depth: int) -> None:
        if depth > 3:
            raise ValueError("metadata nesting is too deep (max depth 3)")
        if isinstance(item, dict):
            if len(item) > 50:
                raise ValueError("metadata object has too many keys")
            for key, nested in item.items():
                if not isinstance(key, str) or len(key) > 100:
                    raise ValueError("metadata keys must be strings of at most 100 chars")
                walk(nested, depth + 1)
        elif isinstance(item, list):
            if len(item) > 100:
                raise ValueError("metadata arrays may contain at most 100 items")
            for nested in item:
                walk(nested, depth + 1)
        elif not isinstance(item, (str, int, float, bool, type(None))):
            raise ValueError("metadata values must be JSON scalars, lists or objects")
        elif isinstance(item, str) and len(item) > 1_000:
            raise ValueError("metadata string values may be at most 1000 chars")

    walk(value, 0)
    encoded = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    if len(encoded.encode("utf-8")) > 4_096:
        raise ValueError("metadata is too large (max 4 KiB)")
    return value


class DiaryCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    content: str = Field(
        min_length=1, max_length=50_000, description="Original diary text; stored unchanged."
    )
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("content")
    @classmethod
    def _content_not_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("content must not be empty or whitespace only")
        if has_forbidden_control_chars(value):
            raise ValueError("content must not contain NUL or unsupported control characters")
        return value

    @field_validator("metadata")
    @classmethod
    def _metadata_valid(cls, value: dict[str, Any]) -> dict[str, Any]:
        return _validate_metadata(value)


class DiaryUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    content: str = Field(min_length=1, max_length=50_000)
    expected_version: int | None = Field(default=None, ge=1, description="Optimistic concurrency guard.")
    change_reason: str | None = Field(default=None, max_length=500)

    @field_validator("content")
    @classmethod
    def _content_not_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("content must not be empty or whitespace only")
        if has_forbidden_control_chars(value):
            raise ValueError("content must not contain NUL or unsupported control characters")
        return value


class RevisionOut(ORMModel):
    id: str
    entry_id: str
    version: int
    content: str
    content_hash: str
    previous_revision_hash: str | None
    change_reason: str | None
    created_at: datetime


class DiaryListItem(ORMModel):
    id: str
    preview: str
    original_preview: str
    current_version: int
    created_at: datetime
    updated_at: datetime
    deleted_at: datetime | None
    is_deleted: bool
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("preview", "original_preview", mode="before")
    @classmethod
    def _cut(cls, value: str) -> str:
        text = str(value)
        return text if len(text) <= 160 else text[:157] + "..."


class DiaryDetail(ORMModel):
    id: str
    original_text: str
    original_content_hash: str
    current_version: int
    current_revision_id: str | None
    created_at: datetime
    updated_at: datetime
    deleted_at: datetime | None
    is_deleted: bool
    metadata: dict[str, Any] = Field(default_factory=dict)
    current_content: str
    current_revision: RevisionOut | None = None


class RevisionList(BaseModel):
    entry_id: str
    total: int
    versions: list[RevisionOut]


class IntegrityIssue(BaseModel):
    code: str
    message: str
    version: int | None = None


class IntegrityReport(BaseModel):
    entry_id: str
    original_text_matches_hash: bool
    revision_chain_valid: bool
    revisions_checked: int
    issues: list[IntegrityIssue] = Field(default_factory=list)


class DiaryReferences(BaseModel):
    entry_id: str
    is_deleted: bool
    memories: int = Field(ge=0)
    memory_sources: int = Field(ge=0)
    persons: int = Field(ge=0)
    can_permanently_delete: bool
    guidance: str = (
        "Permanent diary deletion is blocked until all referencing memories and persons "
        "are purged. Memories can be deleted via DELETE /api/v1/memories/{id}; persons via "
        "DELETE /api/v1/persons/{id}. Revoking a memory does not remove its reference."
    )
