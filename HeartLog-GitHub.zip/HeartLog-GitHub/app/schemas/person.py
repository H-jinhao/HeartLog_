"""Person schemas.

People are never auto-merged: aliases are labels attached to one source-recorded
profile, and timeline results are explicitly text matches rather than identity
resolutions.
"""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.schemas.common import ORMModel


class PersonCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    display_name: str = Field(min_length=1, max_length=200)
    aliases: list[str] = Field(default_factory=list, max_length=20)
    source_entry_id: str
    source_revision_id: str
    source_evidence: str | None = Field(default=None, max_length=500)

    @field_validator("display_name")
    @classmethod
    def _not_blank(cls, value: str) -> str:
        cleaned = value.strip()
        if not cleaned:
            raise ValueError("display_name must not be blank")
        return cleaned

    @field_validator("aliases")
    @classmethod
    def _clean_aliases(cls, values: list[str]) -> list[str]:
        cleaned: list[str] = []
        for value in values:
            item = value.strip()
            if item and item not in cleaned:
                cleaned.append(item)
        return cleaned


class PersonOut(ORMModel):
    id: str
    display_name: str
    aliases: list[str]
    source_entry_id: str
    source_revision_id: str
    source_evidence: str | None
    created_at: datetime
    updated_at: datetime


class PersonList(BaseModel):
    items: list[PersonOut]
    total: int
    limit: int
    offset: int
    has_more: bool


class PersonForgetResponse(BaseModel):
    person_id: str
    forgotten_at: datetime
    source_entry_id: str
    source_revision_id: str
    audit_event_id: str
    note: str = (
        "The person row was permanently removed. An append-only audit event remains "
        "without personal notes; earlier backups/exports are not modified."
    )


class TimelineHit(BaseModel):
    entry_id: str
    revision_id: str
    version: int
    created_at: datetime
    snippet: str
    matched_name: str
    is_current: bool


class PersonTimeline(BaseModel):
    person_id: str
    display_name: str
    names_used_for_search: list[str]
    method: str = "literal_text_match"
    note: str = (
        "This timeline finds literal mentions of the person's names. It does not prove identity "
        "for the same name across unrelated contexts and performs no automatic merging."
    )
    items: list[TimelineHit]
