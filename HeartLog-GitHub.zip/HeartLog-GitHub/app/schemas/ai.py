"""Schemas for AI-originated structured output.

The model response is parsed into these Pydantic objects *before* any database
write.  Extra keys are forbidden: the model cannot smuggle arbitrary columns or
SQL into persistence.  Evidence validation against the exact diary revision is
performed by the memory service, because these objects do not have the source
text.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from app.models.enums import MemoryType


class CandidateMemory(BaseModel):
    model_config = ConfigDict(extra="forbid")

    content: str = Field(min_length=1, max_length=4_000)
    memory_type: MemoryType
    confidence: float | None = Field(default=None, ge=0.0, le=1.0)
    evidence_text: str = Field(min_length=1, max_length=2_000)
    start_offset: int | None = Field(default=None, ge=0)
    end_offset: int | None = Field(default=None, ge=0)

    @model_validator(mode="after")
    def _validate_offsets(self) -> CandidateMemory:
        if (self.start_offset is None) != (self.end_offset is None):
            raise ValueError("start_offset and end_offset must be provided together")
        if (
            self.start_offset is not None
            and self.end_offset is not None
            and self.end_offset <= self.start_offset
        ):
            raise ValueError("end_offset must be greater than start_offset")
        return self


class ExtractionEnvelope(BaseModel):
    model_config = ConfigDict(extra="forbid")

    candidates: list[CandidateMemory] = Field(default_factory=list)
    provider: str
    model: str
    mode: Literal["ai"] = "ai"


class AssistantReply(BaseModel):
    content: str = Field(min_length=1)
    citations: list[dict[str, Any]] = Field(default_factory=list)
    mode: Literal["ai", "placeholder"] = "ai"
