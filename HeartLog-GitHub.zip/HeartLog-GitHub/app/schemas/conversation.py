"""Conversation API schemas.

Conversations are private user data.  These models are the only way conversation
content leaves the service layer; nothing here is written back into diary
entries or memories.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.schemas.common import ORMModel


class ConversationCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str | None = Field(default=None, max_length=200, description="Optional conversation title.")

    @field_validator("title")
    @classmethod
    def _blank_title_to_none(cls, value: str | None) -> str | None:
        if value is None:
            return None
        cleaned = value.strip()
        return cleaned or None


class MessageCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    content: str = Field(min_length=1, max_length=50_000)

    @field_validator("content")
    @classmethod
    def _content_not_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("content must not be empty or whitespace only")
        return value


class Citation(BaseModel):
    """A citation verified against a real stored memory/source.

    Every field is canonicalised from the database by the conversation service;
    model-supplied snippets or IDs are never trusted verbatim.
    """

    model_config = ConfigDict(extra="forbid")

    memory_id: str
    entry_id: str
    revision_id: str
    version: int | None = None
    snippet: str
    memory_type: str | None = None
    source_created_at: str | None = Field(
        default=None,
        description="Diary creation time (ISO 8601, UTC) for context when citing the past.",
    )


class MessageOut(ORMModel):
    id: str
    conversation_id: str
    role: Literal["user", "assistant", "system"]
    content: str
    mode: Literal["ai", "placeholder"]
    citations: list[Citation] = Field(default_factory=list)
    model_name: str | None = None
    created_at: datetime


class ConversationOut(ORMModel):
    id: str
    title: str | None = None
    created_at: datetime
    updated_at: datetime
    message_count: int = Field(default=0, ge=0)


class ConversationDetail(ConversationOut):
    messages: list[MessageOut] = Field(default_factory=list)


class MessageExchange(BaseModel):
    """Result of posting one user message and its (AI or placeholder) reply."""

    conversation_id: str
    user_message: MessageOut
    assistant_message: MessageOut
    mode: Literal["ai", "placeholder"]
    ai_used: bool
    citations: list[Citation] = Field(default_factory=list)
    provider: str | None = None
    model: str | None = None
    notice: str | None = Field(
        default=None,
        description="Human-readable label for placeholder mode; null when a real AI reply was used.",
    )


def citation_from_context(memory: dict[str, Any]) -> dict[str, Any]:
    """Build a canonical citation dict from one context-memory payload."""

    source = memory.get("source") or {}
    evidence = source.get("evidence") or memory.get("content") or ""
    return {
        "memory_id": str(memory["memory_id"]),
        "entry_id": str(source.get("entry_id") or ""),
        "revision_id": str(source.get("revision_id") or ""),
        "version": source.get("version"),
        "snippet": str(evidence)[:300],
        "memory_type": memory.get("memory_type"),
        "source_created_at": source.get("diary_time"),
    }
