"""Search result schemas."""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


class SearchHit(BaseModel):
    kind: Literal["diary", "memory"]
    snippet: str
    created_at: datetime
    entry_id: str
    revision_id: str
    version: int
    is_current: bool
    memory_id: str | None = None
    memory_type: str | None = None
    verification_status: str | None = None
    confidence: float | None = None


class SearchResponse(BaseModel):
    query: str
    scope: Literal["all", "diaries", "memories"]
    include_history: bool
    include_deleted_sources: bool = False
    total: int = Field(ge=0)
    limit: int = Field(ge=1)
    offset: int = Field(ge=0)
    has_more: bool
    items: list[SearchHit]
