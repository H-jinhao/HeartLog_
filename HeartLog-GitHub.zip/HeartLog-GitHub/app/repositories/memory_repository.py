"""Persistence queries for memories, evidence sources and audit events.

The repository owns SQLAlchemy queries only.  Transactions, evidence
validation and state transitions live in :mod:`app.services.memory_service`.

Design notes
------------
* Diary lookups always go through :class:`~app.models.diary.DiaryRevision`
  rows; the service must validate evidence against the immutable revision text.
* Memory reads eagerly load ``sources`` and ``source_revision`` so API
  serialisation never triggers lazy I/O after the request session is closed.
* ``AuditEvent`` helpers live here (instead of a separate module) because the
  memory workstream may only create ``memory_repository.py``; they are append
  only and never updated or deleted.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session, joinedload, selectinload

from app.models.audit import AuditEvent
from app.models.diary import DiaryEntry, DiaryRevision
from app.models.memory import Memory, MemorySource


@dataclass(frozen=True)
class MemoryListFilters:
    """Resolved filters for a memory listing query.

    ``exclude_statuses`` lets the service express the default "active only"
    view without duplicating the revoked/superseded status knowledge in the
    repository.
    """

    memory_type: str | None = None
    verification_status: str | None = None
    entry_id: str | None = None
    entry_ids: tuple[str, ...] | None = None
    is_active: bool | None = None
    exclude_statuses: tuple[str, ...] = ()
    include_deleted_sources: bool = False


class MemoryRepository:
    """Query/mutation gateway for memory rows."""

    def __init__(self, session: Session) -> None:
        self.session = session

    # ------------------------------------------------------------------
    # Diary source lookups
    # ------------------------------------------------------------------
    def get_entry(self, entry_id: str) -> DiaryEntry | None:
        return self.session.get(DiaryEntry, entry_id)

    def get_revision(self, revision_id: str) -> DiaryRevision | None:
        return self.session.get(DiaryRevision, revision_id)

    def get_revision_by_version(self, entry_id: str, version: int) -> DiaryRevision | None:
        return self.session.scalar(
            select(DiaryRevision).where(
                DiaryRevision.entry_id == entry_id,
                DiaryRevision.version == version,
            )
        )

    def get_revisions(self, revision_ids: list[str]) -> dict[str, DiaryRevision]:
        if not revision_ids:
            return {}
        rows = self.session.scalars(select(DiaryRevision).where(DiaryRevision.id.in_(revision_ids))).all()
        return {revision.id: revision for revision in rows}

    # ------------------------------------------------------------------
    # Memory reads
    # ------------------------------------------------------------------
    def get(self, memory_id: str) -> Memory | None:
        return self.session.scalar(
            select(Memory)
            .options(
                selectinload(Memory.sources),
                joinedload(Memory.source_revision),
                joinedload(Memory.source_entry),
            )
            .where(Memory.id == memory_id)
        )

    def list(
        self,
        filters: MemoryListFilters,
        *,
        limit: int,
        offset: int,
    ) -> tuple[list[Memory], int]:
        conditions = []
        if filters.memory_type is not None:
            conditions.append(Memory.memory_type == filters.memory_type)
        if filters.verification_status is not None:
            conditions.append(Memory.verification_status == filters.verification_status)
        if filters.entry_id is not None:
            conditions.append(Memory.source_entry_id == filters.entry_id)
        if filters.entry_ids is not None:
            conditions.append(Memory.source_entry_id.in_(filters.entry_ids))
        if filters.is_active is not None:
            conditions.append(Memory.is_active.is_(filters.is_active))
        if filters.exclude_statuses:
            conditions.append(Memory.verification_status.not_in(filters.exclude_statuses))
        if not filters.include_deleted_sources:
            conditions.append(DiaryEntry.deleted_at.is_(None))

        count_statement = select(func.count()).select_from(Memory)
        items_statement = (
            select(Memory)
            .options(
                selectinload(Memory.sources),
                joinedload(Memory.source_revision),
                joinedload(Memory.source_entry),
            )
            .order_by(Memory.created_at.desc(), Memory.id.desc())
            .limit(limit)
            .offset(offset)
        )
        if not filters.include_deleted_sources:
            # The source-diary filter needs the join in both the page query and
            # the count query so pagination totals stay consistent.
            count_statement = count_statement.join(DiaryEntry, DiaryEntry.id == Memory.source_entry_id)
            items_statement = items_statement.join(DiaryEntry, DiaryEntry.id == Memory.source_entry_id)
        if conditions:
            count_statement = count_statement.where(*conditions)
            items_statement = items_statement.where(*conditions)

        total = int(self.session.scalar(count_statement) or 0)
        items = list(self.session.scalars(items_statement).all())
        return items, total

    def find_duplicate(
        self,
        *,
        source_revision_id: str,
        content_hash: str,
        memory_type: str,
        exclude_memory_id: str | None = None,
    ) -> Memory | None:
        """Find a live memory for the same revision/content/type.

        The database also enforces this with a unique constraint; this lookup
        exists to reject duplicates with a friendly structured reason before
        touching the transaction (and as a recovery probe after an
        ``IntegrityError``).
        """

        statement = select(Memory).where(
            Memory.source_revision_id == source_revision_id,
            Memory.content_hash == content_hash,
            Memory.memory_type == memory_type,
        )
        if exclude_memory_id is not None:
            statement = statement.where(Memory.id != exclude_memory_id)
        return self.session.scalar(statement.limit(1))

    def get_sources_with_versions(
        self,
        memory_id: str,
    ) -> list[tuple[MemorySource, int | None]]:
        rows = self.session.execute(
            select(MemorySource, DiaryRevision.version)
            .outerjoin(DiaryRevision, DiaryRevision.id == MemorySource.revision_id)
            .where(MemorySource.memory_id == memory_id)
            .order_by(MemorySource.created_at, MemorySource.id)
        ).all()
        return [(source, version) for source, version in rows]

    def count_sources(self, memory_id: str) -> int:
        return int(
            self.session.scalar(
                select(func.count()).select_from(MemorySource).where(MemorySource.memory_id == memory_id)
            )
            or 0
        )

    # ------------------------------------------------------------------
    # Writes (flush/commit boundaries are owned by the service)
    # ------------------------------------------------------------------
    def add(self, memory: Memory) -> Memory:
        self.session.add(memory)
        return memory

    def add_source(self, source: MemorySource) -> MemorySource:
        self.session.add(source)
        return source

    def flush(self) -> None:
        self.session.flush()

    def commit(self) -> None:
        self.session.commit()

    def rollback(self) -> None:
        self.session.rollback()

    def begin_nested(self) -> Any:
        # Exposed so the service can isolate one candidate's INSERT behind a
        # SAVEPOINT and skip only that candidate on IntegrityError.
        return self.session.begin_nested()


class AuditRepository:
    """Append-only audit event writer.

    Details must stay structural (ids, versions, counts, reason codes).  Full
    diary text and raw model evidence are never stored here.
    """

    def __init__(self, session: Session) -> None:
        self.session = session

    def add(
        self,
        *,
        event_type: str,
        entity_type: str,
        entity_id: str | None,
        actor: str,
        details: dict[str, Any] | None = None,
    ) -> AuditEvent:
        event = AuditEvent(
            event_type=event_type,
            entity_type=entity_type,
            entity_id=entity_id,
            actor=actor,
            details=details or {},
        )
        self.session.add(event)
        return event
