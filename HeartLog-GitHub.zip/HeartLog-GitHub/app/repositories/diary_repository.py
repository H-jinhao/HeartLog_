"""Queries for diary entries, revisions and the integrity chain."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Select, func, or_, select
from sqlalchemy.orm import Session

from app.models.diary import DiaryEntry, DiaryRevision


def _escape_like(value: str) -> str:
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


class DiaryRepository:
    def __init__(self, session: Session) -> None:
        self.session = session

    def get_entry(self, entry_id: str, *, include_deleted: bool = False) -> DiaryEntry | None:
        stmt = select(DiaryEntry).where(DiaryEntry.id == entry_id)
        if not include_deleted:
            stmt = stmt.where(DiaryEntry.deleted_at.is_(None))
        return self.session.scalar(stmt)

    def get_revision(self, entry_id: str, version: int) -> DiaryRevision | None:
        return self.session.scalar(
            select(DiaryRevision).where(
                DiaryRevision.entry_id == entry_id,
                DiaryRevision.version == version,
            )
        )

    def get_current_revision(self, entry: DiaryEntry) -> DiaryRevision | None:
        if entry.current_revision_id:
            revision = self.session.get(DiaryRevision, entry.current_revision_id)
            if revision is not None:
                return revision
        return self.get_revision(entry.id, entry.current_version)

    def list_revisions(self, entry_id: str) -> list[DiaryRevision]:
        return list(
            self.session.scalars(
                select(DiaryRevision)
                .where(DiaryRevision.entry_id == entry_id)
                .order_by(DiaryRevision.version.asc())
            )
        )

    def _list_stmt(
        self,
        *,
        q: str | None,
        date_from: datetime | None,
        date_to: datetime | None,
        include_deleted: bool,
    ) -> Select[tuple[DiaryEntry, DiaryRevision]]:
        stmt = select(DiaryEntry, DiaryRevision).join(
            DiaryRevision, DiaryRevision.id == DiaryEntry.current_revision_id
        )
        if not include_deleted:
            stmt = stmt.where(DiaryEntry.deleted_at.is_(None))
        if date_from is not None:
            stmt = stmt.where(DiaryEntry.created_at >= date_from)
        if date_to is not None:
            stmt = stmt.where(DiaryEntry.created_at <= date_to)
        if q:
            pattern = f"%{_escape_like(q)}%"
            stmt = stmt.where(
                or_(
                    DiaryRevision.content.ilike(pattern, escape="\\"),
                    DiaryEntry.original_text.ilike(pattern, escape="\\"),
                )
            )
        return stmt

    def list_entries(
        self,
        *,
        q: str | None = None,
        date_from: datetime | None = None,
        date_to: datetime | None = None,
        include_deleted: bool = False,
        limit: int = 20,
        offset: int = 0,
    ) -> list[tuple[DiaryEntry, DiaryRevision]]:
        stmt = (
            self._list_stmt(
                q=q,
                date_from=date_from,
                date_to=date_to,
                include_deleted=include_deleted,
            )
            .order_by(DiaryEntry.created_at.desc(), DiaryEntry.id.desc())
            .limit(limit)
            .offset(offset)
        )
        return [(entry, revision) for entry, revision in self.session.execute(stmt).all()]

    def count_entries(
        self,
        *,
        q: str | None = None,
        date_from: datetime | None = None,
        date_to: datetime | None = None,
        include_deleted: bool = False,
    ) -> int:
        # Reuse the same joins/filters but count distinct entries (the join on the
        # unique current revision could otherwise duplicate if data were damaged).
        base = self._list_stmt(
            q=q,
            date_from=date_from,
            date_to=date_to,
            include_deleted=include_deleted,
        ).subquery()
        return int(self.session.scalar(select(func.count()).select_from(base)) or 0)

    def count_references(self, entry_id: str) -> dict[str, int]:
        """Count restricted references that block permanent deletion."""

        from app.models.memory import Memory, MemorySource
        from app.models.person import Person

        memory_count = int(
            self.session.scalar(
                select(func.count()).select_from(Memory).where(Memory.source_entry_id == entry_id)
            )
            or 0
        )
        source_count = int(
            self.session.scalar(
                select(func.count()).select_from(MemorySource).where(MemorySource.entry_id == entry_id)
            )
            or 0
        )
        person_count = int(
            self.session.scalar(
                select(func.count()).select_from(Person).where(Person.source_entry_id == entry_id)
            )
            or 0
        )
        return {"memories": memory_count, "memory_sources": source_count, "persons": person_count}
