"""Persistence repositories.

Repositories own SQLAlchemy queries.  Services own transactions and business
rules.  Routes stay thin and never execute SQL directly.
"""
