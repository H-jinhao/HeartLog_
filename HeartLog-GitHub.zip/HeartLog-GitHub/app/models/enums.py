"""Shared enums for the domain.

Values are stored as strings with SQLite CHECK constraints rather than native
database enums, which keeps migrations and backups portable.
"""

from __future__ import annotations

from enum import StrEnum


class MemoryType(StrEnum):
    """What kind of claim a memory contains.

    A model may only produce these candidate types.  In particular a model
    inference is never converted into an explicit fact just because the model is
    confident.
    """

    EXPLICIT_FACT = "explicit_fact"
    SUBJECTIVE_FEELING = "subjective_feeling"
    EXPLICIT_BELIEF = "explicit_belief"
    MODEL_INFERENCE = "model_inference"


class MemorySourceType(StrEnum):
    DIARY_ENTRY = "diary_entry"
    USER_CORRECTION = "user_correction"
    IMPORT = "import"


class VerificationStatus(StrEnum):
    PENDING = "pending"
    CONFIRMED = "confirmed"
    SUPERSEDED = "superseded"
    REVOKED = "revoked"


class CreatedBy(StrEnum):
    USER = "user"
    MODEL = "model"
    IMPORT = "import"


class Actor(StrEnum):
    USER = "user"
    SYSTEM = "system"
    MODEL = "model"


class ConversationRole(StrEnum):
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"


class MessageMode(StrEnum):
    AI = "ai"
    PLACEHOLDER = "placeholder"


MEMORY_TYPES = tuple(item.value for item in MemoryType)
MEMORY_SOURCE_TYPES = tuple(item.value for item in MemorySourceType)
VERIFICATION_STATUSES = tuple(item.value for item in VerificationStatus)
CREATED_BY_VALUES = tuple(item.value for item in CreatedBy)
