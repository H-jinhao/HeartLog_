"""People mentioned in the user's life.

HeartLog intentionally does **not** auto-merge people with the same name.  A
person record must point to the diary revision that introduced it.  A later,
explicit identity-resolution feature can merge records with audit history.
"""

from __future__ import annotations

from sqlalchemy import JSON, ForeignKey, Index, String, event, inspect
from sqlalchemy.ext.mutable import MutableList
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.exceptions import ProtectedRecordError
from app.db.base import Base, TimestampMixin, UUIDPrimaryKeyMixin


class Person(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "persons"
    __table_args__ = (
        Index("ix_persons_display_name", "display_name"),
        Index("ix_persons_source_entry", "source_entry_id"),
    )

    display_name: Mapped[str] = mapped_column(String(200), nullable=False)
    aliases: Mapped[list[str]] = mapped_column(
        MutableList.as_mutable(JSON),
        nullable=False,
        default=list,
    )
    source_entry_id: Mapped[str] = mapped_column(
        ForeignKey("diary_entries.id", ondelete="RESTRICT"),
        nullable=False,
    )
    source_revision_id: Mapped[str] = mapped_column(
        ForeignKey("diary_revisions.id", ondelete="RESTRICT"),
        nullable=False,
    )
    source_evidence: Mapped[str | None] = mapped_column(String(500), nullable=True)

    source_entry: Mapped[DiaryEntry] = relationship(  # noqa: F821
        foreign_keys=[source_entry_id],
    )
    source_revision: Mapped[DiaryRevision] = relationship(  # noqa: F821
        foreign_keys=[source_revision_id],
    )


@event.listens_for(Person, "before_update")
def _person_source_guard(_mapper: object, _connection: object, target: Person) -> None:
    state = inspect(target)
    for attribute in (
        "id",
        "source_entry_id",
        "source_revision_id",
        "source_evidence",
        "created_at",
    ):
        if state.attrs[attribute].history.has_changes():
            raise ProtectedRecordError(
                f"Person source field '{attribute}' is immutable",
                details={"person_id": target.id, "field": attribute},
            )
