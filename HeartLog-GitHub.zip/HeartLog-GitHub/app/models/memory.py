"""Traceable long-term memory and its immutable sources.

Design rule: a memory row always has at least one primary diary/revision source
at the database level.  Additional evidence snippets live in
:class:`MemorySource` and must exactly match the referenced revision text.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import (
    JSON,
    CheckConstraint,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    event,
    inspect,
)
from sqlalchemy.ext.mutable import MutableDict
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.exceptions import ProtectedRecordError
from app.core.hashing import sha256_text
from app.core.time import utcnow
from app.db.base import Base, TimestampMixin, UUIDPrimaryKeyMixin
from app.db.types import UTCDateTime
from app.models.enums import (
    CREATED_BY_VALUES,
    MEMORY_SOURCE_TYPES,
    MEMORY_TYPES,
    VERIFICATION_STATUSES,
)


def _in_clause(column: str, values: tuple[str, ...]) -> str:
    joined = ", ".join(f"'{value}'" for value in values)
    return f"{column} IN ({joined})"


class Memory(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "memories"
    __table_args__ = (
        CheckConstraint(_in_clause("memory_type", MEMORY_TYPES), name="ck_memories_type"),
        CheckConstraint(_in_clause("source_type", MEMORY_SOURCE_TYPES), name="ck_memories_source_type"),
        CheckConstraint(
            _in_clause("verification_status", VERIFICATION_STATUSES),
            name="ck_memories_verification_status",
        ),
        CheckConstraint(_in_clause("created_by", CREATED_BY_VALUES), name="ck_memories_created_by"),
        CheckConstraint(
            "confidence IS NULL OR (confidence >= 0 AND confidence <= 1)", name="ck_memories_confidence"
        ),
        CheckConstraint(
            "source_type <> 'diary_entry' OR (source_entry_id IS NOT NULL AND source_revision_id IS NOT NULL)",
            name="ck_memories_source_required",
        ),
        CheckConstraint(
            "verification_status <> 'revoked' OR is_active = 0",
            name="ck_memories_revoked_inactive",
        ),
        CheckConstraint(
            "verification_status <> 'superseded' OR is_active = 0",
            name="ck_memories_superseded_inactive",
        ),
        UniqueConstraint(
            "source_revision_id",
            "content_hash",
            "memory_type",
            name="uq_memories_revision_content_type",
        ),
        Index("ix_memories_type", "memory_type"),
        Index("ix_memories_status", "verification_status"),
        Index("ix_memories_active", "is_active"),
        Index("ix_memories_source_entry", "source_entry_id"),
        Index("ix_memories_source_revision", "source_revision_id"),
        Index("ix_memories_created_at", "created_at"),
    )

    content: Mapped[str] = mapped_column(Text, nullable=False)
    content_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    memory_type: Mapped[str] = mapped_column(String(32), nullable=False)
    source_type: Mapped[str] = mapped_column(String(32), nullable=False, default="diary_entry")
    source_entry_id: Mapped[str] = mapped_column(
        ForeignKey("diary_entries.id", ondelete="RESTRICT"),
        nullable=False,
    )
    source_revision_id: Mapped[str] = mapped_column(
        ForeignKey("diary_revisions.id", ondelete="RESTRICT"),
        nullable=False,
    )
    confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    verification_status: Mapped[str] = mapped_column(
        String(32),
        nullable=False,
        default="pending",
    )
    is_active: Mapped[bool] = mapped_column(default=True, nullable=False)
    created_by: Mapped[str] = mapped_column(String(16), nullable=False, default="model")
    confirmed_by: Mapped[str | None] = mapped_column(String(16), nullable=True)
    confirmed_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    revoked_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    supersedes_memory_id: Mapped[str | None] = mapped_column(
        ForeignKey("memories.id", ondelete="SET NULL"),
        nullable=True,
    )
    metadata_json: Mapped[dict] = mapped_column(
        "metadata",
        MutableDict.as_mutable(JSON),
        nullable=False,
        default=dict,
    )

    sources: Mapped[list[MemorySource]] = relationship(
        back_populates="memory",
        cascade="all, delete-orphan",
        order_by="MemorySource.created_at",
    )
    source_entry: Mapped[DiaryEntry] = relationship(foreign_keys=[source_entry_id])  # noqa: F821
    source_revision: Mapped[DiaryRevision] = relationship(foreign_keys=[source_revision_id])  # noqa: F821


class MemorySource(UUIDPrimaryKeyMixin, Base):
    __tablename__ = "memory_sources"
    __table_args__ = (
        CheckConstraint(
            "start_offset IS NULL OR start_offset >= 0",
            name="ck_memory_sources_start_offset",
        ),
        CheckConstraint(
            "end_offset IS NULL OR end_offset >= 0",
            name="ck_memory_sources_end_offset",
        ),
        CheckConstraint(
            "start_offset IS NULL OR end_offset IS NULL OR end_offset >= start_offset",
            name="ck_memory_sources_offsets_order",
        ),
        Index("ix_memory_sources_memory", "memory_id"),
        Index("ix_memory_sources_revision", "revision_id"),
    )

    memory_id: Mapped[str] = mapped_column(
        ForeignKey("memories.id", ondelete="CASCADE"),
        nullable=False,
    )
    entry_id: Mapped[str] = mapped_column(
        ForeignKey("diary_entries.id", ondelete="RESTRICT"),
        nullable=False,
    )
    revision_id: Mapped[str] = mapped_column(
        ForeignKey("diary_revisions.id", ondelete="RESTRICT"),
        nullable=False,
    )
    evidence_text: Mapped[str] = mapped_column(Text, nullable=False)
    start_offset: Mapped[int | None] = mapped_column(Integer, nullable=True)
    end_offset: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), nullable=False, default=utcnow)

    memory: Mapped[Memory] = relationship(back_populates="sources")


@event.listens_for(Memory, "before_insert")
def _memory_hash_before_insert(_mapper: object, _connection: object, target: Memory) -> None:
    target.content_hash = sha256_text(target.content)


@event.listens_for(Memory, "before_update")
def _memory_update_guard(_mapper: object, _connection: object, target: Memory) -> None:
    """Allow review-state changes, but never silent content rewrites.

    Corrections are represented by a *new* memory that supersedes the old one;
    this keeps every version auditable.
    """

    state = inspect(target)
    protected = (
        "content",
        "content_hash",
        "memory_type",
        "created_by",
        "source_type",
        "source_entry_id",
        "source_revision_id",
    )
    for attribute in protected:
        if state.attrs[attribute].history.has_changes():
            raise ProtectedRecordError(
                f"Memory field '{attribute}' is immutable; create a superseding correction instead",
                details={"field": attribute, "memory_id": target.id},
            )


@event.listens_for(MemorySource, "before_update")
def _memory_source_update_guard(_mapper: object, _connection: object, target: MemorySource) -> None:
    raise ProtectedRecordError(
        "Memory sources are immutable evidence; revoke the memory and create a corrected one instead",
        details={"source_id": target.id, "memory_id": target.memory_id},
    )


def active_memory_filter_sql() -> str:
    """SQL fragment used by raw queries / migrations for this version."""

    return "is_active = 1 AND verification_status NOT IN ('revoked', 'superseded')"


def memory_dict(memory: Memory) -> dict[str, Any]:
    return {
        "id": memory.id,
        "content": memory.content,
        "memory_type": memory.memory_type,
        "verification_status": memory.verification_status,
        "source_entry_id": memory.source_entry_id,
        "source_revision_id": memory.source_revision_id,
        "confidence": memory.confidence,
        "is_active": memory.is_active,
    }
