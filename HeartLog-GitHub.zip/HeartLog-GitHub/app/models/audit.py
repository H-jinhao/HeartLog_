"""Append-only audit trail.

Audit details are intentionally limited to structural metadata (IDs, versions,
counts, reasons).  They must never copy a complete private diary entry.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import JSON, Index, String, event
from sqlalchemy.ext.mutable import MutableDict
from sqlalchemy.orm import Mapped, mapped_column

from app.core.exceptions import ProtectedRecordError
from app.core.time import utcnow
from app.db.base import Base, UUIDPrimaryKeyMixin
from app.db.types import UTCDateTime


class AuditEvent(UUIDPrimaryKeyMixin, Base):
    __tablename__ = "audit_events"
    __table_args__ = (
        Index("ix_audit_events_entity", "entity_type", "entity_id"),
        Index("ix_audit_events_event_type", "event_type"),
        Index("ix_audit_events_created_at", "created_at"),
    )

    event_type: Mapped[str] = mapped_column(String(64), nullable=False)
    entity_type: Mapped[str] = mapped_column(String(32), nullable=False)
    entity_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    actor: Mapped[str] = mapped_column(String(16), nullable=False, default="user")
    details: Mapped[dict[str, Any]] = mapped_column(
        MutableDict.as_mutable(JSON),
        nullable=False,
        default=dict,
    )
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), nullable=False, default=utcnow)


def _forbid_change(target: AuditEvent) -> None:
    raise ProtectedRecordError(
        "Audit events are append-only and cannot be updated or deleted",
        details={"event_id": target.id},
    )


@event.listens_for(AuditEvent, "before_update")
def _audit_update_guard(_mapper: object, _connection: object, target: AuditEvent) -> None:
    _forbid_change(target)


@event.listens_for(AuditEvent, "before_delete")
def _audit_delete_guard(_mapper: object, _connection: object, target: AuditEvent) -> None:
    _forbid_change(target)
