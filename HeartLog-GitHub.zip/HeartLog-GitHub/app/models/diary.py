"""Diary entry and immutable revision models.

The original text is written exactly once.  Every edit creates a new revision;
old revisions and the original are never updated.  ORM listeners and SQLite
triggers both refuse mutations of protected fields.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    JSON,
    CheckConstraint,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    event,
    inspect,
)
from sqlalchemy.ext.mutable import MutableDict
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.exceptions import ProtectedRecordError
from app.core.hashing import sha256_text
from app.core.time import utcnow
from app.db.base import Base, TimestampMixin, UUIDPrimaryKeyMixin
from app.db.types import UTCDateTime


class DiaryEntry(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "diary_entries"
    __table_args__ = (
        CheckConstraint("current_version >= 1", name="ck_diary_entries_current_version"),
        CheckConstraint("length(original_text) > 0", name="ck_diary_entries_original_not_empty"),
        Index("ix_diary_entries_created_at", "created_at"),
        Index("ix_diary_entries_deleted_at", "deleted_at"),
    )

    original_text: Mapped[str] = mapped_column(Text, nullable=False)
    original_content_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    current_version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    # Deliberately no FK here: revisions reference the entry, and keeping the
    # pointer FK-free avoids a circular constraint while preserving insert order.
    current_revision_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    deleted_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    metadata_json: Mapped[dict] = mapped_column(
        "metadata",
        MutableDict.as_mutable(JSON),
        nullable=False,
        default=dict,
    )

    revisions: Mapped[list[DiaryRevision]] = relationship(
        back_populates="entry",
        cascade="all, delete-orphan",
        order_by="DiaryRevision.version",
    )

    @property
    def is_deleted(self) -> bool:
        return self.deleted_at is not None


class DiaryRevision(UUIDPrimaryKeyMixin, Base):
    __tablename__ = "diary_revisions"
    __table_args__ = (
        UniqueConstraint("entry_id", "version", name="uq_diary_revisions_entry_version"),
        CheckConstraint("version >= 1", name="ck_diary_revisions_version"),
        CheckConstraint("length(content) > 0", name="ck_diary_revisions_content_not_empty"),
        Index("ix_diary_revisions_entry_version", "entry_id", "version"),
        Index("ix_diary_revisions_created_at", "created_at"),
    )

    entry_id: Mapped[str] = mapped_column(
        ForeignKey("diary_entries.id", ondelete="CASCADE"),
        nullable=False,
    )
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    content_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    previous_revision_hash: Mapped[str | None] = mapped_column(String(64), nullable=True)
    change_reason: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), nullable=False, default=utcnow)

    entry: Mapped[DiaryEntry] = relationship(back_populates="revisions")


@event.listens_for(DiaryEntry, "before_insert")
def _entry_hash_before_insert(_mapper: object, _connection: object, target: DiaryEntry) -> None:
    # Always derive the hash from the exact submitted text, even if a caller
    # attempted to supply a custom hash.
    target.original_content_hash = sha256_text(target.original_text)


@event.listens_for(DiaryRevision, "before_insert")
def _revision_hash_before_insert(_mapper: object, _connection: object, target: DiaryRevision) -> None:
    target.content_hash = sha256_text(target.content)


@event.listens_for(DiaryEntry, "before_update")
def _entry_update_guard(_mapper: object, _connection: object, target: DiaryEntry) -> None:
    state = inspect(target)
    for attribute in ("id", "original_text", "original_content_hash", "created_at"):
        if state.attrs[attribute].history.has_changes():
            raise ProtectedRecordError(
                f"Diary field '{attribute}' is immutable; create a revision instead",
                details={"field": attribute},
            )
    if target.current_version < 1:
        raise ProtectedRecordError("current_version must be >= 1")


@event.listens_for(DiaryRevision, "before_update")
def _revision_update_guard(_mapper: object, _connection: object, target: DiaryRevision) -> None:
    raise ProtectedRecordError(
        "Diary revisions are immutable; append a new revision instead",
        details={"revision_id": target.id, "version": target.version},
    )


@event.listens_for(DiaryRevision, "before_delete")
def _revision_delete_guard(_mapper: object, _connection: object, target: DiaryRevision) -> None:
    # Hard deletion is only performed by the audited permanent-deletion flow,
    # which marks the session explicitly.  Ordinary code paths cannot delete a
    # revision by accident.
    session = inspect(target).session
    allow = bool(session and session.info.get("heartlog.allow_permanent_delete"))
    if not allow:
        raise ProtectedRecordError(
            "Diary revisions cannot be deleted through normal business operations",
            details={"revision_id": target.id, "version": target.version},
        )


@event.listens_for(DiaryEntry, "before_delete")
def _entry_delete_guard(_mapper: object, _connection: object, target: DiaryEntry) -> None:
    session = inspect(target).session
    allow = bool(session and session.info.get("heartlog.allow_permanent_delete"))
    if not allow:
        raise ProtectedRecordError(
            "Diary entries are soft-deleted by default; permanent deletion must use the audited admin flow",
            details={"entry_id": target.id},
        )
