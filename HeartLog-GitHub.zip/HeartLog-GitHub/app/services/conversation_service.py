"""Conversation service: storage, memory-context retrieval and reply handling.

Behaviour when AI is disabled
-----------------------------
HeartLog never pretends that a model answered.  If AI is disabled / not
configured, posting a message still succeeds (HTTP 200) but the assistant message
is stored with ``mode="placeholder"`` and ``ai_used=false``, and the reply text
is an explicitly labelled deterministic local notice.  This keeps the user's
message safe locally while being honest about the absence of AI.

Transaction boundaries
----------------------
The provider call is made **outside** any database transaction:

1. session A validates the conversation, stores the user message, and snapshots
   the relevant memory context / limited history; commit + close.
2. no database session is open while the provider is awaited.
3. session B stores the assistant message with verified citations; commit + close.

If the provider call fails, the user message is already persisted (so the user
does not lose their text) and the API returns an honest error; no assistant
message is fabricated.

Citations
---------
Model-provided citations are only trusted as *references*: an ID must exist in
the context records that were actually sent to the provider.  Unknown / invented
IDs are dropped, and the snippet and source metadata are always rebuilt from the
database, never copied from model output.
"""

from __future__ import annotations

import re
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.core.exceptions import NotFoundError
from app.core.time import utcnow
from app.models.conversation import Conversation, Message
from app.models.diary import DiaryEntry
from app.models.enums import ConversationRole, MessageMode, VerificationStatus
from app.models.memory import Memory
from app.schemas.ai import AssistantReply
from app.schemas.conversation import citation_from_context
from app.services.ai_service import AIService

#: How many memories are sent to the provider as context.
MAX_CONTEXT_MEMORIES = 8
#: How many recent messages are sent as conversation history.
MAX_HISTORY_MESSAGES = 20
#: How many recent memories are scanned for relevance before ranking.
_MEMORY_SCAN_LIMIT = 200
#: Hard cap on citations returned per reply (defensive bound).
MAX_CITATIONS = 20

PLACEHOLDER_NOTICE = (
    "【占位模式 / placeholder mode】AI 对话未启用或未配置，本条回复不是由 AI 生成的，"
    "也没有任何内容离开本机。你的消息已安全保存在本地。若希望获得 AI 回复，请先阅读隐私说明，"
    "然后设置 HEARTLOG_AI_ENABLED=true、HEARTLOG_AI_CONSENT=true 并配置提供方。"
    "（This is a deterministic local placeholder. No model was called and no data left this device.）"
)

PLACEHOLDER_HINT = "AI disabled or not configured; a labelled local placeholder reply was stored."

_INACTIVE_STATUSES = (
    VerificationStatus.REVOKED.value,
    VerificationStatus.SUPERSEDED.value,
)

_ASCII_WORD_RE = re.compile(r"[a-z0-9]+")


# ---------------------------------------------------------------------------
# Conversation / message storage
# ---------------------------------------------------------------------------


def create_conversation(session: Session, title: str | None = None) -> Conversation:
    conversation = Conversation(title=title)
    session.add(conversation)
    session.commit()
    session.refresh(conversation)
    return conversation


def get_conversation(session: Session, conversation_id: str) -> Conversation:
    conversation = session.get(Conversation, conversation_id)
    if conversation is None:
        raise NotFoundError(
            "Conversation not found",
            details={"conversation_id": conversation_id},
        )
    return conversation


def list_messages(session: Session, conversation_id: str) -> list[Message]:
    get_conversation(session, conversation_id)
    statement = (
        select(Message)
        .where(Message.conversation_id == conversation_id)
        .order_by(Message.created_at, Message.id)
    )
    return list(session.execute(statement).scalars().all())


def load_history(
    session: Session,
    conversation_id: str,
    *,
    limit: int = MAX_HISTORY_MESSAGES,
) -> list[dict[str, str]]:
    """Return the most recent user/assistant messages in chronological order."""

    statement = (
        select(Message)
        .where(
            Message.conversation_id == conversation_id,
            Message.role.in_((ConversationRole.USER.value, ConversationRole.ASSISTANT.value)),
        )
        .order_by(Message.created_at.desc(), Message.id.desc())
        .limit(limit)
    )
    rows = list(session.execute(statement).scalars().all())
    rows.reverse()
    return [{"role": message.role, "content": message.content} for message in rows]


# ---------------------------------------------------------------------------
# Memory context retrieval (active, non-revoked, relevant)
# ---------------------------------------------------------------------------


def _tokens(text: str) -> set[str]:
    """Cheap language-agnostic token set (ASCII words + character bigrams)."""

    lowered = text.lower()
    tokens = set(_ASCII_WORD_RE.findall(lowered))
    dense = re.sub(r"\s+", "", lowered)
    if len(dense) >= 2:
        tokens.update(dense[index : index + 2] for index in range(len(dense) - 1))
    elif dense:
        tokens.add(dense)
    return tokens


def _memory_context_payload(memory: Memory) -> dict[str, Any]:
    revision = memory.source_revision
    entry = memory.source_entry
    evidence = memory.sources[0].evidence_text if memory.sources else memory.content
    return {
        "memory_id": memory.id,
        "content": memory.content,
        "memory_type": memory.memory_type,
        "verification_status": memory.verification_status,
        "confidence": memory.confidence,
        "source": {
            "entry_id": memory.source_entry_id,
            "revision_id": memory.source_revision_id,
            "version": revision.version if revision is not None else None,
            "diary_time": entry.created_at.isoformat() if entry is not None else None,
            "evidence": evidence,
        },
    }


def select_context_memories(
    session: Session,
    user_message: str,
    *,
    limit: int = MAX_CONTEXT_MEMORIES,
) -> list[dict[str, Any]]:
    """Retrieve active, non-revoked memories relevant to *user_message*.

    Relevance is a deterministic local token overlap; no external service is
    consulted.  Only memories whose source diary entry is not deleted are used.
    When nothing relevant exists, an empty list is returned (the prompt forbids
    the model from pretending it remembers something).
    """

    statement = (
        select(Memory)
        .join(DiaryEntry, Memory.source_entry_id == DiaryEntry.id)
        .where(
            Memory.is_active.is_(True),
            Memory.verification_status.not_in(_INACTIVE_STATUSES),
            DiaryEntry.deleted_at.is_(None),
        )
        .options(
            selectinload(Memory.source_revision),
            selectinload(Memory.source_entry),
            selectinload(Memory.sources),
        )
        .order_by(Memory.created_at.desc(), Memory.id.desc())
        .limit(_MEMORY_SCAN_LIMIT)
    )
    memories = list(session.execute(statement).scalars().all())
    query_tokens = _tokens(user_message)
    if not query_tokens:
        return []

    scored: list[tuple[int, int, Memory]] = []
    for index, memory in enumerate(memories):
        overlap = query_tokens & _tokens(memory.content)
        if overlap:
            scored.append((len(overlap), -index, memory))
    scored.sort(key=lambda item: (item[0], item[1]), reverse=True)
    return [_memory_context_payload(memory) for _, _, memory in scored[:limit]]


# ---------------------------------------------------------------------------
# Citations and placeholder reply
# ---------------------------------------------------------------------------


def validate_citations(
    raw_citations: list[dict[str, Any]],
    context_memories: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Strictly validate model citations against the context actually sent.

    * an unknown / fabricated ``memory_id`` is dropped;
    * duplicate citations are collapsed;
    * entry/revision/version/snippet/time are always rebuilt from the database
      payload, never taken from model output.
    """

    allowed = {str(item["memory_id"]): item for item in context_memories if item.get("memory_id")}
    validated: list[dict[str, Any]] = []
    seen: set[str] = set()
    for raw in raw_citations:
        if not isinstance(raw, dict):
            continue
        memory_id = raw.get("memory_id")
        if not isinstance(memory_id, str) or memory_id not in allowed or memory_id in seen:
            continue
        seen.add(memory_id)
        validated.append(citation_from_context(allowed[memory_id]))
        if len(validated) >= MAX_CITATIONS:
            break
    return validated


def build_placeholder_reply() -> AssistantReply:
    return AssistantReply(
        content=PLACEHOLDER_NOTICE,
        citations=[],
        mode=MessageMode.PLACEHOLDER.value,
    )


# ---------------------------------------------------------------------------
# Message exchange orchestration
# ---------------------------------------------------------------------------


async def send_message(
    *,
    ai_service: AIService,
    session_factory: Any,
    conversation_id: str,
    content: str,
) -> dict[str, Any]:
    """Store a user message and produce/store an assistant reply.

    Returns a plain dict consumed by the route; ORM objects are fully loaded and
    detached when returned.
    """

    ai_available = ai_service.configured
    intended_mode = MessageMode.AI.value if ai_available else MessageMode.PLACEHOLDER.value

    # Phase 1: validate + persist the user message, snapshot context. No network
    # request is in flight while this session is open.
    with session_factory() as session:
        conversation = get_conversation(session, conversation_id)
        history = load_history(session, conversation_id)
        context_memories = select_context_memories(session, content) if ai_available else []
        user_message = Message(
            conversation_id=conversation.id,
            role=ConversationRole.USER.value,
            content=content,
            mode=intended_mode,
            citations=[],
            model_name=None,
        )
        session.add(user_message)
        conversation.updated_at = utcnow()
        session.commit()
        session.refresh(user_message)

    # Phase 2: provider call with no database transaction open.
    if ai_available:
        reply = await ai_service.companion_reply(
            user_message=content,
            context_memories=context_memories,
            history=history,
        )
        mode = MessageMode.AI.value
        citations = validate_citations(reply.citations, context_memories)
        provider_name: str | None = ai_service.provider_name
        model_name: str | None = ai_service.model_name
        notice = None
    else:
        reply = build_placeholder_reply()
        mode = MessageMode.PLACEHOLDER.value
        citations = []
        provider_name = None
        model_name = None
        notice = PLACEHOLDER_HINT

    # Phase 3: separate DB transaction for the assistant message.
    with session_factory() as session:
        conversation = get_conversation(session, conversation_id)
        assistant_message = Message(
            conversation_id=conversation.id,
            role=ConversationRole.ASSISTANT.value,
            content=reply.content,
            mode=mode,
            citations=citations,
            model_name=model_name,
        )
        session.add(assistant_message)
        conversation.updated_at = utcnow()
        session.commit()
        session.refresh(assistant_message)

    return {
        "conversation_id": conversation_id,
        "user_message": user_message,
        "assistant_message": assistant_message,
        "mode": mode,
        "ai_used": mode == MessageMode.AI.value,
        "citations": citations,
        "provider": provider_name,
        "model": model_name,
        "notice": notice,
    }
