"""Diary business rules: immutable originals, append-only revisions, audit."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy.exc import IntegrityError, OperationalError
from sqlalchemy.orm import Session

from app.core.config import Settings
from app.core.exceptions import ConflictError, NotFoundError, ValidationError
from app.core.hashing import sha256_text
from app.core.text import has_forbidden_control_chars
from app.core.time import ensure_utc, utcnow
from app.models.audit import AuditEvent
from app.models.diary import DiaryEntry, DiaryRevision
from app.repositories.diary_repository import DiaryRepository
from app.schemas.common import Page
from app.schemas.diary import (
    DiaryDetail,
    DiaryListItem,
    DiaryReferences,
    IntegrityIssue,
    IntegrityReport,
    RevisionOut,
)


class DiaryService:
    def __init__(self, session: Session, settings: Settings) -> None:
        self.session = session
        self.settings = settings
        self.repo = DiaryRepository(session)

    # ------------------------------------------------------------------ helpers
    def _audit(self, event_type: str, entity_id: str, details: dict[str, Any] | None = None) -> None:
        self.session.add(
            AuditEvent(
                event_type=event_type,
                entity_type="diary_entry",
                entity_id=entity_id,
                actor="user",
                details=details or {},
            )
        )

    def _validate_content(self, content: str) -> None:
        if not content.strip():
            raise ValidationError("content must not be empty or whitespace only")
        if has_forbidden_control_chars(content):
            raise ValidationError(
                "content must not contain NUL or unsupported control characters",
                code="invalid_content",
            )
        if len(content) > self.settings.max_diary_chars:
            raise ValidationError(
                "content exceeds the configured maximum length",
                details={
                    "length": len(content),
                    "max_length": self.settings.max_diary_chars,
                },
            )

    def _commit(self) -> None:
        try:
            self.session.commit()
        except Exception:
            self.session.rollback()
            raise

    @staticmethod
    def _revision_out(revision: DiaryRevision) -> RevisionOut:
        return RevisionOut.model_validate(revision)

    def _detail(self, entry: DiaryEntry) -> DiaryDetail:
        revision = self.repo.get_current_revision(entry)
        if revision is None:
            raise NotFoundError("Diary revision data is missing", code="revision_missing")
        payload = {
            "id": entry.id,
            "original_text": entry.original_text,
            "original_content_hash": entry.original_content_hash,
            "current_version": entry.current_version,
            "current_revision_id": entry.current_revision_id,
            "created_at": entry.created_at,
            "updated_at": entry.updated_at,
            "deleted_at": entry.deleted_at,
            "is_deleted": entry.is_deleted,
            "metadata": entry.metadata_json,
            "current_content": revision.content,
            "current_revision": self._revision_out(revision),
        }
        return DiaryDetail.model_validate(payload)

    @staticmethod
    def _list_item(entry: DiaryEntry, revision: DiaryRevision) -> DiaryListItem:
        return DiaryListItem.model_validate(
            {
                "id": entry.id,
                "preview": revision.content,
                "original_preview": entry.original_text,
                "current_version": entry.current_version,
                "created_at": entry.created_at,
                "updated_at": entry.updated_at,
                "deleted_at": entry.deleted_at,
                "is_deleted": entry.is_deleted,
                "metadata": entry.metadata_json,
            }
        )

    # --------------------------------------------------------------- commands
    def create(self, *, content: str, metadata: dict[str, Any] | None = None) -> DiaryDetail:
        self._validate_content(content)
        entry = DiaryEntry(
            original_text=content,
            original_content_hash=sha256_text(content),
            current_version=1,
            metadata_json=metadata or {},
        )
        self.session.add(entry)
        try:
            self.session.flush()
            revision = DiaryRevision(
                entry_id=entry.id,
                version=1,
                content=content,
                content_hash=sha256_text(content),
                previous_revision_hash=None,
                change_reason="Initial version",
            )
            self.session.add(revision)
            self.session.flush()
            entry.current_revision_id = revision.id
            self._audit("diary.created", entry.id, {"version": 1})
            self._commit()
        except Exception:
            self.session.rollback()
            raise
        # Relationships remain loaded with expire_on_commit=False.
        return self._detail(entry)

    def list(
        self,
        *,
        q: str | None,
        date_from: datetime | None,
        date_to: datetime | None,
        limit: int | None,
        offset: int,
    ) -> Page[DiaryListItem]:
        if date_from is not None:
            date_from = ensure_utc(date_from)
        if date_to is not None:
            date_to = ensure_utc(date_to)
        if date_from and date_to and date_from > date_to:
            raise ValidationError("date_from must not be after date_to")
        effective_limit = min(limit or self.settings.default_page_size, self.settings.max_page_size)
        rows = self.repo.list_entries(
            q=q,
            date_from=date_from,
            date_to=date_to,
            include_deleted=False,
            limit=effective_limit,
            offset=offset,
        )
        total = self.repo.count_entries(
            q=q,
            date_from=date_from,
            date_to=date_to,
            include_deleted=False,
        )
        items = [self._list_item(entry, revision) for entry, revision in rows]
        return Page[DiaryListItem](
            items=items,
            total=total,
            limit=effective_limit,
            offset=offset,
            has_more=offset + len(items) < total,
        )

    def get(self, entry_id: str) -> DiaryDetail:
        entry = self.repo.get_entry(entry_id)
        if entry is None:
            raise NotFoundError("Diary entry not found", details={"entry_id": entry_id})
        return self._detail(entry)

    def update(
        self,
        entry_id: str,
        *,
        content: str,
        expected_version: int | None,
        change_reason: str | None,
    ) -> DiaryDetail:
        self._validate_content(content)
        entry = self.repo.get_entry(entry_id)
        if entry is None:
            raise NotFoundError("Diary entry not found", details={"entry_id": entry_id})
        if expected_version is not None and expected_version != entry.current_version:
            raise ConflictError(
                "The diary entry has changed since it was loaded; re-read and retry",
                code="version_conflict",
                details={
                    "expected_version": expected_version,
                    "current_version": entry.current_version,
                },
            )
        previous = self.repo.get_current_revision(entry)
        if previous is None:
            raise NotFoundError("Diary revision data is missing", code="revision_missing")
        new_version = entry.current_version + 1
        revision = DiaryRevision(
            entry_id=entry.id,
            version=new_version,
            content=content,
            content_hash=sha256_text(content),
            previous_revision_hash=previous.content_hash,
            change_reason=change_reason,
        )
        self.session.add(revision)
        try:
            self.session.flush()
            entry.current_version = new_version
            entry.current_revision_id = revision.id
            entry.updated_at = utcnow()
            self._audit(
                "diary.revision_created",
                entry.id,
                {
                    "from_version": previous.version,
                    "to_version": new_version,
                    "has_change_reason": bool(change_reason),
                },
            )
            self._commit()
        except IntegrityError:
            self.session.rollback()
            current = self.repo.get_entry(entry_id)
            raise ConflictError(
                "Another revision was created concurrently; re-read and retry",
                code="version_conflict",
                details={"current_version": current.current_version if current else None},
            ) from None
        except OperationalError as exc:
            self.session.rollback()
            message = str(exc).lower()
            if "locked" in message or "busy" in message:
                # SQLite raises SQLITE_BUSY / SQLITE_BUSY_SNAPSHOT when a stale
                # read transaction cannot be upgraded after another writer
                # committed.  This is a concurrency conflict, not a server bug.
                current = self.repo.get_entry(entry_id)
                raise ConflictError(
                    "The diary entry was edited concurrently; re-read and retry",
                    code="version_conflict",
                    details={"current_version": current.current_version if current else None},
                ) from None
            raise
        except Exception:
            self.session.rollback()
            raise
        return self._detail(entry)

    def revisions(self, entry_id: str) -> tuple[str, list[RevisionOut]]:
        entry = self.repo.get_entry(entry_id)
        if entry is None:
            raise NotFoundError("Diary entry not found", details={"entry_id": entry_id})
        revisions = self.repo.list_revisions(entry.id)
        return entry.id, [self._revision_out(revision) for revision in revisions]

    def revision(self, entry_id: str, version: int) -> RevisionOut:
        entry = self.repo.get_entry(entry_id)
        if entry is None:
            raise NotFoundError("Diary entry not found", details={"entry_id": entry_id})
        revision = self.repo.get_revision(entry.id, version)
        if revision is None:
            raise NotFoundError(
                "Diary revision not found",
                details={"entry_id": entry_id, "version": version},
            )
        return self._revision_out(revision)

    def soft_delete(self, entry_id: str) -> DiaryEntry:
        entry = self.repo.get_entry(entry_id)
        if entry is None:
            raise NotFoundError("Diary entry not found", details={"entry_id": entry_id})
        entry.deleted_at = utcnow()
        self._audit("diary.soft_deleted", entry.id, {"current_version": entry.current_version})
        self._commit()
        return entry

    def restore(self, entry_id: str) -> DiaryDetail:
        entry = self.repo.get_entry(entry_id, include_deleted=True)
        if entry is None:
            raise NotFoundError("Diary entry not found", details={"entry_id": entry_id})
        if entry.deleted_at is None:
            raise ConflictError("Diary entry is not deleted", code="not_deleted")
        entry.deleted_at = None
        self._audit("diary.restored", entry.id, {"current_version": entry.current_version})
        self._commit()
        return self._detail(entry)

    def references(self, entry_id: str) -> DiaryReferences:
        """Expose the reference counts that block permanent deletion."""

        entry = self.repo.get_entry(entry_id, include_deleted=True)
        if entry is None:
            raise NotFoundError("Diary entry not found", details={"entry_id": entry_id})
        refs = self.repo.count_references(entry.id)
        return DiaryReferences(
            entry_id=entry.id,
            is_deleted=entry.is_deleted,
            memories=refs["memories"],
            memory_sources=refs["memory_sources"],
            persons=refs["persons"],
            can_permanently_delete=not any(refs.values()),
        )

    def permanent_delete(self, entry_id: str) -> None:
        entry = self.repo.get_entry(entry_id, include_deleted=True)
        if entry is None:
            raise NotFoundError("Diary entry not found", details={"entry_id": entry_id})
        refs = self.repo.count_references(entry.id)
        if any(refs.values()):
            raise ConflictError(
                "This diary is referenced by memories or people and cannot be permanently deleted. "
                "Purge/anonymize the referencing memories and purge persons first via the forget "
                "endpoints, or keep the diary soft-deleted. Revoking a memory does not remove its "
                "source reference.",
                code="entry_has_references",
                details=refs,
            )
        self._audit("diary.permanently_deleted", entry.id, {"current_version": entry.current_version})
        try:
            self.session.flush()
            self.session.info["heartlog.allow_permanent_delete"] = True
            self.session.delete(entry)  # cascades to revisions through the relationship
            self.session.commit()
        except Exception:
            self.session.rollback()
            raise
        finally:
            self.session.info.pop("heartlog.allow_permanent_delete", None)

    def integrity(self, entry_id: str, *, include_deleted: bool = False) -> IntegrityReport:
        entry = self.repo.get_entry(entry_id, include_deleted=include_deleted)
        if entry is None:
            raise NotFoundError("Diary entry not found", details={"entry_id": entry_id})
        issues: list[IntegrityIssue] = []
        original_ok = sha256_text(entry.original_text) == entry.original_content_hash
        if not original_ok:
            issues.append(
                IntegrityIssue(
                    code="original_hash_mismatch",
                    message="Stored original text does not match its recorded hash",
                )
            )
        revisions = self.repo.list_revisions(entry.id)
        expected_previous: str | None = None
        chain_ok = True
        for expected_version, revision in enumerate(revisions, start=1):
            if revision.version != expected_version:
                chain_ok = False
                issues.append(
                    IntegrityIssue(
                        code="version_sequence_gap",
                        message="Revision versions are not contiguous",
                        version=revision.version,
                    )
                )
            if sha256_text(revision.content) != revision.content_hash:
                chain_ok = False
                issues.append(
                    IntegrityIssue(
                        code="revision_hash_mismatch",
                        message="Revision content does not match its recorded hash",
                        version=revision.version,
                    )
                )
            if revision.previous_revision_hash != expected_previous:
                chain_ok = False
                issues.append(
                    IntegrityIssue(
                        code="revision_chain_mismatch",
                        message="Revision does not link to the previous revision hash",
                        version=revision.version,
                    )
                )
            expected_previous = revision.content_hash
        if len(revisions) != entry.current_version:
            chain_ok = False
            issues.append(
                IntegrityIssue(
                    code="revision_count_mismatch",
                    message="Revision count does not match current_version",
                    version=entry.current_version,
                )
            )
        if entry.current_revision_id != (revisions[-1].id if revisions else None):
            chain_ok = False
            issues.append(
                IntegrityIssue(
                    code="current_pointer_mismatch",
                    message="current_revision_id does not point at the latest revision",
                    version=entry.current_version,
                )
            )
        return IntegrityReport(
            entry_id=entry.id,
            original_text_matches_hash=original_ok,
            revision_chain_valid=chain_ok,
            revisions_checked=len(revisions),
            issues=issues,
        )
