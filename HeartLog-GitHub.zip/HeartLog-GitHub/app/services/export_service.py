"""Full user-data export.

An export contains the original diary text and every revision on purpose: it is
the user's data.  It never contains configuration, tokens, API keys or provider
credentials.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app import __version__
from app.core.exceptions import AppError
from app.core.time import utcnow
from app.models.audit import AuditEvent
from app.models.conversation import Conversation, Message
from app.models.diary import DiaryEntry, DiaryRevision
from app.models.memory import Memory, MemorySource
from app.models.person import Person


def _iso(value: datetime | None) -> str | None:
    return value.isoformat().replace("+00:00", "Z") if value is not None else None


def build_export(session: Session) -> dict[str, Any]:
    """Build the complete export payload without mutating user records."""

    diaries: list[dict[str, Any]] = []
    entries = list(session.scalars(select(DiaryEntry).order_by(DiaryEntry.created_at.asc())))
    for entry in entries:
        revisions = list(
            session.scalars(
                select(DiaryRevision)
                .where(DiaryRevision.entry_id == entry.id)
                .order_by(DiaryRevision.version.asc())
            )
        )
        diaries.append(
            {
                "id": entry.id,
                "original_text": entry.original_text,
                "original_content_hash": entry.original_content_hash,
                "current_version": entry.current_version,
                "current_revision_id": entry.current_revision_id,
                "metadata": entry.metadata_json,
                "created_at": _iso(entry.created_at),
                "updated_at": _iso(entry.updated_at),
                "deleted_at": _iso(entry.deleted_at),
                "revisions": [
                    {
                        "id": revision.id,
                        "version": revision.version,
                        "content": revision.content,
                        "content_hash": revision.content_hash,
                        "previous_revision_hash": revision.previous_revision_hash,
                        "change_reason": revision.change_reason,
                        "created_at": _iso(revision.created_at),
                    }
                    for revision in revisions
                ],
            }
        )

    memories: list[dict[str, Any]] = []
    for memory in session.scalars(select(Memory).order_by(Memory.created_at.asc())):
        sources = list(
            session.scalars(
                select(MemorySource)
                .where(MemorySource.memory_id == memory.id)
                .order_by(MemorySource.created_at.asc())
            )
        )
        memories.append(
            {
                "id": memory.id,
                "content": memory.content,
                "content_hash": memory.content_hash,
                "memory_type": memory.memory_type,
                "source_type": memory.source_type,
                "source_entry_id": memory.source_entry_id,
                "source_revision_id": memory.source_revision_id,
                "confidence": memory.confidence,
                "verification_status": memory.verification_status,
                "is_active": memory.is_active,
                "created_by": memory.created_by,
                "confirmed_by": memory.confirmed_by,
                "confirmed_at": _iso(memory.confirmed_at),
                "revoked_at": _iso(memory.revoked_at),
                "supersedes_memory_id": memory.supersedes_memory_id,
                "metadata": memory.metadata_json,
                "created_at": _iso(memory.created_at),
                "updated_at": _iso(memory.updated_at),
                "sources": [
                    {
                        "id": source.id,
                        "entry_id": source.entry_id,
                        "revision_id": source.revision_id,
                        "evidence_text": source.evidence_text,
                        "start_offset": source.start_offset,
                        "end_offset": source.end_offset,
                        "created_at": _iso(source.created_at),
                    }
                    for source in sources
                ],
            }
        )

    persons = [
        {
            "id": person.id,
            "display_name": person.display_name,
            "aliases": list(person.aliases),
            "source_entry_id": person.source_entry_id,
            "source_revision_id": person.source_revision_id,
            "source_evidence": person.source_evidence,
            "created_at": _iso(person.created_at),
            "updated_at": _iso(person.updated_at),
        }
        for person in session.scalars(select(Person).order_by(Person.created_at.asc()))
    ]

    conversations: list[dict[str, Any]] = []
    for conversation in session.scalars(select(Conversation).order_by(Conversation.created_at.asc())):
        messages = list(
            session.scalars(
                select(Message)
                .where(Message.conversation_id == conversation.id)
                .order_by(Message.created_at.asc())
            )
        )
        conversations.append(
            {
                "id": conversation.id,
                "title": conversation.title,
                "created_at": _iso(conversation.created_at),
                "updated_at": _iso(conversation.updated_at),
                "messages": [
                    {
                        "id": message.id,
                        "role": message.role,
                        "content": message.content,
                        "mode": message.mode,
                        "citations": list(message.citations),
                        "model_name": message.model_name,
                        "created_at": _iso(message.created_at),
                    }
                    for message in messages
                ],
            }
        )

    audit_events = [
        {
            "id": event.id,
            "event_type": event.event_type,
            "entity_type": event.entity_type,
            "entity_id": event.entity_id,
            "actor": event.actor,
            "details": dict(event.details),
            "created_at": _iso(event.created_at),
        }
        for event in session.scalars(select(AuditEvent).order_by(AuditEvent.created_at.asc()))
    ]

    exported_at = utcnow()
    return {
        "schema_version": "heartlog.export.v1",
        "app_version": __version__,
        "exported_at": _iso(exported_at),
        "note": (
            "This archive contains private diary data. Store and transfer it securely. "
            "The original_text field is immutable in HeartLog; revisions are listed separately."
        ),
        "counts": {
            "diaries": len(diaries),
            "revisions": sum(len(diary["revisions"]) for diary in diaries),
            "memories": len(memories),
            "memory_sources": sum(len(memory["sources"]) for memory in memories),
            "persons": len(persons),
            "conversations": len(conversations),
            "audit_events": len(audit_events),
        },
        "diaries": diaries,
        "memories": memories,
        "persons": persons,
        "conversations": conversations,
        "audit_events": audit_events,
    }


def export_and_audit(session: Session) -> dict[str, Any]:
    payload = build_export(session)
    session.add(
        AuditEvent(
            event_type="data.exported",
            entity_type="system",
            entity_id=None,
            actor="user",
            details={"counts": payload["counts"], "format": "json"},
        )
    )
    try:
        session.commit()
    except Exception as exc:
        session.rollback()
        raise AppError("Could not record export audit event", code="export_failed", status_code=500) from exc
    return payload
