"""AI provider adapters.

Only ``httpx`` is required; no vendor SDK.  Providers are deliberately thin and
stateless: one Chat Completions request per call, returning the raw assistant
text.  Parsing, schema validation and prompt-injection defences live in
:mod:`app.services.ai_service`; this module only handles transport-level
concerns and maps transport failures to :class:`~app.core.exceptions.AIServiceError`.

Nothing in this module logs prompts, API keys or diary text.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any, Literal

import httpx

from app.core.config import Settings
from app.core.exceptions import AIConfigurationError, AIResponseError, AIServiceError

if TYPE_CHECKING:  # pragma: no cover - typing only, avoids a circular import
    from app.services.ai_service import AIProvider

logger = logging.getLogger(__name__)

Purpose = Literal["extraction", "companion", "insight"]

#: A hard cap on the raw provider body we are willing to load into memory.
_MAX_PROVIDER_BODY_BYTES = 4_000_000

#: Low temperature for deterministic extraction / review, warmer for chat.
_TEMPERATURES: dict[str, float] = {
    "extraction": 0.0,
    "companion": 0.7,
    "insight": 0.3,
}


class OpenAICompatibleProvider:
    """Minimal OpenAI-compatible ``/chat/completions`` client.

    The adapter is constructed from :class:`app.core.config.Settings`; it only
    becomes usable when ``ai_configured`` is true (which requires explicit
    enablement + consent in settings).  Tests inject a custom
    ``httpx.AsyncBaseTransport`` (e.g. ``httpx.MockTransport``) so no socket is
    ever opened.
    """

    name = "openai_compatible"

    def __init__(
        self,
        settings: Settings,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.settings = settings
        self.model = settings.ai_model
        self._transport = transport

    async def complete(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        purpose: Purpose,
        json_mode: bool = False,
    ) -> str:
        base_url = self.settings.ai_base_url.strip().rstrip("/")
        api_key = self.settings.ai_api_key
        if not base_url or not self.model or api_key is None:
            raise AIConfigurationError(
                "The OpenAI-compatible provider is not fully configured. Set "
                "HEARTLOG_AI_BASE_URL, HEARTLOG_AI_MODEL and HEARTLOG_AI_API_KEY."
            )

        payload: dict[str, Any] = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": _TEMPERATURES.get(purpose, 0.3),
            "max_tokens": self.settings.ai_max_output_tokens,
            "stream": False,
        }
        if json_mode:
            # Best-effort structured output; the prompt also demands strict JSON
            # so servers that ignore ``response_format`` still work.
            payload["response_format"] = {"type": "json_object"}

        headers = {
            "Authorization": f"Bearer {api_key.get_secret_value()}",
            "Accept": "application/json",
        }
        url = f"{base_url}/chat/completions"
        logger.debug("ai_request provider=%s purpose=%s", self.name, purpose)

        try:
            async with httpx.AsyncClient(
                timeout=httpx.Timeout(self.settings.ai_timeout_seconds),
                transport=self._transport,
            ) as client:
                response = await client.post(url, json=payload, headers=headers)
        except httpx.TimeoutException as exc:
            logger.warning("ai_timeout provider=%s purpose=%s", self.name, purpose)
            raise AIServiceError(
                "The AI provider request timed out",
                details={"purpose": purpose},
            ) from exc
        except httpx.HTTPError as exc:
            # Deliberately no request body / URL details: they can contain data.
            logger.warning("ai_transport_error provider=%s purpose=%s", self.name, purpose)
            raise AIServiceError(
                "The AI provider request failed",
                details={"purpose": purpose},
            ) from exc

        if response.status_code >= 400:
            logger.warning(
                "ai_http_error provider=%s purpose=%s status=%s",
                self.name,
                purpose,
                response.status_code,
            )
            raise AIServiceError(
                f"The AI provider returned HTTP {response.status_code}",
                details={"purpose": purpose, "status_code": response.status_code},
            )

        if len(response.content) > _MAX_PROVIDER_BODY_BYTES:
            raise AIResponseError(
                "The AI provider response was too large to process",
                details={"purpose": purpose},
            )

        try:
            data = response.json()
        except ValueError as exc:
            raise AIResponseError(
                "The AI provider returned a non-JSON HTTP body",
                details={"purpose": purpose},
            ) from exc

        return _extract_message_text(data, purpose=purpose)


class MockProvider:
    """Deterministic local provider for ``HEARTLOG_AI_PROVIDER=mock``.

    Used for demos and tests: it never opens a network connection and never
    invents memories.  Outputs are clearly labelled so a user can tell them
    apart from a real model response.
    """

    name = "mock"

    def __init__(self, model: str = "mock") -> None:
        self.model = model or "mock"

    async def complete(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        purpose: Purpose,
        json_mode: bool = False,
    ) -> str:
        if purpose == "extraction":
            # Honest zero-result extraction: never fabricate memories.
            return json.dumps(
                {
                    "candidates": [],
                    "provider": self.name,
                    "model": self.model,
                    "mode": "ai",
                },
                ensure_ascii=False,
            )
        if purpose == "companion":
            return json.dumps(
                {
                    "content": (
                        "（本地 mock 提供方）我收到了你的消息，并把它保存在本地。"
                        "这次没有调用外部模型，因此也不会替你编造记忆。"
                    ),
                    "citations": [],
                },
                ensure_ascii=False,
            )
        return "（本地 mock 提供方）本次回顾未调用外部模型，也没有生成新的记忆或事实。"


def _extract_message_text(data: Any, *, purpose: Purpose) -> str:
    """Extract assistant text from an OpenAI Chat Completions response body."""

    if not isinstance(data, dict):
        raise AIResponseError(
            "The AI provider returned an unexpected JSON body",
            details={"purpose": purpose},
        )
    choices = data.get("choices")
    if not isinstance(choices, list) or not choices:
        raise AIResponseError(
            "The AI provider response contained no choices",
            details={"purpose": purpose},
        )
    first = choices[0]
    message = first.get("message") if isinstance(first, dict) else None
    content = message.get("content") if isinstance(message, dict) else None
    if isinstance(content, list):
        # Some compatible servers return content as a list of parts.
        parts: list[str] = []
        for part in content:
            if isinstance(part, dict) and isinstance(part.get("text"), str):
                parts.append(part["text"])
            elif isinstance(part, str):
                parts.append(part)
        content = "".join(parts)
    if not isinstance(content, str) or not content.strip():
        raise AIResponseError(
            "The AI provider response contained no text content",
            details={"purpose": purpose},
        )
    return content


def build_provider(settings: Settings) -> AIProvider | None:
    """Build the configured provider, or ``None`` when AI is unavailable.

    No network is performed here; construction is pure.
    """

    if not settings.ai_configured:
        return None
    if settings.ai_provider == "mock":
        return MockProvider(model=settings.ai_model or "mock")
    if settings.ai_provider == "openai_compatible":
        return OpenAICompatibleProvider(settings)
    return None
