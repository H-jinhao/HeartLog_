"""Weekly / monthly insight service.

The service always has two honest modes:

* ``local_statistics`` — AI is disabled or not configured (or the provider call
  failed): return deterministic local statistics, period boundaries and real
  source references.  ``narrative`` is ``None`` and a note states explicitly that
  no AI narrative was generated and no data was sent externally.
* ``ai`` — AI is configured: generate a narrative strictly from structured facts
  (counts + stored memory snippets + source refs) and return it together with the
  same real statistics and sources.  Raw diary text is never sent to the
  provider for reviews.

No fabricated content is ever returned as a source: ``sources`` are built from
database rows only.
"""

from __future__ import annotations

from datetime import UTC, date, datetime, timedelta
from typing import Any, Literal

from sqlalchemy import and_, or_, select
from sqlalchemy.orm import Session, selectinload

from app.core.exceptions import AIResponseError, AIServiceError
from app.models.diary import DiaryEntry
from app.models.enums import MemoryType, VerificationStatus
from app.models.memory import Memory
from app.schemas.insight import (
    DISCLAIMER,
    InsightPeriod,
    InsightResponse,
    InsightSource,
    InsightStatistics,
    MemoryTypeCount,
)
from app.services.ai_service import AIService

PeriodKind = Literal["weekly", "monthly"]

_INACTIVE_STATUSES = (
    VerificationStatus.REVOKED.value,
    VerificationStatus.SUPERSEDED.value,
)
_MAX_PERIOD_ENTRIES = 500
_MAX_PERIOD_MEMORIES = 500
_MAX_SOURCES = 60
_MAX_MEMORIES_FOR_NARRATIVE = 30
_SNIPPET_CHARS = 300

LOCAL_MODE_NOTES = (
    "AI 未启用或未配置：本次未生成任何 AI 叙事，以上仅为本地统计。",
    "本请求没有向任何外部提供方发送数据。",
    "如需 AI 回顾，请先阅读隐私说明，再启用 AI 并记录同意。",
)

AI_MODE_NOTES = (
    "叙事仅基于本次返回的统计与已存记忆片段生成，未新增事实。",
    "AI 可能出错，请以引用来源为准。",
)


# ---------------------------------------------------------------------------
# Period resolution
# ---------------------------------------------------------------------------


def resolve_period(
    period: PeriodKind,
    reference_date: date | None = None,
) -> InsightPeriod:
    """Return UTC period boundaries for a weekly/monthly review.

    Weekly periods start Monday 00:00 UTC; monthly periods start on the first day
    of the month 00:00 UTC.  ``end`` is exclusive.
    """

    reference = reference_date or datetime.now(UTC).date()
    if period == "weekly":
        start_date = reference - timedelta(days=reference.weekday())
        start = datetime(start_date.year, start_date.month, start_date.day, tzinfo=UTC)
        end = start + timedelta(days=7)
    elif period == "monthly":
        start = datetime(reference.year, reference.month, 1, tzinfo=UTC)
        if reference.month == 12:
            end = datetime(reference.year + 1, 1, 1, tzinfo=UTC)
        else:
            end = datetime(reference.year, reference.month + 1, 1, tzinfo=UTC)
    else:  # pragma: no cover - Literal keeps this unreachable in typed code
        raise ValueError(f"Unsupported insight period: {period!r}")
    return InsightPeriod(
        period=period,
        start=start,
        end=end,
        reference_date=reference,
        timezone="UTC",
    )


# ---------------------------------------------------------------------------
# Data collection
# ---------------------------------------------------------------------------


def _diary_sources(entry: DiaryEntry) -> dict[str, Any]:
    return {
        "memory_id": None,
        "entry_id": entry.id,
        "revision_id": entry.current_revision_id,
        "version": entry.current_version,
        "snippet": None,
        "memory_type": None,
        "created_at": entry.created_at,
    }


def _memory_source(memory: Memory) -> dict[str, Any]:
    revision = memory.source_revision
    evidence = memory.sources[0].evidence_text if memory.sources else memory.content
    return {
        "memory_id": memory.id,
        "entry_id": memory.source_entry_id,
        "revision_id": memory.source_revision_id,
        "version": revision.version if revision is not None else None,
        "snippet": str(evidence)[:_SNIPPET_CHARS],
        "memory_type": memory.memory_type,
        "created_at": memory.created_at,
    }


def collect_period_data(
    session: Session,
    window: InsightPeriod,
) -> tuple[dict[str, Any], list[dict[str, Any]], InsightStatistics]:
    """Collect deterministic local facts for the period.

    Returns ``(facts_for_ai, source_dicts, statistics)``.  ``facts_for_ai`` never
    contains raw diary text: it carries counts plus stored memory snippets.
    """

    entry_statement = (
        select(DiaryEntry)
        .where(
            DiaryEntry.created_at >= window.start,
            DiaryEntry.created_at < window.end,
            DiaryEntry.deleted_at.is_(None),
        )
        .order_by(DiaryEntry.created_at.desc(), DiaryEntry.id.desc())
        .limit(_MAX_PERIOD_ENTRIES)
    )
    entries = list(session.execute(entry_statement).scalars().all())
    entry_ids = [entry.id for entry in entries]

    created_in_period = and_(
        Memory.created_at >= window.start,
        Memory.created_at < window.end,
    )
    if entry_ids:
        memory_period_filter = or_(created_in_period, Memory.source_entry_id.in_(entry_ids))
    else:
        memory_period_filter = created_in_period

    memory_statement = (
        select(Memory)
        .join(DiaryEntry, DiaryEntry.id == Memory.source_entry_id)
        .where(
            memory_period_filter,
            DiaryEntry.deleted_at.is_(None),
            Memory.is_active.is_(True),
            Memory.verification_status.not_in(_INACTIVE_STATUSES),
        )
        .options(
            selectinload(Memory.source_revision),
            selectinload(Memory.source_entry),
            selectinload(Memory.sources),
        )
        .order_by(Memory.created_at.desc(), Memory.id.desc())
        .limit(_MAX_PERIOD_MEMORIES)
    )
    memories = list(session.execute(memory_statement).scalars().all())

    counts = {memory_type.value: 0 for memory_type in MemoryType}
    for memory in memories:
        if memory.memory_type in counts:
            counts[memory.memory_type] += 1

    statistics = InsightStatistics(
        diary_entries=len(entries),
        memories=len(memories),
        memory_type_counts=[
            MemoryTypeCount(memory_type=memory_type.value, count=counts[memory_type.value])
            for memory_type in MemoryType
        ],
    )

    sources: list[dict[str, Any]] = [_diary_sources(entry) for entry in entries[:20]]
    sources.extend(_memory_source(memory) for memory in memories[:40])
    sources = sources[:_MAX_SOURCES]

    facts: dict[str, Any] = {
        "period": {
            "kind": window.period,
            "start": window.start.isoformat(),
            "end": window.end.isoformat(),
            "reference_date": window.reference_date.isoformat(),
            "timezone": window.timezone,
        },
        "statistics": {
            "diary_entries": statistics.diary_entries,
            "memories": statistics.memories,
            "memory_type_counts": counts,
        },
        "memory_records": [
            {
                "memory_id": memory.id,
                "memory_type": memory.memory_type,
                "verification_status": memory.verification_status,
                "content": str(memory.content)[:_SNIPPET_CHARS],
                "entry_id": memory.source_entry_id,
                "revision_id": memory.source_revision_id,
                "version": (memory.source_revision.version if memory.source_revision is not None else None),
                "diary_time": (
                    memory.source_entry.created_at.isoformat() if memory.source_entry is not None else None
                ),
            }
            for memory in memories[:_MAX_MEMORIES_FOR_NARRATIVE]
        ],
        "source_entries": [
            {
                "entry_id": entry.id,
                "version": entry.current_version,
                "created_at": entry.created_at.isoformat(),
            }
            for entry in entries[:_MAX_MEMORIES_FOR_NARRATIVE]
        ],
    }
    return facts, sources, statistics


# ---------------------------------------------------------------------------
# Insight assembly
# ---------------------------------------------------------------------------


def _response(
    *,
    window: InsightPeriod,
    statistics: InsightStatistics,
    sources: list[dict[str, Any]],
    mode: Literal["ai", "local_statistics"],
    narrative: str | None,
    notes: list[str],
    provider: str | None = None,
    model: str | None = None,
) -> InsightResponse:
    return InsightResponse(
        mode=mode,
        ai_used=mode == "ai",
        period=window,
        statistics=statistics,
        narrative=narrative,
        sources=[InsightSource.model_validate(source) for source in sources],
        notes=notes,
        disclaimer=DISCLAIMER,
        provider=provider,
        model=model,
    )


async def build_insight(
    *,
    ai_service: AIService,
    session: Session,
    period: PeriodKind,
    reference_date: date | None = None,
) -> InsightResponse:
    """Build a weekly or monthly insight response."""

    window = resolve_period(period, reference_date)
    facts, sources, statistics = collect_period_data(session, window)

    if not ai_service.configured:
        return _response(
            window=window,
            statistics=statistics,
            sources=sources,
            mode="local_statistics",
            narrative=None,
            notes=list(LOCAL_MODE_NOTES),
        )

    purpose = "weekly_review" if period == "weekly" else "monthly_review"
    try:
        narrative = await ai_service.generate_narrative(purpose=purpose, facts=facts)
    except (AIServiceError, AIResponseError):
        # Never invent a fallback narrative: return the local statistics instead
        # and say plainly that the AI narrative could not be generated.
        return _response(
            window=window,
            statistics=statistics,
            sources=sources,
            mode="local_statistics",
            narrative=None,
            notes=[
                "AI 叙事生成失败（提供方错误或响应不可用），本次仅返回本地统计，未使用任何虚构内容。",
                *LOCAL_MODE_NOTES[1:],
            ],
        )

    return _response(
        window=window,
        statistics=statistics,
        sources=sources,
        mode="ai",
        narrative=narrative,
        notes=list(AI_MODE_NOTES),
        provider=ai_service.provider_name,
        model=ai_service.model_name,
    )
