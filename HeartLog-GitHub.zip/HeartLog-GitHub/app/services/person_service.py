"""People operations with explicit source provenance and no automatic merging."""

from __future__ import annotations

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.core.config import Settings
from app.core.exceptions import ConflictError, NotFoundError, ValidationError
from app.core.time import utcnow
from app.models.audit import AuditEvent
from app.models.diary import DiaryEntry, DiaryRevision
from app.models.person import Person
from app.schemas.person import (
    PersonCreate,
    PersonForgetResponse,
    PersonList,
    PersonOut,
    PersonTimeline,
    TimelineHit,
)


class PersonService:
    def __init__(self, session: Session, settings: Settings) -> None:
        self.session = session
        self.settings = settings

    def _audit(self, event_type: str, entity_id: str, details: dict | None = None) -> AuditEvent:
        event = AuditEvent(
            event_type=event_type,
            entity_type="person",
            entity_id=entity_id,
            actor="user",
            details=details or {},
        )
        self.session.add(event)
        return event

    def create(self, payload: PersonCreate) -> PersonOut:
        entry = self.session.get(DiaryEntry, payload.source_entry_id)
        if entry is None or entry.deleted_at is not None:
            raise NotFoundError(
                "Source diary entry not found",
                details={"source_entry_id": payload.source_entry_id},
            )
        revision = self.session.get(DiaryRevision, payload.source_revision_id)
        if revision is None or revision.entry_id != entry.id:
            raise ValidationError(
                "Source revision does not belong to the supplied diary entry",
                details={
                    "source_entry_id": entry.id,
                    "source_revision_id": payload.source_revision_id,
                },
            )
        if payload.source_evidence is not None:
            if payload.source_evidence not in revision.content:
                raise ValidationError(
                    "source_evidence must be an exact excerpt of the source revision",
                    details={"source_revision_id": revision.id},
                )
        existing = self.session.scalar(
            select(Person).where(
                Person.display_name == payload.display_name,
                Person.source_revision_id == revision.id,
            )
        )
        if existing is not None:
            raise ConflictError(
                "A person with this name is already recorded from this revision",
                code="person_already_recorded",
                details={"person_id": existing.id},
            )
        person = Person(
            display_name=payload.display_name,
            aliases=list(payload.aliases),
            source_entry_id=entry.id,
            source_revision_id=revision.id,
            source_evidence=payload.source_evidence,
        )
        self.session.add(person)
        try:
            self.session.flush()
            self._audit("person.created", person.id, {"source_entry_id": entry.id})
            self.session.commit()
        except Exception:
            self.session.rollback()
            raise
        return PersonOut.model_validate(person)

    def list(
        self,
        *,
        q: str | None,
        limit: int,
        offset: int,
        include_deleted_sources: bool = False,
    ) -> PersonList:
        stmt = select(Person)
        count_stmt = select(func.count()).select_from(Person)
        if not include_deleted_sources:
            stmt = stmt.join(DiaryEntry, DiaryEntry.id == Person.source_entry_id).where(
                DiaryEntry.deleted_at.is_(None)
            )
            count_stmt = count_stmt.join(DiaryEntry, DiaryEntry.id == Person.source_entry_id).where(
                DiaryEntry.deleted_at.is_(None)
            )
        if q:
            pattern = f"%{q}%"
            stmt = stmt.where(Person.display_name.ilike(pattern))
            count_stmt = count_stmt.where(Person.display_name.ilike(pattern))
        total = int(self.session.scalar(count_stmt) or 0)
        items = list(
            self.session.scalars(stmt.order_by(Person.created_at.desc()).limit(limit).offset(offset))
        )
        return PersonList(
            items=[PersonOut.model_validate(item) for item in items],
            total=total,
            limit=limit,
            offset=offset,
            has_more=offset + len(items) < total,
        )

    def _get_person_or_404(self, person_id: str, *, include_deleted_sources: bool = False) -> Person:
        person = self.session.get(Person, person_id)
        if person is None:
            raise NotFoundError("Person not found", details={"person_id": person_id})
        if not include_deleted_sources:
            entry = self.session.get(DiaryEntry, person.source_entry_id)
            if entry is not None and entry.deleted_at is not None:
                raise NotFoundError("Person not found", details={"person_id": person_id})
        return person

    def get(self, person_id: str, *, include_deleted_sources: bool = False) -> PersonOut:
        person = self._get_person_or_404(person_id, include_deleted_sources=include_deleted_sources)
        return PersonOut.model_validate(person)

    def forget(self, person_id: str) -> PersonForgetResponse:
        """Permanently remove a person record (contentless audit tombstone remains)."""

        person = self._get_person_or_404(person_id, include_deleted_sources=True)
        source_entry_id = person.source_entry_id
        source_revision_id = person.source_revision_id
        forgotten_at = utcnow()
        audit_event = self._audit(
            "person.purged",
            person.id,
            {
                "person_id": person.id,
                "source_entry_id": source_entry_id,
                "source_revision_id": source_revision_id,
                "alias_count": len(person.aliases),
                "had_source_evidence": person.source_evidence is not None,
            },
        )
        try:
            self.session.flush()
            audit_event_id = audit_event.id
            self.session.delete(person)
            self.session.commit()
        except Exception:
            self.session.rollback()
            raise
        return PersonForgetResponse(
            person_id=person_id,
            forgotten_at=forgotten_at,
            source_entry_id=source_entry_id,
            source_revision_id=source_revision_id,
            audit_event_id=audit_event_id,
        )

    def timeline(
        self,
        person_id: str,
        *,
        limit: int,
        offset: int,
        include_deleted_sources: bool = False,
    ) -> PersonTimeline:
        person = self._get_person_or_404(person_id, include_deleted_sources=include_deleted_sources)
        names = [person.display_name, *person.aliases]
        name_filters = [DiaryRevision.content.ilike(f"%{name}%") for name in names]
        stmt = (
            select(DiaryEntry, DiaryRevision)
            .join(DiaryRevision, DiaryRevision.entry_id == DiaryEntry.id)
            .where(
                DiaryEntry.deleted_at.is_(None),
                or_(*name_filters),
            )
            .order_by(DiaryRevision.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
        rows = self.session.execute(stmt).all()
        items: list[TimelineHit] = []
        for entry, revision in rows:
            matched = next((name for name in names if name in revision.content), names[0])
            index = revision.content.find(matched)
            start = max(0, index - 60)
            end = min(len(revision.content), index + len(matched) + 60)
            snippet = (
                ("…" if start > 0 else "")
                + revision.content[start:end]
                + ("…" if end < len(revision.content) else "")
            )
            items.append(
                TimelineHit(
                    entry_id=entry.id,
                    revision_id=revision.id,
                    version=revision.version,
                    created_at=revision.created_at,
                    snippet=snippet,
                    matched_name=matched,
                    is_current=revision.id == entry.current_revision_id,
                )
            )
        return PersonTimeline(
            person_id=person.id,
            display_name=person.display_name,
            names_used_for_search=names,
            items=items,
        )
