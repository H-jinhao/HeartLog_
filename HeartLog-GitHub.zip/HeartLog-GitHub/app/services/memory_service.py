"""Business rules and transactions for traceable long-term memories.

Guarantees enforced here (not merely by convention):

1. **No source, no memory.**  Every extraction candidate must quote an exact
   substring of the referenced, immutable diary revision.  Optional offsets are
   re-checked with ``content[start:end]``.  Invalid candidates are rejected
   individually with structured codes and write no rows; if every candidate is
   invalid the request fails with ``422`` and nothing is persisted.
2. **Review is explicit.**  Model-extracted memories start ``pending`` with
   ``created_by="model"``.  Confidence (even ``0.99``) never auto-confirms a
   memory, and confirmation never changes ``memory_type`` (a model inference
   stays a model inference).
3. **History is append-only.**  Confirmation only changes review state;
   correction creates a *new* memory and marks the old one ``superseded``.
   Revocation only flips state.  Original content is never rewritten.
4. **Atomicity.**  Memories, their evidence sources and audit events are
   committed in one transaction; any unexpected database error rolls the whole
   batch back.  A duplicate candidate is isolated behind a SAVEPOINT and
   skipped rather than poisoning the rest of the batch.
5. **AI failures write nothing.**  Disabled/unconfigured AI yields
   ``503 ai_not_configured``; provider failures are mapped to ``502`` errors.

Audit details are structural only (ids, versions, counts, reason codes); diary
text and model evidence are never logged or copied into audit events.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from pydantic import ValidationError as PydanticValidationError
from sqlalchemy.exc import IntegrityError

from app.core.config import Settings
from app.core.exceptions import (
    AIConfigurationError,
    AIResponseError,
    AIServiceError,
    AppError,
    ConflictError,
    NotFoundError,
    ValidationError,
)
from app.core.hashing import sha256_text
from app.core.time import utcnow
from app.models.diary import DiaryEntry, DiaryRevision
from app.models.enums import (
    CreatedBy,
    MemorySourceType,
    MemoryType,
    VerificationStatus,
)
from app.models.memory import Memory, MemorySource
from app.repositories.memory_repository import (
    AuditRepository,
    MemoryListFilters,
    MemoryRepository,
)
from app.schemas.ai import CandidateMemory, ExtractionEnvelope
from app.schemas.common import Page
from app.schemas.memory import (
    MAX_MEMORY_CONTENT_CHARS,
    ExtractionReport,
    ForgetMode,
    MemoryForgetResponse,
    MemoryOut,
    MemorySourceDetail,
    MemorySourceList,
    MemorySourceOut,
    RejectedCandidate,
)
from app.services.ai_service import AIService

logger = logging.getLogger("heartlog.memory")

ACTOR_USER = CreatedBy.USER.value
ACTOR_MODEL = CreatedBy.MODEL.value

# Stable rejection codes returned to clients / tests.
REASON_CONTENT_BLANK = "content_blank"
REASON_CONTENT_TOO_LONG = "content_too_long"
REASON_EVIDENCE_TOO_LONG = "evidence_too_long"
REASON_EVIDENCE_NOT_FOUND = "evidence_not_found"
REASON_EVIDENCE_OFFSET_MISMATCH = "evidence_offset_mismatch"
REASON_DUPLICATE_MEMORY = "duplicate_memory"

# Response details are bounded so a runaway model output cannot produce an
# enormous error body.
MAX_REJECTED_DETAILS = 50


@dataclass(frozen=True)
class _ValidatedCandidate:
    """A model candidate whose evidence matched the exact revision text."""

    index: int
    content: str
    content_hash: str
    memory_type: str
    confidence: float | None
    evidence_text: str
    start_offset: int | None
    end_offset: int | None


class MemoryService:
    """Application service for the memory subsystem.

    The service owns transactions; the route layer stays thin and the
    repository executes queries.
    """

    def __init__(
        self,
        *,
        session: Any,
        settings: Settings,
        ai_service: AIService | None = None,
    ) -> None:
        self.session = session
        self.settings = settings
        self.ai_service = ai_service
        self.repo = MemoryRepository(session)
        self.audit = AuditRepository(session)

    # ------------------------------------------------------------------
    # Extraction
    # ------------------------------------------------------------------
    async def extract(
        self,
        *,
        entry_id: str,
        revision_id: str | None = None,
        version: int | None = None,
    ) -> ExtractionReport:
        """Run AI extraction against one exact, immutable diary revision."""

        ai = self.ai_service
        if ai is None or not ai.configured:
            # Fail before reading or writing anything: a disabled AI must not
            # leave audit or memory rows behind.
            raise AIConfigurationError(
                "Memory extraction requires a configured AI provider; nothing was saved.",
                details={"reason": "ai_not_configured"},
            )

        entry = self.repo.get_entry(entry_id)
        if entry is None:
            raise NotFoundError("Diary entry not found", details={"entry_id": entry_id})
        if entry.deleted_at is not None:
            raise ConflictError(
                "Cannot extract memories from a deleted diary entry",
                code="diary_deleted",
                details={"entry_id": entry.id},
            )

        revision = self._resolve_revision(entry, revision_id=revision_id, version=version)
        source_content = revision.content

        try:
            envelope = await ai.extract_memories(
                entry_id=entry.id,
                revision_id=revision.id,
                version=revision.version,
                content=source_content,
            )
        except AppError:
            # Domain errors from the AI adapter (configuration, invalid
            # response, provider failure) already carry correct status codes.
            raise
        except PydanticValidationError as exc:
            raise AIResponseError(
                "The AI provider returned a malformed extraction payload; nothing was saved.",
            ) from exc
        except Exception as exc:  # pragma: no cover - defensive translation
            logger.warning("memory_extraction_transport_failed error_type=%s", type(exc).__name__)
            raise AIServiceError(
                "AI extraction failed; nothing was saved.",
            ) from exc

        if not isinstance(envelope, ExtractionEnvelope):
            try:
                envelope = ExtractionEnvelope.model_validate(envelope)
            except PydanticValidationError as exc:
                raise AIResponseError(
                    "The AI provider returned a malformed extraction payload; nothing was saved.",
                ) from exc

        candidates: list[CandidateMemory] = list(envelope.candidates)
        valid, rejected = self._validate_candidates(candidates, source_content=source_content)

        if candidates and not valid:
            # *Every* candidate was invalid: reject the batch atomically.
            self.repo.rollback()
            raise ValidationError(
                "No candidate memory could be verified against the diary revision; nothing was saved.",
                code="no_valid_candidates",
                details={
                    "candidate_count": len(candidates),
                    "rejected_count": len(rejected),
                    "rejected": self._rejected_details(rejected),
                },
            )

        created = self._persist_candidates(
            valid,
            rejected=rejected,
            candidate_count=len(candidates),
            entry=entry,
            revision=revision,
            envelope=envelope,
        )

        created_output = [self._memory_out(memory, source_version=revision.version) for memory in created]
        return ExtractionReport(
            entry_id=entry.id,
            revision_id=revision.id,
            version=revision.version,
            provider=envelope.provider,
            model=envelope.model,
            candidate_count=len(candidates),
            created=created_output,
            rejected=rejected,
            created_count=len(created_output),
            rejected_count=len(rejected),
        )

    # ------------------------------------------------------------------
    # Reads
    # ------------------------------------------------------------------
    def get_memory(self, memory_id: str, *, include_deleted_sources: bool = False) -> MemoryOut:
        memory = self._get_memory_or_404(memory_id, include_deleted_sources=include_deleted_sources)
        return self._memory_out(memory)

    def list_memories(
        self,
        *,
        memory_type: MemoryType | None = None,
        verification_status: VerificationStatus | None = None,
        entry_id: str | None = None,
        active: bool | None = None,
        include_deleted_sources: bool = False,
        limit: int | None = None,
        offset: int = 0,
    ) -> Page[MemoryOut]:
        """List memories with the documented default of "active only".

        Semantics:

        * no filters: active memories only (``is_active=1`` and status not
          ``revoked``/``superseded``); this is the normal list/search view.
        * ``active=True``: same as the default.
        * ``active=False``: inactive records only (revoked/superseded).
        * explicit ``verification_status``: exact status match; ``active`` is
          only applied when it was also supplied.  This allows inspecting
          revoked rows deliberately (``?verification_status=revoked``).
        """

        effective_limit = self._resolve_limit(limit)
        filters = self._resolve_filters(
            memory_type=memory_type,
            verification_status=verification_status,
            entry_id=entry_id,
            active=active,
            include_deleted_sources=include_deleted_sources,
        )
        items, total = self.repo.list(filters, limit=effective_limit, offset=offset)
        page_items = [self._memory_out(memory) for memory in items]
        return Page(
            items=page_items,
            total=total,
            limit=effective_limit,
            offset=offset,
            has_more=(offset + len(page_items)) < total,
        )

    def list_sources(self, memory_id: str, *, include_deleted_sources: bool = False) -> MemorySourceList:
        memory = self._get_memory_or_404(memory_id, include_deleted_sources=include_deleted_sources)
        rows = self.repo.get_sources_with_versions(memory.id)
        sources: list[MemorySourceDetail] = []
        for source, revision_version in rows:
            source_out = MemorySourceOut.model_validate(source)
            sources.append(
                MemorySourceDetail(
                    **source_out.model_dump(),
                    revision_version=revision_version,
                )
            )
        return MemorySourceList(
            memory_id=memory.id,
            total=len(sources),
            sources=sources,
        )

    # ------------------------------------------------------------------
    # Review transitions
    # ------------------------------------------------------------------
    def confirm(self, memory_id: str) -> MemoryOut:
        """User confirmation: pending -> confirmed, never an auto-promotion."""

        memory = self._get_memory_or_404(memory_id, include_deleted_sources=True)
        previous = memory.verification_status
        if previous == VerificationStatus.CONFIRMED.value:
            raise ConflictError(
                "Memory is already confirmed",
                code="already_confirmed",
                details={"memory_id": memory.id},
            )
        if previous != VerificationStatus.PENDING.value:
            raise ConflictError(
                "Only pending memories can be confirmed",
                code="invalid_state_transition",
                details={"memory_id": memory.id, "verification_status": previous},
            )

        # memory_type is deliberately untouched: a model_inference stays a
        # model_inference even after the user confirms it.
        memory.verification_status = VerificationStatus.CONFIRMED.value
        memory.confirmed_by = ACTOR_USER
        memory.confirmed_at = utcnow()
        self.audit.add(
            event_type="memory.confirmed",
            entity_type="memory",
            entity_id=memory.id,
            actor=ACTOR_USER,
            details={
                "memory_id": memory.id,
                "memory_type": memory.memory_type,
                "previous_status": previous,
                "new_status": VerificationStatus.CONFIRMED.value,
                "confirmed_by": ACTOR_USER,
                "source_entry_id": memory.source_entry_id,
                "source_revision_id": memory.source_revision_id,
            },
        )
        self._commit()
        return self._memory_out(memory)

    def correct(
        self,
        memory_id: str,
        *,
        content: str,
        change_reason: str | None = None,
    ) -> MemoryOut:
        """Create a superseding correction; the old row is never rewritten."""

        memory = self._get_memory_or_404(memory_id, include_deleted_sources=True)
        if memory.verification_status not in (
            VerificationStatus.PENDING.value,
            VerificationStatus.CONFIRMED.value,
        ):
            raise ConflictError(
                "Only pending or confirmed memories can be corrected",
                code="invalid_state_transition",
                details={
                    "memory_id": memory.id,
                    "verification_status": memory.verification_status,
                },
            )

        content_limit = self._content_limit()
        if len(content) > content_limit:
            raise ValidationError(
                "Corrected content is too long",
                code="content_too_long",
                details={"max_chars": content_limit},
            )
        new_hash = sha256_text(content)
        if new_hash == memory.content_hash:
            raise ValidationError(
                "Corrected content is identical to the current memory; nothing to correct",
                code="correction_unchanged",
                details={"memory_id": memory.id},
            )

        self._validate_memory_evidence(memory)
        if not memory.sources:
            # Defensive: the invariant "no source, no memory" should make this
            # impossible, but corrections must never fabricate a source-less row.
            raise ConflictError(
                "This memory has no evidence sources; it cannot be corrected",
                code="missing_sources",
                details={"memory_id": memory.id},
            )

        existing = self.repo.find_duplicate(
            source_revision_id=memory.source_revision_id,
            content_hash=new_hash,
            memory_type=memory.memory_type,
            exclude_memory_id=memory.id,
        )
        if existing is not None:
            raise ConflictError(
                "A memory with this corrected content already exists for the same diary revision",
                code=REASON_DUPLICATE_MEMORY,
                details={"memory_id": memory.id, "existing_memory_id": existing.id},
            )

        now = utcnow()
        metadata: dict[str, Any] = dict(memory.metadata_json or {})
        metadata["correction"] = {
            "corrected_memory_id": memory.id,
            "previous_content_hash": memory.content_hash,
            "change_reason": change_reason,
            "source_count": len(memory.sources),
        }
        corrected = Memory(
            content=content,
            content_hash=new_hash,
            memory_type=memory.memory_type,
            source_type=MemorySourceType.USER_CORRECTION.value,
            source_entry_id=memory.source_entry_id,
            source_revision_id=memory.source_revision_id,
            confidence=memory.confidence,
            verification_status=VerificationStatus.CONFIRMED.value,
            is_active=True,
            created_by=ACTOR_USER,
            confirmed_by=ACTOR_USER,
            confirmed_at=now,
            supersedes_memory_id=memory.id,
            metadata_json=metadata,
        )
        for source in memory.sources:
            corrected.sources.append(
                MemorySource(
                    entry_id=source.entry_id,
                    revision_id=source.revision_id,
                    evidence_text=source.evidence_text,
                    start_offset=source.start_offset,
                    end_offset=source.end_offset,
                )
            )

        previous_status = memory.verification_status
        memory.verification_status = VerificationStatus.SUPERSEDED.value
        memory.is_active = False
        self.repo.add(corrected)

        self.audit.add(
            event_type="memory.created",
            entity_type="memory",
            entity_id=corrected.id,
            actor=ACTOR_USER,
            details={
                "memory_id": corrected.id,
                "memory_type": corrected.memory_type,
                "source_type": MemorySourceType.USER_CORRECTION.value,
                "verification_status": VerificationStatus.CONFIRMED.value,
                "supersedes_memory_id": memory.id,
                "source_entry_id": corrected.source_entry_id,
                "source_revision_id": corrected.source_revision_id,
                "source_count": len(corrected.sources),
            },
        )
        self.audit.add(
            event_type="memory.corrected",
            entity_type="memory",
            entity_id=memory.id,
            actor=ACTOR_USER,
            details={
                "memory_id": memory.id,
                "superseded_by_memory_id": corrected.id,
                "memory_type": memory.memory_type,
                "previous_status": previous_status,
                "new_status": VerificationStatus.SUPERSEDED.value,
                "source_entry_id": memory.source_entry_id,
                "source_revision_id": memory.source_revision_id,
            },
        )

        try:
            self._commit()
        except IntegrityError as exc:
            raise ConflictError(
                "A memory with this corrected content already exists for the same diary revision",
                code=REASON_DUPLICATE_MEMORY,
                details={"memory_id": memory.id},
            ) from exc
        return self._memory_out(corrected)

    def revoke(self, memory_id: str, *, reason: str | None = None) -> MemoryOut:
        """Revoke a memory: hidden from normal lists, still traceable by id."""

        memory = self._get_memory_or_404(memory_id, include_deleted_sources=True)
        previous = memory.verification_status
        if previous == VerificationStatus.REVOKED.value:
            raise ConflictError(
                "Memory is already revoked",
                code="already_revoked",
                details={"memory_id": memory.id},
            )
        if previous not in (
            VerificationStatus.PENDING.value,
            VerificationStatus.CONFIRMED.value,
        ):
            raise ConflictError(
                "Only pending or confirmed memories can be revoked",
                code="invalid_state_transition",
                details={"memory_id": memory.id, "verification_status": previous},
            )

        # Both fields change in the same UPDATE so the SQLite check constraint
        # (revoked implies inactive) is always satisfied.
        memory.verification_status = VerificationStatus.REVOKED.value
        memory.is_active = False
        memory.revoked_at = utcnow()
        self.audit.add(
            event_type="memory.revoked",
            entity_type="memory",
            entity_id=memory.id,
            actor=ACTOR_USER,
            details={
                "memory_id": memory.id,
                "memory_type": memory.memory_type,
                "previous_status": previous,
                "new_status": VerificationStatus.REVOKED.value,
                "source_count": self.repo.count_sources(memory.id),
                "reason": reason,
            },
        )
        self._commit()
        return self._memory_out(memory)

    def forget(self, memory_id: str, *, mode: ForgetMode) -> MemoryForgetResponse:
        """Irreversibly remove memory content and evidence (purge/anonymize).

        Both modes delete the memory row and its evidence sources so the source
        diary is no longer referenced by this memory.  The only retained trace
        is an append-only, contentless audit event.  This operation cannot be
        undone; backups/exports made earlier still contain the old data.
        """

        memory = self._get_memory_or_404(memory_id, include_deleted_sources=True)
        source_count = len(memory.sources)
        source_entry_id = memory.source_entry_id
        source_revision_id = memory.source_revision_id
        memory_type = memory.memory_type
        verification_status = memory.verification_status
        supersedes_memory_id = memory.supersedes_memory_id
        forgotten_at = utcnow()
        event_type = "memory.anonymized" if mode == "anonymize" else "memory.purged"

        audit_event = self.audit.add(
            event_type=event_type,
            entity_type="memory",
            entity_id=memory.id,
            actor=ACTOR_USER,
            details={
                "memory_id": memory.id,
                "mode": mode,
                "memory_type": memory_type,
                "verification_status": verification_status,
                "source_entry_id": source_entry_id,
                "source_revision_id": source_revision_id,
                "source_count": source_count,
                "had_supersedes_link": supersedes_memory_id is not None,
            },
        )
        try:
            # Flush first so the audit row gets its stable id before the memory
            # row (and cascade-deleted MemorySource rows) disappear.
            self.repo.flush()
            audit_event_id = audit_event.id
            self.session.delete(memory)
            self._commit()
        except Exception:
            self.repo.rollback()
            raise

        return MemoryForgetResponse(
            memory_id=memory_id,
            mode=mode,
            forgotten_at=forgotten_at,
            source_entry_id=source_entry_id,
            source_revision_id=source_revision_id,
            memory_type=memory_type,
            purged_sources=source_count,
            audit_event_id=audit_event_id,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _resolve_revision(
        self,
        entry: DiaryEntry,
        *,
        revision_id: str | None,
        version: int | None,
    ) -> DiaryRevision:
        revision: DiaryRevision | None = None
        if revision_id is not None:
            revision = self.repo.get_revision(revision_id)
            if revision is None or revision.entry_id != entry.id:
                raise NotFoundError(
                    "Diary revision not found for this entry",
                    code="revision_not_found",
                    details={"entry_id": entry.id},
                )
        if version is not None:
            by_version = self.repo.get_revision_by_version(entry.id, version)
            if by_version is None:
                raise NotFoundError(
                    "Diary revision version not found for this entry",
                    code="revision_not_found",
                    details={"entry_id": entry.id, "version": version},
                )
            if revision is not None and revision.id != by_version.id:
                raise ValidationError(
                    "revision_id and version identify different diary revisions",
                    code="revision_mismatch",
                    details={"entry_id": entry.id, "revision_id": revision_id, "version": version},
                )
            revision = by_version
        if revision is None:
            revision = self._current_revision(entry)
        if sha256_text(revision.content) != revision.content_hash:
            raise ConflictError(
                "The diary revision failed its integrity check; extraction was refused",
                code="source_integrity_error",
                details={"entry_id": entry.id, "revision_id": revision.id, "version": revision.version},
            )
        return revision

    def _current_revision(self, entry: DiaryEntry) -> DiaryRevision:
        revision: DiaryRevision | None = None
        if entry.current_revision_id:
            revision = self.repo.get_revision(entry.current_revision_id)
            if revision is not None and revision.entry_id != entry.id:
                revision = None
        if revision is None:
            revision = self.repo.get_revision_by_version(entry.id, entry.current_version)
        if revision is None:
            raise ConflictError(
                "Diary entry has no revision to extract from",
                code="missing_revision",
                details={"entry_id": entry.id},
            )
        return revision

    def _validate_candidates(
        self,
        candidates: list[CandidateMemory],
        *,
        source_content: str,
    ) -> tuple[list[_ValidatedCandidate], list[RejectedCandidate]]:
        valid: list[_ValidatedCandidate] = []
        rejected: list[RejectedCandidate] = []
        evidence_limit = self.settings.max_evidence_chars
        content_limit = self._content_limit()

        for index, candidate in enumerate(candidates):
            reason: str | None = None
            message = ""
            if not candidate.content.strip():
                reason = REASON_CONTENT_BLANK
                message = "Candidate content is empty or whitespace only."
            elif len(candidate.content) > content_limit:
                reason = REASON_CONTENT_TOO_LONG
                message = f"Candidate content exceeds the configured {content_limit} character limit."
            elif len(candidate.evidence_text) > evidence_limit:
                reason = REASON_EVIDENCE_TOO_LONG
                message = f"Evidence text exceeds the configured {evidence_limit} character limit."
            elif candidate.evidence_text not in source_content:
                reason = REASON_EVIDENCE_NOT_FOUND
                message = "Evidence text is not an exact substring of the diary revision content."
            elif candidate.start_offset is not None and candidate.end_offset is not None:
                start, end = candidate.start_offset, candidate.end_offset
                if (
                    end > len(source_content)
                    or start > len(source_content)
                    or source_content[start:end] != candidate.evidence_text
                ):
                    reason = REASON_EVIDENCE_OFFSET_MISMATCH
                    message = "Evidence offsets do not match the exact diary revision slice."
            if reason is not None:
                rejected.append(
                    RejectedCandidate(
                        index=index,
                        reason=reason,
                        message=message,
                        memory_type=candidate.memory_type.value,
                    )
                )
                continue
            valid.append(
                _ValidatedCandidate(
                    index=index,
                    content=candidate.content,
                    content_hash=sha256_text(candidate.content),
                    memory_type=candidate.memory_type.value,
                    confidence=candidate.confidence,
                    evidence_text=candidate.evidence_text,
                    start_offset=candidate.start_offset,
                    end_offset=candidate.end_offset,
                )
            )
        return valid, rejected

    def _persist_candidates(
        self,
        valid: list[_ValidatedCandidate],
        *,
        rejected: list[RejectedCandidate],
        candidate_count: int,
        entry: DiaryEntry,
        revision: DiaryRevision,
        envelope: ExtractionEnvelope,
    ) -> list[Memory]:
        created: list[Memory] = []
        try:
            for candidate in valid:
                duplicate_key = {
                    "source_revision_id": revision.id,
                    "content_hash": candidate.content_hash,
                    "memory_type": candidate.memory_type,
                }
                if self.repo.find_duplicate(**duplicate_key) is not None:
                    rejected.append(self._duplicate_rejection(candidate.index, candidate.memory_type))
                    continue
                memory = self._build_memory(
                    candidate,
                    entry=entry,
                    revision=revision,
                    envelope=envelope,
                )
                try:
                    with self.repo.begin_nested():
                        self.repo.add(memory)
                        self.repo.flush()
                except IntegrityError:
                    # A concurrent writer inserted the same claim between the
                    # lookup and the INSERT.  Skip just this candidate; the
                    # SAVEPOINT rollback keeps the rest of the batch intact.
                    if self.repo.find_duplicate(**duplicate_key) is not None:
                        rejected.append(self._duplicate_rejection(candidate.index, candidate.memory_type))
                        continue
                    raise
                created.append(memory)

            for memory in created:
                self.audit.add(
                    event_type="memory.created",
                    entity_type="memory",
                    entity_id=memory.id,
                    actor=ACTOR_MODEL,
                    details={
                        "memory_id": memory.id,
                        "memory_type": memory.memory_type,
                        "source_type": memory.source_type,
                        "verification_status": memory.verification_status,
                        "source_entry_id": memory.source_entry_id,
                        "source_revision_id": memory.source_revision_id,
                        "source_count": len(memory.sources),
                    },
                )
            self.audit.add(
                event_type="memories.extracted",
                entity_type="diary_entry",
                entity_id=entry.id,
                actor=ACTOR_MODEL,
                details={
                    "entry_id": entry.id,
                    "revision_id": revision.id,
                    "version": revision.version,
                    "provider": envelope.provider,
                    "model": envelope.model,
                    "candidate_count": candidate_count,
                    "created_count": len(created),
                    "rejected_count": len(rejected),
                    "rejected_reasons": sorted({item.reason for item in rejected}),
                    "created_memory_ids": [memory.id for memory in created],
                },
            )
            self.repo.commit()
        except Exception:
            self.repo.rollback()
            raise
        return created

    def _build_memory(
        self,
        candidate: _ValidatedCandidate,
        *,
        entry: DiaryEntry,
        revision: DiaryRevision,
        envelope: ExtractionEnvelope,
    ) -> Memory:
        memory = Memory(
            content=candidate.content,
            content_hash=candidate.content_hash,
            memory_type=candidate.memory_type,
            source_type=MemorySourceType.DIARY_ENTRY.value,
            source_entry_id=entry.id,
            source_revision_id=revision.id,
            confidence=candidate.confidence,
            verification_status=VerificationStatus.PENDING.value,
            is_active=True,
            created_by=ACTOR_MODEL,
            metadata_json={
                "extraction": {
                    "provider": envelope.provider,
                    "model": envelope.model,
                    "revision_id": revision.id,
                    "revision_version": revision.version,
                    "match_mode": ("offsets" if candidate.start_offset is not None else "substring"),
                }
            },
        )
        memory.sources.append(
            MemorySource(
                entry_id=entry.id,
                revision_id=revision.id,
                evidence_text=candidate.evidence_text,
                start_offset=candidate.start_offset,
                end_offset=candidate.end_offset,
            )
        )
        return memory

    def _validate_memory_evidence(self, memory: Memory) -> None:
        """Re-verify copied evidence against immutable revision text."""

        revision_ids = {memory.source_revision_id} | {source.revision_id for source in memory.sources}
        revisions = self.repo.get_revisions(sorted(revision_ids))
        primary = revisions.get(memory.source_revision_id)
        if primary is None or primary.entry_id != memory.source_entry_id:
            raise ConflictError(
                "The memory's primary diary revision is missing or belongs to another entry",
                code="invalid_source_evidence",
                details={"memory_id": memory.id},
            )
        for source in memory.sources:
            revision = revisions.get(source.revision_id)
            if (
                revision is None
                or revision.entry_id != source.entry_id
                or sha256_text(revision.content) != revision.content_hash
                or source.evidence_text not in revision.content
            ):
                raise ConflictError(
                    "The memory has evidence that no longer matches its diary revision",
                    code="invalid_source_evidence",
                    details={"memory_id": memory.id, "source_id": source.id},
                )
            if source.start_offset is not None and source.end_offset is not None:
                if revision.content[source.start_offset : source.end_offset] != source.evidence_text:
                    raise ConflictError(
                        "The memory has evidence offsets that no longer match its diary revision",
                        code="invalid_source_evidence",
                        details={"memory_id": memory.id, "source_id": source.id},
                    )

    def _resolve_filters(
        self,
        *,
        memory_type: MemoryType | None,
        verification_status: VerificationStatus | None,
        entry_id: str | None,
        active: bool | None,
        include_deleted_sources: bool = False,
    ) -> MemoryListFilters:
        memory_type_value = memory_type.value if memory_type is not None else None
        if verification_status is not None:
            return MemoryListFilters(
                memory_type=memory_type_value,
                verification_status=verification_status.value,
                entry_id=entry_id,
                is_active=active,
                include_deleted_sources=include_deleted_sources,
            )
        if active is False:
            return MemoryListFilters(
                memory_type=memory_type_value,
                entry_id=entry_id,
                is_active=False,
                include_deleted_sources=include_deleted_sources,
            )
        return MemoryListFilters(
            memory_type=memory_type_value,
            entry_id=entry_id,
            is_active=True,
            exclude_statuses=(
                VerificationStatus.REVOKED.value,
                VerificationStatus.SUPERSEDED.value,
            ),
            include_deleted_sources=include_deleted_sources,
        )

    def _resolve_limit(self, limit: int | None) -> int:
        configured = limit if limit is not None else self.settings.default_page_size
        return max(1, min(configured, self.settings.max_page_size))

    def _content_limit(self) -> int:
        # The runtime evidence-width setting can only tighten the schema bound.
        return min(MAX_MEMORY_CONTENT_CHARS, self.settings.max_evidence_chars)

    def _get_memory_or_404(self, memory_id: str, *, include_deleted_sources: bool = False) -> Memory:
        memory = self.repo.get(memory_id)
        if memory is None:
            raise NotFoundError("Memory not found", details={"memory_id": memory_id})
        if (
            not include_deleted_sources
            and memory.source_entry is not None
            and memory.source_entry.deleted_at is not None
        ):
            # Derived memories follow the default-hidden policy when their source
            # diary is soft-deleted.  A caller can opt in explicitly via the
            # include_deleted_sources query parameter, and purge/review actions
            # by id remain possible because they are targeted operations.
            raise NotFoundError("Memory not found", details={"memory_id": memory_id})
        return memory

    def _memory_out(self, memory: Memory, *, source_version: int | None = None) -> MemoryOut:
        if source_version is None:
            revision = memory.source_revision
            source_version = revision.version if revision is not None else None
        sources = [
            MemorySourceOut.model_validate(source)
            for source in sorted(memory.sources, key=lambda item: (item.created_at, item.id))
        ]
        source_entry_deleted = bool(
            memory.source_entry is not None and memory.source_entry.deleted_at is not None
        )
        return MemoryOut(
            id=memory.id,
            content=memory.content,
            content_hash=memory.content_hash,
            memory_type=memory.memory_type,
            source_type=memory.source_type,
            confidence=memory.confidence,
            verification_status=memory.verification_status,
            is_active=memory.is_active,
            created_by=memory.created_by,
            confirmed_by=memory.confirmed_by,
            confirmed_at=memory.confirmed_at,
            revoked_at=memory.revoked_at,
            supersedes_memory_id=memory.supersedes_memory_id,
            source_entry_id=memory.source_entry_id,
            source_revision_id=memory.source_revision_id,
            source_version=source_version,
            source_entry_deleted=source_entry_deleted,
            created_at=memory.created_at,
            updated_at=memory.updated_at,
            metadata=dict(memory.metadata_json or {}),
            sources=sources,
        )

    def _commit(self) -> None:
        try:
            self.repo.commit()
        except Exception:
            self.repo.rollback()
            raise

    @staticmethod
    def _duplicate_rejection(index: int, memory_type: str) -> RejectedCandidate:
        return RejectedCandidate(
            index=index,
            reason=REASON_DUPLICATE_MEMORY,
            message="An identical memory already exists for this diary revision.",
            memory_type=memory_type,
        )

    @staticmethod
    def _rejected_details(rejected: list[RejectedCandidate]) -> list[dict[str, Any]]:
        return [item.model_dump() for item in rejected[:MAX_REJECTED_DETAILS]]
