"""Keyword search across diary revisions and active memories.

This is intentionally a transparent SQL substring search, not a semantic search
that could invent relevance.  Every hit points at a concrete revision; memory
hits also keep their primary diary/revision source.  Revoked and soft-deleted
records are excluded.
"""

from __future__ import annotations

from typing import Literal

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.config import Settings
from app.core.exceptions import ValidationError
from app.models.diary import DiaryEntry, DiaryRevision
from app.models.enums import VerificationStatus
from app.models.memory import Memory
from app.schemas.search import SearchHit, SearchResponse


def _escape_like(value: str) -> str:
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def _snippet(content: str, query: str, width: int = 70) -> str:
    normalised = " ".join(content.split())
    if not normalised:
        return ""
    lowered = normalised.lower()
    index = lowered.find(query.lower())
    if index < 0:
        return normalised if len(normalised) <= width * 2 else normalised[: width * 2] + "…"
    start = max(0, index - width)
    end = min(len(normalised), index + len(query) + width)
    prefix = "…" if start > 0 else ""
    suffix = "…" if end < len(normalised) else ""
    return prefix + normalised[start:end] + suffix


class SearchService:
    def __init__(self, session: Session, settings: Settings) -> None:
        self.session = session
        self.settings = settings

    def search(
        self,
        *,
        query: str,
        scope: Literal["all", "diaries", "memories"],
        include_history: bool,
        include_deleted_sources: bool = False,
        limit: int | None,
        offset: int,
    ) -> SearchResponse:
        q = query.strip()
        if not q:
            raise ValidationError("q must not be blank")
        if len(q) > 200:
            raise ValidationError("q is too long", details={"max_length": 200})
        effective_limit = min(limit or self.settings.default_page_size, self.settings.max_page_size)
        fetch = offset + effective_limit
        pattern = f"%{_escape_like(q)}%"
        diary_hits: list[SearchHit] = []
        memory_hits: list[SearchHit] = []
        diary_total = 0
        memory_total = 0

        if scope in ("all", "diaries"):
            diary_hits, diary_total = self._search_diaries(
                q=q,
                pattern=pattern,
                include_history=include_history,
                fetch=fetch,
            )
        if scope in ("all", "memories"):
            memory_hits, memory_total = self._search_memories(
                q=q,
                pattern=pattern,
                fetch=fetch,
                include_deleted_sources=include_deleted_sources,
            )

        merged = sorted(diary_hits + memory_hits, key=lambda hit: hit.created_at, reverse=True)
        page_items = merged[offset : offset + effective_limit]
        total = diary_total + memory_total
        return SearchResponse(
            query=q,
            scope=scope,
            include_history=include_history,
            include_deleted_sources=include_deleted_sources,
            total=total,
            limit=effective_limit,
            offset=offset,
            has_more=offset + len(page_items) < total,
            items=page_items,
        )

    def _search_diaries(
        self,
        *,
        q: str,
        pattern: str,
        include_history: bool,
        fetch: int,
    ) -> tuple[list[SearchHit], int]:
        stmt = (
            select(DiaryEntry, DiaryRevision)
            .join(DiaryRevision, DiaryRevision.entry_id == DiaryEntry.id)
            .where(
                DiaryEntry.deleted_at.is_(None),
                DiaryRevision.content.ilike(pattern, escape="\\"),
            )
        )
        if not include_history:
            stmt = stmt.where(DiaryRevision.id == DiaryEntry.current_revision_id)
        stmt = stmt.order_by(DiaryRevision.created_at.desc()).limit(fetch)
        rows = self.session.execute(stmt).all()
        current_ids = {entry.id: entry.current_revision_id for entry, _revision in rows}
        hits = [
            SearchHit(
                kind="diary",
                snippet=_snippet(revision.content, q),
                created_at=revision.created_at,
                entry_id=entry.id,
                revision_id=revision.id,
                version=revision.version,
                is_current=(revision.id == current_ids.get(entry.id)),
            )
            for entry, revision in rows
        ]
        count_stmt = (
            select(func.count())
            .select_from(DiaryRevision)
            .join(DiaryEntry, DiaryRevision.entry_id == DiaryEntry.id)
            .where(
                DiaryEntry.deleted_at.is_(None),
                DiaryRevision.content.ilike(pattern, escape="\\"),
            )
        )
        if not include_history:
            count_stmt = count_stmt.where(DiaryRevision.id == DiaryEntry.current_revision_id)
        total = int(self.session.scalar(count_stmt) or 0)
        return hits, total

    def _search_memories(
        self,
        *,
        q: str,
        pattern: str,
        fetch: int,
        include_deleted_sources: bool = False,
    ) -> tuple[list[SearchHit], int]:
        base_conditions = [
            Memory.is_active.is_(True),
            Memory.verification_status.notin_(
                [VerificationStatus.REVOKED.value, VerificationStatus.SUPERSEDED.value]
            ),
            Memory.content.ilike(pattern, escape="\\"),
        ]
        if not include_deleted_sources:
            base_conditions.append(DiaryEntry.deleted_at.is_(None))
        stmt = select(Memory)
        count_stmt = select(func.count()).select_from(Memory)
        if not include_deleted_sources:
            stmt = stmt.join(DiaryEntry, DiaryEntry.id == Memory.source_entry_id)
            count_stmt = count_stmt.join(DiaryEntry, DiaryEntry.id == Memory.source_entry_id)
        stmt = stmt.where(*base_conditions).order_by(Memory.created_at.desc()).limit(fetch)
        base_conditions = [
            Memory.is_active.is_(True),
            Memory.verification_status.notin_(
                [VerificationStatus.REVOKED.value, VerificationStatus.SUPERSEDED.value]
            ),
            Memory.content.ilike(pattern, escape="\\"),
        ]
        if not include_deleted_sources:
            base_conditions.append(DiaryEntry.deleted_at.is_(None))
        count_stmt = count_stmt.where(*base_conditions)
        memories = list(self.session.scalars(stmt))
        hits: list[SearchHit] = []
        for memory in memories:
            revision = self.session.get(DiaryRevision, memory.source_revision_id)
            if revision is None:
                continue
            entry = self.session.get(DiaryEntry, memory.source_entry_id)
            hits.append(
                SearchHit(
                    kind="memory",
                    snippet=_snippet(memory.content, q),
                    created_at=memory.created_at,
                    entry_id=memory.source_entry_id,
                    revision_id=memory.source_revision_id,
                    version=revision.version,
                    is_current=bool(entry and entry.current_revision_id == revision.id),
                    memory_id=memory.id,
                    memory_type=memory.memory_type,
                    verification_status=memory.verification_status,
                    confidence=memory.confidence,
                )
            )
        total = int(self.session.scalar(count_stmt) or 0)
        return hits, total
