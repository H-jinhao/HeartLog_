"""Backup primitives shared by the HeartLog backup/restore command-line tools.

The module is intentionally independent from the FastAPI application: it needs
only SQLite, ``cryptography`` and (for the CLI helpers) the configured database
path.  Keeping the logic here lets the scripts stay thin and makes every
guarantee unit-testable without starting the server.

Encrypted backup format (all integers big-endian)::

    MAGIC          b"HEARTLOG-BACKUP-ENC-v1\\n"          (fixed, versioned)
    header_length  uint32
    header_json    UTF-8 canonical JSON (see ``_build_encryption_header``)
    ciphertext     AES-256-GCM stream ciphertext
    tag            16-byte AES-GCM authentication tag

The header is authenticated as AEAD associated data, so changing the KDF
parameters, salt or nonce makes decryption fail.  A fresh random 16-byte salt
and 12-byte nonce are generated for every backup; the AES-256 key is derived
with Scrypt.

Privacy rules enforced by this module:

* the passphrase is never stored in the backup, the manifest, logs, argv or
  error messages;
* manifests and drill reports contain metadata only (paths, hashes of the
  backup container, row counts, cipher/KDF parameters, record IDs and issue
  codes) -- never diary/memory text and never a hash of the plaintext database;
* retention only deletes HeartLog's own auto-named backups that are accompanied
  by a self-consistent ``.sha256`` sidecar and ``.json`` manifest.
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import re
import sqlite3
import struct
import tempfile
import urllib.parse
from collections.abc import Iterable
from contextlib import closing
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

from app import __version__
from app.core.hashing import sha256_text

LOGGER = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Format constants
# ---------------------------------------------------------------------------

MAGIC = b"HEARTLOG-BACKUP-ENC-v1\n"
ENCRYPTED_FORMAT = "heartlog.encrypted-backup"
ENCRYPTED_FORMAT_VERSION = 1
MANIFEST_FORMAT = "heartlog.backup"
MANIFEST_FORMAT_VERSION = 2

CIPHER = "AES-256-GCM"
KDF = "scrypt"
KEY_LENGTH = 32
SALT_LENGTH = 16
NONCE_LENGTH = 12
GCM_TAG_LENGTH = 16
SCRYPT_N = 2**14
SCRYPT_R = 8
SCRYPT_P = 1
_MAX_HEADER_BYTES = 64 * 1024
_CHUNK_SIZE = 1024 * 1024

# Scrypt bounds accepted while decrypting.  They protect a restore/drill from a
# malicious header that tries to make the KDF allocate absurd amounts of memory.
_SCRYPT_N_MIN, _SCRYPT_N_MAX = 2**10, 2**20
_SCRYPT_R_MIN, _SCRYPT_R_MAX = 1, 32
_SCRYPT_P_MIN, _SCRYPT_P_MAX = 1, 16

DEFAULT_PASSPHRASE_ENV = "HEARTLOG_BACKUP_PASSPHRASE"
DEFAULT_RETENTION = 14
ENCRYPTED_SUFFIX = ".db.enc"
PLAIN_SUFFIX = ".db"

# Auto-generated names are the only files retention may ever delete.
AUTO_BACKUP_RE = re.compile(r"^heartlog-(\d{8}T\d{6}Z)\.db(?:\.enc)?$")
_AUTO_TIME_FORMAT = "%Y%m%dT%H%M%SZ"
_ENV_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,127}$")
_HEX64_RE = re.compile(r"^[0-9a-f]{64}$")
_SAFE_LABEL_RE = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")

# Tables every HeartLog backup must contain for the restore drill to pass.
# ``alembic_version`` is reported when present but is not required (the app can
# create the schema through ``create_all`` during development).
EXPECTED_TABLES: tuple[str, ...] = (
    "audit_events",
    "conversations",
    "diary_entries",
    "diary_revisions",
    "memories",
    "memory_sources",
    "messages",
    "persons",
)


class BackupError(RuntimeError):
    """A clear, content-free backup/restore failure for CLI callers."""


# ---------------------------------------------------------------------------
# Small file helpers
# ---------------------------------------------------------------------------


def sha256_file(path: Path) -> str:
    """Return the hex SHA-256 digest of a file (read in bounded chunks)."""

    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(_CHUNK_SIZE), b""):
            digest.update(chunk)
    return digest.hexdigest()


def checksum_path(backup: Path) -> Path:
    """Sibling ``<backup>.sha256`` path."""

    backup = Path(backup)
    return backup.with_name(backup.name + ".sha256")


def manifest_path(backup: Path) -> Path:
    """Sibling ``<backup>.json`` manifest path."""

    backup = Path(backup)
    return backup.with_name(backup.name + ".json")


def _atomic_write_text(path: Path, text: str) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    try:
        temporary.write_text(text, encoding="utf-8")
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def read_manifest(backup: Path) -> dict[str, Any] | None:
    """Read the JSON manifest for *backup*, or return ``None`` when absent.

    A manifest that exists but is not a JSON object is an error: silently
    ignoring it could hide tampering.
    """

    path = manifest_path(backup)
    if not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise BackupError(f"Backup manifest is missing or invalid JSON: {path}") from exc
    if not isinstance(payload, dict):
        raise BackupError(f"Backup manifest is not a JSON object: {path}")
    return payload


def is_encrypted(backup: Path) -> bool:
    """Whether *backup* starts with the versioned HeartLog ciphertext magic."""

    backup = Path(backup)
    try:
        with backup.open("rb") as handle:
            return handle.read(len(MAGIC)) == MAGIC
    except OSError:
        return False


# ---------------------------------------------------------------------------
# Naming and configured paths
# ---------------------------------------------------------------------------


def auto_backup_filename(*, encrypted: bool, now: datetime | None = None) -> str:
    """Name for a HeartLog-generated backup (the only prunable name shape)."""

    stamp = (now or datetime.now(UTC)).astimezone(UTC).strftime(_AUTO_TIME_FORMAT)
    suffix = ENCRYPTED_SUFFIX if encrypted else PLAIN_SUFFIX
    return f"heartlog-{stamp}{suffix}"


def parse_auto_backup_time(name: str) -> datetime | None:
    """Parse the UTC timestamp from an auto-generated backup name."""

    match = AUTO_BACKUP_RE.match(name)
    if match is None:
        return None
    try:
        return datetime.strptime(match.group(1), _AUTO_TIME_FORMAT).replace(tzinfo=UTC)
    except ValueError:
        return None


def configured_database_path() -> Path:
    """Resolve the file-backed SQLite database path from application settings."""

    from sqlalchemy.engine import make_url

    from app.core.config import get_settings

    url = make_url(get_settings().database_url)
    if url.get_backend_name() != "sqlite" or not url.database or url.database == ":memory:":
        raise BackupError("Only file-backed SQLite databases are supported.")
    return Path(url.database)


def configured_backup_dir() -> Path:
    """Resolve the configured backup directory from application settings."""

    from app.core.config import get_settings

    return Path(get_settings().backup_dir)


# ---------------------------------------------------------------------------
# Passphrase handling
# ---------------------------------------------------------------------------


def _validate_passphrase(passphrase: object) -> str:
    if not isinstance(passphrase, str) or not passphrase:
        raise BackupError(
            "Backup passphrase is empty. Set a strong passphrase; it is never written to disk or logs."
        )
    return passphrase


def resolve_passphrase(
    explicit: str | None = None,
    *,
    env_name: str = DEFAULT_PASSPHRASE_ENV,
) -> str:
    """Return the passphrase from an explicit value or an env-var indirection.

    Command-line tools must never take the passphrase itself as a flag: it would
    appear in process listings and shell history.  They pass the *name* of the
    environment variable instead (``--passphrase-env``).
    """

    if not isinstance(env_name, str) or _ENV_NAME_RE.match(env_name) is None:
        raise BackupError(f"Invalid passphrase environment variable name: {env_name!r}")
    if explicit is not None:
        return _validate_passphrase(explicit)
    value = os.environ.get(env_name)
    if not value:
        raise BackupError(
            f"Backup passphrase is not set. Export {env_name} before running an encrypted "
            "backup, restore or drill. The passphrase is never stored in the backup, "
            "manifest, argv or logs."
        )
    return _validate_passphrase(value)


# ---------------------------------------------------------------------------
# AES-256-GCM container
# ---------------------------------------------------------------------------


def _derive_key(passphrase: str, salt: bytes, *, n: int, r: int, p: int) -> bytes:
    kdf = Scrypt(salt=salt, length=KEY_LENGTH, n=n, r=r, p=p)
    return kdf.derive(passphrase.encode("utf-8"))


def _b64e(value: bytes) -> str:
    return base64.b64encode(value).decode("ascii")


def _b64d(value: object, *, field: str) -> bytes:
    if not isinstance(value, str):
        raise BackupError(f"Encrypted backup header field {field!r} is invalid.")
    try:
        return base64.b64decode(value.encode("ascii"), validate=True)
    except (ValueError, UnicodeEncodeError) as exc:
        raise BackupError(f"Encrypted backup header field {field!r} is not valid base64.") from exc


def _encryption_header(salt: bytes, nonce: bytes) -> dict[str, Any]:
    return {
        "format": ENCRYPTED_FORMAT,
        "version": ENCRYPTED_FORMAT_VERSION,
        "cipher": CIPHER,
        "kdf": KDF,
        "kdf_params": {
            "n": SCRYPT_N,
            "r": SCRYPT_R,
            "p": SCRYPT_P,
            "length": KEY_LENGTH,
            "salt_b64": _b64e(salt),
        },
        "nonce_b64": _b64e(nonce),
        "created_at": datetime.now(UTC).isoformat(),
        "app_version": __version__,
    }


def _header_prefix(header: dict[str, Any]) -> bytes:
    header_bytes = json.dumps(header, sort_keys=True, separators=(",", ":")).encode("utf-8")
    if len(header_bytes) > _MAX_HEADER_BYTES:
        raise BackupError("Encrypted backup header is unexpectedly large.")
    return MAGIC + struct.pack(">I", len(header_bytes)) + header_bytes


def _read_header(handle: Any) -> tuple[dict[str, Any], bytes]:
    """Read and validate the versioned header from an opened binary file."""

    magic = handle.read(len(MAGIC))
    if magic != MAGIC:
        raise BackupError("Not a HeartLog encrypted backup (unknown or unsupported format/version).")
    length_bytes = handle.read(4)
    if len(length_bytes) != 4:
        raise BackupError("Encrypted backup is truncated: missing header length.")
    header_length = struct.unpack(">I", length_bytes)[0]
    if not 0 < header_length <= _MAX_HEADER_BYTES:
        raise BackupError("Encrypted backup header length is invalid.")
    header_bytes = handle.read(header_length)
    if len(header_bytes) != header_length:
        raise BackupError("Encrypted backup is truncated: incomplete header.")
    try:
        header = json.loads(header_bytes.decode("utf-8"))
    except (ValueError, UnicodeDecodeError) as exc:
        raise BackupError("Encrypted backup header is not valid JSON.") from exc
    if not isinstance(header, dict):
        raise BackupError("Encrypted backup header is not a JSON object.")
    if header.get("format") != ENCRYPTED_FORMAT:
        raise BackupError("Unsupported encrypted backup format name.")
    if header.get("version") != ENCRYPTED_FORMAT_VERSION:
        raise BackupError(f"Unsupported encrypted backup format version: {header.get('version')!r}.")
    if header.get("cipher") != CIPHER:
        raise BackupError("Unsupported encrypted backup cipher (only AES-256-GCM is supported).")
    if header.get("kdf") != KDF:
        raise BackupError("Unsupported encrypted backup KDF (only scrypt is supported).")
    return header, MAGIC + length_bytes + header_bytes


def _scrypt_params(header: dict[str, Any]) -> tuple[bytes, bytes, int, int, int]:
    params = header.get("kdf_params")
    if not isinstance(params, dict):
        raise BackupError("Encrypted backup header is missing Scrypt parameters.")
    n, r, p, length = params.get("n"), params.get("r"), params.get("p"), params.get("length")
    if not all(isinstance(value, int) and not isinstance(value, bool) for value in (n, r, p, length)):
        raise BackupError("Encrypted backup Scrypt parameters are invalid.")
    if not _SCRYPT_N_MIN <= n <= _SCRYPT_N_MAX or n & (n - 1):
        raise BackupError("Encrypted backup Scrypt cost parameter is out of range.")
    if not _SCRYPT_R_MIN <= r <= _SCRYPT_R_MAX:
        raise BackupError("Encrypted backup Scrypt block-size parameter is out of range.")
    if not _SCRYPT_P_MIN <= p <= _SCRYPT_P_MAX:
        raise BackupError("Encrypted backup Scrypt parallelism parameter is out of range.")
    if length != KEY_LENGTH:
        raise BackupError("Encrypted backup key length is not 32 bytes.")
    salt = _b64d(params.get("salt_b64"), field="salt_b64")
    if not 8 <= len(salt) <= 64:
        raise BackupError("Encrypted backup salt length is invalid.")
    nonce = _b64d(header.get("nonce_b64"), field="nonce_b64")
    if len(nonce) != NONCE_LENGTH:
        raise BackupError("Encrypted backup nonce length is invalid.")
    return salt, nonce, n, r, p


def encrypt_file(source: Path, destination: Path, passphrase: str) -> dict[str, Any]:
    """Encrypt *source* into a versioned AES-256-GCM container."""

    source, destination = Path(source), Path(destination)
    if not source.is_file():
        raise BackupError(f"Source file does not exist: {source}")
    if destination.exists():
        raise BackupError(f"Refusing to overwrite existing encrypted backup: {destination}")
    passphrase = _validate_passphrase(passphrase)
    destination.parent.mkdir(parents=True, exist_ok=True)

    salt = os.urandom(SALT_LENGTH)
    nonce = os.urandom(NONCE_LENGTH)
    header = _encryption_header(salt, nonce)
    prefix = _header_prefix(header)
    key = _derive_key(passphrase, salt, n=SCRYPT_N, r=SCRYPT_R, p=SCRYPT_P)

    partial = destination.with_name(destination.name + ".partial")
    partial.unlink(missing_ok=True)
    try:
        encryptor = Cipher(algorithms.AES(key), modes.GCM(nonce)).encryptor()
        encryptor.authenticate_additional_data(prefix)
        with source.open("rb") as source_handle, partial.open("wb") as target_handle:
            target_handle.write(prefix)
            for chunk in iter(lambda: source_handle.read(_CHUNK_SIZE), b""):
                target_handle.write(encryptor.update(chunk))
            target_handle.write(encryptor.finalize())
            target_handle.write(encryptor.tag)
        os.replace(partial, destination)
    except BaseException:
        partial.unlink(missing_ok=True)
        raise
    return header


def decrypt_file(encrypted: Path, destination: Path, passphrase: str) -> dict[str, Any]:
    """Decrypt a HeartLog AES-256-GCM container into *destination*.

    Raises :class:`BackupError` with a clear message for a wrong passphrase, a
    corrupted/tampered container or an unsupported format version.
    """

    encrypted, destination = Path(encrypted), Path(destination)
    if not encrypted.is_file():
        raise BackupError(f"Backup does not exist: {encrypted}")
    if destination.exists():
        raise BackupError(f"Refusing to overwrite existing file while decrypting: {destination}")
    passphrase = _validate_passphrase(passphrase)
    destination.parent.mkdir(parents=True, exist_ok=True)

    partial = destination.with_name(destination.name + ".partial")
    partial.unlink(missing_ok=True)
    try:
        with encrypted.open("rb") as handle:
            header, prefix = _read_header(handle)
            salt, nonce, n, r, p = _scrypt_params(header)
            file_size = encrypted.stat().st_size
            ciphertext_length = file_size - len(prefix) - GCM_TAG_LENGTH
            if ciphertext_length < 0:
                raise BackupError("Encrypted backup is truncated: missing authentication tag.")
            handle.seek(-GCM_TAG_LENGTH, os.SEEK_END)
            tag = handle.read(GCM_TAG_LENGTH)
            if len(tag) != GCM_TAG_LENGTH:
                raise BackupError("Encrypted backup is truncated: missing authentication tag.")
            handle.seek(len(prefix))
            key = _derive_key(passphrase, salt, n=n, r=r, p=p)
            decryptor = Cipher(algorithms.AES(key), modes.GCM(nonce, tag)).decryptor()
            decryptor.authenticate_additional_data(prefix)
            remaining = ciphertext_length
            with partial.open("wb") as target_handle:
                while remaining:
                    chunk = handle.read(min(_CHUNK_SIZE, remaining))
                    if not chunk:
                        raise BackupError("Encrypted backup is truncated.")
                    remaining -= len(chunk)
                    target_handle.write(decryptor.update(chunk))
                target_handle.write(decryptor.finalize())
        os.replace(partial, destination)
    except InvalidTag as exc:
        partial.unlink(missing_ok=True)
        raise BackupError(
            "Failed to decrypt backup: wrong passphrase, or the file was corrupted/tampered with."
        ) from exc
    except BackupError:
        partial.unlink(missing_ok=True)
        raise
    except OSError as exc:
        partial.unlink(missing_ok=True)
        raise BackupError(f"Could not read or write backup file: {exc}") from exc
    except Exception as exc:  # pragma: no cover - defensive cryptography/parse errors
        partial.unlink(missing_ok=True)
        raise BackupError("Failed to decrypt backup: the file is not a valid encrypted backup.") from exc
    return header


# ---------------------------------------------------------------------------
# SQLite helpers
# ---------------------------------------------------------------------------


def _quote_identifier(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def _table_counts(connection: sqlite3.Connection) -> dict[str, int]:
    names = [
        row[0]
        for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
        )
    ]
    return {
        name: connection.execute(f"SELECT COUNT(*) FROM {_quote_identifier(name)}").fetchone()[0]
        for name in names
    }


def _write_sqlite_copy(source: Path, destination: Path) -> tuple[str, dict[str, int]]:
    """Copy a live SQLite database with the online backup API and verify it."""

    source, destination = Path(source), Path(destination)
    if not source.is_file():
        raise BackupError(f"Source database does not exist: {source}")
    if destination.exists():
        raise BackupError(f"Refusing to overwrite existing file: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        with (
            closing(sqlite3.connect(source)) as source_connection,
            closing(sqlite3.connect(destination)) as target_connection,
        ):
            source_connection.backup(target_connection)
            rows = target_connection.execute("PRAGMA integrity_check").fetchall()
            integrity = "ok" if rows == [("ok",)] else "failed"
            table_counts = _table_counts(target_connection)
    except sqlite3.Error as exc:
        destination.unlink(missing_ok=True)
        raise BackupError(f"SQLite backup failed: {exc}") from exc
    if integrity != "ok":
        destination.unlink(missing_ok=True)
        raise BackupError("Backup integrity check failed.")
    return integrity, table_counts


def _sqlite_readonly_uri(path: Path) -> str:
    """``file:`` URI that opens *path* read-only and never mutates it.

    ``immutable=1`` is important: a backup copied from a WAL-mode database keeps
    the WAL flag in its header, and a plain read-only connection could otherwise
    try to create ``-shm``/``-wal`` sidecars next to the backup.
    """

    posix = Path(path).resolve().as_posix()
    encoded = urllib.parse.quote(posix, safe="/:")
    return f"file:{encoded}?mode=ro&immutable=1"


def sqlite_integrity_check(path: Path) -> str:
    """Run ``PRAGMA integrity_check`` on *path* without writing to it."""

    path = Path(path)
    if not path.is_file():
        raise BackupError(f"Database file does not exist: {path}")
    try:
        with closing(sqlite3.connect(_sqlite_readonly_uri(path), uri=True)) as connection:
            connection.execute("PRAGMA query_only=ON")
            rows = connection.execute("PRAGMA integrity_check").fetchall()
    except sqlite3.Error as exc:
        raise BackupError(f"Could not read SQLite file read-only: {exc}") from exc
    return "ok" if rows == [("ok",)] else "failed"


# ---------------------------------------------------------------------------
# Backup creation
# ---------------------------------------------------------------------------


def _manifest_common(
    *,
    source: Path,
    destination: Path,
    digest: str,
    integrity: str,
    table_counts: dict[str, int],
    encrypted: bool,
) -> dict[str, Any]:
    return {
        "app_version": __version__,
        "created_at": datetime.now(UTC).isoformat(),
        "format": MANIFEST_FORMAT,
        "format_version": MANIFEST_FORMAT_VERSION,
        "source": str(source),
        "backup": str(destination),
        "encrypted": encrypted,
        "sha256": digest,
        "size_bytes": destination.stat().st_size,
        "integrity_check": integrity,
        "table_counts": table_counts,
    }


def _write_metadata(destination: Path, manifest: dict[str, Any]) -> None:
    _atomic_write_text(checksum_path(destination), str(manifest["sha256"]) + "\n")
    _atomic_write_text(
        manifest_path(destination),
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
    )


def create_plaintext_backup(source: Path, destination: Path) -> dict[str, Any]:
    """Create a verified plaintext SQLite backup with sidecar and manifest.

    The backup file itself is not encrypted.  ``--encrypt`` exists for that and
    is recommended whenever the backup leaves an encrypted disk.
    """

    source, destination = Path(source), Path(destination)
    if not source.is_file():
        raise BackupError(f"Source database does not exist: {source}")
    if destination.exists():
        raise BackupError(f"Refusing to overwrite existing backup: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)

    partial = destination.with_name(destination.name + ".partial")
    partial.unlink(missing_ok=True)
    created = False
    try:
        integrity, table_counts = _write_sqlite_copy(source, partial)
        os.replace(partial, destination)
        created = True
        manifest = _manifest_common(
            source=source,
            destination=destination,
            digest=sha256_file(destination),
            integrity=integrity,
            table_counts=table_counts,
            encrypted=False,
        )
        _write_metadata(destination, manifest)
    except BaseException:
        partial.unlink(missing_ok=True)
        if created:
            destination.unlink(missing_ok=True)
            checksum_path(destination).unlink(missing_ok=True)
            manifest_path(destination).unlink(missing_ok=True)
        raise
    return manifest


def create_encrypted_backup(source: Path, destination: Path, passphrase: str) -> dict[str, Any]:
    """Create an encrypted (AES-256-GCM + Scrypt) backup of a SQLite database.

    A verified plaintext SQLite copy is built in a private temporary directory,
    encrypted into *destination*, and the temporary plaintext is removed before
    returning.  The manifest records the ciphertext SHA-256 and cipher/KDF
    parameters, never the passphrase or any plaintext hash.
    """

    source, destination = Path(source), Path(destination)
    if not source.is_file():
        raise BackupError(f"Source database does not exist: {source}")
    if destination.exists():
        raise BackupError(f"Refusing to overwrite existing backup: {destination}")
    passphrase = _validate_passphrase(passphrase)
    destination.parent.mkdir(parents=True, exist_ok=True)

    created = False
    try:
        with tempfile.TemporaryDirectory(prefix="heartlog-encrypt-") as temp_dir:
            staging = Path(temp_dir) / "payload.db"
            integrity, table_counts = _write_sqlite_copy(source, staging)
            header = encrypt_file(staging, destination, passphrase)
        created = True
        manifest = _manifest_common(
            source=source,
            destination=destination,
            digest=sha256_file(destination),
            integrity=integrity,
            table_counts=table_counts,
            encrypted=True,
        )
        manifest.update(
            {
                "cipher": CIPHER,
                "kdf": KDF,
                "kdf_params": dict(header["kdf_params"]),
                "nonce_b64": header["nonce_b64"],
                "header_version": header["version"],
            }
        )
        _write_metadata(destination, manifest)
    except BaseException:
        if created:
            destination.unlink(missing_ok=True)
            checksum_path(destination).unlink(missing_ok=True)
            manifest_path(destination).unlink(missing_ok=True)
        raise
    return manifest


# ---------------------------------------------------------------------------
# Verification and retention
# ---------------------------------------------------------------------------


def verify_backup_file(backup: Path) -> dict[str, Any]:
    """Verify checksum/manifest consistency without decrypting the payload.

    Returns metadata about the file; raises :class:`BackupError` on a checksum
    mismatch, an inconsistent manifest or an unreadable file.  The returned dict
    never contains private record content.
    """

    backup = Path(backup)
    if not backup.is_file():
        raise BackupError(f"Backup does not exist: {backup}")
    encrypted = is_encrypted(backup)
    manifest = read_manifest(backup)
    actual_sha256 = sha256_file(backup)

    sidecar_expected: str | None = None
    sidecar = checksum_path(backup)
    if sidecar.is_file():
        try:
            tokens = sidecar.read_text(encoding="utf-8").strip().split()
        except OSError as exc:
            raise BackupError(f"Could not read checksum file: {sidecar}") from exc
        if not tokens:
            raise BackupError(f"Checksum file is empty: {sidecar}")
        sidecar_expected = tokens[0].lower()
        if _HEX64_RE.match(sidecar_expected) is None:
            raise BackupError(f"Checksum file does not contain a SHA-256 digest: {sidecar}")
        if sidecar_expected != actual_sha256:
            raise BackupError(
                "Backup checksum mismatch: the file was modified or corrupted after it was "
                "created; refusing to trust this backup."
            )

    if manifest is not None:
        manifest_encrypted = bool(manifest.get("encrypted", False))
        if manifest_encrypted != encrypted:
            raise BackupError(
                "Backup manifest encryption state does not match the file contents; "
                "refusing to trust this backup."
            )
        expected_sha256 = manifest.get("sha256")
        if expected_sha256 is not None:
            if not isinstance(expected_sha256, str) or _HEX64_RE.match(expected_sha256.lower()) is None:
                raise BackupError(
                    f"Backup manifest contains an invalid SHA-256 value: {manifest_path(backup)}"
                )
            if expected_sha256.lower() != actual_sha256:
                raise BackupError(
                    "Backup manifest SHA-256 does not match the file; the backup file or its "
                    "manifest was modified."
                )
        expected_size = manifest.get("size_bytes")
        if isinstance(expected_size, int) and expected_size != backup.stat().st_size:
            raise BackupError("Backup manifest size does not match the file; refusing to trust this backup.")

    checksum_verified = bool(sidecar_expected) or bool(manifest and manifest.get("sha256"))
    return {
        "backup": str(backup),
        "encrypted": encrypted,
        "sha256": actual_sha256,
        "size_bytes": backup.stat().st_size,
        "has_sidecar": sidecar_expected is not None,
        "has_manifest": manifest is not None,
        "checksum_verified": checksum_verified,
        "manifest": manifest,
    }


def _safe_label(value: object) -> str:
    """Render an untrusted identifier without echoing arbitrary database text.

    A restore drill may be pointed at a tampered backup whose id/table columns
    contain arbitrary content.  Only short identifier-shaped values are echoed
    verbatim; anything else becomes a stable digest prefix so reports never
    reproduce private content.
    """

    text = str(value)
    if _SAFE_LABEL_RE.match(text):
        return text
    return "digest:" + hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()[:12]


def _retention_metadata_ok(backup: Path) -> bool:
    """Whether an auto-named file has self-consistent metadata worth deleting."""

    try:
        manifest = read_manifest(backup)
        if manifest is None:
            return False
        digest = manifest.get("sha256")
        if not isinstance(digest, str) or _HEX64_RE.match(digest.lower()) is None:
            return False
        recorded_name = manifest.get("backup")
        if recorded_name is not None and Path(str(recorded_name)).name != backup.name:
            return False
        expected_size = manifest.get("size_bytes")
        if isinstance(expected_size, int) and expected_size != backup.stat().st_size:
            return False
        if bool(manifest.get("encrypted", False)) != is_encrypted(backup):
            return False
        sidecar = checksum_path(backup)
        if not sidecar.is_file():
            return False
        tokens = sidecar.read_text(encoding="utf-8").strip().split()
        return bool(tokens) and tokens[0].lower() == digest.lower()
    except (BackupError, OSError, ValueError):
        return False


def prune_backups(
    directory: Path,
    retention: int,
    *,
    protected: Iterable[Path] = (),
) -> list[Path]:
    """Delete old auto-generated backups according to *retention*.

    ``retention=0`` means unlimited (no pruning).  Only files whose name matches
    HeartLog's own auto-generated pattern **and** that carry a self-consistent
    ``.sha256`` sidecar plus ``.json`` manifest are candidates; manually named
    files, foreign files and backups with missing/invalid metadata are always
    kept.  Returns the list of deleted backup paths.
    """

    if isinstance(retention, bool) or not isinstance(retention, int) or retention < 0:
        raise BackupError("Retention must be a non-negative integer (0 means unlimited).")
    if retention == 0:
        return []
    directory = Path(directory)
    if not directory.is_dir():
        return []

    protected_names = {Path(path).resolve() for path in protected}
    candidates: list[tuple[datetime, str, Path]] = []
    for entry in directory.iterdir():
        if not entry.is_file() or entry.is_symlink():
            continue
        parsed = parse_auto_backup_time(entry.name)
        if parsed is None:
            continue
        if not _retention_metadata_ok(entry):
            LOGGER.warning(
                "retention_skipped_unsafe_metadata file=%s reason=missing_or_invalid_metadata",
                entry.name,
            )
            continue
        candidates.append((parsed, entry.name, entry))

    candidates.sort(key=lambda item: (item[0], item[1]), reverse=True)
    deleted: list[Path] = []
    # Delete oldest first for predictable output.  ``protected`` (the backup that
    # was just created) participates in the quota count but is never removed,
    # even if the system clock moved backwards.
    for _, _, entry in reversed(candidates[retention:]):
        if entry.resolve() in protected_names:
            LOGGER.warning("retention_skipped_protected backup=%s", entry.name)
            continue
        for path in (entry, checksum_path(entry), manifest_path(entry)):
            path.unlink(missing_ok=True)
        deleted.append(entry)
        LOGGER.info("retention_deleted backup=%s", entry.name)
    return deleted


# ---------------------------------------------------------------------------
# Read-only restore drill
# ---------------------------------------------------------------------------


def _collect_diary_issues(connection: sqlite3.Connection) -> tuple[list[str], list[str], int, int]:
    """Return (original-hash issues, revision-chain issues, entries, revisions)."""

    hash_issues: list[str] = []
    chain_issues: list[str] = []
    entry_count = 0
    revision_count = 0
    entries = connection.execute(
        "SELECT id, original_text, original_content_hash, current_version, current_revision_id "
        "FROM diary_entries"
    ).fetchall()
    for entry_id, original_text, recorded_hash, current_version, current_revision_id in entries:
        entry_count += 1
        label = _safe_label(entry_id)
        if sha256_text(original_text or "") != (recorded_hash or ""):
            hash_issues.append(f"diary:{label}:original_hash_mismatch")
        revisions = connection.execute(
            "SELECT id, version, content, content_hash, previous_revision_hash "
            "FROM diary_revisions WHERE entry_id = ? ORDER BY version ASC",
            (entry_id,),
        ).fetchall()
        revision_count += len(revisions)
        expected_previous: str | None = None
        for expected_version, revision in enumerate(revisions, start=1):
            _revision_id, version, content, content_hash, previous_hash = revision
            if version != expected_version:
                chain_issues.append(f"diary:{label}:version_sequence_gap:v{version}")
            if sha256_text(content or "") != (content_hash or ""):
                chain_issues.append(f"diary:{label}:revision_hash_mismatch:v{version}")
            if previous_hash != expected_previous:
                chain_issues.append(f"diary:{label}:revision_chain_mismatch:v{version}")
            expected_previous = content_hash
        if len(revisions) != current_version:
            chain_issues.append(f"diary:{label}:revision_count_mismatch")
        latest_revision_id = revisions[-1][0] if revisions else None
        if current_revision_id != latest_revision_id:
            chain_issues.append(f"diary:{label}:current_pointer_mismatch")
    return hash_issues, chain_issues, entry_count, revision_count


def _collect_memory_issues(
    connection: sqlite3.Connection,
) -> tuple[list[str], list[str], list[str], list[str], int, int]:
    """Return (hash, source, evidence, offset issues, memories, sources)."""

    hash_issues: list[str] = []
    source_issues: list[str] = []
    evidence_issues: list[str] = []
    offset_issues: list[str] = []
    memory_count = 0
    source_count = 0
    memories = connection.execute(
        "SELECT id, content, content_hash, source_entry_id, source_revision_id FROM memories"
    ).fetchall()
    for memory_id, content, content_hash, source_entry_id, source_revision_id in memories:
        memory_count += 1
        label = _safe_label(memory_id)
        if sha256_text(content or "") != (content_hash or ""):
            hash_issues.append(f"memory:{label}:content_hash_mismatch")
        sources = connection.execute(
            "SELECT entry_id, revision_id, evidence_text, start_offset, end_offset "
            "FROM memory_sources WHERE memory_id = ?",
            (memory_id,),
        ).fetchall()
        source_count += len(sources)
        if not sources:
            source_issues.append(f"memory:{label}:no_evidence_sources")
            continue
        if not any(
            entry_id == source_entry_id and revision_id == source_revision_id
            for entry_id, revision_id, *_rest in sources
        ):
            source_issues.append(f"memory:{label}:primary_source_not_in_sources")
        for entry_id, revision_id, evidence_text, start_offset, end_offset in sources:
            revision = connection.execute(
                "SELECT entry_id, content FROM diary_revisions WHERE id = ?", (revision_id,)
            ).fetchone()
            if revision is None:
                source_issues.append(f"memory:{label}:source_revision_missing")
                continue
            revision_entry_id, revision_content = revision
            if revision_entry_id != entry_id:
                source_issues.append(f"memory:{label}:source_revision_entry_mismatch")
            if (evidence_text or "") not in (revision_content or ""):
                evidence_issues.append(f"memory:{label}:evidence_not_in_revision")
            if start_offset is not None and end_offset is not None:
                valid_offsets = 0 <= start_offset <= end_offset <= len(revision_content or "")
                if not valid_offsets or (revision_content or "")[start_offset:end_offset] != evidence_text:
                    offset_issues.append(f"memory:{label}:evidence_offset_mismatch")
    return hash_issues, source_issues, evidence_issues, offset_issues, memory_count, source_count


def inspect_database(path: Path) -> dict[str, Any]:
    """Read-only integrity/invariant inspection of a HeartLog SQLite database.

    The returned dict contains only metadata (table names/counts, record IDs and
    issue codes) -- never diary or memory text.  Raises :class:`BackupError` when
    the file cannot be opened as SQLite at all.
    """

    path = Path(path)
    if not path.is_file():
        raise BackupError(f"Database file does not exist: {path}")
    try:
        connection = sqlite3.connect(_sqlite_readonly_uri(path), uri=True)
    except sqlite3.Error as exc:
        raise BackupError(f"Could not open database read-only: {exc}") from exc

    try:
        connection.execute("PRAGMA query_only=ON")
        integrity_rows = connection.execute("PRAGMA integrity_check").fetchall()
        integrity = "ok" if integrity_rows == [("ok",)] else "failed"

        tables = {
            row[0]
            for row in connection.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            )
        }
        missing_tables = [name for name in EXPECTED_TABLES if name not in tables]
        table_counts = {
            name: connection.execute(f"SELECT COUNT(*) FROM {_quote_identifier(name)}").fetchone()[0]
            for name in EXPECTED_TABLES
            if name in tables
        }

        foreign_key_violations = connection.execute("PRAGMA foreign_key_check").fetchall()
        foreign_key_issue_tables = sorted({_safe_label(row[0]) for row in foreign_key_violations})

        diary_hash_issues: list[str] = []
        diary_chain_issues: list[str] = []
        memory_hash_issues: list[str] = []
        memory_source_issues: list[str] = []
        memory_evidence_issues: list[str] = []
        memory_offset_issues: list[str] = []
        entry_count = revision_count = memory_count = source_count = 0

        if not missing_tables:
            diary_hash_issues, diary_chain_issues, entry_count, revision_count = _collect_diary_issues(
                connection
            )
            (
                memory_hash_issues,
                memory_source_issues,
                memory_evidence_issues,
                memory_offset_issues,
                memory_count,
                source_count,
            ) = _collect_memory_issues(connection)
    except sqlite3.Error as exc:
        raise BackupError(f"Could not read SQLite database: {exc}") from exc
    finally:
        connection.close()

    issues: list[str] = []
    if integrity != "ok":
        issues.append("integrity_check_failed")
    issues.extend(f"missing_table:{name}" for name in missing_tables)
    issues.extend(f"foreign_key_violation:{name}" for name in foreign_key_issue_tables)
    issues.extend(diary_hash_issues)
    issues.extend(diary_chain_issues)
    issues.extend(memory_hash_issues)
    issues.extend(memory_source_issues)
    issues.extend(memory_evidence_issues)
    issues.extend(memory_offset_issues)

    checks = [
        {
            "name": "integrity_check",
            "ok": integrity == "ok",
            "detail": "PRAGMA integrity_check: ok" if integrity == "ok" else "PRAGMA integrity_check failed",
        },
        {
            "name": "schema_tables",
            "ok": not missing_tables,
            "detail": (
                f"{len(EXPECTED_TABLES)} expected tables present"
                if not missing_tables
                else "missing tables: " + ", ".join(missing_tables)
            ),
        },
        {
            "name": "foreign_keys",
            "ok": not foreign_key_issue_tables,
            "detail": (
                "no foreign-key violations"
                if not foreign_key_issue_tables
                else f"{len(foreign_key_violations)} violation(s)"
            ),
        },
        {
            "name": "diary_original_hashes",
            "ok": not diary_hash_issues,
            "detail": f"{entry_count} diary entries checked",
        },
        {
            "name": "diary_revision_chains",
            "ok": not diary_chain_issues,
            "detail": f"{revision_count} revisions checked",
        },
        {
            "name": "memory_content_hashes",
            "ok": not memory_hash_issues,
            "detail": f"{memory_count} memories checked",
        },
        {
            "name": "memory_sources",
            "ok": not memory_source_issues,
            "detail": f"{source_count} evidence sources checked",
        },
        {
            "name": "memory_evidence",
            "ok": not memory_evidence_issues and not memory_offset_issues,
            "detail": "evidence snippets match immutable revisions and offsets",
        },
    ]
    return {
        "ok": not issues,
        "integrity_check": integrity,
        "issues": issues,
        "checks": checks,
        "table_counts": table_counts,
        "tables_found": sorted(tables),
        "tables_missing": missing_tables,
    }


def drill_backup(
    backup: Path,
    *,
    passphrase: str | None = None,
    passphrase_env: str = DEFAULT_PASSPHRASE_ENV,
) -> dict[str, Any]:
    """Run a full offline restore drill against *backup*.

    Verifies the checksum/manifest, decrypts encrypted backups into a temporary
    directory, runs SQLite/HeartLog invariants on the restored copy and cleans
    every temporary file up.  The live database is never opened and never
    overwritten.  Returns a JSON-serialisable report whose ``ok`` key is true
    only when every check passed.
    """

    path = Path(backup)
    report: dict[str, Any] = {
        "status": "failed",
        "ok": False,
        "backup": str(path),
        "encrypted": None,
        "checksum_verified": False,
        "checks": [],
        "issues": [],
        "table_counts": {},
    }

    def finish() -> dict[str, Any]:
        report["ok"] = not report["issues"]
        report["status"] = "ok" if report["ok"] else "failed"
        return report

    if not path.is_file():
        report["issues"].append("backup_missing")
        report["checks"].append({"name": "file", "ok": False, "detail": "backup file does not exist"})
        return finish()

    encrypted = is_encrypted(path)
    report["encrypted"] = encrypted
    try:
        metadata = verify_backup_file(path)
    except BackupError as exc:
        report["issues"].append("verification_failed")
        report["checks"].append({"name": "checksum", "ok": False, "detail": str(exc)})
        return finish()

    report["checksum_verified"] = metadata["checksum_verified"]
    if metadata["checksum_verified"]:
        report["checks"].append(
            {"name": "checksum", "ok": True, "detail": "SHA-256 sidecar/manifest verified"}
        )
    else:
        report["issues"].append("checksum_missing")
        report["checks"].append(
            {
                "name": "checksum",
                "ok": False,
                "detail": "no .sha256 sidecar or manifest SHA-256 available to verify the file",
            }
        )
    report["checks"].append(
        {
            "name": "encryption",
            "ok": True,
            "detail": "encrypted (AES-256-GCM, Scrypt)" if encrypted else "plaintext SQLite backup",
        }
    )

    temp_dir: tempfile.TemporaryDirectory[str] | None = None
    try:
        if encrypted:
            try:
                resolved = resolve_passphrase(passphrase, env_name=passphrase_env)
            except BackupError as exc:
                report["issues"].append("passphrase_missing")
                report["checks"].append({"name": "decryption", "ok": False, "detail": str(exc)})
                return finish()
            temp_dir = tempfile.TemporaryDirectory(prefix="heartlog-drill-")
            database = Path(temp_dir.name) / "drill.db"
            try:
                header = decrypt_file(path, database, resolved)
            except BackupError as exc:
                report["issues"].append("decryption_failed")
                report["checks"].append({"name": "decryption", "ok": False, "detail": str(exc)})
                return finish()
            report["checks"].append(
                {
                    "name": "decryption",
                    "ok": True,
                    "detail": f"decrypted format version {header.get('version')}",
                }
            )
        else:
            database = path

        try:
            database_report = inspect_database(database)
        except BackupError as exc:
            report["issues"].append("database_unreadable")
            report["checks"].append({"name": "database", "ok": False, "detail": str(exc)})
            return finish()

        report["table_counts"] = database_report["table_counts"]
        report["checks"].extend(database_report["checks"])
        report["issues"].extend(database_report["issues"])
        return finish()
    finally:
        if temp_dir is not None:
            temp_dir.cleanup()
