"""In-process rate limiting for the versioned API.

Design notes
------------
* **Disabled by default.**  ``HEARTLOG_RATE_LIMIT_ENABLED=false`` keeps local
  single-user use (and the existing test suite) completely unaffected.
* **Only ``/api/v1`` is limited.**  Health checks, documentation and the
  OpenAPI schema are served normally so monitoring and local docs keep working.
* **Sliding window.**  The limiter records the monotonic timestamp of every
  accepted request per client and rejects a request when ``limit`` accepted
  requests fall inside the trailing ``window_seconds``.  This is more accurate
  than a fixed window (no burst at the window boundary) and lets ``Retry-After``
  tell the client exactly when a slot frees up.
* **Bounded memory.**  The per-client map is capped at
  ``max_tracked_clients``; stale clients are purged first and, if the map is
  still full, the least-recently-active client is evicted.  An attacker that
  churns source addresses can therefore evict other clients' buckets (and so
  regain some quota) while consuming bounded memory.  That is an accepted
  trade-off for an in-process limiter; put a proxy-level limit in front for
  untrusted networks (see ``deploy/nginx.conf``).
* **Thread-safe.**  A single :class:`threading.Lock` guards the map; ``check``
  is short and never performs I/O.
* **Per-process.**  Each uvicorn worker has its own limiter.  Run one worker
  locally, or treat the effective limit as ``workers * rate_limit_requests``.
* **Forwarding headers are untrusted by default.**  ``X-Forwarded-For`` is only
  read when ``HEARTLOG_TRUST_PROXY_HEADERS=true``.  In that case the first hop
  is used, which means the reverse proxy MUST overwrite (not append to) the
  header; ``deploy/nginx.conf`` uses ``$remote_addr`` for exactly this reason.
* **Logging.**  A rejection logs only request id, method, *path* (never the
  query string), limit, window and retry-after.  It never logs bodies, headers
  or the client address; paths/ids are already part of the existing access log.

The limiter is *not* a WAF/IDS.  It adds a cheap application-level guard for
accidental or scripted floods; it does not survive restarts, cannot see traffic
before the app and does not replace TLS, authentication or proxy limits.
"""

from __future__ import annotations

import ipaddress
import logging
import math
import threading
import time
from collections import deque
from collections.abc import Callable, Iterable

from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
from starlette.types import ASGIApp

from app.core.config import Settings

logger = logging.getLogger("heartlog.rate_limit")

DEFAULT_MAX_TRACKED_CLIENTS = 10_000

MonotonicClock = Callable[[], float]


class RateLimitResult:
    """Outcome of one :meth:`SlidingWindowRateLimiter.check` call."""

    __slots__ = ("allowed", "limit", "remaining", "reset_after", "retry_after")

    def __init__(
        self,
        *,
        allowed: bool,
        limit: int,
        remaining: int,
        retry_after: int,
        reset_after: int,
    ) -> None:
        self.allowed = allowed
        self.limit = limit
        self.remaining = remaining
        self.retry_after = retry_after
        self.reset_after = reset_after

    def __repr__(self) -> str:  # pragma: no cover - debugging helper
        return (
            f"RateLimitResult(allowed={self.allowed!r}, limit={self.limit!r}, "
            f"remaining={self.remaining!r}, retry_after={self.retry_after!r})"
        )


class SlidingWindowRateLimiter:
    """Thread-safe, bounded sliding-window request limiter.

    ``clock`` is injectable so tests can advance time without sleeping; it must
    return monotonically non-decreasing seconds.
    """

    def __init__(
        self,
        *,
        limit: int,
        window_seconds: int,
        max_tracked_clients: int = DEFAULT_MAX_TRACKED_CLIENTS,
        clock: MonotonicClock = time.monotonic,
    ) -> None:
        if limit < 1:
            raise ValueError("limit must be >= 1")
        if window_seconds < 1:
            raise ValueError("window_seconds must be >= 1")
        if max_tracked_clients < 1:
            raise ValueError("max_tracked_clients must be >= 1")
        self._limit = limit
        self._window_seconds = window_seconds
        self._max_tracked_clients = max_tracked_clients
        self._clock = clock
        self._lock = threading.Lock()
        self._events: dict[str, deque[float]] = {}

    @property
    def limit(self) -> int:
        return self._limit

    @property
    def window_seconds(self) -> int:
        return self._window_seconds

    @property
    def max_tracked_clients(self) -> int:
        return self._max_tracked_clients

    @property
    def tracked_client_count(self) -> int:
        with self._lock:
            return len(self._events)

    def reconfigure(self, *, limit: int, window_seconds: int) -> None:
        """Apply new numeric limits (used if ``app.state.settings`` is edited).

        Clears tracked state so an old window cannot leak into the new policy.
        """

        if limit < 1 or window_seconds < 1:
            raise ValueError("limit and window_seconds must be >= 1")
        with self._lock:
            if (limit, window_seconds) == (self._limit, self._window_seconds):
                return
            self._limit = limit
            self._window_seconds = window_seconds
            self._events.clear()

    def reset(self) -> None:
        """Drop all tracked clients (tests/administrative use)."""

        with self._lock:
            self._events.clear()

    def check(self, key: str) -> RateLimitResult:
        """Record one request for ``key`` and decide whether it is allowed."""

        now = self._clock()
        with self._lock:
            window = float(self._window_seconds)
            events = self._events.get(key)
            if events is None:
                self._make_room(now)
                events = deque()
                self._events[key] = events
            self._prune(events, now)
            limit = self._limit
            if len(events) < limit:
                events.append(now)
                return RateLimitResult(
                    allowed=True,
                    limit=limit,
                    remaining=limit - len(events),
                    retry_after=0,
                    reset_after=_seconds_until_expiry(now, events[0], window),
                )
            retry_after = _seconds_until_expiry(now, events[0], window)
            return RateLimitResult(
                allowed=False,
                limit=limit,
                remaining=0,
                retry_after=retry_after,
                reset_after=retry_after,
            )

    def _prune(self, events: deque[float], now: float) -> None:
        cutoff = now - self._window_seconds
        while events and events[0] <= cutoff:
            events.popleft()

    def _make_room(self, now: float) -> None:
        """Ensure a *new* key can be inserted without growing past the bound."""

        if len(self._events) < self._max_tracked_clients:
            return
        cutoff = now - self._window_seconds
        stale = [key for key, events in self._events.items() if not events or events[-1] <= cutoff]
        for key in stale:
            del self._events[key]
        while len(self._events) >= self._max_tracked_clients:
            # Evict the least recently active client.  Ties are broken by
            # insertion order (dicts preserve it), which keeps behaviour
            # deterministic in tests.
            oldest_key = min(self._events, key=lambda key: self._events[key][-1])
            del self._events[oldest_key]


def _seconds_until_expiry(now: float, oldest: float, window: float) -> int:
    """Whole seconds until ``oldest`` leaves the trailing window."""

    return max(1, math.ceil(window - (now - oldest)))


def _parse_ip(value: str | None) -> str | None:
    """Return a canonical IP string, or ``None`` if ``value`` is not an IP."""

    if not value:
        return None
    candidate = value.strip()
    if candidate.startswith("[") and candidate.endswith("]"):
        candidate = candidate[1:-1]
    try:
        return str(ipaddress.ip_address(candidate))
    except ValueError:
        return None


def client_key_from_request(request: Request, *, trust_proxy_headers: bool) -> str:
    """Derive the rate-limit bucket key for a request.

    With ``trust_proxy_headers`` the first ``X-Forwarded-For`` hop is used when
    it parses as an IP address; otherwise (or when the header is absent or
    malformed) the direct peer address is used.  Client-supplied forwarding
    headers are ignored entirely in the default configuration.
    """

    if trust_proxy_headers:
        forwarded = request.headers.get("x-forwarded-for")
        if forwarded:
            first_hop = forwarded.split(",", 1)[0]
            forwarded_ip = _parse_ip(first_hop)
            if forwarded_ip is not None:
                return forwarded_ip
    peer = request.client
    peer_host = peer.host if peer is not None else None
    if peer_host:
        return _parse_ip(peer_host) or peer_host
    return "unknown"


def is_rate_limited_path(
    path: str,
    *,
    api_prefix: str,
    exempt_paths: Iterable[str] = (),
) -> bool:
    """Whether ``path`` is subject to the in-process limiter.

    Only the versioned API prefix is limited.  Exempt entries match the exact
    path or any sub-path (``/docs`` and ``/docs/foo``).
    """

    prefix = api_prefix.rstrip("/")
    if not prefix:
        return False
    if not (path == prefix or path.startswith(prefix + "/")):
        return False
    for exempt in exempt_paths:
        normalised = exempt.rstrip("/") or "/"
        if path == normalised or path.startswith(normalised + "/"):
            return False
    return True


def build_rate_limiter(settings: Settings) -> SlidingWindowRateLimiter:
    """Create a limiter from settings (one per application instance)."""

    return SlidingWindowRateLimiter(
        limit=settings.rate_limit_requests,
        window_seconds=settings.rate_limit_window_seconds,
    )


class RateLimitMiddleware(BaseHTTPMiddleware):
    """HTTP middleware applying :class:`SlidingWindowRateLimiter` to the API.

    Register this **before** the request-context middleware so the rejection
    response still receives the existing request id / privacy headers and is
    included in the access log::

        app.add_middleware(RateLimitMiddleware)
        # ... then @app.middleware("http") request_context ...
    """

    def __init__(self, app: ASGIApp) -> None:
        super().__init__(app)

    async def dispatch(self, request: Request, call_next):  # type: ignore[no-untyped-def]
        settings: Settings | None = getattr(request.app.state, "settings", None)
        limiter: SlidingWindowRateLimiter | None = getattr(request.app.state, "rate_limiter", None)
        if settings is None or limiter is None or not settings.rate_limit_enabled:
            return await call_next(request)
        if not is_rate_limited_path(
            request.url.path,
            api_prefix=settings.api_v1_prefix,
            exempt_paths=settings.rate_limit_exempt_path_set,
        ):
            return await call_next(request)

        # Settings are normally immutable after start-up; this keeps ad-hoc
        # test/administrative changes to app.state.settings effective.
        if (limiter.limit, limiter.window_seconds) != (
            settings.rate_limit_requests,
            settings.rate_limit_window_seconds,
        ):
            limiter.reconfigure(
                limit=settings.rate_limit_requests,
                window_seconds=settings.rate_limit_window_seconds,
            )

        key = client_key_from_request(
            request,
            trust_proxy_headers=settings.trust_proxy_headers,
        )
        result = limiter.check(key)
        if result.allowed:
            return await call_next(request)

        request_id = getattr(request.state, "request_id", None)
        # Path only: the query string and request body may contain private data.
        logger.warning(
            "rate_limited request_id=%s method=%s path=%s limit=%s window_seconds=%s retry_after=%s",
            request_id,
            request.method,
            request.url.path,
            result.limit,
            settings.rate_limit_window_seconds,
            result.retry_after,
        )
        response: Response = JSONResponse(
            status_code=429,
            content={
                "error": {
                    "code": "rate_limited",
                    "message": "Too many requests. Please retry later.",
                    "details": {
                        "limit": result.limit,
                        "window_seconds": settings.rate_limit_window_seconds,
                        "retry_after_seconds": result.retry_after,
                    },
                }
            },
        )
        response.headers["Retry-After"] = str(result.retry_after)
        response.headers["X-RateLimit-Limit"] = str(result.limit)
        response.headers["X-RateLimit-Remaining"] = "0"
        response.headers["X-RateLimit-Reset"] = str(result.reset_after)
        return response
