"""Deterministic content hashes used for integrity checks.

Hashes are *not* encryption and do not make records tamper-proof on their own.
They let HeartLog detect accidental or silent modification and make revision
chains verifiable.  Hashes are computed over UTF-8 text with newlines preserved
as submitted by the user.
"""

from __future__ import annotations

import hashlib


def sha256_text(text: str) -> str:
    """Return a hex SHA-256 digest for *text*."""

    return hashlib.sha256(text.encode("utf-8")).hexdigest()
