"""Application settings loaded from environment variables / local ``.env``.

No secret has a usable default.  Private data is never sent to an external
provider unless AI access is enabled, explicit consent is recorded, and a
provider is configured.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, SecretStr, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        env_prefix="HEARTLOG_",
        case_sensitive=False,
        extra="ignore",
    )

    app_name: str = "HeartLog"
    environment: Literal["local", "test", "staging", "production"] = "local"
    debug: bool = False
    log_level: str = "INFO"

    database_url: str = "sqlite:///./data/heartlog.db"
    data_dir: Path = Path("./data")
    backup_dir: Path = Path("./backups")
    auto_create_schema: bool = True

    api_v1_prefix: str = "/api/v1"
    # When set, all /api/v1 endpoints require ``Authorization: Bearer <token>``.
    api_token: SecretStr | None = None
    # Required for permanent deletion.  Permanent deletion is disabled entirely
    # while this is unset, even in local mode.
    admin_token: SecretStr | None = None

    # --- Deployment / network hardening ---------------------------------
    # In-process rate limiting for /api/v1.  Disabled by default so local use
    # (and the existing test suite) is unaffected.  See app/core/rate_limit.py
    # and docs/deployment_security.md.
    rate_limit_enabled: bool = False
    rate_limit_requests: int = Field(default=240, ge=1, le=1_000_000)
    rate_limit_window_seconds: int = Field(default=60, ge=1, le=86_400)
    # Comma-separated path prefixes that are never rate limited.  Paths outside
    # the API prefix are never limited in the first place; this mainly protects
    # health/documentation endpoints if the prefix is customised.
    rate_limit_exempt_paths: str = "/health,/docs,/redoc,/openapi.json"
    # Trust the first ``X-Forwarded-For`` hop for the rate-limit key.  Enable
    # ONLY when the app is bound to loopback behind a reverse proxy that
    # *overwrites* (does not append to) the header.  Default false: direct peer
    # address is used and client-supplied forwarding headers are ignored.
    trust_proxy_headers: bool = False

    max_diary_chars: int = Field(default=50_000, ge=1, le=1_000_000)
    max_change_reason_chars: int = Field(default=500, ge=1, le=10_000)
    default_page_size: int = Field(default=20, ge=1, le=200)
    max_page_size: int = Field(default=100, ge=1, le=500)
    max_evidence_chars: int = Field(default=2_000, ge=1, le=20_000)

    # AI is disabled by default.  Both ``ai_enabled`` and ``ai_consent`` must be
    # true before any private diary text can leave the machine.
    ai_enabled: bool = False
    ai_consent: bool = False
    ai_provider: Literal["openai_compatible", "mock", "disabled"] = "disabled"
    ai_base_url: str = ""
    ai_model: str = ""
    ai_api_key: SecretStr | None = None
    ai_timeout_seconds: float = Field(default=60.0, ge=1.0, le=600.0)
    ai_max_output_tokens: int = Field(default=2_000, ge=64, le=32_000)

    @field_validator("api_v1_prefix")
    @classmethod
    def _normalise_prefix(cls, value: str) -> str:
        if not value.startswith("/"):
            raise ValueError("api_v1_prefix must start with '/'")
        return value.rstrip("/")

    @field_validator("log_level")
    @classmethod
    def _normalise_log_level(cls, value: str) -> str:
        allowed = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        upper = value.upper()
        if upper not in allowed:
            raise ValueError(f"log_level must be one of {sorted(allowed)}")
        return upper

    @field_validator("rate_limit_exempt_paths")
    @classmethod
    def _normalise_exempt_paths(cls, value: str) -> str:
        """Normalise a comma-separated exempt-path list.

        ``HEARTLOG_RATE_LIMIT_EXEMPT_PATHS=/health,/docs`` is friendlier in a
        ``.env`` file than a JSON list, which is why the field is a plain string
        with a derived :attr:`rate_limit_exempt_path_set`.
        """

        normalised: list[str] = []
        for raw in value.split(","):
            item = raw.strip()
            if not item:
                continue
            if not item.startswith("/"):
                raise ValueError("rate_limit_exempt_paths entries must start with '/'")
            path = item.rstrip("/") or "/"
            if path not in normalised:
                normalised.append(path)
        return ",".join(normalised)

    @field_validator("api_token", "admin_token", "ai_api_key", mode="before")
    @classmethod
    def _blank_secret_to_none(cls, value: object) -> object:
        """Treat an empty env var (``HEARTLOG_API_TOKEN=``) as "not configured"."""

        if isinstance(value, str) and not value.strip():
            return None
        return value

    @model_validator(mode="after")
    def _warn_or_validate_ai(self) -> Settings:
        if self.ai_enabled and not self.ai_consent:
            raise ValueError(
                "AI is enabled but HEARTLOG_AI_CONSENT is false; refusing to start with implicit consent"
            )
        if self.ai_provider == "openai_compatible" and self.ai_enabled:
            if not self.ai_base_url.startswith(("http://", "https://")):
                raise ValueError("HEARTLOG_AI_BASE_URL must be an http(s) URL when AI is enabled")
            if not self.ai_model:
                raise ValueError("HEARTLOG_AI_MODEL is required when AI is enabled")
        return self

    @property
    def ai_configured(self) -> bool:
        """Whether a real external provider is fully configured and consented."""

        if not (self.ai_enabled and self.ai_consent):
            return False
        if self.ai_provider == "mock":
            return True
        return bool(self.ai_base_url and self.ai_model and self.ai_api_key)

    @property
    def is_sqlite(self) -> bool:
        return self.database_url.startswith("sqlite")

    @property
    def rate_limit_exempt_path_set(self) -> frozenset[str]:
        """Parsed form of :attr:`rate_limit_exempt_paths`."""

        return frozenset(path for path in self.rate_limit_exempt_paths.split(",") if path)

    def deployment_warnings(self) -> list[str]:
        """Non-fatal security warnings for staging/production deployments.

        The messages never interpolate secret values, so they are safe to log
        verbatim.  Warnings are intentionally advisory: a hardened local setup
        may legitimately run with some of these disabled.
        """

        if self.environment not in ("staging", "production"):
            return []
        warnings: list[str] = []
        if self.api_token is None:
            warnings.append("HEARTLOG_API_TOKEN is not set; every /api/v1 endpoint is unauthenticated")
        if self.admin_token is None:
            warnings.append("HEARTLOG_ADMIN_TOKEN is not set; permanent deletion stays disabled")
        if self.debug:
            warnings.append("HEARTLOG_DEBUG=true; do not expose debug output to untrusted users")
        if not self.rate_limit_enabled:
            warnings.append("HEARTLOG_RATE_LIMIT_ENABLED=false; no application-level request throttling")
        if self.trust_proxy_headers:
            warnings.append(
                "HEARTLOG_TRUST_PROXY_HEADERS=true; only safe behind a trusted proxy "
                "that overwrites X-Forwarded-For"
            )
        if self.ai_enabled:
            warnings.append(
                "HEARTLOG_AI_ENABLED=true; private diary text may be sent to the configured provider"
            )
        return warnings

    def ensure_directories(self) -> None:
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.backup_dir.mkdir(parents=True, exist_ok=True)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Load settings once for the running process (overridable in tests)."""

    return Settings()
