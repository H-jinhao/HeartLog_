"""Small text-validation helpers for user-supplied content."""

from __future__ import annotations

#: C0 controls are not meaningful diary text.  Tabs/newlines are allowed; a NUL
#: is explicitly rejected because SQLite's ``length()`` stops at the first NUL,
#: which previously let input bypass the non-empty CHECK and surface as a 500.
_FORBIDDEN_CONTROL_CHARS = frozenset(
    [chr(code) for code in range(0x20) if code not in (0x09, 0x0A, 0x0D)] + ["\x7f"]
)


def has_forbidden_control_chars(value: str) -> bool:
    return any(character in _FORBIDDEN_CONTROL_CHARS for character in value)
