"""Time helpers.

All timestamps stored by HeartLog are UTC.  The SQLite driver does not preserve
timezone information, so :class:`app.db.types.UTCDateTime` re-attaches UTC on
read.  Keeping this in one place avoids ambiguous naive datetimes leaking into
the API.
"""

from __future__ import annotations

from datetime import UTC, datetime


def utcnow() -> datetime:
    """Return the current time as a timezone-aware UTC datetime."""

    return datetime.now(UTC)


def ensure_utc(value: datetime) -> datetime:
    """Treat naive datetimes as UTC and convert aware ones to UTC."""

    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)
