"""Optional local access control.

HeartLog is local-first, but a local HTTP server can still be reached by other
processes.  Two opt-in tokens are supported:

* ``HEARTLOG_API_TOKEN``: required as a bearer token on every ``/api/v1`` call.
* ``HEARTLOG_ADMIN_TOKEN``: required for irreversible operations (currently
  permanent deletion).  Permanent deletion stays disabled when it is unset.

This is deliberately simple; production deployments should put HeartLog behind
a real authentication / reverse-proxy layer.  See ``docs/privacy.md``.
"""

from __future__ import annotations

import hmac
from typing import Annotated

from fastapi import Header, Request

from app.core.config import Settings
from app.core.exceptions import ForbiddenError, UnauthorizedError


def _settings_from_request(request: Request) -> Settings:
    return request.app.state.settings


def _matches(provided: str, expected: str) -> bool:
    return hmac.compare_digest(provided.encode("utf-8"), expected.encode("utf-8"))


def require_api_access(
    request: Request,
    authorization: Annotated[str | None, Header()] = None,
) -> None:
    settings = _settings_from_request(request)
    if settings.api_token is None:
        return
    expected = settings.api_token.get_secret_value()
    if not authorization or not authorization.startswith("Bearer "):
        raise UnauthorizedError("A bearer token is required", details={"scheme": "Bearer"})
    supplied = authorization.removeprefix("Bearer ").strip()
    if not _matches(supplied, expected):
        raise UnauthorizedError("Invalid bearer token")


def require_admin(
    request: Request,
    x_admin_token: Annotated[str | None, Header()] = None,
) -> None:
    settings = _settings_from_request(request)
    if settings.admin_token is None:
        raise ForbiddenError(
            "Permanent operations are disabled. Set HEARTLOG_ADMIN_TOKEN to enable them.",
            code="admin_disabled",
        )
    if not x_admin_token or not _matches(x_admin_token, settings.admin_token.get_secret_value()):
        raise ForbiddenError("A valid X-Admin-Token header is required", code="admin_required")
