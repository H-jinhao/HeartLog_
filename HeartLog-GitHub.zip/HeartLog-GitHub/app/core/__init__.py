"""Cross-cutting concerns: configuration, security, errors, time, hashing."""
