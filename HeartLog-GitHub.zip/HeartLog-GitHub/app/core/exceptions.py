"""Domain errors with stable API error codes.

Routes raise these instead of leaking SQLAlchemy / provider exceptions.  The
global handlers in :mod:`app.main` serialise them as::

    {"error": {"code": "...", "message": "...", "details": ...}}
"""

from __future__ import annotations

from typing import Any


class AppError(Exception):
    status_code: int = 400
    code: str = "bad_request"

    def __init__(
        self,
        message: str,
        *,
        code: str | None = None,
        status_code: int | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        if code is not None:
            self.code = code
        if status_code is not None:
            self.status_code = status_code
        self.details = details or {}


class NotFoundError(AppError):
    status_code = 404
    code = "not_found"


class ConflictError(AppError):
    status_code = 409
    code = "conflict"


class ForbiddenError(AppError):
    status_code = 403
    code = "forbidden"


class UnauthorizedError(AppError):
    status_code = 401
    code = "unauthorized"


class ValidationError(AppError):
    status_code = 422
    code = "validation_error"


class ProtectedRecordError(AppError):
    """Raised when an operation would mutate immutable original data."""

    status_code = 409
    code = "protected_record"


class AIConfigurationError(AppError):
    status_code = 503
    code = "ai_not_configured"


class AIResponseError(AppError):
    status_code = 502
    code = "ai_invalid_response"


class AIServiceError(AppError):
    status_code = 502
    code = "ai_service_error"
