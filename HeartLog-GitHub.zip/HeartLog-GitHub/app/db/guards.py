"""Database-level integrity guards for SQLite.

Application code already refuses to mutate original records.  These triggers
are defence in depth: an accidental raw SQL update (or a future bug that
bypasses the ORM) still hits ``RAISE(ABORT)`` and the transaction rolls back.

They are installed idempotently both after ``create_all`` (local convenience)
and by the initial Alembic migration.  On a non-SQLite database this function
is a no-op; the ORM listeners remain active.
"""

from __future__ import annotations

from sqlalchemy import Engine
from sqlalchemy.engine import Connection

_TRIGGERS: tuple[str, ...] = (
    """
    CREATE TRIGGER IF NOT EXISTS trg_diary_original_text_immutable
    BEFORE UPDATE OF original_text ON diary_entries
    FOR EACH ROW WHEN OLD.original_text IS NOT NEW.original_text
    BEGIN
        SELECT RAISE(ABORT, 'original_text_immutable');
    END
    """,
    """
    CREATE TRIGGER IF NOT EXISTS trg_diary_original_hash_immutable
    BEFORE UPDATE OF original_content_hash ON diary_entries
    FOR EACH ROW WHEN OLD.original_content_hash IS NOT NEW.original_content_hash
    BEGIN
        SELECT RAISE(ABORT, 'original_content_hash_immutable');
    END
    """,
    """
    CREATE TRIGGER IF NOT EXISTS trg_diary_revisions_immutable
    BEFORE UPDATE ON diary_revisions
    FOR EACH ROW
    BEGIN
        SELECT RAISE(ABORT, 'diary_revision_immutable');
    END
    """,
    """
    CREATE TRIGGER IF NOT EXISTS trg_diary_revision_identity_immutable
    BEFORE UPDATE OF entry_id, version, content, content_hash, previous_revision_hash ON diary_revisions
    FOR EACH ROW
    BEGIN
        SELECT RAISE(ABORT, 'diary_revision_immutable');
    END
    """,
    """
    CREATE TRIGGER IF NOT EXISTS trg_audit_events_no_update
    BEFORE UPDATE ON audit_events
    FOR EACH ROW
    BEGIN
        SELECT RAISE(ABORT, 'audit_events_append_only');
    END
    """,
    """
    CREATE TRIGGER IF NOT EXISTS trg_audit_events_no_delete
    BEFORE DELETE ON audit_events
    FOR EACH ROW
    BEGIN
        SELECT RAISE(ABORT, 'audit_events_append_only');
    END
    """,
    """
    CREATE TRIGGER IF NOT EXISTS trg_memory_sources_immutable
    BEFORE UPDATE OF memory_id, entry_id, revision_id, evidence_text, start_offset, end_offset ON memory_sources
    FOR EACH ROW
    BEGIN
        SELECT RAISE(ABORT, 'memory_source_immutable');
    END
    """,
    """
    CREATE TRIGGER IF NOT EXISTS trg_memory_confirmation_requires_reviewer
    BEFORE UPDATE OF verification_status ON memories
    FOR EACH ROW
    WHEN NEW.verification_status = 'confirmed'
         AND OLD.verification_status <> 'confirmed'
         AND NEW.confirmed_by IS NULL
    BEGIN
        SELECT RAISE(ABORT, 'user_confirmation_required');
    END
    """,
    """
    CREATE TRIGGER IF NOT EXISTS trg_memory_content_immutable
    BEFORE UPDATE OF content, content_hash, memory_type, created_by ON memories
    FOR EACH ROW
    BEGIN
        SELECT RAISE(ABORT, 'memory_content_immutable');
    END
    """,
)


def install_sqlite_guards_on_connection(connection: Connection) -> None:
    """Install triggers using an explicit Alembic connection/transaction."""

    if connection.dialect.name != "sqlite":
        return
    for statement in _TRIGGERS:
        connection.exec_driver_sql(statement)


def install_sqlite_guards(engine: Engine) -> None:
    if engine.dialect.name != "sqlite":
        return
    with engine.begin() as connection:
        install_sqlite_guards_on_connection(connection)
