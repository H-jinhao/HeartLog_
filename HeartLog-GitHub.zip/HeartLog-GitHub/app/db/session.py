"""Engine and session construction.

A new engine is built for every application instance.  Tests therefore get a
completely isolated temporary database and can never touch the user's real
``data/heartlog.db``.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

from sqlalchemy import Engine, create_engine, event
from sqlalchemy.engine import make_url
from sqlalchemy.orm import Session, sessionmaker

from app.core.config import Settings


def _sqlite_path(database_url: str) -> Path | None:
    url = make_url(database_url)
    if url.get_backend_name() != "sqlite":
        return None
    if url.database in (None, "", ":memory:"):
        return None
    return Path(url.database)


def create_engine_for(settings: Settings) -> Engine:
    """Create a configured SQLAlchemy engine for the given settings."""

    connect_args: dict[str, object] = {}
    if settings.is_sqlite:
        # TestClient executes requests in worker threads, so the SQLite
        # connection must be usable outside the creating thread.
        connect_args = {"check_same_thread": False, "timeout": 30}
        path = _sqlite_path(settings.database_url)
        if path is not None:
            path.parent.mkdir(parents=True, exist_ok=True)
    engine = create_engine(
        settings.database_url,
        future=True,
        pool_pre_ping=True,
        connect_args=connect_args,
    )
    if settings.is_sqlite:
        event.listen(engine, "connect", _set_sqlite_pragmas)
        # pysqlite normally defers BEGIN until the first DML statement.  That
        # makes an early SAVEPOINT the outermost SQLite transaction, so
        # RELEASE can silently commit work that a later rollback should undo.
        # Take explicit control of transaction boundaries (SQLAlchemy's
        # documented pysqlite recipe) so Session/SAVEPOINT semantics are sound.
        event.listen(engine, "begin", _begin_sqlite_transaction)
    return engine


def _begin_sqlite_transaction(connection: object) -> None:
    connection.exec_driver_sql("BEGIN")  # type: ignore[attr-defined]


def _set_sqlite_pragmas(dbapi_connection: object, _connection_record: object) -> None:
    # Autocommit at the driver level; SQLAlchemy's begin event above issues the
    # actual BEGIN for every unit of work, including SAVEPOINT users.
    dbapi_connection.isolation_level = None  # type: ignore[attr-defined]
    cursor = dbapi_connection.cursor()  # type: ignore[attr-defined]
    try:
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.execute("PRAGMA busy_timeout=30000")
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA synchronous=NORMAL")
    finally:
        cursor.close()


def create_session_factory(engine: Engine) -> sessionmaker[Session]:
    return sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


def iter_session(session_factory: sessionmaker[Session]) -> Iterator[Session]:
    """Yield a session and guarantee it is closed (used by scripts)."""

    session = session_factory()
    try:
        yield session
    finally:
        session.close()
