"""HeartLog FastAPI application factory.

The factory pattern gives tests a fresh engine, session factory and AI adapter
per test, all backed by an isolated temporary SQLite file.  It also keeps the
module importable without performing environment-dependent I/O at import time.
"""

from __future__ import annotations

import logging
import re
import time
import uuid
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from sqlalchemy import inspect as sa_inspect
from sqlalchemy.exc import SQLAlchemyError
from starlette.exceptions import HTTPException as StarletteHTTPException

from app import __version__
from app.api.router import api_router
from app.api.routes import health
from app.core.config import Settings, get_settings
from app.core.exceptions import AppError
from app.core.rate_limit import RateLimitMiddleware, build_rate_limiter
from app.db.base import Base
from app.db.guards import install_sqlite_guards
from app.db.session import create_engine_for, create_session_factory
from app.services.ai_service import build_ai_service

logger = logging.getLogger("heartlog")
_REQUEST_ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")


def _configure_logging(settings: Settings) -> None:
    logging.basicConfig(
        level=getattr(logging, settings.log_level, logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )
    # Third-party loggers can be noisy locally; never lower this globally because
    # provider debug logs might include private prompt text.
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)


def _error_response(status_code: int, code: str, message: str, details: dict | None = None) -> JSONResponse:
    payload = {"error": {"code": code, "message": message, "details": details or {}}}
    return JSONResponse(status_code=status_code, content=payload)


def _validation_details(exc: RequestValidationError) -> dict:
    """Strip raw input values from validation errors.

    FastAPI normally echoes the invalid input, which could put diary text in
    responses/logs.  Only location and a human-readable reason are returned.
    """

    return {
        "fields": [
            {
                "loc": ".".join(str(part) for part in error.get("loc", [])),
                "msg": error.get("msg", "invalid value"),
                "type": error.get("type", "value_error"),
            }
            for error in exc.errors()
        ]
    }


def create_app(settings: Settings | None = None) -> FastAPI:
    app_settings = settings or get_settings()
    app_settings.ensure_directories()
    _configure_logging(app_settings)

    engine = create_engine_for(app_settings)
    session_factory = create_session_factory(engine)

    # Import models before create_all so every table is registered.
    import app.models  # noqa: F401

    if app_settings.auto_create_schema:
        Base.metadata.create_all(engine)
    if app_settings.is_sqlite:
        table_names = set(sa_inspect(engine).get_table_names())
        if {"diary_entries", "diary_revisions", "audit_events"} <= table_names:
            install_sqlite_guards(engine)

    @asynccontextmanager
    async def lifespan(_app: FastAPI) -> AsyncIterator[None]:
        logger.info(
            "heartlog_start version=%s environment=%s ai_enabled=%s",
            __version__,
            app_settings.environment,
            app_settings.ai_enabled,
        )
        yield
        engine.dispose()
        logger.info("heartlog_stop")

    app = FastAPI(
        title=app_settings.app_name,
        version=__version__,
        description=(
            "Local-first emotional diary and traceable long-term memory system. "
            "Original diary text is immutable; every edit creates a revision."
        ),
        lifespan=lifespan,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
    )
    app.state.settings = app_settings
    app.state.engine = engine
    app.state.session_factory = session_factory
    app.state.ai_service = build_ai_service(app_settings)
    # One per application instance (not module-level) so tests, multiple
    # create_app() calls and embedded use never share bucket state.
    app.state.rate_limiter = build_rate_limiter(app_settings)

    # Non-fatal deployment warnings; messages contain no secret values.
    for warning in app_settings.deployment_warnings():
        logger.warning(
            "deployment_security environment=%s issue=%s",
            app_settings.environment,
            warning,
        )

    app.include_router(health.router)
    app.include_router(api_router, prefix=app_settings.api_v1_prefix)

    # Registered *before* the request-context middleware below: Starlette wraps
    # the last-added middleware outermost, so request_context stays outermost
    # and still adds X-Request-ID / privacy headers and an access-log line to
    # rate-limited 429 responses.
    app.add_middleware(RateLimitMiddleware)

    @app.middleware("http")
    async def request_context(request: Request, call_next):  # type: ignore[no-untyped-def]
        supplied_request_id = request.headers.get("X-Request-ID")
        request_id = (
            supplied_request_id
            if supplied_request_id and _REQUEST_ID_RE.fullmatch(supplied_request_id)
            else str(uuid.uuid4())
        )
        request.state.request_id = request_id
        started = time.perf_counter()
        try:
            response = await call_next(request)
        except Exception:
            # Do not log query strings or bodies: both may contain private data.
            logger.exception(
                "unhandled_error request_id=%s method=%s path=%s",
                request_id,
                request.method,
                request.url.path,
            )
            raise
        elapsed_ms = round((time.perf_counter() - started) * 1000, 1)
        response.headers["X-Request-ID"] = request_id
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("Referrer-Policy", "no-referrer")
        if request.url.path.startswith(app_settings.api_v1_prefix):
            # Private API responses should not be retained by shared caches.
            response.headers.setdefault("Cache-Control", "no-store")
        logger.info(
            "request request_id=%s method=%s path=%s status=%s duration_ms=%s",
            request_id,
            request.method,
            request.url.path,
            response.status_code,
            elapsed_ms,
        )
        return response

    @app.exception_handler(AppError)
    async def app_error_handler(_request: Request, exc: AppError) -> JSONResponse:
        return _error_response(exc.status_code, exc.code, exc.message, exc.details)

    @app.exception_handler(RequestValidationError)
    async def request_validation_handler(_request: Request, exc: RequestValidationError) -> JSONResponse:
        return _error_response(
            422,
            "validation_error",
            "Request validation failed",
            _validation_details(exc),
        )

    @app.exception_handler(StarletteHTTPException)
    async def http_error_handler(_request: Request, exc: StarletteHTTPException) -> JSONResponse:
        detail = exc.detail if isinstance(exc.detail, str) else "HTTP error"
        return _error_response(exc.status_code, "http_error", detail)

    @app.exception_handler(SQLAlchemyError)
    async def sqlalchemy_error_handler(_request: Request, exc: SQLAlchemyError) -> JSONResponse:
        # Never call logger.exception here: SQLAlchemy exception strings can
        # include the failing SQL statement and its bound parameters, which may
        # contain private diary text.  Only the exception class is safe.
        logger.error("database_error type=%s", type(exc).__name__)
        return _error_response(500, "database_error", "A database error occurred")

    @app.get("/", include_in_schema=False)
    def root() -> dict[str, str]:
        return {
            "app": app_settings.app_name,
            "version": __version__,
            "docs": "/docs",
            "health": "/health",
            "api": app_settings.api_v1_prefix,
        }

    return app


# Run with the application factory so no database is touched at import time:
#   uvicorn "app.main:create_app" --factory
