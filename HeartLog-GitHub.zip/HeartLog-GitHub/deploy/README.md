# HeartLog 部署安全示例（Nginx / Caddy / systemd）

本目录给出把 HeartLog 从"本机开发进程"提升到"可受控网络访问"的**参考配置**：

| 文件 | 用途 |
| --- | --- |
| `nginx.conf` | Nginx 完整示例：TLS 1.2/1.3、HSTS（默认注释）、`limit_req`、`auth_basic` 示例、反向代理到 `127.0.0.1:8000`、安全响应头、请求体上限、默认隐藏 `/docs`、隐私化访问日志 |
| `Caddyfile` | Caddy v2 等价替代：TLS、`basic_auth` 占位、反向代理、默认隐藏文档 |
| `heartlog.service` | systemd 加固服务单元：专用用户、`NoNewPrivileges`、`ProtectSystem=strict`、`PrivateTmp`、`StateDirectory`、`UMask=0077`、syscall/能力限制 |
| `heartlog.env.example` | systemd `EnvironmentFile` 模板（令牌、限流、路径；不含真实密钥） |

> ⚠️ **诚实声明（重要）**
>
> 这些配置经过逐行人工审阅与逻辑核对，但**没有**在本项目的真实 Nginx / Caddy /
> systemd 环境中做过端到端联调。上线前必须由部署者自行执行并确认：
> `nginx -t`、`caddy validate`、`systemd-analyze verify`、
> `systemd-analyze security`、真实证书握手、限流触发与 429 行为。
> 示例中的域名、证书路径、密码哈希、限流阈值全部是占位值，必须替换。
> 更完整的中文说明见 [`docs/deployment_security.md`](../docs/deployment_security.md)。

---

## 1. 选择部署形态

| 形态 | 适用 | 传输加密 | 认证 | 限流 |
| --- | --- | --- | --- | --- |
| A. 只监听 `127.0.0.1:8000` | 只在本机使用（推荐默认） | 无（不出网卡） | `HEARTLOG_API_TOKEN` 可选 | 应用内限流可选 |
| B. uvicorn 直接 TLS（`--ssl-keyfile/--ssl-certfile`） | 单机自用、临时演示 | 有（证书可自签） | 同上 | 同上 |
| C. Nginx/Caddy 反代 + TLS + 可选 basic auth | 局域网/公网暴露（**唯一推荐**的对外形态） | 有（真实 CA 证书） | 代理层 + 应用令牌双层 | 代理层 + 应用内双层 |

**不要**把 uvicorn 直接绑定 `0.0.0.0` 暴露到公网：HeartLog 没有 WAF/IDS、没有多用户隔离、
没有登录会话，应用层限流是进程内的（重启即清零、多 worker 各自计数）。

---

## 2. 威胁模型（本目录配置能覆盖什么）

**能缓解：**

- 链路窃听 / 中间人：TLS 1.2/1.3 + 强密码套件（形态 B/C）。
- 暴力破解与脚本洪水：`limit_req`（代理层）+ `HEARTLOG_RATE_LIMIT_*`（应用层）。
- 无认证访问：`auth_basic`（代理层）与 `HEARTLOG_API_TOKEN`（应用层）可叠加。
- 响应头类浏览器攻击：`X-Content-Type-Options`、`Referrer-Policy`、`X-Frame-Options` 等。
- 文档/元数据面暴露：默认把 `/docs`、`/redoc`、`/openapi.json` 置 404。
- 日志泄漏搜索词：`nginx.conf` 使用只记录 `$uri`（不含 query string）的日志格式。
- 本机其他账户读取数据文件：`deploy/heartlog.service` 的 `UMask=0077` +
  `StateDirectory` + `scripts/harden_permissions.py`。

**不能覆盖（必须写入你的威胁模型）：**

- 拥有 `data/` 文件系统读写权限的人：可以直接读/改 SQLite 文件；哈希链只能"发现"篡改，不能阻止。
- 获得服务运行账户或 root 权限的攻击者：可读进程内存、令牌和全部数据。
- 恶意/被入侵的 AI provider：启用 AI 后日记正文可能被发送（见 `docs/privacy.md`）。
- 备份/导出文件：HeartLog 文件本身不加密，需自行用加密卷或 `age`/GPG 处理。
- 多用户、角色、审计身份：HeartLog 是单用户应用，令牌是静态共享密钥。
- 供应链、依赖漏洞、0-day：未做安全审计。

---

## 3. Nginx 部署（形态 C）

### 3.1 安装与证书

```bash
sudo apt install nginx certbot python3-certbot-nginx apache2-utils   # Debian/Ubuntu 示例
sudo certbot --nginx -d heartlog.example.com                          # 获取真实证书
```

把示例里的 `heartlog.example.com`、证书路径换成你的真实域名/路径。

### 3.2 安装配置

```bash
sudo cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.bak
# 将 deploy/nginx.conf 的 http{...} 内容合并进现有配置，或整份替换后确认路径可用；
# 若整份替换，务必保留本机既有的 mime.types 路径等站点配置习惯。
sudo nginx -t && sudo systemctl reload nginx
```

### 3.3 可选：给 API 加 HTTP Basic Auth

```bash
sudo htpasswd -B -c /etc/nginx/heartlog.htpasswd heartlog-user
# 然后在 nginx.conf 的 location /api/v1/ 中取消 auth_basic 两行注释
sudo nginx -t && sudo systemctl reload nginx
```

Basic Auth 与 `HEARTLOG_API_TOKEN` 可以同时启用；前者保护"谁能连到应用"，后者保护
"应用是否接受该请求"。Basic Auth 密码也会经 TLS 传输，HTTP 下不要使用。

### 3.4 启动后端并验证

```bash
# HeartLog 只监听 loopback
uvicorn "app.main:create_app" --factory --host 127.0.0.1 --port 8000

# 在另一终端验证（替换域名）
curl -sSf https://heartlog.example.com/health
curl -sS -o /dev/null -w '%{http_code}\n' https://heartlog.example.com/docs   # 期望 404
curl -sS -o /dev/null -w '%{http_code}\n' https://heartlog.example.com/api/v1/diaries
```

---

## 4. Caddy 部署（形态 C 的可选替代）

```bash
sudo caddy validate --config deploy/Caddyfile
sudo cp deploy/Caddyfile /etc/caddy/Caddyfile
# 按需生成 basic auth 哈希：
caddy hash-password --plaintext 'a-long-random-password'
sudo systemctl reload caddy
```

说明：

- 若使用真实域名且 80/443 可被外网访问，可以删掉 `tls` 两行让 Caddy 自动申请证书；
  否则保留"自带证书"写法。
- `basic_auth` 指令要求 Caddy ≥ 2.8（更早版本叫 `basicauth`）。
- Caddyfile 中的 `rate_limit` 块需要社区插件
  `github.com/mholt/caddy-ratelimit`（用 `xcaddy` 构建），**不是** Caddy 标准发行版内置功能；
  没有该插件时请依赖应用内限流或前置 CDN/WAF。

---

## 5. systemd 部署（Linux 常驻）

以下命令以 `/opt/heartlog` 为代码目录、`/var/lib/heartlog` 为数据目录：

```bash
# 1) 创建无登录系统用户
sudo useradd --system --home /opt/heartlog --shell /usr/sbin/nologin heartlog

# 2) 放置代码并创建虚拟环境（不要用 root 跑 pip）
sudo install -d -o heartlog -g heartlog -m 0755 /opt/heartlog
sudo -u heartlog git clone <your-repo> /opt/heartlog   # 或 rsync 你的工作副本
sudo -u heartlog python3 -m venv /opt/heartlog/.venv
sudo -u heartlog /opt/heartlog/.venv/bin/pip install -r /opt/heartlog/requirements.txt

# 3) 数据目录（仅服务账户可访问）
sudo install -d -o heartlog -g heartlog -m 0700 \
    /var/lib/heartlog /var/lib/heartlog/data \
    /var/lib/heartlog/backups /var/lib/heartlog/exports

# 4) 环境文件：复制模板、填真实令牌，权限 0600
sudo install -d -m 0750 -o root -g heartlog /etc/heartlog
sudo install -m 0600 -o root -g heartlog /dev/null /etc/heartlog/heartlog.env
sudo nano /etc/heartlog/heartlog.env    # 参照 deploy/heartlog.env.example

# 5) 首次迁移（应用不自动建表时；alembic 从进程环境读取 HEARTLOG_DATABASE_URL）
sudo -u heartlog env \
    HEARTLOG_DATABASE_URL=sqlite:////var/lib/heartlog/data/heartlog.db \
    HEARTLOG_DATA_DIR=/var/lib/heartlog/data \
    HEARTLOG_BACKUP_DIR=/var/lib/heartlog/backups \
    sh -c 'cd /opt/heartlog && .venv/bin/python -m alembic upgrade head'

# 6) 安装并启动服务
sudo install -m 0644 /opt/heartlog/deploy/heartlog.service /etc/systemd/system/heartlog.service
sudo systemctl daemon-reload
sudo systemctl enable --now heartlog
sudo systemctl status --no-pager heartlog
journalctl -u heartlog -n 50 --no-pager
```

验证与加固检查：

```bash
systemd-analyze verify deploy/heartlog.service       # 语法/依赖检查
systemd-analyze security heartlog.service            # 暴露面评分
curl -sS http://127.0.0.1:8000/health
ls -l /var/lib/heartlog /var/lib/heartlog/data       # 期望 drwx------ / -rw-------
```

注意：

- `ProtectProc=invisible` / `ProcSubset=pid` 需要 systemd ≥ 247，老系统删除这两行。
- `MemoryDenyWriteExecute=true` / `SystemCallFilter=@system-service` 在极少数依赖会失效；
  如服务无法启动，逐项放宽并在变更记录中说明原因。
- 服务日志进 journald。HeartLog 设计上不记录日记正文/令牌，但路径、异常栈仍可能敏感，
  多用户机器请限制 `journalctl` 访问。
- 服务绑定 `127.0.0.1:8000`，前面必须搭配 Nginx/Caddy；不要改成 `0.0.0.0`。

---

## 6. 应用内限流（与代理限流的分工）

```bash
# .env / EnvironmentFile 示例
HEARTLOG_RATE_LIMIT_ENABLED=true
HEARTLOG_RATE_LIMIT_REQUESTS=240
HEARTLOG_RATE_LIMIT_WINDOW_SECONDS=60
# 仅当 Nginx/Caddy 覆盖（而非追加）X-Forwarded-For 时才打开：
HEARTLOG_TRUST_PROXY_HEADERS=true
```

- 作用范围：`/api/v1` 前缀；`/health`、`/docs`、`/openapi.json` 等默认放行。
- 429 响应：`{"error":{"code":"rate_limited",...}}`，带 `Retry-After`、
  `X-RateLimit-Limit/Remaining/Reset` 头；仍会经过原有 request-id/隐私头/访问日志中间件。
- `X-Forwarded-For` **默认不信任**。`nginx.conf` 用 `$remote_addr` 覆盖该头；
  若改成 `$proxy_add_x_forwarded_for`（追加语义），客户端可伪造第一跳绕过按 IP 限流。
- 进程内限流：单 worker 有效；`--workers N` 时实际阈值约为 `N × requests`。
  重启清零。对公网暴露请同时启用代理层 `limit_req`。

---

## 7. 文件权限

```bash
# 先看 dry-run（默认不修改任何东西）
python scripts/harden_permissions.py

# 确认后应用：POSIX 目录 0700 / 文件 0600；Windows 用 icacls 收紧 ACL
python scripts/harden_permissions.py --apply

# 服务器上数据目录在 /var/lib/heartlog 时：
python scripts/harden_permissions.py --root /var/lib/heartlog --apply
```

Windows：脚本会为每个条目生成并（在 `--apply` 时）执行
`icacls <path> /inheritance:r /grant:r "<当前用户>":... /grant:r *S-1-5-18:... /grant:r *S-1-5-32-544:...`，
只移除继承 ACE，不删除当前用户/SYSTEM/Administrators 的显式授权。需要时用管理员终端执行。

---

## 8. 证书轮换

```bash
# Let's Encrypt：自动续期，检查 dry-run
sudo certbot renew --dry-run

# 自签开发证书（仅本机；默认输出 certs/，已被 gitignore）
python scripts/generate_dev_cert.py --force
```

替换证书后 `sudo systemctl reload nginx`（或 `systemctl reload caddy`）即可，不必重启
HeartLog 后端。私钥文件权限保持 0600，避免进入备份/同步盘。

---

## 9. Windows 说明

HeartLog 也支持 Windows 本机部署；Windows 没有 systemd：

- **Windows 服务**：可用 [NSSM](https://nssm.cc/) 或
  `sc.exe create HeartLog binPath= "...python.exe -m uvicorn ..."` 包装 uvicorn；
  服务账户建议使用专用本地账户，并对其 profile/数据目录设置 ACL。
- **开机自启（不装服务）**：任务计划程序创建"登录时/开机时"任务，运行
  `C:\path\to\.venv\Scripts\python.exe -m uvicorn "app.main:create_app" --factory --host 127.0.0.1 --port 8000`，
  "起始于"设为项目目录。
- **TLS**：Windows 本机可直接用 uvicorn `--ssl-keyfile/--ssl-certfile` 配合
  `scripts/generate_dev_cert.py` 生成的自签证书；对外仍推荐 Nginx（Windows 版）或
  Caddy 反代并配置系统信任的证书。
- **权限**：用 `scripts/harden_permissions.py --apply` 的 icacls 路径，或用
  `icacls "D:\HeartLog\data" /inheritance:r /grant:r "%USERNAME%":(OI)(CI)F`。
- **防火墙**：保持 uvicorn 只监听 `127.0.0.1`；若要局域网访问，只放行反代端口（443），
  不要放行 8000。

---

## 10. 上线前 checklist

- [ ] `nginx -t` / `caddy validate` / `systemd-analyze verify` 通过（本仓库未实测）。
- [ ] 真实 CA 证书已配置，HTTP 强制跳转 HTTPS；HSTS 按需且谨慎开启。
- [ ] `HEARTLOG_API_TOKEN`、`HEARTLOG_ADMIN_TOKEN` 为长随机值，`.env`/env file 0600。
- [ ] 代理层与应用层限流都已启用并实际触发过一次 429。
- [ ] `/docs`、`/redoc`、`/openapi.json` 默认 404（确需开启时加认证）。
- [ ] `HEARTLOG_TRUST_PROXY_HEADERS=true` 仅配合"覆盖 XFF"的代理；否则保持 false。
- [ ] 数据/备份/导出目录权限已收紧；备份已加密或放在加密卷。
- [ ] 访问日志不含 query string；日志轮转与访问控制已配置。
- [ ] 已运行 `python scripts/verify_integrity.py`、备份/恢复演练（见 docs/operations.md）。
- [ ] 已知悉：SQLite 文件访问权限才是最终安全边界，TLS/认证/限流不改变这一点。
