#!/usr/bin/env python
"""Restore a HeartLog backup with explicit safety checks.

Usage:
    python scripts/restore.py PATH_TO_BACKUP [--force]

The application must be stopped.  Plaintext SQLite backups and encrypted
AES-256-GCM backups created by ``scripts/backup.py --encrypt`` are both
accepted.  If the target database already exists, a pre-restore safety backup is
created and the command requires ``--force``.  The backup's sibling ``.sha256``
file and/or JSON manifest are verified when present, and the staged restore is
integrity-checked before it replaces the live database.

Encrypted backups need the passphrase in the environment variable named by
``--passphrase-env`` (default ``HEARTLOG_BACKUP_PASSPHRASE``).  The passphrase is
never accepted on the command line and never printed.
"""

from __future__ import annotations

import argparse
import os
import shutil
import sys
from datetime import UTC, datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from app.services.backup_service import (  # noqa: E402
    DEFAULT_PASSPHRASE_ENV,
    BackupError,
    configured_database_path,
    create_plaintext_backup,
    decrypt_file,
    resolve_passphrase,
    sha256_file,
    sqlite_integrity_check,
    verify_backup_file,
)

__all__ = [
    "main",
    "restore_backup",
    "sha256_file",
    "target_database_path",
    "verify_backup",
]


def target_database_path() -> Path:
    """Resolve the configured file-backed SQLite database path."""

    return configured_database_path()


def verify_backup(path: Path) -> dict:
    """Verify checksum/manifest consistency and return backup metadata.

    Kept as a CLI-style helper for backward compatibility: failures raise
    ``SystemExit`` (the original script contract) instead of ``BackupError``;
    the restore flow below uses :func:`verify_backup_file` directly.
    """

    try:
        return verify_backup_file(Path(path))
    except BackupError as exc:
        raise SystemExit(str(exc)) from exc


def _active_sidecar(target: Path) -> Path | None:
    for suffix in ("-wal", "-shm"):
        sidecar = Path(str(target) + suffix)
        if sidecar.exists() and sidecar.stat().st_size > 0:
            return sidecar
    return None


def restore_backup(
    backup: Path,
    target: Path | None = None,
    *,
    force: bool = False,
    passphrase: str | None = None,
    passphrase_env: str = DEFAULT_PASSPHRASE_ENV,
) -> dict:
    """Restore *backup* over *target* with staging and safety backups.

    Raises :class:`BackupError` (content-free message) for a checksum mismatch,
    missing/wrong passphrase, active SQLite sidecars or a missing ``--force``.
    The live database is never modified unless a verified staged copy exists and
    a safety backup of the previous target was created successfully.
    """

    backup = Path(backup)
    target = Path(target) if target is not None else target_database_path()
    target = target.resolve()

    metadata = verify_backup_file(backup)
    encrypted = metadata["encrypted"]
    resolved_passphrase = resolve_passphrase(passphrase, env_name=passphrase_env) if encrypted else None

    if target.exists():
        if not force:
            raise BackupError(
                f"Target database exists: {target}. Stop HeartLog and re-run with --force to restore."
            )
        active_sidecar = _active_sidecar(target)
        if active_sidecar is not None:
            raise BackupError(
                f"Active SQLite sidecar found ({active_sidecar.name}). Stop HeartLog and "
                "checkpoint the database before restoring."
            )

    target.parent.mkdir(parents=True, exist_ok=True)
    staging = target.with_name(target.name + ".restore-tmp")
    staging.unlink(missing_ok=True)
    safety_backup: Path | None = None
    try:
        if encrypted:
            decrypt_file(backup, staging, resolved_passphrase)
        else:
            shutil.copy2(backup, staging)
        if sqlite_integrity_check(staging) != "ok":
            raise BackupError("Staged restore failed integrity check; the live database was not changed.")

        if target.exists():
            safety_directory = target.parent / "backups"
            safety_backup = safety_directory / (
                f"pre-restore-{datetime.now(UTC).strftime('%Y%m%dT%H%M%SZ')}.db"
            )
            try:
                create_plaintext_backup(target, safety_backup)
            except BackupError as exc:
                raise BackupError(
                    f"Could not create a pre-restore safety backup; aborting restore: {exc}"
                ) from exc
        os.replace(staging, target)
    except BaseException:
        staging.unlink(missing_ok=True)
        raise

    # A zero-length -wal/-shm left by a clean shutdown would make the restored
    # database look active to SQLite; remove only empty sidecars (non-empty ones
    # were refused above).
    for suffix in ("-wal", "-shm"):
        sidecar = Path(str(target) + suffix)
        if sidecar.exists() and sidecar.stat().st_size == 0:
            sidecar.unlink(missing_ok=True)

    return {
        "restored": str(target),
        "backup": str(backup),
        "encrypted": encrypted,
        "safety_backup": str(safety_backup) if safety_backup is not None else None,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("backup", type=Path, help="Backup file to restore (.db or encrypted .db.enc)")
    parser.add_argument("--force", action="store_true", help="Required when the target DB already exists")
    parser.add_argument(
        "--passphrase-env",
        default=DEFAULT_PASSPHRASE_ENV,
        metavar="NAME",
        help=(
            "Name of the environment variable holding the backup passphrase "
            f"(default: {DEFAULT_PASSPHRASE_ENV})"
        ),
    )
    args = parser.parse_args(argv)

    try:
        result = restore_backup(
            args.backup,
            target_database_path(),
            force=args.force,
            passphrase_env=args.passphrase_env,
        )
    except BackupError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    print(f"Restored {result['backup']} -> {result['restored']}")
    if result["encrypted"]:
        print("Encrypted backup decrypted and verified before replacing the database.")
    if result["safety_backup"]:
        print(f"Safety backup created: {result['safety_backup']}")
    print("Start HeartLog and verify records before deleting any safety backup.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
