#!/usr/bin/env python
"""Local backup scheduler for HeartLog (no external scheduler dependency).

Usage:
    python scripts/backup_scheduler.py --once [--encrypt] [--retention N]
    python scripts/backup_scheduler.py --interval-hours 24 [--encrypt] [--retention N]
    python scripts/backup_scheduler.py --interval-seconds 3600

The scheduler creates a normal HeartLog backup (plaintext or AES-256-GCM
encrypted), applies the retention policy after every successful run, and exits
cleanly on SIGINT/SIGTERM (a running backup finishes before shutdown).

Logging is metadata-only: paths, counts, status, error reasons.  The backup
passphrase is read from the environment variable named by ``--passphrase-env``
(default ``HEARTLOG_BACKUP_PASSPHRASE``) and is never printed, stored or passed
through argv.

Examples:
    # One backup, e.g. from Windows Task Scheduler or cron
    python scripts/backup_scheduler.py --once --encrypt

    # Foreground daemon: backup every 6 hours, keep the newest 14
    python scripts/backup_scheduler.py --interval-hours 6 --encrypt --retention 14

Stop the loop with Ctrl+C (SIGINT) or SIGTERM; the current backup completes
first and then the process exits with code 0.
"""

from __future__ import annotations

import argparse
import logging
import signal
import sys
import threading
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from app.services.backup_service import (  # noqa: E402
    DEFAULT_PASSPHRASE_ENV,
    DEFAULT_RETENTION,
    BackupError,
    auto_backup_filename,
    configured_backup_dir,
    configured_database_path,
    create_encrypted_backup,
    create_plaintext_backup,
    prune_backups,
    resolve_passphrase,
)

LOGGER = logging.getLogger("heartlog.backup_scheduler")


def run_once(
    *,
    encrypt: bool = False,
    retention: int = DEFAULT_RETENTION,
    passphrase: str | None = None,
    passphrase_env: str = DEFAULT_PASSPHRASE_ENV,
    backup_dir: Path | None = None,
    source: Path | None = None,
) -> dict[str, Any]:
    """Create one auto-named backup and prune old auto backups.

    This is the testable core of the scheduler: it returns a JSON-serialisable
    metadata dict (paths, counts, status) and never logs/returns private content
    or the passphrase.  ``passphrase`` is for in-process callers/tests only; the
    command line uses the env-var indirection.
    """

    if isinstance(retention, bool) or not isinstance(retention, int) or retention < 0:
        raise BackupError("Retention must be a non-negative integer (0 means unlimited).")

    database = Path(source) if source is not None else configured_database_path()
    directory = Path(backup_dir) if backup_dir is not None else configured_backup_dir()
    directory.mkdir(parents=True, exist_ok=True)

    destination = directory / auto_backup_filename(encrypted=encrypt)
    if destination.exists():
        raise BackupError(
            f"Backup for this timestamp already exists ({destination.name}); "
            "retry in a moment or use scripts/backup.py --output for an explicit name."
        )

    if encrypt:
        resolved = resolve_passphrase(passphrase, env_name=passphrase_env)
        manifest = create_encrypted_backup(database, destination, resolved)
    else:
        manifest = create_plaintext_backup(database, destination)

    deleted = prune_backups(directory, retention, protected={destination})
    result = {
        "status": "ok",
        "backup": str(destination),
        "encrypted": manifest["encrypted"],
        "sha256": manifest["sha256"],
        "size_bytes": manifest["size_bytes"],
        "table_counts": manifest["table_counts"],
        "created_at": manifest["created_at"],
        "retention": retention,
        "deleted_count": len(deleted),
        "deleted": [path.name for path in deleted],
    }
    LOGGER.info(
        "backup_ok path=%s encrypted=%s size_bytes=%s retention=%s pruned=%s",
        destination,
        manifest["encrypted"],
        manifest["size_bytes"],
        retention,
        len(deleted),
    )
    return result


def make_signal_handler(stop_event: threading.Event) -> Any:
    """Create a SIGINT/SIGTERM handler that requests a graceful stop."""

    def handler(signum: int, _frame: object) -> None:
        LOGGER.info("shutdown_requested signal=%s", signum)
        stop_event.set()

    return handler


def install_signal_handlers(stop_event: threading.Event) -> list[tuple[int, Any]]:
    """Install graceful SIGINT/SIGTERM handlers, returning the previous ones."""

    previous: list[tuple[int, Any]] = []
    for name in ("SIGINT", "SIGTERM"):
        signum = getattr(signal, name, None)
        if signum is None:
            continue
        try:
            previous.append((signum, signal.getsignal(signum)))
            signal.signal(signum, make_signal_handler(stop_event))
        except (ValueError, OSError):  # not supported here / not the main thread
            if previous and previous[-1][0] == signum:
                previous.pop()
    return previous


def restore_signal_handlers(previous: list[tuple[int, Any]]) -> None:
    for signum, handler in previous:
        try:
            signal.signal(signum, handler)
        except (ValueError, OSError):  # pragma: no cover - defensive restore
            continue


def run_loop(
    *,
    interval_seconds: int,
    encrypt: bool = False,
    retention: int = DEFAULT_RETENTION,
    passphrase: str | None = None,
    passphrase_env: str = DEFAULT_PASSPHRASE_ENV,
    backup_dir: Path | None = None,
    source: Path | None = None,
    stop_event: threading.Event | None = None,
) -> int:
    """Run backups forever until SIGINT/SIGTERM (or *stop_event* is set)."""

    if isinstance(interval_seconds, bool) or not isinstance(interval_seconds, int) or interval_seconds < 1:
        raise BackupError("Interval must be at least 1 second.")
    stop = stop_event if stop_event is not None else threading.Event()
    previous = install_signal_handlers(stop)
    exit_code = 0
    LOGGER.info(
        "scheduler_start interval_seconds=%s encrypt=%s retention=%s",
        interval_seconds,
        encrypt,
        retention,
    )
    try:
        while not stop.is_set():
            try:
                result = run_once(
                    encrypt=encrypt,
                    retention=retention,
                    passphrase=passphrase,
                    passphrase_env=passphrase_env,
                    backup_dir=backup_dir,
                    source=source,
                )
                LOGGER.info(
                    "scheduler_run status=ok path=%s encrypted=%s pruned=%s",
                    result["backup"],
                    result["encrypted"],
                    result["deleted_count"],
                )
            except BackupError as exc:
                exit_code = 1
                LOGGER.error("scheduler_run status=failed reason=%s", exc)
            except Exception as exc:  # noqa: BLE001 - a scheduler must not die on one bad run
                exit_code = 1
                LOGGER.error(
                    "scheduler_run status=failed reason=unexpected_error type=%s",
                    type(exc).__name__,
                )
            if stop.wait(interval_seconds):
                break
    finally:
        restore_signal_handlers(previous)
        LOGGER.info("scheduler_stop")
    return exit_code


def _positive_interval(args: argparse.Namespace, parser: argparse.ArgumentParser) -> int:
    if args.interval_seconds is not None and args.interval_hours is not None:
        parser.error("choose only one of --interval-seconds or --interval-hours")
    if args.interval_seconds is not None:
        interval = args.interval_seconds
    elif args.interval_hours is not None:
        interval = int(round(args.interval_hours * 3600))
    else:
        parser.error("choose --once or an interval (--interval-seconds/--interval-hours)")
    if interval < 1:
        parser.error("interval must be at least 1 second")
    return interval


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--once", action="store_true", help="Create one backup and exit")
    parser.add_argument("--interval-seconds", type=int, default=None, help="Seconds between backups")
    parser.add_argument("--interval-hours", type=float, default=None, help="Hours between backups")
    parser.add_argument("--encrypt", action="store_true", help="Create encrypted AES-256-GCM backups")
    parser.add_argument(
        "--retention",
        type=int,
        default=DEFAULT_RETENTION,
        metavar="N",
        help=f"Keep N most recent auto-generated backups (default {DEFAULT_RETENTION}; 0 = unlimited)",
    )
    parser.add_argument(
        "--passphrase-env",
        default=DEFAULT_PASSPHRASE_ENV,
        metavar="NAME",
        help=(
            "Name of the environment variable holding the backup passphrase "
            f"(default: {DEFAULT_PASSPHRASE_ENV})"
        ),
    )
    parser.add_argument(
        "--backup-dir",
        type=Path,
        default=None,
        help="Override the backup directory (default: HEARTLOG_BACKUP_DIR)",
    )
    args = parser.parse_args(argv)
    if args.retention < 0:
        parser.error("--retention must be >= 0 (0 means unlimited)")
    if args.once and (args.interval_seconds is not None or args.interval_hours is not None):
        parser.error("--once cannot be combined with an interval")
    interval = None if args.once else _positive_interval(args, parser)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )

    if args.encrypt:
        # Fail fast for a missing passphrase instead of looping on a
        # configuration error that cannot fix itself.
        try:
            resolve_passphrase(env_name=args.passphrase_env)
        except BackupError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2

    common: dict[str, Any] = {
        "encrypt": args.encrypt,
        "retention": args.retention,
        "passphrase_env": args.passphrase_env,
        "backup_dir": args.backup_dir,
    }
    if args.once:
        try:
            result = run_once(**common)
        except BackupError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2
        print(f"Backup created: {result['backup']}")
        print(f"Encrypted: {'yes (AES-256-GCM)' if result['encrypted'] else 'no (plaintext SQLite)'}")
        print(f"Rows: {result['table_counts']}")
        print(f"Retention: deleted {result['deleted_count']} old auto-generated backup(s)")
        return 0

    try:
        return run_loop(interval_seconds=interval, **common)  # type: ignore[arg-type]
    except BackupError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
