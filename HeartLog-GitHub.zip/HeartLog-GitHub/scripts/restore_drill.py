#!/usr/bin/env python
"""Offline restore drill: verify a HeartLog backup is really restorable.

Usage:
    python scripts/restore_drill.py BACKUP [--json]

The drill never touches the live database and never restores over it.  It:

1. verifies the backup file's SHA-256 sidecar / JSON manifest;
2. decrypts encrypted backups into a temporary directory (passphrase comes from
   ``--passphrase-env``, default ``HEARTLOG_BACKUP_PASSPHRASE``);
3. opens the copy read-only and runs ``PRAGMA integrity_check``;
4. checks that every expected HeartLog table is present;
5. verifies diary original-text hashes, revision hash chains and
   ``current_version`` / ``current_revision_id`` pointers;
6. verifies memory content hashes, evidence sources and exact evidence
   substrings/offsets against immutable diary revisions;
7. removes all temporary files.

Prints metadata only (paths, counts, issue codes) -- never diary or memory text.
Exit code 0 means every check passed; 1 means the drill failed; 2 means the
command itself could not run (e.g. unknown format, unusable arguments).
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from app.services.backup_service import (  # noqa: E402
    DEFAULT_PASSPHRASE_ENV,
    BackupError,
    drill_backup,
)

__all__ = ["drill_backup", "main", "print_report"]


def print_report(report: dict) -> None:
    """Print a metadata-only human-readable drill report."""

    encrypted = report.get("encrypted")
    if encrypted is None:
        label = "unknown"
    else:
        label = "encrypted" if encrypted else "plaintext"
    print(f"Backup: {report.get('backup')} ({label})")
    for check in report.get("checks", []):
        marker = "ok" if check.get("ok") else "FAIL"
        print(f"  [{marker}] {check.get('name')}: {check.get('detail')}")
    counts = report.get("table_counts") or {}
    if counts:
        print(f"Table rows: {counts}")
    issues = report.get("issues") or []
    if issues:
        print(f"Restore drill FAILED: {len(issues)} issue(s)")
        for issue in issues:
            print(f"  - {issue}")
    else:
        print("Restore drill: OK")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("backup", type=Path, help="Backup file to drill (.db or encrypted .db.enc)")
    parser.add_argument("--json", action="store_true", help="Print a JSON report instead of text")
    parser.add_argument(
        "--passphrase-env",
        default=DEFAULT_PASSPHRASE_ENV,
        metavar="NAME",
        help=(
            "Name of the environment variable holding the backup passphrase "
            f"(default: {DEFAULT_PASSPHRASE_ENV})"
        ),
    )
    args = parser.parse_args(argv)

    try:
        report = drill_backup(
            args.backup,
            passphrase_env=args.passphrase_env,
        )
    except BackupError as exc:
        if args.json:
            report = {
                "status": "failed",
                "ok": False,
                "backup": str(args.backup),
                "encrypted": None,
                "checksum_verified": False,
                "checks": [],
                "issues": ["drill_error"],
                "table_counts": {},
                "error": str(exc),
            }
            print(json.dumps(report, indent=2, ensure_ascii=False))
        else:
            print(f"error: {exc}", file=sys.stderr)
        return 2

    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print_report(report)
    return 0 if report.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
