#!/usr/bin/env python
"""Generate a self-signed TLS certificate for *local development* only.

The certificate is intentionally a throwaway: it is self-signed, not issued by
a public CA, and clients will show a warning unless they explicitly trust it.
**Never use this for a production deployment.**  For production either put
HeartLog behind a reverse proxy with a real certificate (Let's Encrypt / your
organisational CA) or install a certificate you obtained through your normal
process; see ``deploy/README.md`` and ``docs/deployment_security.md``.

Usage
-----
::

    python scripts/generate_dev_cert.py                 # writes certs/localhost.{key,crt}
    python scripts/generate_dev_cert.py --force         # overwrite existing files
    python scripts/generate_dev_cert.py --out-dir /tmp/heartlog-certs --days 365

Then start uvicorn with TLS (see the command printed at the end)::

    python -m uvicorn "app.main:create_app" --factory \\
        --host 127.0.0.1 --port 8443 \\
        --ssl-keyfile certs/localhost.key --ssl-certfile certs/localhost.crt

``certs/``, ``*.key`` and ``*.pem`` are git-ignored; keep the private key out of
version control, backups you share, and chat/issue trackers.
"""

from __future__ import annotations

import argparse
import ipaddress
import os
import sys
import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path

try:  # pragma: no cover - the dependency is pinned in requirements.txt
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID
except ImportError:  # pragma: no cover - friendly message instead of traceback
    print(
        "ERROR: the 'cryptography' package is required.\n"
        "Install project dependencies first: pip install -r requirements.txt",
        file=sys.stderr,
    )
    raise SystemExit(1) from None

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_OUT_DIR = PROJECT_ROOT / "certs"
DEFAULT_DAYS = 825
DEFAULT_CN = "localhost"

POSIX = os.name == "posix"


def _build_certificate(
    *,
    common_name: str,
    days: int,
) -> tuple[rsa.RSAPrivateKey, x509.Certificate]:
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = issuer = x509.Name(
        [
            x509.NameAttribute(NameOID.COMMON_NAME, common_name),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "HeartLog local development"),
        ]
    )
    now = datetime.now(UTC)
    dns_names = ["localhost"] if common_name == "localhost" else ["localhost", common_name]
    san = x509.SubjectAlternativeName(
        [
            *(x509.DNSName(name) for name in dns_names),
            x509.IPAddress(ipaddress.IPv4Address("127.0.0.1")),
            x509.IPAddress(ipaddress.IPv6Address("::1")),
        ]
    )
    certificate = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - timedelta(days=1))
        .not_valid_after(now + timedelta(days=days))
        .add_extension(san, critical=False)
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(
            x509.KeyUsage(
                digital_signature=True,
                content_commitment=False,
                key_encipherment=True,
                data_encipherment=False,
                key_agreement=True,
                key_cert_sign=False,
                crl_sign=False,
                encipher_only=False,
                decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(
            x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]),
            critical=False,
        )
        .add_extension(
            x509.SubjectKeyIdentifier.from_public_key(key.public_key()),
            critical=False,
        )
        .sign(key, hashes.SHA256())
    )
    return key, certificate


def _write_private_key(path: Path, key: rsa.RSAPrivateKey) -> None:
    data = key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    _atomic_write(path, data)


def _write_certificate(path: Path, certificate: x509.Certificate) -> None:
    _atomic_write(path, certificate.public_bytes(serialization.Encoding.PEM))


def _atomic_write(path: Path, data: bytes) -> None:
    """Write ``data`` to ``path`` via a temporary file in the same directory."""

    handle, temporary_name = tempfile.mkstemp(dir=str(path.parent), prefix=f".{path.name}.", suffix=".tmp")
    temporary_path = Path(temporary_name)
    try:
        with os.fdopen(handle, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary_path, path)
    finally:
        temporary_path.unlink(missing_ok=True)


def _restrict_permissions(path: Path, mode: int) -> None:
    """Best-effort permission restriction (meaningful on POSIX only)."""

    try:
        path.chmod(mode)
    except OSError as exc:  # pragma: no cover - e.g. restricted filesystems
        print(f"WARNING: could not set permissions on {path}: {exc}", file=sys.stderr)


def _format_fingerprint(certificate: x509.Certificate) -> str:
    digest = certificate.fingerprint(hashes.SHA256()).hex().upper()
    return ":".join(digest[index : index + 2] for index in range(0, len(digest), 2))


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate a throwaway self-signed localhost certificate for HeartLog development.",
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=DEFAULT_OUT_DIR,
        help=f"output directory (default: {DEFAULT_OUT_DIR})",
    )
    parser.add_argument(
        "--days",
        type=int,
        default=DEFAULT_DAYS,
        help=f"certificate validity in days (default: {DEFAULT_DAYS})",
    )
    parser.add_argument(
        "--common-name",
        default=DEFAULT_CN,
        help=f"certificate common name (default: {DEFAULT_CN})",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="overwrite existing key/certificate files",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    if not 1 <= args.days <= 3650:
        print("ERROR: --days must be between 1 and 3650", file=sys.stderr)
        return 2
    out_dir: Path = args.out_dir.expanduser()
    key_path = out_dir / "localhost.key"
    cert_path = out_dir / "localhost.crt"

    if not args.force and (key_path.exists() or cert_path.exists()):
        print(
            f"ERROR: refusing to overwrite existing certificate material in {out_dir}\n"
            f"       found: {key_path if key_path.exists() else cert_path}\n"
            "       use --force to replace it (the old key will be lost).",
            file=sys.stderr,
        )
        return 2

    out_dir.mkdir(parents=True, exist_ok=True)
    if POSIX:
        _restrict_permissions(out_dir, 0o700)

    print(f"Generating self-signed development certificate in {out_dir} ...")
    key, certificate = _build_certificate(common_name=args.common_name, days=args.days)
    _write_private_key(key_path, key)
    _write_certificate(cert_path, certificate)
    # Private key is the sensitive part: 0600.  The certificate is public: 0644.
    _restrict_permissions(key_path, 0o600)
    _restrict_permissions(cert_path, 0o644)

    print(
        "\n" + "=" * 78 + "\n"
        "[DEV ONLY] Self-signed certificate generated -- NOT FOR PRODUCTION.\n"
        "It is not issued by a public certificate authority, browsers and HTTP\n"
        "clients will warn unless you explicitly trust it, and any secret that\n"
        "relies on this certificate's identity can be impersonated by anyone who\n"
        "has the key file. Use it only on loopback for local development.\n" + "=" * 78
    )
    print(f"  Certificate : {cert_path}")
    print(f"  Private key : {key_path}")
    print(f"  Validity    : {args.days} days (from {datetime.now(UTC):%Y-%m-%d})")
    print(f"  SHA-256     : {_format_fingerprint(certificate)}")
    print(
        "\nStart HeartLog with TLS (local only):\n"
        f'  python -m uvicorn "app.main:create_app" --factory --host 127.0.0.1 --port 8443 \\\n'
        f"      --ssl-keyfile {key_path} --ssl-certfile {cert_path}\n"
        "\nTest with curl (trusting only this certificate for the request):\n"
        f"  curl --cacert {cert_path} https://localhost:8443/health\n"
        "\nKeep certs/, *.key and *.pem out of version control (they are git-ignored)."
    )
    if os.name == "nt":
        user = os.environ.get("USERNAME", "%USERNAME%")
        print(
            "\nWindows: restrict the private key's ACL to your account, e.g.\n"
            f'  icacls "{key_path}" /inheritance:r /grant:r "{user}":F\n'
            f'  icacls "{out_dir}" /inheritance:r /grant:r "{user}":(OI)(CI)F'
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
