#!/usr/bin/env python
"""Create a verified HeartLog backup, optionally AES-256-GCM encrypted.

Usage:
    python scripts/backup.py [--output PATH] [--encrypt] [--retention N]

The backup uses SQLite's online backup API (safe while HeartLog is running),
verifies ``PRAGMA integrity_check`` and writes a sibling SHA-256 sidecar plus a
small JSON manifest that contains metadata only.

``--encrypt`` creates a versioned AES-256-GCM container (Scrypt KDF) instead of
a plaintext SQLite file.  The passphrase is read from the environment variable
named by ``--passphrase-env`` (default ``HEARTLOG_BACKUP_PASSPHRASE``); it is
never accepted as a command-line value, never stored in the backup/manifest and
never printed.

After a successful backup, ``--retention N`` keeps the N most recent
auto-generated backups in the backup directory (default 14, ``0`` = unlimited).
Only files matching HeartLog's own generated naming and carrying consistent
``.sha256``/``.json`` metadata are ever removed.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from app.services.backup_service import (  # noqa: E402
    DEFAULT_PASSPHRASE_ENV,
    DEFAULT_RETENTION,
    BackupError,
    auto_backup_filename,
    configured_backup_dir,
    configured_database_path,
    create_encrypted_backup,
    create_plaintext_backup,
    manifest_path,
    prune_backups,
    resolve_passphrase,
    sha256_file,
)

__all__ = [
    "backup_database",
    "database_path",
    "main",
    "sha256_file",
]


def database_path() -> Path:
    """Resolve the configured file-backed SQLite database path."""

    return configured_database_path()


def backup_database(source: Path, destination: Path) -> dict:
    """Create a plaintext, integrity-checked backup (MVP-compatible helper).

    Kept as a module-level function because the existing test suite imports it
    from this script.  CLI-style failures are raised as ``SystemExit`` so the
    script still behaves like the original MVP tool.
    """

    try:
        return create_plaintext_backup(Path(source), Path(destination))
    except BackupError as exc:
        raise SystemExit(str(exc)) from exc


def _retention_directory(args: argparse.Namespace, default_dir: Path, destination: Path) -> Path:
    if args.backup_dir is not None:
        return Path(args.backup_dir)
    if args.output is not None:
        # The user explicitly chose where these backups live; prune there instead
        # of surprising them by touching the configured backup directory.
        return destination.parent
    return default_dir


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--output", type=Path, help="Destination backup file (must not exist)")
    parser.add_argument(
        "--encrypt",
        action="store_true",
        help="Write an encrypted AES-256-GCM backup instead of a plaintext SQLite file",
    )
    parser.add_argument(
        "--retention",
        type=int,
        default=DEFAULT_RETENTION,
        metavar="N",
        help=(
            "Keep N most recent auto-generated backups in the backup directory "
            f"(default {DEFAULT_RETENTION}; 0 = unlimited)"
        ),
    )
    parser.add_argument(
        "--backup-dir",
        type=Path,
        default=None,
        help="Directory to prune with --retention (default: output parent or HEARTLOG_BACKUP_DIR)",
    )
    parser.add_argument(
        "--passphrase-env",
        default=DEFAULT_PASSPHRASE_ENV,
        metavar="NAME",
        help=(
            "Name of the environment variable holding the backup passphrase "
            f"(default: {DEFAULT_PASSPHRASE_ENV})"
        ),
    )
    args = parser.parse_args(argv)
    if args.retention < 0:
        parser.error("--retention must be >= 0 (0 means unlimited)")

    try:
        source = database_path()
        backup_dir = configured_backup_dir()
    except BackupError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    destination = (
        Path(args.output)
        if args.output is not None
        else backup_dir / auto_backup_filename(encrypted=args.encrypt)
    )
    try:
        if args.encrypt:
            passphrase = resolve_passphrase(env_name=args.passphrase_env)
            manifest = create_encrypted_backup(source, destination, passphrase)
        else:
            manifest = create_plaintext_backup(source, destination)
    except BackupError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    print(f"Backup created: {manifest['backup']}")
    print(f"Encrypted: {'yes (AES-256-GCM)' if manifest['encrypted'] else 'no (plaintext SQLite)'}")
    print(f"SHA-256: {manifest['sha256']}")
    print(f"Manifest: {manifest_path(destination)}")
    print(f"Rows: {manifest['table_counts']}")

    retention_dir = _retention_directory(args, backup_dir, destination)
    if args.retention == 0:
        print(f"Retention: unlimited (0); no pruning in {retention_dir}")
    else:
        try:
            deleted = prune_backups(retention_dir, args.retention, protected={destination})
        except BackupError as exc:
            print(f"error: retention failed: {exc}", file=sys.stderr)
            return 2
        print(
            f"Retention: keep {args.retention} most recent auto-generated backups in "
            f"{retention_dir}; deleted {len(deleted)}"
        )
        for path in deleted:
            print(f"  deleted: {path.name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
