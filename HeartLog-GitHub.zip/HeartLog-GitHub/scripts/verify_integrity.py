#!/usr/bin/env python
"""Verify hashes, revision chains, memory sources and evidence excerpts.

Prints only IDs/codes, never diary text.  Exits non-zero when any issue is found.
"""

from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from sqlalchemy import select  # noqa: E402

from app.core.config import get_settings  # noqa: E402
from app.db.session import create_engine_for, create_session_factory  # noqa: E402
from app.models.diary import DiaryEntry, DiaryRevision  # noqa: E402
from app.models.memory import Memory, MemorySource  # noqa: E402
from app.services.diary_service import DiaryService  # noqa: E402


def main() -> int:
    settings = get_settings()
    engine = create_engine_for(settings)
    session_factory = create_session_factory(engine)
    session = session_factory()
    issues: list[str] = []
    try:
        entries = list(session.scalars(select(DiaryEntry)))
        for entry in entries:
            report = DiaryService(session, settings).integrity(entry.id, include_deleted=True)
            for issue in report.issues:
                issues.append(f"diary:{entry.id}:{issue.code}:v{issue.version}")

        memories = list(session.scalars(select(Memory)))
        for memory in memories:
            sources = list(session.scalars(select(MemorySource).where(MemorySource.memory_id == memory.id)))
            if not sources:
                issues.append(f"memory:{memory.id}:no_evidence_sources")
                continue
            if not any(
                source.revision_id == memory.source_revision_id and source.entry_id == memory.source_entry_id
                for source in sources
            ):
                issues.append(f"memory:{memory.id}:primary_source_not_in_sources")
            for source in sources:
                revision = session.get(DiaryRevision, source.revision_id)
                if revision is None:
                    issues.append(f"memory:{memory.id}:source_revision_missing:{source.revision_id}")
                    continue
                if revision.entry_id != source.entry_id:
                    issues.append(f"memory:{memory.id}:source_revision_entry_mismatch")
                if source.evidence_text not in revision.content:
                    issues.append(f"memory:{memory.id}:evidence_not_in_revision")
                if source.start_offset is not None and source.end_offset is not None:
                    if revision.content[source.start_offset : source.end_offset] != source.evidence_text:
                        issues.append(f"memory:{memory.id}:evidence_offset_mismatch")
    finally:
        session.close()
        engine.dispose()

    print(f"Checked diaries and memories. Issues: {len(issues)}")
    for issue in issues:
        print(" -", issue)
    return 1 if issues else 0


if __name__ == "__main__":
    raise SystemExit(main())
