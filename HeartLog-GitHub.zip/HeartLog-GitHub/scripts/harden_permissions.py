#!/usr/bin/env python
"""Harden filesystem permissions for HeartLog's private data directories.

HeartLog stores everything in plaintext files: the SQLite database (plus its
``-wal``/``-shm`` sidecars), backups and exports.  OS-level file permissions are
therefore the last line of defence against other local accounts/processes.  This
script restricts ``data/``, ``backups/`` and ``exports/`` to the current user.

Behaviour
---------
* **Dry-run by default.**  Nothing is changed unless ``--apply`` is passed; the
  script prints the exact commands it would run.
* **POSIX (Linux/macOS):** directories become ``0700``, regular files ``0600``.
* **Windows:** removes inherited ACLs and grants the current user, SYSTEM and
  Administrators full control on every existing entry (no removal of the
  current user's access).  Requires a shell that may change ACLs; expected to
  work for files you own, otherwise failures are reported per entry.
* Only ``data/``, ``backups/`` and ``exports/`` under the project root are
  touched by default.  Additional directories require explicit ``--include``
  and must still be inside the project root.
* Symlinks / NTFS reparse points are refused and never followed.  Files outside
  the listed targets are never modified.

Warnings
--------
Removing inherited ACLs (Windows) / tightening modes (POSIX) can break other
tools that read these files (backup agents, sync clients, editors running as a
different user, another OS account you share the machine with).  Review the
dry-run output first.  On Windows, run from an elevated shell if granting
SYSTEM/Administrators fails.  This script does not encrypt anything: a user with
administrator/root access can still read the files; see
``docs/deployment_security.md`` for the full threat model.
"""

from __future__ import annotations

import argparse
import os
import stat
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_TARGET_NAMES = ("data", "backups", "exports")
DIR_MODE = 0o700
FILE_MODE = 0o600

POSIX = os.name == "posix"
WINDOWS = os.name == "nt"

# Well-known Windows SIDs, valid on every locale.
WINDOWS_SYSTEM_SID = "*S-1-5-18"
WINDOWS_ADMINISTRATORS_SID = "*S-1-5-32-544"


@dataclass(frozen=True)
class WalkEntry:
    path: Path
    is_directory: bool


@dataclass(frozen=True)
class WalkResult:
    entries: list[WalkEntry]
    skipped_links: list[Path]


def _is_symlink_or_reparse(path: Path) -> bool:
    """True for POSIX symlinks and Windows reparse points (junctions etc.)."""

    try:
        if path.is_symlink():
            return True
    except OSError:  # pragma: no cover - unreadable path
        return True
    if WINDOWS and path.exists():
        try:
            attributes = path.stat(follow_symlinks=False).st_file_attributes
        except OSError:  # pragma: no cover
            return False
        return bool(attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT)
    return False


def _absolute(path: Path) -> Path:
    return Path(os.path.abspath(path))


def collect_targets(root: Path, includes: list[str]) -> tuple[list[Path], list[str], list[str]]:
    """Resolve target directories.

    Returns ``(targets, missing, errors)``.  Every target must exist, be a real
    directory inside ``root`` and not be a symlink/reparse point.
    """

    root = _absolute(root)
    targets: list[Path] = []
    missing: list[str] = []
    errors: list[str] = []
    seen: set[Path] = set()
    for raw in [*DEFAULT_TARGET_NAMES, *includes]:
        candidate = Path(raw).expanduser()
        if not candidate.is_absolute():
            candidate = root / candidate
        candidate = _absolute(candidate)
        if _is_symlink_or_reparse(candidate):
            errors.append(f"refusing symlink/reparse-point target: {candidate}")
            continue
        try:
            resolved = candidate.resolve(strict=True)
        except FileNotFoundError:
            missing.append(str(candidate))
            continue
        except OSError as exc:
            errors.append(f"cannot resolve {candidate}: {exc}")
            continue
        if not resolved.is_relative_to(root):
            errors.append(f"refusing target outside project root: {candidate}")
            continue
        if not resolved.is_dir():
            errors.append(f"target is not a directory: {resolved}")
            continue
        if resolved not in seen:
            seen.add(resolved)
            targets.append(resolved)
    return targets, missing, errors


def walk_target(target: Path) -> WalkResult:
    """Walk a directory without ever following symlinks/reparse points."""

    entries: list[WalkEntry] = []
    skipped: list[Path] = []
    for dirpath, dirnames, filenames in os.walk(target, followlinks=False):
        base = Path(dirpath)
        # Never descend into symlinked/junctioned directories (os.walk will not
        # follow them anyway, but remove them so they are reported once).
        for name in list(dirnames):
            child = base / name
            if _is_symlink_or_reparse(child):
                skipped.append(child)
                dirnames.remove(name)
        entries.append(WalkEntry(path=base, is_directory=True))
        for name in sorted(filenames):
            child = base / name
            if _is_symlink_or_reparse(child):
                skipped.append(child)
                continue
            try:
                if stat.S_ISREG(child.stat(follow_symlinks=False).st_mode):
                    entries.append(WalkEntry(path=child, is_directory=False))
            except OSError:  # pragma: no cover - race/unreadable entry
                skipped.append(child)
    return WalkResult(entries=entries, skipped_links=skipped)


def _posix_mode(path: Path) -> int:
    return stat.S_IMODE(path.stat(follow_symlinks=False).st_mode)


def plan_posix(targets: list[Path]) -> tuple[list[tuple[Path, int]], WalkResult]:
    changes: list[tuple[Path, int]] = []
    all_skipped: list[Path] = []
    for target in targets:
        walk = walk_target(target)
        all_skipped.extend(walk.skipped_links)
        for entry in walk.entries:
            desired = DIR_MODE if entry.is_directory else FILE_MODE
            try:
                current = _posix_mode(entry.path)
            except OSError:  # pragma: no cover
                current = -1
            if current != desired:
                changes.append((entry.path, desired))
    return changes, WalkResult(entries=[], skipped_links=all_skipped)


def _windows_identity() -> str:
    user = os.environ.get("USERNAME") or os.environ.get("USER") or "CURRENT_USER"
    domain = os.environ.get("USERDOMAIN")
    return f"{domain}\\{user}" if domain else user


def windows_grant_specs(is_directory: bool) -> list[str]:
    """Explicit ACEs: current user + SYSTEM + Administrators keep full control."""

    inheritance = "(OI)(CI)F" if is_directory else "F"
    return [
        f"{_windows_identity()}:{inheritance}",
        f"{WINDOWS_SYSTEM_SID}:{inheritance}",
        f"{WINDOWS_ADMINISTRATORS_SID}:{inheritance}",
    ]


def plan_windows(targets: list[Path]) -> tuple[list[list[str]], WalkResult]:
    commands: list[list[str]] = []
    all_skipped: list[Path] = []
    for target in targets:
        walk = walk_target(target)
        all_skipped.extend(walk.skipped_links)
        for entry in walk.entries:
            command = ["icacls", str(entry.path), "/inheritance:r"]
            for grant in windows_grant_specs(entry.is_directory):
                command.extend(["/grant:r", grant])
            commands.append(command)
    return commands, WalkResult(entries=[], skipped_links=all_skipped)


def display_command(command: list[str]) -> str:
    return subprocess.list2cmdline(command)


def apply_posix(changes: list[tuple[Path, int]]) -> list[str]:
    errors: list[str] = []
    for path, mode in changes:
        try:
            path.chmod(mode)
        except OSError as exc:
            errors.append(f"chmod {oct(mode)} {path}: {exc}")
    return errors


def apply_windows(commands: list[list[str]]) -> list[str]:
    errors: list[str] = []
    for command in commands:
        try:
            completed = subprocess.run(
                command,
                check=False,
                capture_output=True,
                text=True,
                errors="replace",
            )
        except OSError as exc:
            errors.append(f"{display_command(command)}: {exc}")
            continue
        output = (completed.stdout or "").strip()
        if completed.returncode != 0:
            errors.append(
                f"{display_command(command)} (exit {completed.returncode})"
                + (f": {output}" if output else "")
            )
    return errors


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Restrict permissions on HeartLog data/backups/exports. "
            "Dry-run by default; pass --apply to change anything."
        )
    )
    parser.add_argument(
        "--apply",
        action="store_true",
        help="actually change permissions (default is a dry run)",
    )
    parser.add_argument(
        "--root",
        type=Path,
        default=PROJECT_ROOT,
        help=f"project root containing data/backups/exports (default: {PROJECT_ROOT})",
    )
    parser.add_argument(
        "--include",
        action="append",
        default=[],
        metavar="PATH",
        help=(
            "additional directory to harden, relative to --root or absolute; "
            "must stay inside the project root (repeatable)"
        ),
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="only print the summary (suppresses the per-entry command list)",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    root = _absolute(args.root.expanduser())
    if _is_symlink_or_reparse(root):
        print(f"ERROR: refusing to operate on symlink/reparse-point root: {root}", file=sys.stderr)
        return 2
    if not root.is_dir():
        print(f"ERROR: project root is not a directory: {root}", file=sys.stderr)
        return 2

    targets, missing, errors = collect_targets(root, args.include)
    if errors:
        for message in errors:
            print(f"ERROR: {message}", file=sys.stderr)
        print("Aborting: no permissions were changed.", file=sys.stderr)
        return 2

    print("HeartLog permission hardening")
    print(f"  project root : {root}")
    print(f"  platform     : {'POSIX' if POSIX else 'Windows' if WINDOWS else os.name}")
    print(f"  mode         : {'APPLY (changes filesystem)' if args.apply else 'DRY-RUN (no changes)'}")
    print()
    if missing:
        print("Skipped (directory does not exist):")
        for path in missing:
            print(f"  - {path}")
        print()

    if POSIX:
        changes, walk = plan_posix(targets)
        if not args.quiet:
            print(f"Directory mode {oct(DIR_MODE)}, file mode {oct(FILE_MODE)}:")
            for path, mode in changes:
                verb = "chmod" if args.apply else "would chmod"
                print(f"  {verb} {oct(mode)} {path}")
        print(
            f"Targets: {len(targets)}; entries to update: {len(changes)}; "
            f"symlinks/reparse points skipped: {len(walk.skipped_links)}"
        )
        for path in walk.skipped_links:
            print(f"  skipped (symlink): {path}")
        if args.apply:
            apply_errors = apply_posix(changes)
        else:
            apply_errors = []
    elif WINDOWS:
        commands, walk = plan_windows(targets)
        if not args.quiet:
            print("icacls commands (remove inherited ACEs, grant current user + SYSTEM + Administrators):")
            for command in commands:
                print(f"  {'RUN' if args.apply else 'would run'}: {display_command(command)}")
        print(
            f"Targets: {len(targets)}; entries to update: {len(commands)}; "
            f"symlinks/reparse points skipped: {len(walk.skipped_links)}"
        )
        for path in walk.skipped_links:
            print(f"  skipped (symlink): {path}")
        if args.apply:
            apply_errors = apply_windows(commands)
        else:
            apply_errors = []
    else:  # pragma: no cover - exotic platform
        print(f"ERROR: unsupported platform {os.name!r}; no changes made.", file=sys.stderr)
        return 2

    if not args.apply:
        print()
        print(
            "Dry-run complete: no permissions were changed.  Review the list above, then re-run with --apply."
        )
        if WINDOWS:
            print(
                "Windows note: run from an elevated shell if granting SYSTEM/Administrators "
                "fails; other accounts/tools that legitimately need these files will lose access."
            )
        return 0
    if apply_errors:
        print()
        for message in apply_errors:
            print(f"ERROR: {message}", file=sys.stderr)
        print(f"Finished with {len(apply_errors)} error(s).", file=sys.stderr)
        return 1
    print()
    print("Permissions updated.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
