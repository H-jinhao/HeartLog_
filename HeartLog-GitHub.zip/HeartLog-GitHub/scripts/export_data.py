#!/usr/bin/env python
"""Export all user data from the configured database to a JSON archive."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import UTC, datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from app.core.config import get_settings  # noqa: E402
from app.db.session import create_engine_for, create_session_factory  # noqa: E402
from app.services.export_service import export_and_audit  # noqa: E402


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Destination JSON file")
    args = parser.parse_args(argv)
    settings = get_settings()
    destination = args.output or (
        PROJECT_ROOT / "exports" / f"heartlog-export-{datetime.now(UTC).strftime('%Y%m%dT%H%M%SZ')}.json"
    )
    if destination.exists():
        raise SystemExit(f"Refusing to overwrite existing export: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    engine = create_engine_for(settings)
    session_factory = create_session_factory(engine)
    session = session_factory()
    try:
        payload = export_and_audit(session)
    finally:
        session.close()
        engine.dispose()
    destination.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Export written: {destination}")
    print(f"Counts: {payload['counts']}")
    print("This file contains private diary data. Store it securely and do not commit it.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
