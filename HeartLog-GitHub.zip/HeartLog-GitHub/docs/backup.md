# HeartLog 备份与恢复（加密 / 保留策略 / 定时任务 / 恢复演练）

本文覆盖 HeartLog 的**产品化备份能力**。基础运维（启动/停止/迁移/导出/完整性校验）见 [运维手册](operations.md)；隐私与威胁模型见 [隐私说明](privacy.md)。

> 所有命令默认在**项目根目录**执行。SQLite 相对路径（如 `sqlite:///./data/heartlog.db`、`./backups`）是相对**当前工作目录**解析的，换目录执行会指向不同文件。

---

## 1. 能力总览

| 能力 | 脚本 / 模块 | 说明 |
| --- | --- | --- |
| 明文备份（MVP 兼容） | `scripts/backup.py` | SQLite 在线备份 API + `PRAGMA integrity_check` + `.sha256` + `.json` manifest |
| 加密备份 | `scripts/backup.py --encrypt` | AES-256-GCM + Scrypt KDF，版本化文件头；口令只来自环境变量 |
| 保留策略（自动清理） | `scripts/backup.py --retention N`、`scripts/backup_scheduler.py` | 只删除 HeartLog 自己命名的、带有效 `.sha256` + manifest 的备份 |
| 本地定时备份 | `scripts/backup_scheduler.py` | `--once` 或 `--interval-seconds/--interval-hours` 循环；SIGINT/SIGTERM 优雅退出；不依赖 APScheduler |
| 恢复（明文/加密） | `scripts/restore.py` | 保留原有安全校验；加密备份先解密到 staging；支持 `--force`、安全备份、活跃 WAL 检查 |
| 恢复演练 | `scripts/restore_drill.py` | 只读校验备份可恢复性，不碰在线数据库、不覆盖；`--json` 机器可读 |
| 共享实现 | `app/services/backup_service.py` | 加解密容器、manifest、保留策略、只读完整性/不变量检查 |

设计原则：

- **默认本地**：备份只写到本机磁盘（默认 `HEARTLOG_BACKUP_DIR=./backups`），没有云上传、遥测或远程同步；
- **加密可选但推荐**：`--encrypt` 生成密文；不加时备份是**完整明文 SQLite 数据库**；
- **元数据最小化**：manifest、日志、恢复演练报告只包含路径、文件大小、行数、哈希、记录 ID、错误码；**不包含日记正文/记忆正文/明文数据库哈希/口令**；
- **删除有证据**：自动保留策略只会删除同时满足"HeartLog 自动命名 + 自洽 sidecar/manifest"的文件。

---

## 2. 需要先理解的文件形态

每次备份默认生成三个文件（同名）：

```text
backups/
  heartlog-20261029T072715Z.db            # 备份本体（明文 SQLite 或 AES-256-GCM 密文）
  heartlog-20261029T072715Z.db.sha256     # 备份本体的 SHA-256（一行十六进制）
  heartlog-20261029T072715Z.db.json       # manifest（JSON，元数据）
```

加密备份的命名以 `.db.enc` 结尾：

```text
heartlog-20261029T072715Z.db.enc
heartlog-20261029T072715Z.db.enc.sha256
heartlog-20261029T072715Z.db.enc.json
```

- **自动命名规则（只有这种命名会被保留策略删除）**：`heartlog-<UTC 时间戳 YYYYmmddTHHMMSSZ>.db` 或 `heartlog-<...>.db.enc`；
- 手动命名的备份（如 `my-backup.db`、`before-upgrade.db.enc`）**永远不会**被自动清理；
- `.sha256` 是备份**容器文件**（加密时即密文）的哈希，不是 SQLite 明文哈希；
- manifest 的 `sha256` 与 `.sha256` 一致；manifest 还记录 `encrypted`、`cipher`、`kdf`、`kdf_params`（含 `salt_b64`）、`nonce_b64`、`size_bytes`、`integrity_check`、`table_counts`、`created_at`、源/目标路径等。

manifest 示例（加密，节选）：

```json
{
  "format": "heartlog.backup",
  "format_version": 2,
  "encrypted": true,
  "cipher": "AES-256-GCM",
  "kdf": "scrypt",
  "kdf_params": {"n": 16384, "r": 8, "p": 1, "length": 32, "salt_b64": "..."},
  "nonce_b64": "...",
  "sha256": "<密文 SHA-256>",
  "size_bytes": 123456,
  "integrity_check": "ok",
  "table_counts": {"diary_entries": 12, "diary_revisions": 31, "...": 0}
}
```

> manifest / `.sha256` 只是**辅助校验 + 可运维元数据**，不是签名。能同时改写备份与 manifest 的攻击者可以绕过"文件哈希"这一层；但加密备份仍受 AES-GCM 认证标签保护（无口令无法伪造有效密文），恢复演练还会校验 SQLite 与业务不变量。详见 §12。

**向后兼容**：产品化之前（MVP）生成的明文备份没有 `encrypted`/`format` 字段，`restore.py` 与 `restore_drill.py` 仍可正常读取（缺失 `encrypted` 按 `false` 处理，`.sha256` 与 manifest 的 `sha256` 仍会校验）。加密功能只对新备份生效，旧备份不会自动加密。

---

## 3. 快速开始

### 3.1 明文备份（与旧版行为兼容）

```bash
python scripts/backup.py
# 输出：backups/heartlog-<UTC>.db + .sha256 + .json
```

```bash
# 指定路径（目标必须不存在，防误覆盖）
python scripts/backup.py --output /path/to/heartlog-20261029.db

# 默认保留 14 个自动命名备份；0 表示不清理
python scripts/backup.py --retention 14
```

### 3.2 加密备份（推荐）

```bash
# 口令只通过环境变量传入（不要写在命令行参数里！）
export HEARTLOG_BACKUP_PASSPHRASE='请替换为足够长的随机口令'      # bash
# Windows PowerShell: $env:HEARTLOG_BACKUP_PASSPHRASE = '请替换为足够长的随机口令'

python scripts/backup.py --encrypt
# 输出：backups/heartlog-<UTC>.db.enc + .sha256 + .json
```

- 如果不加密：备份是**明文完整数据库**，包含全部日记、修订、记忆、证据、对话与审计；
- 如果加了口令：备份容器是 AES-256-GCM 密文，但**文件名、大小、行数、manifest 仍然可见**；
- **口令丢失 = 数据永久无法恢复**。HeartLog 不保存口令，也不做密钥托管（key escrow）。

### 3.3 保留策略与加密一起使用

```bash
python scripts/backup.py --encrypt --retention 14
# 行为：先成功创建本次加密备份，再在备份目录里只保留最新 14 个
#       "HeartLog 自动命名 + sidecar/manifest 自洽" 的备份，其余连同 sidecar/manifest 删除
```

### 3.4 恢复演练 / 恢复

```bash
# 只读演练（强烈建议每次备份后或定期执行）
python scripts/restore_drill.py backups/heartlog-20261029T072715Z.db.enc
python scripts/restore_drill.py backups/heartlog-20261029T072715Z.db.enc --json

# 真正恢复（先停止 HeartLog 服务！目标库已存在时必须 --force）
python scripts/restore.py backups/heartlog-20261029T072715Z.db.enc --force
```

### 3.5 命令退出码

| 脚本 | 0 | 1 | 2 |
| --- | --- | --- | --- |
| `backup.py` | 备份（及保留策略）成功 | — | 参数/配置/备份失败（口令缺失、目标已存在等） |
| `restore.py` | 恢复成功 | — | 校验失败、口令错误、目标已存在未加 `--force`、WAL sidecar 活跃等 |
| `restore_drill.py` | 所有检查通过 | 演练失败（校验和/解密/SQLite/业务不变量问题） | 命令无法执行（如参数错误） |
| `backup_scheduler.py` | 成功 / 收到信号优雅退出 | 循环中至少一次备份失败 | 配置错误（如加密但口令缺失） |

> 当前工作区（Windows 开发环境）请按 [运维手册 §1](operations.md#1-环境准备) 设置 `PYTHONPATH` 与解释器；下文统一用 `python` 表示你的解释器。

---

## 4. 加密格式与密钥管理

### 4.1 文件格式（版本化，向后兼容）

加密文件布局（所有整数大端）：

```text
MAGIC          b"HEARTLOG-BACKUP-ENC-v1\n"      # 固定魔数，含版本
header_length  uint32
header_json    UTF-8 规范 JSON
ciphertext     AES-256-GCM 流式密文
tag            16 字节 GCM 认证标签
```

header 内容（与 manifest 中的参数一致）：

```json
{
  "format": "heartlog.encrypted-backup",
  "version": 1,
  "cipher": "AES-256-GCM",
  "kdf": "scrypt",
  "kdf_params": {"n": 16384, "r": 8, "p": 1, "length": 32, "salt_b64": "..."},
  "nonce_b64": "...",
  "created_at": "2026-10-29T07:27:15+00:00",
  "app_version": "0.1.0"
}
```

实现要点（`app/services/backup_service.py`）：

- **AES-256-GCM**，每次备份生成新的 16 字节随机 salt 和 12 字节随机 nonce；
- 密钥由 **Scrypt**（`n=2^14, r=8, p=1`，32 字节）从口令派生；
- header 作为 **AEAD 附加认证数据（AAD）**，篡改 header/参数/版本会直接导致解密失败；
- 流式加解密（1 MiB 分块），内存占用与数据库大小基本无关；
- 解密时对 header 中的 Scrypt 参数做范围校验，避免恶意文件逼迫进程分配巨额内存；
- 解密先写到 `.partial` 临时文件，认证通过后才原子改名为目标文件；失败不会留下半成品。

支持的版本：`version=1`。遇到未知 `format`/`version`/`cipher`/`kdf` 会给出明确错误并以非 0 退出，而不是静默尝试。

### 4.2 口令从哪来

- 默认环境变量：`HEARTLOG_BACKUP_PASSPHRASE`；
- 自定义变量名（仍只传**变量名**，不传值）：`--passphrase-env MY_HEARTLOG_PASSPHRASE`；
- **命令行永远不接受口令明文**（避免出现在 shell 历史、进程列表、CI 日志）；
- 口令**不会**写进备份、manifest、日志、恢复演练报告；
- 注意：备份脚本直接读取**进程环境变量**。把它写进项目根目录 `.env` 不会被读取（`.env` 只用于 `HEARTLOG_*` 应用配置）；请通过 shell、systemd `EnvironmentFile`、cron 环境或任务计划包装脚本注入。

安全示例：

```bash
# 交互式 shell：export 本身会留在 shell 历史，可临时关闭历史或用前置空格（HISTCONTROL）
export HEARTLOG_BACKUP_PASSPHRASE="$(pass show heartlog/backup)"   # 从密码管理器读取
python scripts/backup.py --encrypt
unset HEARTLOG_BACKUP_PASSPHRASE
```

```powershell
# Windows：从 Windows Credential Manager / DPAPI 读取后再注入进程环境
$env:HEARTLOG_BACKUP_PASSPHRASE = (Get-StoredCredential ...).Password
python scripts/backup.py --encrypt
Remove-Item Env:HEARTLOG_BACKUP_PASSPHRASE
```

### 4.3 密钥管理规则

| 事项 | 建议 |
| --- | --- |
| 口令强度 | 至少 16 个随机字符（推荐使用密码管理器生成的长随机串，如 32+ 字符）；**不要复用**其它服务密码 |
| 保存位置 | 密码管理器 / OS 凭据管理器（Windows Credential Manager、macOS Keychain、KeePassXC 等）；不要写进 git、聊天记录、文档 |
| 丢失后果 | **不可恢复**。HeartLog 没有后门口令、没有密钥托管、没有恢复码 |
| 轮换 | 用新口令重新执行一次 `--encrypt` 备份并 `restore_drill.py` 验证；旧备份仍只能用旧口令解密，直到按保留策略/手动清理掉 |
| 泄露处置 | 立即用新口令重做加密备份并对旧加密备份做安全处置；仅轮换口令**不会**让已泄露的旧密文重新安全 |
| 迁移机器 | 同时迁移口令（通过密码管理器）；不要只复制 `.db.enc` 文件 |
| 共享备份 | 每个接收方需要能获取口令；不要通过同一渠道同时发送密文和口令 |

### 4.4 加密不覆盖什么

- 备份/临时文件的**文件系统元数据**（文件名、大小、时间、行数）；
- manifest 中的路径、`table_counts`、密文 SHA-256；
- **执行备份/恢复/演练期间的进程环境变量**（同机同用户进程可能读取）；
- 加解密时的**明文临时文件**：创建加密备份时，会在系统临时目录生成一个已验证的明文 SQLite staging 文件，加密完成后立即删除；恢复/演练会解密到临时文件并在结束后删除。操作系统/文件系统/崩溃转储仍可能残留这些临时文件；
- 因此仍建议：全盘加密 + 最小文件权限 + 不要把备份放进公开同步目录。

---

## 5. `scripts/backup.py` 完整参数

| 参数 | 默认 | 说明 |
| --- | --- | --- |
| `--output PATH` | 自动命名 | 备份目标路径，必须不存在；`--encrypt` 时同路径写入密文（不会自动改后缀） |
| `--encrypt` | 关 | 生成 AES-256-GCM 加密备份（默认明文） |
| `--retention N` | `14` | 备份成功后保留 N 个最新自动命名备份；`0` = 不清理 |
| `--backup-dir PATH` | 见下 | 保留策略扫描的目录；不指定时：有 `--output` 用其父目录，否则用 `HEARTLOG_BACKUP_DIR` |
| `--passphrase-env NAME` | `HEARTLOG_BACKUP_PASSPHRASE` | 存放口令的环境变量名 |

备份过程：

1. 用 SQLite **在线备份 API** 复制数据库（服务运行中也可安全执行）；
2. 对副本执行 `PRAGMA integrity_check`，非 `ok` 立即失败并清理；
3. 明文模式直接原子落地；加密模式在系统临时目录做成验证过的 staging 后加密；
4. 计算**容器文件** SHA-256，写 `.sha256` 与 manifest；
5. 全部成功后才执行 `--retention` 清理（备份失败不会触发清理）。

---

## 6. 保留策略（Retention）语义

`--retention N`（默认 14）：

- **N > 0**：在本次备份**成功后**，扫描备份目录，按文件名中的 UTC 时间戳从新到旧排序，只保留最新 N 个；更旧的删除；
- **N = 0**：不自动清理（无限保留）；
- **只会删除同时满足以下全部条件的文件**：
  1. 文件名严格匹配 `heartlog-YYYYmmddTHHMMSSZ.db` 或 `heartlog-YYYYmmddTHHMMSSZ.db.enc`；
  2. 存在 `.json` manifest 且是合法 JSON；
  3. manifest 的 `sha256` 与 `.sha256` 一致，manifest 的 `size_bytes`（若存在）与实际大小一致，`encrypted` 标志与实际文件头一致；
  4. manifest 记录的 `backup` 文件名与当前文件名一致（防止误把别的备份的元数据当成自己的）。
- 不满足条件的自动命名文件（如 metadata 丢失/损坏）会被**保留**并打一条 warning 日志，交给你人工判断；
- 手动命名文件、未知文件、外部工具产生的文件**永不删除**；
- 删除时同时删除对应 `.sha256` 与 `.json`；
- **本次刚创建的备份**永远受保护，即使系统时钟回拨导致它"看起来很旧"。

> 语义边界：保留策略只按**文件名中的时间**排序，不读取 SQLite 内容；请保持系统时钟正确（NTP）。重命名自动备份会使其不再受自动清理管理——这是有意设计（避免误删手工文件）。

手动清理示例（确认不再需要后）：

```bash
# 列出自动命名备份（按名称=时间排序）
ls -1 backups/heartlog-*.db* | sort

# 手动删除一个备份及其元数据（示例）
rm backups/heartlog-20260101T000000Z.db
rm backups/heartlog-20260101T000000Z.db.sha256
rm backups/heartlog-20260101T000000Z.db.json
```

**删除数据时**（软删除/永久删除/撤回记忆）请记得：历史备份仍然包含旧内容，需要按你的保留策略/手动清理历史备份与导出文件；HeartLog 不会自动"遗忘"备份中的历史数据。详见 §12。

---

## 7. 定时备份 `scripts/backup_scheduler.py`

### 7.1 命令行

```text
python scripts/backup_scheduler.py --once [--encrypt] [--retention N]
python scripts/backup_scheduler.py --interval-hours 6 [--encrypt] [--retention N]
python scripts/backup_scheduler.py --interval-seconds 3600
```

| 参数 | 说明 |
| --- | --- |
| `--once` | 备份一次后退出（适合交给系统计划任务）；不能与 interval 同用 |
| `--interval-hours H` / `--interval-seconds S` | 前台循环，间隔至少 1 秒；二选一 |
| `--encrypt` | 生成加密备份（需要环境变量口令） |
| `--retention N` | 每次成功备份后按 §6 清理，默认 `14`，`0` 不限 |
| `--backup-dir PATH` | 覆盖 `HEARTLOG_BACKUP_DIR` |
| `--passphrase-env NAME` | 口令环境变量名 |

行为：

- 每次循环生成一个自动命名备份并应用保留策略；
- **日志只含元数据**：时间、路径、是否加密、字节数、行数、清理数量、错误类型/原因；不记录日记内容或口令；
- 收到 **SIGINT（Ctrl+C）/SIGTERM** 时：当前这次备份先完成，然后退出，退出码 0；循环中某次备份失败会记录错误并继续下次运行（最终退出码为 1）；
- 若 `--encrypt` 但启动时口令缺失，**立即报错退出（码 2）**，不会空转重试；
- 不依赖 APScheduler 或任何外部调度库。

```bash
# 前台常驻示例：每 6 小时一次，加密，保留 14 个
export HEARTLOG_BACKUP_PASSPHRASE="$(pass show heartlog/backup)"
python scripts/backup_scheduler.py --interval-hours 6 --encrypt --retention 14
```

### 7.2 Windows 任务计划（Task Scheduler）

推荐用 `--once`，由任务计划负责周期：

**方式 A：图形界面**

1. 打开"任务计划程序" → "创建基本任务"；
2. 触发器：每天（或每 6 小时，使用"重复任务间隔"）；
3. 操作：启动程序
   - 程序：`C:\Path\To\python.exe`（替换为你的 Python 解释器）
   - 参数：`C:\Path\To\HeartLog\scripts\backup_scheduler.py --once --encrypt --retention 14`
   - 起始于：`C:\Path\To\HeartLog`
4. 勾选"不管用户是否登录都要运行"时，注意环境变量口令需要包装脚本显式设置；
5. "条件"里取消"只有在计算机使用交流电源时才启动"等可能阻止运行的限制。

**方式 B：命令行创建**

```bat
schtasks /Create /TN "HeartLog Backup" /SC DAILY /ST 03:00 ^
  /TR "\"C:\Path\To\python.exe\" \"C:\Path\To\HeartLog\scripts\backup_scheduler.py\" --once --encrypt --retention 14" ^
  /F
```

**口令注入**：任务计划不会自动继承你交互式 shell 的环境变量。可选做法（按安全性排序）：

1. 用一个受 ACL 保护的包装脚本（如 `C:\Path\To\HeartLog\.local\backup-task.cmd`，仅当前用户可读，放在加密卷上）：
   ```bat
   @echo off
   set "HEARTLOG_BACKUP_PASSPHRASE=<从密码管理器取出的口令>"
   "C:\Path\To\python.exe" "C:\Path\To\HeartLog\scripts\backup_scheduler.py" --once --encrypt --retention 14
   ```
   任务计划指向该 `.cmd`。**不要**把该文件提交进 git 或放入同步目录；
2. 用 PowerShell 脚本从 Windows Credential Manager / DPAPI 读取口令后再调用 Python；
3. 若你接受风险，可设置用户级环境变量（`setx HEARTLOG_BACKUP_PASSPHRASE ...`），但注意它会长期存在注册表中、对同用户进程可见。

> 若使用 Windows"只在用户登录时运行"，任务会继承该用户登录会话的环境变量；"不管用户是否登录"时不会。

### 7.3 cron（Linux/macOS）

```cron
# crontab -e（文件权限 600）
HEARTLOG_BACKUP_PASSPHRASE=<口令或读取密码管理器的脚本输出>
0 3 * * * cd /opt/heartlog && /opt/heartlog/.venv/bin/python scripts/backup_scheduler.py --once --encrypt --retention 14 >> /var/log/heartlog-backup.log 2>&1
```

crontab 中的环境变量行会以明文存在 `crontab` 文件里（权限按用户隔离）；更严格的做法是让 cron 调用一个从密钥管理器取口令的包装脚本，或改用 systemd timer + `EnvironmentFile`。

### 7.4 systemd timer（Linux）

`/etc/heartlog/backup.env`（`chmod 600`，属主为运行用户）：

```dotenv
HEARTLOG_BACKUP_PASSPHRASE=<足够长的随机口令>
```

`/etc/systemd/system/heartlog-backup.service`：

```ini
[Unit]
Description=HeartLog encrypted backup
After=network.target

[Service]
Type=oneshot
User=heartlog
WorkingDirectory=/opt/heartlog
EnvironmentFile=/etc/heartlog/backup.env
ExecStart=/opt/heartlog/.venv/bin/python scripts/backup_scheduler.py --once --encrypt --retention 14
```

`/etc/systemd/system/heartlog-backup.timer`：

```ini
[Unit]
Description=Run HeartLog backup every 6 hours

[Timer]
OnCalendar=*-*-* 00/6:00:00
Persistent=true

[Install]
WantedBy=timers.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now heartlog-backup.timer
systemctl list-timers heartlog-backup.timer
journalctl -u heartlog-backup.service --since today
```

> 日志（journald）包含路径/行数/状态等元数据；请按敏感文件管理日志访问权限。

---

## 8. 恢复演练 `scripts/restore_drill.py`

```bash
python scripts/restore_drill.py backups/heartlog-20261029T072715Z.db.enc
python scripts/restore_drill.py backups/heartlog-20261029T072715Z.db.enc --json
```

可选参数：`--passphrase-env NAME`（默认 `HEARTLOG_BACKUP_PASSPHRASE`）。

演练做的事（**只读**，绝不写入在线数据库、绝不覆盖现有库）：

1. 校验 `.sha256` 与 manifest 的一致性（同时检查 manifest 的 `encrypted` 标志与实际文件头是否一致）；
2. 加密备份：从环境变量取口令，AES-GCM 解密到系统临时目录；
3. 以只读 + `immutable` 方式打开副本，执行 `PRAGMA integrity_check` 与 `PRAGMA foreign_key_check`；
4. 检查必须存在的表：`diary_entries`、`diary_revisions`、`memories`、`memory_sources`、`persons`、`conversations`、`messages`、`audit_events`；
5. 日记不变量：
   - `sha256(original_text) == original_content_hash`；
   - 修订 `version` 从 1 连续递增；
   - `sha256(content) == content_hash`；
   - `previous_revision_hash` 逐条衔接（首条为 NULL）；
   - 修订数量 == `current_version`，`current_revision_id` 指向最新修订；
6. 记忆不变量：
   - `sha256(content) == content_hash`；
   - 每条记忆至少有一条证据来源；
   - 主来源（`source_entry_id`/`source_revision_id`）必须在来源列表中；
   - 每条来源的修订存在且属于同一日记；
   - `evidence_text` 是修订正文的**精确子串**，`start_offset`/`end_offset` 匹配；
7. 输出检查结果并清理全部临时文件。

检查项名称（`--json` 的 `checks[].name`）：`checksum`、`encryption`、`decryption`（加密时）、`integrity_check`、`schema_tables`、`foreign_keys`、`diary_original_hashes`、`diary_revision_chains`、`memory_content_hashes`、`memory_sources`、`memory_evidence`。

文本输出示例：

```text
Backup: C:\Path\To\HeartLog\backups\heartlog-20261029T072715Z.db.enc (encrypted)
  [ok] checksum: SHA-256 sidecar/manifest verified
  [ok] encryption: encrypted (AES-256-GCM, Scrypt)
  [ok] decryption: decrypted format version 1
  [ok] integrity_check: PRAGMA integrity_check: ok
  [ok] schema_tables: 8 expected tables present
  [ok] foreign_keys: no foreign-key violations
  [ok] diary_original_hashes: 12 diary entries checked
  [ok] diary_revision_chains: 31 revisions checked
  [ok] memory_content_hashes: 20 memories checked
  [ok] memory_sources: 24 evidence sources checked
  [ok] memory_evidence: evidence snippets match immutable revisions and offsets
Table rows: {"audit_events": 40, "diary_entries": 12, ...}
Restore drill: OK
```

- 全部通过 → 退出码 `0`；
- 任一检查失败（如 checksum 不匹配、口令错误、SQLite 损坏、哈希链断裂、证据不匹配）→ 退出码 `1`，输出 issue 代码（只含 ID/代码，不含正文）；
- `--json` 适合接入监控/CI：`ok`、`status`、`checks`、`issues`、`table_counts`。

> 建议：每次重要备份后演练一次；至少每月演练一次；演练通过 ≠ 已恢复，正式恢复仍应按 §9 执行。

---

## 9. 恢复 `scripts/restore.py`

**前提：停止 HeartLog 服务**（恢复会替换 `HEARTLOG_DATABASE_URL` 指向的数据库文件）。加密备份需要先设置口令环境变量。

```bash
# 1) 停止服务（Ctrl+C / SIGTERM），确认没有活跃写入

# 2) 加密备份（或明文备份）恢复；目标库已存在时必须 --force
export HEARTLOG_BACKUP_PASSPHRASE='...'
python scripts/restore.py backups/heartlog-20261029T072715Z.db.enc --force

# 3) 重新校验完整性
python scripts/verify_integrity.py
echo "exit=$?"

# 4) 启动并抽查
uvicorn "app.main:create_app" --factory --host 127.0.0.1 --port 8000
curl -s "http://127.0.0.1:8000/api/v1/diaries?limit=1"
```

脚本行为（保留 MVP 的全部安全措施）：

1. 校验备份存在；校验 `.sha256` / manifest（存在时；加密备份还校验加密标志一致）；
2. 加密备份：从环境变量读取口令并解密到目标目录下的 `.restore-tmp` staging 文件（**先解密到 staging，不直接覆盖目标**）；
3. 对 staging 执行 `PRAGMA integrity_check`，失败则放弃，**现有数据库完全不动**；
4. 目标库存在且未加 `--force` → 拒绝；
5. 目标库存在时：`-wal`/`-shm` 非空 → 拒绝（说明数据库可能仍在使用，必须先停服务/检查点）；
6. 目标库存在时：先在 **目标库所在目录的 `backups/` 子目录**生成 `pre-restore-<UTC>.db` 安全备份（注意：这是 `data/backups/`，与 `HEARTLOG_BACKUP_DIR` 的 `./backups/` 是两个位置）；安全备份失败则中止；
7. 原子替换目标文件；清理空的 `-wal`/`-shm` sidecar；
8. 打印路径提示，退出码 0。

失败场景（口令错误、校验失败、活跃 sidecar、无 `--force` 等）退出码 `2`，**不会覆盖目标数据库**。

恢复后建议：

- 确认数据（列表/搜索/完整性校验）；
- 保留 pre-restore 安全备份一段时间；
- 如果恢复的是旧备份：其中可能包含删除前的数据（见 §12），按你的隐私预期处理旧备份/导出/同步副本。

---

## 10. 备份文件生命周期与保管

| 阶段 | 建议 |
| --- | --- |
| 创建 | 用 `backup.py` / `backup_scheduler.py`，不要手工复制正在运行的 `data/heartlog.db`（WAL 模式下可能丢已提交事务） |
| 加密 | 除非备份所在的磁盘/目录已有可靠的全盘加密，否则使用 `--encrypt` |
| 存放 | 最小权限目录；避免公开同步目录/共享链接；可放到加密卷（BitLocker/FileVault/LUKS） |
| 校验 | `.sha256` + manifest 随备份一起移动；**不要**手工编辑 manifest（会导致校验/保留策略拒绝该文件） |
| 异机保管 | 只复制三个文件（备份 + `.sha256` + `.json`）；加密备份还需能获得口令 |
| 清理 | 用 `--retention` 自动清理，或按 §6 手动删除；删除数据时同步处理所有历史备份/导出 |
| 演练 | `restore_drill.py`；只有演练通过且定期执行的备份才算"有备份" |

---

## 11. 常见问题排查

| 现象 | 可能原因 | 处理 |
| --- | --- | --- |
| `Backup passphrase is not set. Export HEARTLOG_BACKUP_PASSPHRASE ...` | 加密命令缺少环境变量 | 在**进程环境**中设置口令（不是 `.env`）；或 `--passphrase-env` 指定其它变量名 |
| `Failed to decrypt backup: wrong passphrase, or the file was corrupted/tampered with.` | 口令错误 / 密文被改 / 文件截断 | 确认口令来源；用 `.sha256` 校验文件；用其它已知可用备份演练 |
| `Not a HeartLog encrypted backup (unknown or unsupported format/version).` | 文件不是本工具生成的密文（或版本过新） | 确认路径/文件类型；必要时用 `--output` 生成的文件名 |
| `Backup checksum mismatch: ...` | 备份文件被修改/损坏，或 `.sha256` 不是它的 | 不要恢复；从其它备份/副本重新获取 |
| `Backup manifest ... does not match` / `encryption state does not match` | manifest 与备份不配套（错误移动/覆盖） | 找回配套的三个文件；不要手工改 manifest 绕过 |
| `Refusing to overwrite existing backup` | 目标已存在（同名/同秒重复） | 换 `--output` 路径，或稍后重试；不要删除仍需要的备份 |
| `Target database exists: ... re-run with --force` | 目标库已存在 | 确认要覆盖后加 `--force` |
| `Active SQLite sidecar found (_wal/_shm)` | 服务未停/仍写入 | 停止服务；必要时正常启动一次再停，让 SQLite 收尾 |
| 恢复后应用报数据库错误 | 备份本身来自不兼容版本/被改 | 用 `restore_drill.py` 复验；用 pre-restore 安全备份回滚 |
| `--retention` 没删除旧备份 | 文件名不是自动命名 / 缺少或损坏的 sidecar/manifest / 数量未超过 N | 查看 warning 日志；手动确认后删除；检查文件是否被重命名 |
| `restore_drill` 报 `checksum_missing` | 备份缺少 `.sha256` 与 manifest | 从原始备份副本恢复元数据；或用 `backup.py` 重新生成备份 |
| `restore_drill` 报 `decryption_failed` | 口令错误/文件损坏 | 同上 |
| `restore_drill` 报 `revision_hash_mismatch` / `evidence_not_in_revision` | 备份中的业务数据不一致（可能被篡改或旧 bug） | 不要恢复覆盖现网；保留现场并排查来源 |
| 任务计划/cron 执行失败 | 工作目录、解释器路径、环境变量（尤其口令）不对 | 用绝对路径 + `--once`；把 stderr 重定向到受控日志；确认任务用户可读备份目录 |

---

## 12. 已知限制（请纳入你的威胁模型）

1. **没有"密码学擦除"**：备份会保留历史数据。软删除日记、永久删除日记的修订/审计结构、被撤回/更正的记忆、旧修订、审计事件都可能出现在**旧备份**里；删除数据后必须自行清理历史备份与导出副本（`--retention` 只按时间清理，不会理解"删除语义"）。
2. **没有云上传/跨机复制**：本工具只写本机目录，不做对象存储/网盘同步；异机容灾需要你自己复制（并对副本负责）。
3. **没有密钥托管 / 恢复码**：口令丢失即数据不可恢复；没有管理员后门。
4. **没有内置口令轮换/重新加密旧备份**：轮换 = 用新口令做新备份并演练；旧备份要么继续用旧口令，要么清理。
5. **加密容器的元数据可见**：文件名/大小/行数/manifest 路径参数未加密；密文大小近似暴露数据库大小。
6. **同机同用户进程可读取环境变量**：`HEARTLOG_BACKUP_PASSPHRASE` 存在于进程环境时，同用户权限的其它进程在部分平台上可读取；本机多用户场景请依赖 OS 账户隔离。
7. **临时明文**：创建加密备份时在系统临时目录产生明文 staging；恢复/演练时解密到临时文件。正常结束会删除；异常崩溃/交换文件/文件系统日志可能残留，全盘加密仍是必要补充。
8. **同一秒重名**：默认文件名精度为秒；同一秒内重复创建会因"目标已存在"失败（已存在保护优先于覆盖）。重试或使用 `--output`/定时器间隔即可。
9. **时钟敏感**：自动命名与保留策略按 UTC 文件名排序；系统时钟错误会影响顺序，请启用 NTP。
10. **非 SQLite / 内存数据库不支持**：脚本只接受文件型 SQLite（`HEARTLOG_DATABASE_URL` 指向文件）。
11. **加密备份需要额外 CPU**：Scrypt 参数（`n=2^14`）在低端设备上每次备份/恢复约数百毫秒，属预期。
12. **单文件数据库**：备份期间用 SQLite 在线 API 保证一致性；恢复必须停止服务，不支持在线替换。
13. **恢复演练不等于恢复**：演练验证的是备份文件可读/可校验/业务不变量成立，不会验证你恢复后启动的特定版本应用行为；跨版本升级请额外做冒烟测试（健康检查 + 创建/读取一条日记）。

---

## 13. 安全操作清单

- [ ] 备份目录在加密卷上，权限最小化；不要把备份放进公开同步目录/共享链接。
- [ ] 需要离开本机磁盘的备份一律 `--encrypt`；口令由密码管理器管理，>=16 随机字符。
- [ ] 口令只放进程环境/密码管理器，不写进命令行、git、文档、聊天记录。
- [ ] 每 6–24 小时至少备份一次（`backup_scheduler.py --once` + 系统计划任务）；保留策略默认 14 个，按空间调整。
- [ ] 每次重要操作（迁移、升级、启用 AI）前额外手动备份一次，并 `restore_drill.py` 验证。
- [ ] 每月至少做一次恢复演练；把 `restore_drill.py --json` 接入你能看到的告警/日志。
- [ ] 升级/迁移前备份；升级后跑 `python scripts/verify_integrity.py` 并冒烟测试。
- [ ] 删除数据时同步清理历史备份、导出、同步盘副本（备份不会自动遗忘）。
- [ ] 怀疑口令泄露时：用新口令重做备份并演练，妥善处置旧加密备份；不要只改应用配置。

---

## 14. 相关文件

- 共享实现：[`app/services/backup_service.py`](../app/services/backup_service.py)
- 备份脚本：[`scripts/backup.py`](../scripts/backup.py)
- 恢复脚本：[`scripts/restore.py`](../scripts/restore.py)
- 定时备份：[`scripts/backup_scheduler.py`](../scripts/backup_scheduler.py)
- 恢复演练：[`scripts/restore_drill.py`](../scripts/restore_drill.py)
- 测试：[`tests/test_backup_productization.py`](../tests/test_backup_productization.py)
- 基础运维：[`docs/operations.md`](operations.md) · 隐私与威胁模型：[`docs/privacy.md`](privacy.md)
