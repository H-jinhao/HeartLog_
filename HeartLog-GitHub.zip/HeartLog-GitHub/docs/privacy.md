# HeartLog 隐私与安全说明

HeartLog 的设计前提：**日记是最私密的数据之一，默认不应该离开你的电脑。**

本文说明 HeartLog 的默认数据边界、什么情况下会向外部 AI 提供方发送什么数据、日志与配置文件如何处理、备份/导出/删除/遗忘的安全语义、加密备份的密钥管理、可选令牌与生产级认证的差距、限流与部署安全，以及当前的威胁模型与安全限制。

相关文档：[README](../README.md) · [架构](architecture.md) · [数据库设计](database_design.md) · [API](api.md) · [运维](operations.md) · [备份与恢复](backup.md) · [部署安全](deployment_security.md)

---

## 1. 本地优先（local-first）默认值

- **数据落盘位置**：默认只有一个 SQLite 文件 `data/heartlog.db`（可用 `HEARTLOG_DATABASE_URL` 修改）。备份默认写 `backups/`，导出默认写 `exports/`（脚本）或由调用方决定（API）。
- **默认监听本地**：推荐的启动命令是 `--host 127.0.0.1 --port 8000`，只接受本机连接。是否暴露到局域网/公网完全由部署者决定。
- **无遥测、无分析、无云同步**：代码中没有埋点、崩溃上报、远程日志或同步逻辑。
- **无账号体系**：默认没有用户/密码；所有能访问端口的主体看到的是同一份数据。
- **AI 默认关闭**：`ai_enabled=false` 时不构造 provider、不发起任何模型请求；记忆提取返回 `503`，对话返回明确标注的本地占位回复，周期回顾只返回本地统计。
- **派生数据默认跟随来源可见性（v0.2）**：来源日记被软删除后，它的记忆/人物在默认列表、详情与搜索中隐藏，只有显式 `include_deleted_sources=true` 才会看到；周/月回顾**始终**排除这类派生记忆（无 opt-in）。默认**不会**自动删除派生行——要删除必须显式调用遗忘接口（见 §6）。
- **应用内限流默认关闭（v0.2）**：`HEARTLOG_RATE_LIMIT_ENABLED=false`；需要时可开启进程内限流，但完整防护（TLS/认证/代理层限流）依赖部署方式，见 §7 与 [部署安全指南](deployment_security.md)。
- **唯一可能的外部网络行为**：启用 AI 后访问你配置的 OpenAI 兼容服务；以及浏览器打开 `/docs` 时从 CDN 加载 Swagger UI 静态资源（见 §10 的说明）。服务端自身没有其他出站请求。

---

## 2. 什么情况下会发送数据给外部 AI

只有同时满足以下条件才会发生外部数据传输：

1. `HEARTLOG_AI_ENABLED=true`；
2. `HEARTLOG_AI_CONSENT=true`（缺一不可；`AI_ENABLED=true` 而 `CONSENT=false` 时应用**拒绝启动**，见 [`app/core/config.py`](../app/core/config.py)）；
3. 提供方配置完整：
   - `HEARTLOG_AI_PROVIDER=openai_compatible` 且 `AI_BASE_URL`（http/https）、`AI_MODEL`、`AI_API_KEY` 齐全；或
   - `HEARTLOG_AI_PROVIDER=mock`（本地确定性假提供方，**不联网**，仅用于演示/测试）。

`build_ai_service()` 在 `settings.ai_configured` 为假时不会构造 provider，因此"禁用状态"下连 HTTP 客户端都不会存在（[`app/services/ai_service.py`](../app/services/ai_service.py)）。

### 2.1 各功能实际发送的数据

| 功能 | 触发 | 发送给 provider 的内容（代码为准） |
| --- | --- | --- |
| **记忆提取** | `POST /api/v1/memories/extract`（AI 已配置） | 系统提示词（`app/prompts/memory_extraction.md`）+ 一条 user 消息：目标修订的**完整正文 `content`**、`entry_id`、`revision_id`、`version`，用 `<<<BEGIN_UNTRUSTED_DATA>>>` 标记包裹 |
| **陪伴对话** | `POST /api/v1/conversations/{id}/messages`（AI 已配置） | 系统提示词 + user 消息 JSON：本次 `user_message`；最多 8 条本地检索出的相关记忆（`memory_id`、内容、类型、确认状态、confidence、来源 entry/revision/version、日记时间、证据片段）；最多 20 条最近 user/assistant 历史消息；当前 UTC 时间 |
| **周/月回顾** | `GET /api/v1/insights/weekly` 与 `/monthly`（AI 已配置） | 系统提示词 + user 消息 JSON：周期边界、统计数字（日记数、记忆数、按类型计数）、最多 30 条活跃记忆片段（每段 ≤300 字符）及其来源 ID/版本/日记时间、最多 30 条日记的 entry/version/时间（**不含日记原文**） |

不会发送：数据库文件、用户配置、`HEARTLOG_API_TOKEN` / `HEARTLOG_ADMIN_TOKEN`、API Key 之外的凭据、未被上述功能使用的记录、软删除日记原文（提取会拒绝软删除日记；对话检索与回顾都过滤已删除日记及其派生记忆）。来源日记已软删除的派生记忆默认隐藏，也不会进入对话上下文/回顾统计。

提示词模板本身是代码的一部分，可人工审阅：[`app/prompts/memory_extraction.md`](../app/prompts/memory_extraction.md)、[`app/prompts/companion.md`](../app/prompts/companion.md)、[`app/prompts/weekly_review.md`](../app/prompts/weekly_review.md)。

### 2.2 provider 侧的风险

HeartLog **无法控制**外部 AI 提供方：

- 提供方可能记录请求、用于训练或保留日志，具体取决于其条款与配置；
- base URL 由你配置；若配置错误或为第三方代理，数据会发给该地址；
- 模型输出可能被提示注入影响（HeartLog 用"不可信数据"标记与系统提示缓解，但**这是概率性防御**）；
- 模型可能编造内容；HeartLog 通过结构校验 + 证据精确匹配 + 用户确认降低风险，但不能保证模型不产生误导性陈述。

**建议**：优先使用可自托管/本地模型或明确"不训练、不保留"的提供方；不要把 `HEARTLOG_AI_BASE_URL` 指向不信任的代理；不需要 AI 时保持默认关闭。

---

## 3. 日志策略

服务日志（[`app/main.py`](../app/main.py) 与各服务）设计为**不记录私人内容**：

- 访问日志：`request_id`、method、**path（不含 query string）**、status、duration_ms；不记录请求体或响应体。
- 未处理异常：记录 `request_id`、method、path 和异常堆栈；日志格式串中不含请求参数。
- 校验错误：响应与日志都不回显原始输入值，只返回字段位置（`loc`）、原因（`msg`）、类型（`type`）。
- AI 日志：只记录 provider、purpose、HTTP 状态、错误类型等元数据；**不记录提示词、日记正文、API Key**。
- 限流日志（仅 429 时）：`request_id`、method、path、limit、window、retry_after；不记录查询字符串、请求体、头部、客户端地址。
- 审计事件（数据库内，非日志）：只写 ID、版本、计数、状态、理由码等结构信息，不复制日记正文；遗忘审计（`memory.purged`/`memory.anonymized`/`person.purged`）也不含记忆正文或证据文本。
- 第三方库日志：启动时把 `httpx` / `httpcore` 降到 WARNING，避免 provider 的 debug 日志泄漏提示词；但**无法保证**所有第三方库在所有级别下都不输出敏感信息。
- 错误响应：`500 database_error` 不回显 SQL 语句或参数。

注意：

- 如果你把 `HEARTLOG_LOG_LEVEL=DEBUG`，请自行确认第三方库（如 SQLAlchemy）不会把 SQL 参数打进日志；默认 INFO 下 SQL 不打印。
- 进程的 stdout/stderr、systemd journal、终端回滚、IDE 控制台都可能保留日志；部署时按需配置日志轮转与访问权限。
- 反向代理/网关的访问日志可能记录 URL（含 query 参数），这与 HeartLog 自身日志策略无关。

---

## 4. 配置文件与版本控制

[`.gitignore`](../.gitignore) 已忽略：

- `.env`、`.env.*`（仓库只保留无密钥模板 `env.example`）；
- `data/`、`backups/`、`exports/`、`*.db`、`*.db.enc`、`*.sqlite*`、`*.db-wal`、`*.db-shm`；
- 本地 TLS 材料：`certs/`、`*.pem`、`*.key`；
- 虚拟环境、缓存、临时文件等本机运行产物。

原则：

- **永远不要把 `.env`、数据库、备份、导出 JSON 提交到版本库或发给他人。**
- `env.example` 只应包含占位符，不包含真实密钥；提交前人工确认。
- 如果曾误提交密钥：立即轮换该密钥（AI API Key、API Token、Admin Token），并清理历史（单纯删除文件不够）。
- 备份/导出文件即使被 gitignore，也可能被同步盘（OneDrive/Dropbox）、编辑器临时文件、文件索引服务上传；存放目录需自行评估。

---

## 5. 备份、导出与恢复的安全

- **内容敏感**：备份是完整 SQLite 文件，导出是完整 JSON（含原文、全部修订、记忆、证据、人物、会话、审计）。API 导出响应带 `Cache-Control: no-store` 与 `Content-Disposition: attachment`，但这只影响浏览器缓存语义，不改变文件本身是明文的事实。
- **校验与防误覆盖**：`scripts/backup.py` 使用 SQLite 在线备份 API，生成 `.sha256` 与 manifest（含各表行数），并做 `PRAGMA integrity_check`；脚本拒绝覆盖已存在的目标文件。`scripts/restore.py` 在恢复前校验 SHA-256 / manifest 与 `integrity_check`，目标库存在时先做安全备份并要求 `--force`。
- **加密备份是可选项（v0.2）**：`python scripts/backup.py --encrypt` 生成 AES-256-GCM 加密容器（Scrypt 口令派生、版本化文件头、header 作为 AEAD 附加数据）。**不加 `--encrypt` 时备份仍是完整明文数据库**；加密只影响新生成的备份，不会自动加密旧备份。
  - 口令只能通过进程环境变量 `HEARTLOG_BACKUP_PASSPHRASE`（或 `--passphrase-env` 指定的变量名）传入，**不是** Settings/`.env` 字段，也不能写在命令行参数里；
  - **口令丢失 = 加密备份永久无法恢复**：HeartLog 不保存口令、没有密钥托管、没有恢复码；
  - 备份文件名、大小、行数、manifest 元数据（路径/密文 SHA-256/KDF 参数）仍然可见——加密保护的是数据库内容，不是元数据；
  - 加密时会在系统临时目录生成明文 staging 文件（加密后删除）、恢复/演练时解密到临时文件；崩溃/交换文件/文件系统日志仍可能残留，全盘加密仍是必要补充。
  - 完整格式、密钥管理规则与限制见 [备份文档](backup.md#4-加密格式与密钥管理)。
- **保留策略（v0.2）**：`--retention N`（默认 14，`0` 不限）在备份成功后只清理 HeartLog 自动命名、且 `.sha256`/manifest 自洽的旧备份；手动命名/外部文件永不自动删除。**保留策略只按时间清理，不理解"删除语义"**：被遗忘的数据仍可能存在于未被清理的历史备份中。
- **定时备份与恢复演练（v0.2）**：`scripts/backup_scheduler.py` 提供 `--once`（交给 cron/任务计划）或前台循环；`scripts/restore_drill.py` 只读校验备份（哈希、解密、SQLite 完整性、日记/记忆业务不变量），不触碰在线数据库。演练通过 ≠ 已恢复；正式恢复仍需停服务后执行 `scripts/restore.py`。详见 [备份文档](backup.md)。
- **恢复的并发风险**：恢复必须在服务停止时执行；脚本会检查活跃的 `-wal`/`-shm` sidecar，避免在数据库仍被写入时替换文件。
- **保管建议**：
  - 备份/导出文件放入加密卷（BitLocker/FileVault/LUKS）；需要离开本机磁盘时优先用 `--encrypt`（口令由密码管理器保管），或使用 `age`/GPG；
  - 不要把备份放进公开的同步目录或网盘分享链接；
  - 定期做**恢复演练**，确认备份可用（只备份不恢复 = 没有备份）；
  - 删除/遗忘数据时，连同旧备份、导出、同步副本一起处理（见 §6）；HeartLog 不会自动"遗忘"备份里的历史数据。

---

## 6. 删除语义（你删的到底是什么）

| 操作 | 数据后果 |
| --- | --- |
| `DELETE /api/v1/diaries/{id}` | **软删除**：设置 `deleted_at`，默认查询/搜索隐藏；修订与记忆保留；可 `POST .../restore` 恢复。数据库文件里仍有原文。**派生记忆/人物默认隐藏**，但数据未删。 |
| `DELETE /api/v1/memories/{id}?mode=purge\|anonymize` | **遗忘（v0.2）**：永久删除记忆行与其**全部证据来源**；只追加一条不含内容的审计事件（`memory.purged` / `memory.anonymized`）。来源日记不再被该记忆引用，因此可用于解除日记永久删除的阻塞。需 `X-Confirm-Memory-Delete`，**不需要**管理员令牌。不可撤销。 |
| `DELETE /api/v1/persons/{id}` | **遗忘人物（v0.2）**：永久删除人物行；只追加不含内容的 `person.purged` 审计。需 `X-Confirm-Person-Delete`，不需要管理员令牌。不可撤销。 |
| `POST /api/v1/memories/{id}/revoke` | **撤回**：记忆变为 `revoked` 并从默认列表/搜索隐藏；行与证据仍保留以便追溯，仍会阻止物理删除其来源日记。不会删除任何内容。 |
| `POST /api/v1/memories/{id}/correct` | **更正**：旧记忆标记 `superseded`（不删除），新建一条 confirmed 记忆。历史仍可审计。 |
| `DELETE /api/v1/diaries/{id}/permanent` | **物理删除**：删除 entry 及其全部修订（需管理员 Token + `X-Confirm-Permanent-Delete`，且**无任何**记忆/证据/人物引用；可用 `GET /diaries/{id}/references` 查看计数）。审计事件保留（append-only），备份/导出/文件系统副本不自动删除。 |
| 删除备份/导出文件 | 由你手动执行（或对自动命名备份使用 `--retention`）；HeartLog 不会自动按"删除语义"清理历史备份。 |

### 6.1 purge 与 anonymize 的诚实区别

两者**删除的数据完全相同**：记忆行与它的全部证据行都被物理删除，之后数据库里既没有记忆正文，也没有证据片段；来源日记不再被引用。唯一的区别是追加式审计的事件类型（`memory.purged` vs `memory.anonymized`），审计 details 只有 ID/类型/计数等结构字段，**不含正文**。

> `anonymize` **不是**"保留一条去标识化后的记忆"或"原地匿名替换"：它同样删除记忆行。如果你需要保留一条改写后的记忆，请使用更正（correct）接口；需要彻底移除则用 purge/anonymize。

### 6.2 解除日记永久删除阻塞的步骤

1. `GET /api/v1/diaries/{id}/references` 查看 `memories` / `memory_sources` / `persons` 计数与 `can_permanently_delete`；
2. 对每条引用记忆执行 `DELETE /api/v1/memories/{memory_id}?mode=purge`（或 `anonymize`）+ 确认头；
3. 对每个人物执行 `DELETE /api/v1/persons/{person_id}` + 确认头；
4. 再查 `references`，`can_permanently_delete=true` 后执行管理员物理删除。

引用归零前物理删除会返回 `409 entry_has_references`。**revoke 不会解除引用**（撤回仍保留来源行）；想删日记只能先遗忘引用内容。

### 6.3 派生数据的默认隐藏（不是删除）

来源日记软删除后，它的记忆/人物在以下位置默认不可见，传 `include_deleted_sources=true` 可显式查看；响应中 `source_entry_deleted` 字段标明来源日记已删除：

- `GET /memories`、`GET /memories/{id}`、`GET /memories/{id}/sources`；
- `GET /persons`、`GET /persons/{id}`、`GET /persons/{id}/timeline`（timeline 命中始终只来自未删除日记）；
- `GET /search` 的 memory 命中；
- 周/月回顾（`/insights`）**始终**排除这些记忆，没有 opt-in。

隐藏只是**可见性策略**：派生行、证据与内容仍在数据库中，直到你显式 purge；按 id 的审阅/遗忘操作始终可用。若希望"删除日记即删除所有派生内容"，当前版本不提供级联删除，需要自己对每条派生记忆执行遗忘（或等待未来功能）。

### 6.4 关于"被遗忘"的诚实说明

- HeartLog 没有"密码学擦除（crypto-shredding）"；SQLite 页面、WAL 文件、文件系统空闲块、磁盘快照、同步盘、**历史备份/导出**都可能保留旧数据。遗忘只保证当前数据库中的记忆内容/证据/人物行被删除。
- 永久删除的日记，其 `content_hash`（64 位十六进制摘要）会随审计/历史导出保留在部分结构中；已遗忘记忆的审计事件也保留其 ID/类型/来源 ID/计数，但**不含**正文或证据文本。哈希本身不包含可读正文，但可被用于比对已知文本。
- **加密备份的"遗忘"问题**：`--encrypt` 保护的是备份机密性；它并不会让旧备份中的内容消失。要真正减少历史副本中的敏感数据，需要按保留策略/手动清理旧备份与导出，并评估全盘加密、磁盘快照与同步副本。
- 本实现不是完整的"被遗忘权"实现；请把备份/导出/同步副本一起纳入你的威胁模型。

---

## 7. 可选令牌 vs 生产级认证

HeartLog 提供两种**可选**令牌（[`app/core/security.py`](../app/core/security.py)）：

| 配置 | 效果 | 状态码 |
| --- | --- | --- |
| `HEARTLOG_API_TOKEN` 未设置 | `/api/v1/*` 完全开放（仅本机可用时风险较低） | — |
| `HEARTLOG_API_TOKEN` 已设置 | 所有 `/api/v1/*` 需 `Authorization: Bearer <token>`；使用常量时间比较 | 缺失/错误 → `401 unauthorized` |
| `HEARTLOG_ADMIN_TOKEN` 未设置 | **日记物理删除**整体禁用（记忆/人物遗忘不需要该令牌） | `403 admin_disabled` |
| `HEARTLOG_ADMIN_TOKEN` 已设置 | **日记物理删除**需 `X-Admin-Token: <token>` + `X-Confirm-Permanent-Delete` | 缺失/错误 → `403 admin_required` |

公开（无需 Token）的端点：`GET /`、`GET /health`、`GET /docs`、`GET /redoc`、`GET /openapi.json`。

**这不是生产级认证**：

- 单一静态令牌，没有用户、角色、会话、过期、轮换 API、撤销列表；
- 应用本身**不内置 TLS**：本地 HTTP 是明文；放到网络上必须由反向代理（或 uvicorn 直接 TLS）终止 TLS，见 [部署安全指南](deployment_security.md)；
- 应用内限流（`HEARTLOG_RATE_LIMIT_*`）**可选且默认关闭**，是进程内实现（重启清零、多 worker 各自计数），不替代代理层限流/WAF；没有登录暴力破解防护与 CSRF 防护（浏览器场景）；
- 没有登录/审计用户身份能力（审计 `actor` 只有 user/system/model）；
- Token 泄漏后任何持有者都能以完整权限操作，直到重启并更换配置。

**如果必须暴露到非 loopback**：请放在带认证、TLS、访问控制与限流的反向代理之后，并至少设置 `HEARTLOG_API_TOKEN` 与 `HEARTLOG_ADMIN_TOKEN`；更推荐保持本机使用。可选的加固配置（Nginx/Caddy/systemd、本地 TLS、权限收紧）见 [部署安全指南](deployment_security.md) 与 [deploy/README.md](../deploy/README.md)——这些是**参考示例，未在真实环境联调**，上线前需自行验证。

---

## 8. 威胁模型

| 威胁 | 当前状态 | 说明 / 缓解 |
| --- | --- | --- |
| 同一台电脑上的其他进程读取数据库/备份 | ⚠️ 取决于文件系统权限 | 没有应用层加密；建议 OS 账户隔离、磁盘加密 |
| 磁盘/设备丢失或被盗 | ⚠️ 明文落盘 | 依赖 BitLocker/FileVault/LUKS 等全盘加密；备份同样需加密 |
| 同机其他用户通过 HTTP 端口访问 | ⚠️ 默认无 Token | 建议设置 `HEARTLOG_API_TOKEN`；只监听 `127.0.0.1`；可选用应用内限流限制滥用 |
| 局域网/公网攻击者访问端口 | ⚠️ 取决于部署（可选加固） | 应用本身不内置 TLS/登录；应放在带 TLS、认证与**代理层**限流的反向代理之后。应用内限流（`HEARTLOG_RATE_LIMIT_*`，默认关闭、进程内）只是补充；参考配置未在真实环境联调 |
| 暴力破解 / 请求洪水 | ⚠️ 可选缓解 | 开启 `HEARTLOG_RATE_LIMIT_ENABLED=true` 可做进程内限流；公网应叠加代理层 `limit_req` / CDN/WAF。限流重启清零、多 worker 不共享配额 |
| 恶意/被入侵的 AI provider | ⚠️ 无法控制 | 数据在启用 AI 时会被发送；阅读提供方条款，使用可信/本地 provider |
| 提示注入（日记/对话中含恶意指令） | 🛡️ 有缓解，非保证 | untrusted-data 标记 + 系统提示 + 输出 schema 校验 + 证据精确匹配 + 用户确认；模型仍可能被诱导输出误导内容 |
| 模型幻觉被当作事实 | 🛡️ 有缓解 | 记忆必须引用精确原文证据、初始为 pending、永不自动确认、类型不可升级；仍需用户审核 |
| 应用 bug 或误操作改坏历史 | 🛡️ 有缓解 | ORM 监听器 + SQLite 触发器 + 审计 append-only + 完整性校验 |
| 有数据库文件写权限的人篡改历史 | ⚠️ 只能发现，不能阻止 | 哈希链可检出不一致；但可删除触发器/改文件/用备份覆盖；不是防篡改存储 |
| 备份/导出文件泄漏 | ⚠️ 默认明文（加密备份为可选） | 明文备份/导出需放入加密卷或加密后再移动；`scripts/backup.py --encrypt` 可生成 AES-256-GCM 密文，但口令丢失不可恢复、旧备份不会自动失效 |
| 执行遗忘后仍能从旧副本恢复数据 | ⚠️ 无法通过应用解决 | 遗忘只修改当前数据库；历史备份/导出、WAL、快照、同步盘仍可能保留旧内容；需自行按保留策略/手动清理 |
| 供应链/依赖漏洞 | ⚠️ 未审计 | 固定版本依赖；未做安全审计；AI 提供方 SDK 未使用（仅 httpx） |
| 侧信道（时间、错误信息） | ⚠️ 未专门评估 | 错误信息尽量不含私人内容；令牌比较使用常量时间 |

---

## 9. 安全建议清单

- [ ] 只监听 `127.0.0.1`，除非你明确知道自己需要网络访问。
- [ ] 设置 `HEARTLOG_API_TOKEN`（以及需要物理删除时设置 `HEARTLOG_ADMIN_TOKEN`）；使用足够长的随机值，不要复用其他服务密码。
- [ ] 开启全盘加密；把 `data/`、`backups/`、`exports/` 放在受控目录，并用 `scripts/harden_permissions.py`（先 dry-run）缩小权限。
- [ ] 备份/导出后加密再移动（或使用 `backup.py --encrypt`），定期演练恢复；**加密备份口令丢失不可恢复**，请用密码管理器保管。
- [ ] 需要网络暴露时：使用反向代理/TLS + 代理层限流 + 应用令牌，并开启应用内限流（`HEARTLOG_RATE_LIMIT_ENABLED=true`）；不要直接把 uvicorn 绑定 `0.0.0.0` 暴露到公网。
- [ ] 不需要 AI 时保持 `HEARTLOG_AI_ENABLED=false`；需要时先读本文再打开两个开关，并确认 `AI_BASE_URL` 指向可信服务。
- [ ] 不要把 `.env`、数据库、备份、导出提交到 git 或公开分享。
- [ ] 定期运行 `python scripts/verify_integrity.py` 并关注非零退出；定期运行 `python scripts/restore_drill.py <backup>`。
- [ ] 升级依赖/版本前先备份；删除/遗忘数据时同步处理历史备份与导出。

---

## 10. 当前安全限制与未决问题（明确列出）

1. **没有认证的浏览器会话/UI**：`/docs` 是可交互 API 文档，本身不提供登录；若设置了 `API_TOKEN`，在 Swagger UI 里调用需要手动加 Authorization header。
2. **`/docs` 静态资源来自 CDN**：Swagger UI 的 JS/CSS 默认从 `cdn.jsdelivr.net` 加载（FastAPI 默认行为）。这意味着打开 `/docs` 的**浏览器**会向该 CDN 发起请求（不包含你的日记数据，但暴露访问行为/IP）。完全离线环境可考虑禁用 `/docs` 或本地化这些静态资源——当前代码未做本地化。
3. **响应校验错误不回显输入值**，但字段路径会暴露请求结构；这通常无害。
4. **审计不是密码学防篡改**，只是应用层 append-only + 触发器。
5. **没有密钥轮换 API**：修改 Token/API Key 需要改 `.env` 并重启（见 [运维文档](operations.md#8-密钥与令牌轮换)）。
6. **日志不是正式的结构化审计**：代码按最小化原则记录，但第三方库/代理/操作系统的日志不在控制范围内。数据库异常处理器只记录异常类型（不记录 SQL、绑定参数或 traceback 文本），未处理异常的中间件仍会记录 Python traceback（具体内容取决于异常类型）；请把日志文件视为敏感文件并限制访问/轮转。
7. **没有能理解删除/遗忘语义的数据保留策略**；历史修订、记忆、审计会一直存在，直到你手动处理。备份有按时间排序的 `--retention`，但它**不会**识别遗忘/删除语义去清理含旧数据的备份。
8. **没有静态加密、没有字段级加密**；数据库、WAL、导出 JSON 与**默认的**备份均为明文。加密备份（AES-256-GCM）是可选功能，不改变数据库本身的明文存储。
9. **没有漏洞响应流程/安全审计报告**；项目为私有开发阶段。
10. **本轮新增的部署/备份能力有验证边界**：应用内限流有自动化测试；加密备份/恢复演练覆盖代码路径；但 **Nginx/Caddy/systemd 配置未在真实环境端到端验证**，**真实加密备份的灾难恢复未在真实生产环境演练**，真实外部 AI 调用也未验证。详见 [部署安全指南](deployment_security.md#1-部署形态) 与 [备份文档 §12](backup.md#12-已知限制请纳入你的威胁模型)。
