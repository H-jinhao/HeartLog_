# HeartLog 部署安全指南

本文面向准备把 HeartLog 从"本机开发进程"部署成"受控网络服务"的维护者，覆盖：

- 部署形态选择与威胁模型；
- 本地 TLS（开发自签证书）与生产 TLS（真实 CA / 反向代理）；
- Nginx / Caddy 反向代理示例与验证命令；
- systemd 常驻与加固；Windows 服务 / 任务计划程序部署；
- 令牌与认证、应用内限流、代理层限流；
- 数据目录与备份/导出文件的 OS 权限；
- 日志隐私、生产/预发布启动告警；
- **明确的安全限制**（哪些事这些配置做不到）。

相关文件：[`deploy/nginx.conf`](../deploy/nginx.conf) · [`deploy/Caddyfile`](../deploy/Caddyfile) ·
[`deploy/heartlog.service`](../deploy/heartlog.service) · [`deploy/heartlog.env.example`](../deploy/heartlog.env.example) ·
[`deploy/README.md`](../deploy/README.md) · [`scripts/generate_dev_cert.py`](../scripts/generate_dev_cert.py) ·
[`scripts/harden_permissions.py`](../scripts/harden_permissions.py) · [`app/core/rate_limit.py`](../app/core/rate_limit.py)

> ⚠️ **验证状态（请务必阅读）**
>
> 本仓库中的 Nginx / Caddy / systemd 配置是**参考示例**，经过逐行人工审阅与逻辑核对，
> 但**没有**在真实 Nginx、Caddy、systemd 环境中做端到端部署验证；示例域名、证书路径、
> basic auth 哈希、限流阈值都是占位值。上线前请自行执行
> `nginx -t`、`caddy validate`、`systemd-analyze verify`，并实际验证 TLS 握手、
> 401/403/429、日志脱敏与备份/恢复流程。
>
> 本文中标注"已在本机验证"的部分，仅限开发脚本层面（`generate_dev_cert.py` 的生成/拒绝覆盖/
> `--force`/SAN 检查，`harden_permissions.py` 的 dry-run 与命令构造）；不代表生产环境已验证。
> 应用内限流有自动化测试覆盖（`tests/test_rate_limit.py`）。

---

## 1. 部署形态

| 形态 | 监听 | TLS | 认证 | 适用场景 |
| --- | --- | --- | --- | --- |
| **A. 本机 loopback** | `127.0.0.1:8000` | 无（不出网卡） | 可选 `HEARTLOG_API_TOKEN` | 最推荐：单机个人使用 |
| **B. uvicorn 直接 TLS** | `127.0.0.1:8443` | 有（自签/自有证书） | 同上 | 本机浏览器/客户端需要 HTTPS，或临时演示 |
| **C. 反向代理 + TLS** | 后端 `127.0.0.1:8000` | 有（真实 CA） | 代理层 + 应用令牌 | 需要局域网/公网访问时的**唯一推荐**形态 |

> HeartLog 是单用户本地优先应用：没有用户体系、登录会话、CSRF 防护、WAF/IDS。
> **不要**把 uvicorn 直接绑定 `0.0.0.0` 暴露到公网。

---

## 2. 威胁模型

### 2.1 这些配置能缓解

| 威胁 | 缓解手段 |
| --- | --- |
| 链路窃听 / 中间人 | TLS 1.2/1.3、强密码套件、HTTP→HTTPS 跳转、按需 HSTS |
| 未授权访问 | 反向代理 `auth_basic` + 应用 `HEARTLOG_API_TOKEN` 双层 |
| 暴力破解 / 请求洪水 | 代理层 `limit_req` + 应用内 `HEARTLOG_RATE_LIMIT_*` |
| 浏览器侧响应头攻击 | `X-Content-Type-Options`、`Referrer-Policy`、`X-Frame-Options`、`Cache-Control: no-store` |
| 文档/接口元数据暴露 | 默认 404 隐藏 `/docs`、`/redoc`、`/openapi.json` |
| 代理访问日志泄漏搜索词 | 自定义日志格式只记录 `$uri`（不含 query string） |
| 同机其他账户读数据文件 | 专用服务账户 + `UMask=0077` + 目录 0700/文件 0600（`harden_permissions.py`） |

### 2.2 这些配置**不能**解决

- **拥有 `data/` 文件读写权限的人就是最高权限**：HeartLog 用明文 SQLite，哈希链/触发器
  只能发现部分篡改，不能阻止有文件写权限的人改库、删触发器或用备份覆盖。
- **root / 服务账户被攻破**：进程内存中的令牌、AI Key、解密后的日记都可被读取。
- **磁盘丢失**：SQLite、备份、导出都是明文；必须依赖 BitLocker/FileVault/LUKS 等全盘加密。
- **备份/导出文件泄漏**：备份默认明文；可选 AES-256-GCM 加密（见 `docs/backup.md`），
  未加密时需自行放入加密卷或使用 `age`/GPG。
- **AI provider 侧风险**：启用 AI 后日记正文会发给配置的 provider，见 `docs/privacy.md`。
- **多用户/角色隔离、操作者身份审计**：HeartLog 没有这些能力；能连上端口的主体看到同一份数据。
- **供应链 / 0-day**：依赖版本固定但未做安全审计。

---

## 3. 本地 TLS（开发 / 单机，形态 B）

### 3.1 生成自签证书

项目内置脚本（依赖已在 `requirements.txt` 固定的 `cryptography`）：

```bash
cd /path/to/heartlog              # 或你的项目根目录
python scripts/generate_dev_cert.py
# 输出：certs/localhost.key（私钥）、certs/localhost.crt（自签证书）
# 已有文件时拒绝覆盖；需要替换（旧私钥会丢失）时：
python scripts/generate_dev_cert.py --force
# 自定义目录/有效期：
python scripts/generate_dev_cert.py --out-dir certs --days 365
```

说明：

- 证书 SAN 包含 `DNS:localhost`、`IP:127.0.0.1`、`IP:::1`，`BasicConstraints CA=false`，
  `ExtendedKeyUsage=serverAuth`；默认 825 天有效期。
- POSIX 上私钥 `chmod 600`；Windows 上请用 `icacls` 限制（脚本会打印示例命令）。
- **自签证书不是生产证书**：客户端必须显式信任（curl `--cacert` / 浏览器导入），
  且任何拿到私钥的人都可以冒充该证书身份。仅限 loopback/本机开发。
- `certs/`、`*.key`、`*.pem` 已在 `.gitignore` 中忽略；不要提交或分享私钥。

> 已在本机环境手工验证：生成成功、二次运行返回退出码 2 拒绝覆盖、`--force` 覆盖成功、
> 证书 SAN/CA/EKU 字段与上述一致。

### 3.2 用 uvicorn 启用 TLS

```bash
python -m uvicorn "app.main:create_app" --factory \
    --host 127.0.0.1 --port 8443 \
    --ssl-keyfile certs/localhost.key --ssl-certfile certs/localhost.crt
```

验证：

```bash
curl --cacert certs/localhost.crt https://localhost:8443/health
# 浏览器访问 https://localhost:8443/docs 会提示"不受信任"，需手动信任证书
```

Linux 下若用系统安装的自有证书（非自签 CA）：

```bash
uvicorn "app.main:create_app" --factory --host 127.0.0.1 --port 8443 \
    --ssl-keyfile /etc/heartlog/tls/privkey.pem \
    --ssl-certfile /etc/heartlog/tls/fullchain.pem
```

---

## 4. Nginx 反向代理（形态 C，推荐）

参考配置：[`deploy/nginx.conf`](../deploy/nginx.conf)。部署结构：

```text
Internet/LAN ──TLS──> Nginx :443 ──HTTP(loopback)──> uvicorn 127.0.0.1:8000
```

### 4.1 关键行为

- TLS 1.2/1.3 + 强套件；HSTS 默认**注释**（确认 HTTPS 长期可用后再开）。
- `limit_req_zone $binary_remote_addr zone=heartlog_api:10m rate=10r/s;`
  与 `limit_req zone=heartlog_api burst=20 nodelay;`（示例值，按实际调整）。
- `auth_basic` 示例（注释状态）；密码文件：
  ```bash
  sudo htpasswd -B -c /etc/nginx/heartlog.htpasswd heartlog-user
  ```
- `proxy_pass http://127.0.0.1:8000;`，显式转发 `Authorization`、`X-Admin-Token`、
  `X-Request-ID`。
- **`proxy_set_header X-Forwarded-For $remote_addr;` 覆盖语义**（不是追加）。
  原因：应用在 `HEARTLOG_TRUST_PROXY_HEADERS=true` 时使用**第一跳**作为限流键；
  `$proxy_add_x_forwarded_for` 会把客户端伪造值放第一位，从而绕过按 IP 限流。
- 默认 `location ^~ /docs`、`/openapi.json`、`/redoc` 返回 404；确需开启时取消注释
  并加上 basic auth。
- `client_max_body_size 2m`（日记正文上限 5 万字符）、请求/响应超时、`server_tokens off`。
- 访问日志使用自定义格式，只记录 `$uri`（不含 `?q=...` 等私密查询参数）。

### 4.2 安装与验证

```bash
sudo apt install nginx certbot python3-certbot-nginx apache2-utils   # Debian/Ubuntu 示例
sudo certbot --nginx -d heartlog.example.com                          # 真实证书

sudo cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.bak
sudo nano deploy/nginx.conf      # 修改域名、证书路径、upstream 端口、限流阈值
sudo cp deploy/nginx.conf /etc/nginx/nginx.conf   # 或按站点 include 方式合并
sudo nginx -t
sudo systemctl reload nginx
```

验证命令：

```bash
curl -sSf https://heartlog.example.com/health
curl -sS -o /dev/null -w '%{http_code}\n' https://heartlog.example.com/docs          # 期望 404
curl -sS -o /dev/null -w '%{http_code}\n' https://heartlog.example.com/api/v1/diaries # 401/403 或 200
# 触发代理层限流（示例 10r/s，burst 20）：快速请求，期望出现 429
for i in $(seq 1 100); do curl -s -o /dev/null -w '%{http_code}\n' \
  https://heartlog.example.com/api/v1/diaries; done | sort | uniq -c
```

> 若 Nginx 前还有一层可信代理/负载均衡，需要把 `$remote_addr` 改成真实客户端地址的
> 可信获取方式，并配置 `set_real_ip_from`/`real_ip_header`，否则所有请求会共用同一个 IP 桶。
> 应用侧同样支持只信任"覆盖写"的 XFF。

---

## 5. Caddy 替代（形态 C）

参考配置：[`deploy/Caddyfile`](../deploy/Caddyfile)。

```bash
caddy validate --config deploy/Caddyfile
sudo cp deploy/Caddyfile /etc/caddy/Caddyfile
caddy hash-password --plaintext 'a-long-random-password'   # basic_auth 哈希
sudo systemctl reload caddy
```

要点：

- 真实域名 + 80/443 可达时可用 Caddy 自动 HTTPS（删掉 `tls` 两行）。
- `basic_auth` 需要 Caddy ≥ 2.8（旧版本指令名为 `basicauth`）。
- `reverse_proxy` 的 `header_up X-Forwarded-For {remote_host}` 为覆盖语义；若前面还有
  一层可信代理，改用全局 `trusted_proxies` 配置。
- 示例中 `rate_limit` 需要社区插件 `github.com/mholt/caddy-ratelimit`（`xcaddy` 构建），
  不是标准发行版内置；没有插件时依赖应用内限流或前置 CDN/WAF。
- Caddy 默认 JSON 访问日志包含完整 URI（含 query），请按隐私要求关闭或后处理。

---

## 6. systemd 常驻（Linux）

参考单元：[`deploy/heartlog.service`](../deploy/heartlog.service)、
[`deploy/heartlog.env.example`](../deploy/heartlog.env.example)。

### 6.1 安装步骤

```bash
# 1) 专用无登录系统用户
sudo useradd --system --home /opt/heartlog --shell /usr/sbin/nologin heartlog

# 2) 代码与虚拟环境
sudo install -d -o heartlog -g heartlog -m 0755 /opt/heartlog
sudo -u heartlog git clone <your-repo> /opt/heartlog     # 或 rsync 工作副本
sudo -u heartlog python3 -m venv /opt/heartlog/.venv
sudo -u heartlog /opt/heartlog/.venv/bin/pip install -r /opt/heartlog/requirements.txt

# 3) 数据目录（0700，仅服务账户）
sudo install -d -o heartlog -g heartlog -m 0700 \
    /var/lib/heartlog /var/lib/heartlog/data \
    /var/lib/heartlog/backups /var/lib/heartlog/exports

# 4) 环境文件（含令牌；0600 root:heartlog）
sudo install -d -m 0750 -o root -g heartlog /etc/heartlog
sudo install -m 0600 -o root -g heartlog deploy/heartlog.env.example /etc/heartlog/heartlog.env
sudo nano /etc/heartlog/heartlog.env       # 填真实令牌/路径

# 5) 数据库迁移（首次；alembic 从进程环境读取 HEARTLOG_DATABASE_URL，
#    alembic.ini 的相对路径以代码目录为基准）
sudo -u heartlog env \
    HEARTLOG_DATABASE_URL=sqlite:////var/lib/heartlog/data/heartlog.db \
    HEARTLOG_DATA_DIR=/var/lib/heartlog/data \
    HEARTLOG_BACKUP_DIR=/var/lib/heartlog/backups \
    sh -c 'cd /opt/heartlog && .venv/bin/python -m alembic upgrade head'

# 6) 安装服务并启动
sudo install -m 0644 /opt/heartlog/deploy/heartlog.service /etc/systemd/system/heartlog.service
sudo systemctl daemon-reload
sudo systemctl enable --now heartlog
sudo systemctl status --no-pager heartlog
journalctl -u heartlog -n 100 --no-pager
```

### 6.2 单元文件的关键加固项

- `User=heartlog` + `Group=heartlog`，`WorkingDirectory=/opt/heartlog`；
- `ExecStart=.../uvicorn "app.main:create_app" --factory --host 127.0.0.1 --port 8000
  --no-server-header --no-proxy-headers`（后端只监听 loopback；`--no-proxy-headers`
  避免 uvicorn 自行改写 `request.client`，是否信任 XFF 由应用配置决定）；
- `EnvironmentFile=/etc/heartlog/heartlog.env`（0600）；
- `StateDirectory=heartlog` + `StateDirectoryMode=0700` + `UMask=0077`；
- `NoNewPrivileges`、`PrivateTmp`、`PrivateDevices`、`ProtectSystem=strict`、`ProtectHome`、
  `ProtectProc=invisible`、`ProcSubset=pid`、`ProtectKernel*`、`ProtectClock`、
  `RestrictAddressFamilies`、`RestrictNamespaces`、`LockPersonality`、
  `MemoryDenyWriteExecute`、`CapabilityBoundingSet=`、`SystemCallFilter=@system-service`；
- `Restart=on-failure`、`TimeoutStopSec=20`、`KillSignal=SIGTERM`，lifespan 正常关闭并
  `engine.dispose()`。

### 6.3 验证

```bash
systemd-analyze verify deploy/heartlog.service
systemd-analyze security heartlog.service          # 查看暴露面评分/细节
curl -sS http://127.0.0.1:8000/health
ls -l /var/lib/heartlog /var/lib/heartlog/data     # drwx------ / -rw-------
sudo -u heartlog ls /var/lib/heartlog              # 服务账户可访问
```

注意：

- `ProtectProc=invisible`/`ProcSubset=pid` 需要 systemd ≥ 247；老系统删除这两行。
- `MemoryDenyWriteExecute`、`SystemCallFilter=@system-service` 在少数依赖上可能不兼容，
  如启动失败请逐项放宽并记录原因。
- 备份/导出目录的最终权限由 `scripts/harden_permissions.py` 和 systemd 的 `UMask` 共同保证。

---

## 7. Windows 部署

HeartLog 支持 Windows 本机运行；Windows 没有 systemd，可用以下方式。

### 7.1 任务计划程序（轻量）

1. 打开"任务计划程序"→ 创建任务；
2. 常规：使用专用本地账户（不要用 Administrator 日常账户），"不管用户是否登录都要运行"；
3. 触发器：开机时 / 登录时；
4. 操作：
   - 程序：`C:\HeartLog\.venv\Scripts\python.exe`
   - 参数：`-m uvicorn "app.main:create_app" --factory --host 127.0.0.1 --port 8000`
   - 起始于：`C:\HeartLog`
5. 设置：失败后重启（如每 1 分钟，最多 3 次）。

### 7.2 Windows 服务（常驻）

可用 [NSSM](https://nssm.cc/) 或 `sc.exe` 包装：

```powershell
# 示例：NSSM
nssm install HeartLog "C:\HeartLog\.venv\Scripts\python.exe" `
  -m uvicorn "app.main:create_app" --factory --host 127.0.0.1 --port 8000
nssm set HeartLog AppDirectory "C:\HeartLog"
nssm set HeartLog AppEnvironmentExtra HEARTLOG_ENVIRONMENT=production
nssm start HeartLog
```

或 `sc.exe`（注意 `binPath=` 后面要有空格，命令参数用完整路径）：

```powershell
sc.exe create HeartLog binPath= "\"C:\HeartLog\.venv\Scripts\python.exe\" -m uvicorn \"app.main:create_app\" --factory --host 127.0.0.1 --port 8000" start= auto
sc.exe start HeartLog
```

### 7.3 权限与防火墙

```powershell
# 数据/备份/导出目录 ACL 收紧（脚本会打印/执行同样语义的命令）
python scripts/harden_permissions.py                 # 先 dry-run 看命令
python scripts/harden_permissions.py --apply         # 需要时可提高权限运行

# 私钥单独限制（generate_dev_cert.py 会打印类似命令）
icacls "C:\HeartLog\certs\localhost.key" /inheritance:r /grant:r "$env:USERNAME":F
```

- 只监听 `127.0.0.1`；如要对外，只放行反向代理端口（443），**不要**放行 8000。
- 用 Windows 版 Nginx/Caddy 或 IIS ARR 终止 TLS；直接暴露 uvicorn + 自签证书仅适合本机。
- 防火墙示例：`New-NetFirewallRule -DisplayName "HeartLog HTTPS" -Direction Inbound -LocalPort 443 -Protocol TCP -Action Allow`
  （仅在确实需要外部访问时创建）。

---

## 8. 令牌与认证

HeartLog 提供两个**可选静态令牌**（[`app/core/security.py`](../app/core/security.py)）：

| 配置 | 作用 | 行为 |
| --- | --- | --- |
| `HEARTLOG_API_TOKEN` | `/api/v1/*` 的 Bearer 令牌 | 未设置=不校验；设置后缺失/错误返回 `401 unauthorized`，使用常量时间比较 |
| `HEARTLOG_ADMIN_TOKEN` | 不可逆操作（永久删除）的额外 header | 未设置=永久删除整体禁用（`403 admin_disabled`）；设置后需 `X-Admin-Token` + `X-Confirm-Permanent-Delete` |

生成与设置：

```bash
python -c "import secrets; print(secrets.token_urlsafe(48))"   # 生成两个不同的长随机值
# .env（本地）或 /etc/heartlog/heartlog.env（systemd）：
HEARTLOG_API_TOKEN=替换为长随机值
HEARTLOG_ADMIN_TOKEN=替换为另一个长随机值
```

客户端调用：

```bash
curl -H "Authorization: Bearer $HEARTLOG_API_TOKEN" http://127.0.0.1:8000/api/v1/diaries
# Web 入口是 /docs（若未隐藏）：Swagger UI 里需手动加 Authorization header
```

限制（务必理解）：

- 单用户静态令牌，没有用户/角色/会话/过期/轮换 API/撤销列表；
- 令牌泄漏后任何持有者拥有全部权限，直到改配置并重启；
- 代理层 basic auth 与应用令牌是两层独立机制，不能替代彼此；
- 浏览器场景没有 CSRF 防护；不要把 API 直接暴露给浏览器跨站调用。

---

## 9. 限流（应用内）

实现：[`app/core/rate_limit.py`](../app/core/rate_limit.py)，配置项（都可加 `HEARTLOG_` 前缀
写入 `.env`/环境变量）：

| 配置 | 默认 | 说明 |
| --- | --- | --- |
| `rate_limit_enabled` | `false` | 总开关；默认关闭以保证本地使用与测试不受影响 |
| `rate_limit_requests` | `240` | 滑动窗口内允许的请求数 |
| `rate_limit_window_seconds` | `60` | 窗口长度（秒） |
| `rate_limit_exempt_paths` | `/health,/docs,/redoc,/openapi.json` | 逗号分隔的免限流前缀（按路径或子路径匹配） |
| `trust_proxy_headers` | `false` | 是否信任 `X-Forwarded-For` 的**第一跳**作为限流键 |

行为：

- 只作用于 `<api_v1_prefix>`（默认 `/api/v1`）下的路径；`/health`、文档等非 API 路径本就不限流。
- 每个客户端 IP（或可信代理提供的地址）一个滑动窗口；超过阈值返回：
  - `429`，JSON 信封 `{"error":{"code":"rate_limited","message":"...","details":{"limit":N,"window_seconds":W,"retry_after_seconds":R}}}`
  - 响应头：`Retry-After`、`X-RateLimit-Limit`、`X-RateLimit-Remaining`、`X-RateLimit-Reset`
    （后三者为该窗口的整数值）；仍经过原有 request-id / 隐私响应头 / 访问日志中间件。
- 被拒绝的请求不会延长窗口；时间源用 `time.monotonic`，线程安全，跟踪客户端数量有上限
  （超限时先清理过期项，再淘汰最久未活动的客户端，避免内存无限增长）。
- **默认不信任 `X-Forwarded-For`**；直接使用 TCP 对端地址。仅当部署在可信反向代理之后、
  且代理**覆盖**（而非追加）该头时设置 `trust_proxy_headers=true`。
- 进程内实现：每个 uvicorn worker 独立计数（`--workers N` 时实际阈值约为 `N × requests`；
  重启清零）。公网部署请同时使用代理层 `limit_req` / CDN/WAF。

示例 `.env`：

```ini
HEARTLOG_RATE_LIMIT_ENABLED=true
HEARTLOG_RATE_LIMIT_REQUESTS=240
HEARTLOG_RATE_LIMIT_WINDOW_SECONDS=60
# 仅当 Nginx/Caddy 覆盖 X-Forwarded-For 时开启
HEARTLOG_TRUST_PROXY_HEADERS=true
```

快速验证（N=3 的临时实例）：

```bash
HEARTLOG_RATE_LIMIT_ENABLED=true HEARTLOG_RATE_LIMIT_REQUESTS=3 \
  uvicorn "app.main:create_app" --factory --host 127.0.0.1 --port 8000
for i in 1 2 3 4; do curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:8000/api/v1/diaries; done
# 期望：200 200 200 429
```

> 日志：429 只记录 `request_id/method/path/limit/window/retry_after`，**不记录**查询字符串、
> 请求体、头部或客户端地址；应用访问日志同样只记录 path（不含 query）。

---

## 10. 数据目录与文件权限

HeartLog 的最终安全边界是**文件系统权限**：能读 `data/` 的人就能读全部日记。

### 10.1 脚本用法

[`scripts/harden_permissions.py`](../scripts/harden_permissions.py)：默认 dry-run，**只有加
`--apply` 才修改**。

```bash
# 查看将要做什么（不修改任何东西）
python scripts/harden_permissions.py

# 应用：POSIX 目录 700、文件 600；Windows 用 icacls 收紧继承 ACL
python scripts/harden_permissions.py --apply

# 服务器数据目录不在项目内时（仍会被限制在给的 root 之内）
python scripts/harden_permissions.py --root /var/lib/heartlog --apply

# 额外目录必须显式声明，且必须位于 --root 之内
python scripts/harden_permissions.py --include certs --apply
```

行为与安全约束：

- 默认只处理 `<项目根>/data`、`backups`、`exports`；不触碰其他文件。
- 拒绝符号链接 / Windows reparse point（junction），不跟随链接（防止改到项目外）。
- Windows：为每个条目执行
  `icacls <path> /inheritance:r /grant:r "<当前用户>":... /grant:r *S-1-5-18:... /grant:r *S-1-5-32-544:...`，
  **移除继承 ACE** 但保留当前用户、SYSTEM、Administrators 的显式完全控制；不会删除当前用户访问。
  需要修改 ACL 的权限（对自有文件通常可以；否则用管理员终端）。
- 先跑 dry-run 审阅：收紧权限会影响其他需要读取这些目录的工具/账户（同步盘、备份代理、
  另一 OS 账户）。

> 已验证：dry-run 输出/不修改文件；Windows `--apply` 的命令构造、失败与 OSError 处理在模拟
> `subprocess.run` 下验证通过。真实 ACL 变更需在目标环境用有权限的账户执行确认
> （本仓库开发沙箱不允许 Python 创建子进程，因此未在本机实际执行 icacls）。

### 10.2 期望结果

| 对象 | POSIX | Windows |
| --- | --- | --- |
| `data/`、`backups/`、`exports/` 目录 | `drwx------` (0700) | 仅当前用户 + SYSTEM + Administrators |
| `*.db`、`*.db-wal`、`*.db-shm`、备份、导出 JSON | `-rw-------` (0600) | 同上（显式 ACE） |
| 服务运行账户 | 专用用户（如 `heartlog`） | 专用本地账户 |
| 全盘加密 | LUKS / FileVault / BitLocker | BitLocker |

### 10.3 备份/导出的额外要求

- 备份和导出是**完整明文数据**（含已软删除日记、全部修订、审计）。
- 放入加密卷，或用 `age`/GPG 加密后再移动；不要放进公开同步目录。
- 定期做恢复演练（`docs/operations.md`、`docs/backup.md`）。
- `certs/` 私钥同样按 0600 处理；`.env`、`data/`、`backups/`、`exports/`、`certs/` 均已 gitignore。

---

## 11. TLS 证书处理

### 11.1 生产证书

- 优先用 Let's Encrypt（certbot/caddy 自动续期）或组织 CA。
- Nginx：`ssl_certificate` 指向 `fullchain.pem`，`ssl_certificate_key` 指向 `privkey.pem`。
- 证书私钥权限 0600，属主为代理进程运行账户；不要与 HeartLog 服务账户共享。
- 续期后 `systemctl reload nginx`/`systemctl reload caddy`，无需重启 HeartLog。
- 检查到期与链：

```bash
openssl s_client -connect heartlog.example.com:443 -servername heartlog.example.com </dev/null 2>/dev/null \
  | openssl x509 -noout -subject -issuer -dates
curl -sSf https://heartlog.example.com/health   # 证书/链路错误会直接失败
```

### 11.2 开发/自签证书

- 用 `scripts/generate_dev_cert.py` 生成；仅限 loopback。
- 客户端信任方式：curl `--cacert certs/localhost.crt`；浏览器手动导入（仅测试机）。
- 私钥丢失/泄露：重新生成（`--force`），并撤销任何基于旧证书的信任。
- **不要**把自签证书配置进生产客户端信任库。

### 11.3 轮换流程

1. 生成/获取新证书；
2. 代理配置指向新文件，`nginx -t` / `caddy validate`；
3. reload 代理；
4. 验证握手与健康检查；
5. 观察客户端无 TLS 错误后移除旧证书；
6. 自签开发证书可直接 `--force` 重新生成并重启 uvicorn。

---

## 12. 日志与隐私

- HeartLog 访问日志：`request_id`、method、**path（不含 query string）**、status、duration；
  不记录请求/响应体、日记正文、令牌。
- 429 限流日志：request_id、method、path、limit、window、retry_after；不记录头部/正文/IP。
- 未处理异常：记录 request_id/method/path 与 traceback；traceback 内容取决于异常类型。
- 生产环境 `HEARTLOG_LOG_LEVEL=DEBUG` 前请确认第三方库（SQLAlchemy/httpx 等）不会输出敏感内容；
  `httpx`/`httpcore` 已被降到 WARNING。
- 代理层：**默认 combined 日志会记录完整 URI（含 query）**；`deploy/nginx.conf` 提供只记
  `$uri` 的格式，Caddy 请显式关闭/过滤访问日志。
- journald/终端/IDE 控制台/同步盘都可能保留日志；按需配置轮转与访问控制。

---

## 13. 生产/预发布启动告警

`create_app()` 在 `environment` 为 `production` 或 `staging` 时会以 WARNING 输出
`deployment_security` 日志（**不包含任何密钥值，也不阻止启动**），覆盖：

- 未设置 `HEARTLOG_API_TOKEN`（`/api/v1` 无认证）；
- 未设置 `HEARTLOG_ADMIN_TOKEN`（永久删除保持禁用）；
- `HEARTLOG_DEBUG=true`；
- 未启用应用内限流；
- 开启 `trust_proxy_headers`（提醒必须位于可信代理之后）；
- 启用 AI（提醒私有文本可能外发）。

示例：

```text
WARNING heartlog deployment_security environment=production issue=HEARTLOG_API_TOKEN is not set; every /api/v1 endpoint is unauthenticated
```

部署前请确认 `journalctl -u heartlog | grep deployment_security` 没有你无法接受的项目。

---

## 14. 明确的安全限制

1. **应用内限流是进程内、单机实现**：不是 WAF/IDS；重启清零；多 worker 各自计数；
   分布式/多实例部署需在代理层限流。
2. **没有多用户/角色/会话**：静态共享令牌；审计事件的 `actor` 只有 user/system/model。
3. **SQLite 文件访问权限是最终边界**：能写 `data/*.db` 的人可修改历史；哈希链/触发器只能
   发现部分不一致，不能防篡改，也不能防"用整库备份覆盖"。
4. **没有静态加密**：数据库、WAL、备份、导出的 JSON 都是明文；依赖全盘加密与文件权限。
5. **备份加密是可选能力**：默认明文；使用 `scripts/backup.py --encrypt` 可生成 AES-256-GCM 备份，口令由 `HEARTLOG_BACKUP_PASSPHRASE` 提供（见 `docs/backup.md`），本目录的部署配置不会自动开启加密。
6. **TLS 只保护传输**：不改变服务端明文存储与内存中明文的事实。
7. **没有 CSRF 防护/浏览器会话**：浏览器场景不要把 API 暴露给不信任页面。
8. **`/docs` 默认隐藏但可显式开启**：开启时 Swagger UI 可能从 CDN 加载静态资源（浏览器会
   访问 jsdelivr，暴露访问行为/IP，不含日记数据）；离线环境建议保持隐藏。
9. **代理配置/证书链/限流阈值需按实际环境调优**，本仓库未做生产级压测。
10. **没有漏洞响应流程、安全审计或渗透测试**；项目处于私有开发阶段，请自行评估风险。

---

## 15. 故障排查

| 症状 | 可能原因 / 处理 |
| --- | --- |
| 502 Bad Gateway | 后端未启动/端口不对；`curl http://127.0.0.1:8000/health` 检查 |
| 一直 429（所有人） | 代理未覆盖 XFF，所有请求共用代理 IP；改为 `$remote_addr` 覆盖，或临时提高阈值 |
| 429 出现得太早 | 多层限流叠加（代理 + 应用）；统一阈值或关闭一层 |
| 设置了 trust_proxy_headers 但所有 IP 相同/可伪造 | 代理未覆盖 XFF；或前面还有未受信的代理 |
| 401 全部请求 | `HEARTLOG_API_TOKEN` 已设置但客户端未带 `Authorization: Bearer ...` |
| 403 admin_disabled | 未设置 `HEARTLOG_ADMIN_TOKEN`；按需设置后重启 |
| 启动即退出 | 看 `journalctl -u heartlog`；常见为 env file 路径/权限、AI 配置校验失败、systemd 限制过严 |
| 服务账户无法写数据目录 | 目录属主/权限；`StateDirectory`/`ReadWritePaths`；用 `harden_permissions.py --root ... --apply` |
| TLS 证书错误 | 证书链不完整（用 fullchain）、域名不匹配、时间不同步、自签未信任 |
| Windows ACL 未生效 | 需要修改 ACL 的权限；用管理员终端重跑 `--apply`，或按 dry-run 打印命令手工执行 |
