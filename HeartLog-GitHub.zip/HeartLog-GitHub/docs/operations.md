# HeartLog 运维手册

本文面向"在自己机器上运行 HeartLog"的维护者，覆盖：环境准备、首次初始化、启动/停止、迁移、备份（含加密/保留/定时/恢复演练）、恢复/导出、完整性校验、AI 开启与关闭、令牌与备份口令轮换、部署安全/限流/TLS、故障排查与测试。

相关文档：[README](../README.md) · [架构](architecture.md) · [数据库设计](database_design.md) · [隐私](privacy.md) · [API](api.md) · [备份与恢复](backup.md) · [部署安全](deployment_security.md)

> 所有命令默认在**项目根目录**执行。SQLite 相对路径（如 `sqlite:///./data/heartlog.db`、`./backups`）是相对于**当前工作目录**解析的，换目录启动会指向不同文件。

---

## 1. 环境准备

要求：Python ≥ 3.11。

```bash
# 通用环境
python -m venv .venv
source .venv/bin/activate            # Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt      # 生产/开发同一组固定版本依赖
```

下文命令用 `python` 表示你的解释器。

配置：复制 `env.example` 为 `.env`，按需修改 `HEARTLOG_*`（完整列表见 [README 配置章节](../README.md#配置)）。`.env` 已被 gitignore，**不要提交**。

---

## 2. 首次初始化

```bash
# 1) 建表 + 安装 SQLite 完整性触发器（必须）
python -m alembic upgrade head

# 2) 确认迁移版本
python -m alembic current

# 3) 启动
uvicorn "app.main:create_app" --factory --host 127.0.0.1 --port 8000
```

预期日志：`heartlog_start version=0.1.0 environment=local ai_enabled=False`。

健康检查与第一项数据：

```bash
curl -s http://127.0.0.1:8000/health
curl -s -X POST http://127.0.0.1:8000/api/v1/diaries \
  -H "Content-Type: application/json" \
  -d '{"content":"测试初始化成功"}'
```

如果响应 `201` 且包含 `original_text`/`current_revision`，说明初始化成功。随后可访问 <http://127.0.0.1:8000/docs>。

> ⚠️ **不要混用两条建表路径**：`HEARTLOG_AUTO_CREATE_SCHEMA=true`（默认）时应用启动会 `create_all()` 兜底建表，但不会写 `alembic_version`。若先用应用启动建了表，再执行 `alembic upgrade head` 会因表已存在而失败。固定流程：**新库先迁移，再启动**；或设 `HEARTLOG_AUTO_CREATE_SCHEMA=false` 完全依赖迁移。

---

## 3. 启动与停止

### 3.1 推荐：前台运行

```bash
uvicorn "app.main:create_app" --factory --host 127.0.0.1 --port 8000
```

- 必须使用 `--factory`（`create_app` 是工厂函数；模块导入本身不打开数据库）。
- 只监听 `127.0.0.1`，除非你明确需要并已阅读 [隐私文档的威胁模型](privacy.md#8-威胁模型)。
- 不要用 `uvicorn app.main:app`（没有模块级的 `app` 实例）。

### 3.2 停止（graceful shutdown）

- 前台运行：`Ctrl+C`（SIGINT）或向进程发送 SIGTERM，uvicorn 会等待当前请求结束再退出。
- 应用 lifespan 在退出时执行 `engine.dispose()` 并记录 `heartlog_stop`；SQLite 连接关闭时完成 WAL 的正常收尾。
- **不要在运行中直接复制/替换 `data/heartlog.db`**：WAL 模式下只拷主文件可能丢已提交事务。使用 §4 的备份脚本。
- 如果进程被 `kill -9`/强制结束：已提交数据仍在（WAL 会在下次打开时恢复），但可能残留 `-wal`/`-shm` sidecar；恢复脚本会因此拒绝覆盖，先正常启动一次让 SQLite 自行收尾更安全。

### 3.3 后台运行（可选，示例）

个人本机更推荐前台；若需后台：

```bash
nohup uvicorn "app.main:create_app" --factory --host 127.0.0.1 --port 8000 \
  >> data/uvicorn.log 2>&1 &
```

注意把 `uvicorn.log` 放到受控目录（它可能包含路径/错误信息；HeartLog 设计上不主动打印日记正文，但数据库异常 traceback 可能包含 SQL 语句/绑定参数），并按需做日志轮转。

---

## 4. 备份

> 产品化细节（加密格式、密钥管理、保留语义、调度器参数、恢复演练 CI 接入、退出码）见 [备份与恢复文档](backup.md)。本节只给运维视角的操作步骤。

### 4.1 创建备份（明文）

```bash
python scripts/backup.py
```

- 默认输出：`$HEARTLOG_BACKUP_DIR/heartlog-<UTC时间>.db`（默认 `backups/`）；
- 自定义路径：`python scripts/backup.py --output /path/to/heartlog-backup.db`（目标必须不存在，避免误覆盖）；
- 使用 SQLite 在线备份 API（服务运行中也可安全执行）；
- 完成后做 `PRAGMA integrity_check`，生成同名 `.sha256` 与 `.json` manifest。

本机临时库验证过的输出示例：

```
Backup created: .../backups/heartlog-20261029T072715Z.db
SHA-256: ee61...27c8
Manifest: .../backups/heartlog-20261029T072715Z.db.json
Rows: {'alembic_version': 1, 'audit_events': 1, 'diary_entries': 1, 'diary_revisions': 1, 'memories': 0, ...}
```

manifest 包含：`app_version`、`created_at`、源/目标路径、`sha256`、`size_bytes`、`integrity_check`、各表行数。**明文备份是完整数据库，请放入加密卷或改用加密备份。**

### 4.2 加密备份（推荐离开本机磁盘时使用）

```bash
# 口令只放进程环境变量（不要写进命令行、`.env` 或 git）
export HEARTLOG_BACKUP_PASSPHRASE="$(pass show heartlog/backup)"   # 示例
python scripts/backup.py --encrypt
# 输出 backups/heartlog-<UTC>.db.enc + .sha256 + .json
```

- AES-256-GCM + Scrypt 口令派生；**口令丢失 = 备份永久不可恢复**（无密钥托管/恢复码）；
- 口令也可以由 `--passphrase-env NAME` 指定其它环境变量名；备份脚本**直接读进程环境变量**，写进项目 `.env` 不会生效；
- 文件名/大小/行数/manifest 元数据仍可见（加密保护内容，不保护元数据）；
- 明文备份与加密备份可以并存；加密只对新备份生效。

### 4.3 保留策略

```bash
export HEARTLOG_BACKUP_PASSPHRASE='...'             # 加密时需先按 §4.2 设置口令
python scripts/backup.py --encrypt --retention 14   # 默认 14；0 = 不清理
```

- 只删除 HeartLog **自动命名**（`heartlog-YYYYmmddTHHMMSSZ.db[.enc]`）且 `.sha256`/manifest 自洽的旧备份；手动命名/未知文件永不自动删除；
- 本次新建的备份永远受保护；清理发生在备份成功之后；
- 保留策略只按文件名时间排序，**不理解删除/遗忘语义**——旧备份仍可能包含已删除数据。

### 4.4 定时备份

HeartLog 提供本地调度脚本（不依赖 APScheduler 等外部库）：

```bash
# 交给系统计划任务（推荐）：执行一次后退出
python scripts/backup_scheduler.py --once --encrypt --retention 14

# 或前台常驻循环（Ctrl+C/SIGTERM 优雅退出）
python scripts/backup_scheduler.py --interval-hours 6 --encrypt --retention 14
```

- `--once` 适合 cron / Windows 任务计划 / systemd timer；`--interval-hours H` 或 `--interval-seconds S` 二选一；
- `--encrypt` 但启动时口令缺失 → **立即退出码 2**，不会空转；循环中某次备份失败会记录并继续，最终退出码 1；
- 日志只含元数据（路径/是否加密/字节数/行数/清理数量/错误类型），不含日记内容或口令；
- cron / systemd timer / Windows 任务计划的具体示例（含口令注入的安全做法）见 [备份文档 §7](backup.md#7-定时备份-scriptsbackup_schedulerpy)。

### 4.5 备份频率建议

- 数据变更后/重要操作前（迁移、升级、启用 AI、批量删除/遗忘前）手动备份一次；
- 日常用 `backup_scheduler.py --once` + 系统计划任务（建议 6–24 小时一次），并配置 `--retention`；
- 每次备份后确认退出码为 0 且 `.sha256`/`.json` 同时生成；定期执行恢复演练（§4.6）。

### 4.6 校验与恢复演练

```bash
# 校验 SHA-256（若存在 .sha256）
sha256sum backups/heartlog-*.db          # 加密备份对应 *.db.enc
# 或
python -c "import hashlib,pathlib; p=pathlib.Path('backups/xxx.db'); print(hashlib.sha256(p.read_bytes()).hexdigest())"

# 只读恢复演练（推荐每次重要备份后 / 至少每月一次）
python scripts/restore_drill.py backups/heartlog-<UTC>.db.enc
python scripts/restore_drill.py backups/heartlog-<UTC>.db.enc --json
```

`scripts/restore.py` 在恢复前会自动校验 `.sha256`/manifest 与 `PRAGMA integrity_check`；演练**不会**写在线数据库，验证的是备份可读/可解密/业务不变量成立，**不等于已恢复**。

---

## 5. 恢复

**前提：停止 HeartLog 服务。** 恢复会替换 `HEARTLOG_DATABASE_URL` 指向的数据库文件。

```bash
# 1) 停止服务（Ctrl+C 或 SIGTERM），确认没有 sidecar 写入

# 2) 恢复（目标库已存在时必须 --force）
python scripts/restore.py /path/to/heartlog-backup.db --force

# 3) 重新校验完整性
python scripts/verify_integrity.py

# 4) 启动并抽查
uvicorn "app.main:create_app" --factory --host 127.0.0.1 --port 8000
curl -s "http://127.0.0.1:8000/api/v1/diaries?limit=1"
```

脚本行为（[`scripts/restore.py`](../scripts/restore.py)）：

1. 校验备份存在、`.sha256`/manifest（若存在；加密备份还校验加密标志一致）；加密备份先用口令解密到 staging；
2. 目标库存在且未加 `--force` → 拒绝；
3. 目标库存在时：若 `-wal`/`-shm` sidecar 非空 → 拒绝（说明数据库可能仍在使用，必须先停服务/检查点）；
4. 在目标数据库所在目录的 `backups/` 子目录生成 `pre-restore-<UTC>.db` 安全备份（注意：这是 `data/backups/`，与 `HEARTLOG_BACKUP_DIR` 的 `./backups/` 是两个位置）；
5. 解密/复制到 `.restore-tmp` → 再校验 integrity → 原子替换目标 → 清理空的 WAL/SHM sidecar → 打印提示。

**恢复加密备份**：

```bash
export HEARTLOG_BACKUP_PASSPHRASE='...'          # 与创建备份时相同
python scripts/restore.py backups/heartlog-<UTC>.db.enc --force
python scripts/verify_integrity.py
```

- 口令错误/密文损坏 → 退出码 2，**不会**覆盖现有数据库；
- 恢复后数据库回到备份时刻：备份之后发生的遗忘/删除会"消失"，恢复完成后如需遗忘历史数据需重新执行；
- 恢复后建议：确认数据（列表/搜索/完整性校验）、保留 pre-restore 安全备份一段时间、确认无误后再删除旧备份；如恢复的是旧备份，注意其中可能包含已遗忘/删除的内容。

---

## 6. 导出

```bash
# 方式 A：CLI（写 JSON 文件）
python scripts/export_data.py
python scripts/export_data.py --output /path/to/export.json
# 默认输出 <项目根>/exports/heartlog-export-<UTC>.json；拒绝覆盖已存在文件

# 方式 B：HTTP API（返回附件；会写 data.exported 审计事件）
curl -s http://127.0.0.1:8000/api/v1/export -o heartlog-export.json
```

导出内容与 `counts` 见 [API 文档导出章节](api.md#23-get-apiv1export)。导出是**明文完整数据**（含软删除日记、已撤回记忆、全部修订、审计），安全性详见 [隐私文档](privacy.md#5-备份导出与恢复的安全)。`exports/` 已被 gitignore，但请假定它可能被同步盘/备份软件带走。

---

## 7. 完整性校验

### 7.1 单条日记（在线）

```bash
curl -s http://127.0.0.1:8000/api/v1/diaries/<diary_id>/integrity
```

`original_text_matches_hash=true`、`revision_chain_valid=true`、`issues=[]` 表示正常。异常 code 含义见 [API 文档](api.md#37-get-apiv1diariesdiary_idintegrity--完整性校验)。

### 7.2 全库（离线脚本）

```bash
python scripts/verify_integrity.py
echo "exit=$?"
```

检查内容：所有日记的原文哈希/修订链/指针；所有记忆是否有证据来源、主来源是否在来源列表、来源修订是否存在且属于同一日记、证据是否为修订精确子串、offset 是否匹配。

输出只含 ID 与 code，不打印日记正文；**发现问题时退出码非 0**。正常输出示例：

```
Checked diaries and memories. Issues: 0
```

校验脚本只读，不改数据；发现问题时不要反复运行期待自愈，应从可信备份恢复或人工分析。

---

## 8. 密钥与令牌轮换

HeartLog 的密钥/令牌全部来自环境变量或 `.env`，**修改后需要重启进程**（配置在启动时加载，无热更新）；唯一的例外是备份口令：它由备份/恢复脚本从**进程环境变量**直接读取（不经过 Settings），改动只影响之后运行的脚本。

| 密钥 | 轮换步骤 |
| --- | --- |
| `HEARTLOG_API_TOKEN` | 1) 生成新随机值；2) 更新 `.env`；3) 重启服务；4) 更新所有客户端（curl 脚本、Swagger 中的 Authorization）；5) 旧值立即失效。 |
| `HEARTLOG_ADMIN_TOKEN` | 同上。注意：若不设置该变量，**永久删除会整体禁用**（这是安全的默认值）。 |
| `HEARTLOG_AI_API_KEY` | 1) 在 provider 侧创建新 key；2) 更新 `.env`；3) 重启服务；4) 确认 `GET /health` 的 `ai_ready`；5) 在 provider 侧吊销旧 key。 |
| `HEARTLOG_BACKUP_PASSPHRASE`（备份口令） | 1) 用**新口令**重新执行一次 `backup.py --encrypt`；2) 用新口令 `restore_drill.py` 验证；3) 旧加密备份在按保留策略清理前仍需旧口令；4) 不要把新旧口令同时写在同一个地方。**口令丢失 = 旧加密备份永久不可恢复**，轮换不会让已泄露的旧密文重新安全。 |
| AI `BASE_URL`/`MODEL`/provider | 修改 `.env` → 重启 → 用 `GET /health` 确认 `ai_ready`，并做一次最小功能验证（见 §10.3）。 |

注意：

- 密钥不要写进 shell 历史/脚本/聊天记录；使用密码管理器生成；
- `.env` 与数据库权限按最小化原则设置；备份/导出中**不含**这些密钥（导出服务显式排除配置；备份口令不写入备份/manifest/日志）；
- 如果怀疑泄漏：先轮换/吊销，再排查日志与备份副本；
- 当前没有数据库级加密，Token 轮换不改变已落盘的明文数据；备份口令轮换也不改变旧备份的机密性。

---

## 9. 部署安全、限流与 TLS

HeartLog 默认是**本机单用户服务**；只有需要从其他机器访问时才涉及本节内容。完整参考配置与威胁模型见 [部署安全指南](deployment_security.md)，这里只列运维要点。

### 9.1 应用内限流

```dotenv
# .env / systemd EnvironmentFile（默认关闭，打开后生效）
HEARTLOG_RATE_LIMIT_ENABLED=true
HEARTLOG_RATE_LIMIT_REQUESTS=240
HEARTLOG_RATE_LIMIT_WINDOW_SECONDS=60
# 仅当反向代理覆盖写 X-Forwarded-For 时开启
HEARTLOG_TRUST_PROXY_HEADERS=true
```

- 作用范围：`/api/v1` 前缀；`/health`、`/docs`、`/openapi.json` 等默认免限流（`HEARTLOG_RATE_LIMIT_EXEMPT_PATHS`）；
- 超限：`429 rate_limited` + `Retry-After` / `X-RateLimit-Limit/Remaining/Reset`；429 仍带 `X-Request-ID` 并进入访问日志；
- 进程内实现：重启清零、多 worker 各自计数；公网部署必须同时在代理层做限流（`deploy/nginx.conf` 的 `limit_req` 示例）；
- **`X-Forwarded-For` 默认不信任**：只在可信代理**覆盖写**该头时才开启 `HEARTLOG_TRUST_PROXY_HEADERS`；
- 快速验证：`HEARTLOG_RATE_LIMIT_ENABLED=true HEARTLOG_RATE_LIMIT_REQUESTS=3` 启动临时实例，连续请求应得到 `200 200 200 429`。

### 9.2 TLS 与反向代理

推荐形态：**uvicorn 只监听 `127.0.0.1:8000`，由 Nginx/Caddy 终止 TLS + 认证 + 代理层限流**。

```bash
# 仅本机 HTTPS（开发/自签证书）：
python scripts/generate_dev_cert.py
python -m uvicorn "app.main:create_app" --factory --host 127.0.0.1 --port 8443 \
  --ssl-keyfile certs/localhost.key --ssl-certfile certs/localhost.crt

# 生产：参考 deploy/nginx.conf / deploy/Caddyfile（域名、证书、阈值均为占位值）
#   nginx -t / caddy validate → reload 前必须按实际环境修改
```

- **不要**把 uvicorn 直接绑定 `0.0.0.0` 暴露到公网；应用没有登录会话/多用户隔离/CSRF 防护；
- 参考配置**未在真实 Nginx/Caddy/systemd 环境联调**，上线前必须自行验证 TLS 握手、401/403/429、日志脱敏与 `/docs` 隐藏；
- 生产环境设置 `HEARTLOG_ENVIRONMENT=production` 后启动会输出 `deployment_security` 告警（缺失令牌/未限流等），执行 `journalctl -u heartlog | grep deployment_security` 核对。

### 9.3 OS 权限与 systemd

- 数据/备份/导出目录权限最小化：`python scripts/harden_permissions.py`（默认 dry-run）→ 确认后 `--apply`；Windows 用 `icacls`（脚本会提示/执行同语义命令）；
- Linux 常驻参考 [`deploy/heartlog.service`](../deploy/heartlog.service)（专用用户、`UMask=0077`、`StateDirectory`、systemd 加固项）；安装步骤见 [部署安全指南 §6](deployment_security.md#6-systemd-常驻linux)；
- 日志进 journald/stdout，路径与异常栈仍可能敏感：限制 `journalctl`/日志文件访问并配置轮转。

---

## 10. AI 的开启、验证与关闭

### 10.1 如何判断当前状态

```bash
curl -s http://127.0.0.1:8000/health
```

| 字段组合 | 含义 |
| --- | --- |
| `ai_enabled=false`, `ai_ready=false` | **默认/关闭**：不会调用任何模型 |
| `ai_enabled=true`, `ai_ready=false` | 开关打开但 provider 未完整配置（如 `AI_PROVIDER=disabled` 或缺少 key）→ AI 功能仍不可用；记忆提取会 503 |
| `ai_enabled=true`, `ai_ready=true` | provider 已构建；`openai_compatible` 会联网，`mock` 不会联网 |

### 10.2 启用真实 AI（谨慎）

先在 `.env` 中设置：

```dotenv
HEARTLOG_AI_ENABLED=true
HEARTLOG_AI_CONSENT=true
HEARTLOG_AI_PROVIDER=openai_compatible
HEARTLOG_AI_BASE_URL=https://your-provider.example/v1
HEARTLOG_AI_MODEL=your-model-name
HEARTLOG_AI_API_KEY=your-api-key
HEARTLOG_AI_TIMEOUT_SECONDS=60
```

重启，确认 `GET /health` 的 `ai_enabled=true` 且 `ai_ready=true`。**启用前请完整阅读 [隐私文档](../docs/privacy.md) 的"什么情况下会发送数据"**，确认 provider 的保留/训练政策可接受。

> 若 `HEARTLOG_AI_ENABLED=true` 但 `HEARTLOG_AI_CONSENT=false`，应用**拒绝启动**（防止被隐式开启）。

### 10.3 安全的冒烟测试：mock provider（不联网）

在真正指向外部 provider 前，可以先用 `mock` 验证链路：

```dotenv
HEARTLOG_AI_ENABLED=true
HEARTLOG_AI_CONSENT=true
HEARTLOG_AI_PROVIDER=mock
```

重启后：

- `GET /health` → `ai_ready=true`；
- `POST /api/v1/conversations/{id}/messages` → `200`，`mode="ai"`，但文案明确标注"本地 mock 提供方"，且没有外部请求；
- `POST /api/v1/memories/extract` → `200`，但 mock 提取返回**空候选**（不编造记忆），于是 `created_count=0`；
- `GET /api/v1/insights/weekly` → `mode="ai"`，文案明确说明是本地 mock。

`mock` 只用于验证接口与页面链路，**不代表真实模型质量**。

### 10.4 关闭 AI

将 `HEARTLOG_AI_ENABLED=false`（或直接删除 AI 配置）并重启。随后：

- 记忆提取 → `503 ai_not_configured`（不写数据）；
- 对话 → `200` + `placeholder` 占位回复；
- 回顾 → `200` + `local_statistics`；
- 不会创建 provider、不会发起外部请求。

已存在的记忆/对话/回顾数据不受影响。

### 10.5 各端点 AI 状态速查

| 端点 | AI 关闭 | AI 开启但失败 | AI 正常 |
| --- | --- | --- | --- |
| `POST /memories/extract` | 503，不写 | 502/503，不写 | 200 + pending 记忆 |
| `POST /conversations/{id}/messages` | 200 placeholder | 502/503（用户消息已存，无伪造回复） | 200 ai + citations |
| `GET /insights/*` | 200 local_statistics | 降级 200 local_statistics | 200 ai |
| `GET /health` | enabled/ready 均为 false | enabled=true, ready=true（provider 已配置） | 同左 |

---

## 11. 故障排查

| 现象 | 可能原因 | 处理 |
| --- | --- | --- |
| `401 unauthorized` | 设置了 `HEARTLOG_API_TOKEN` 但请求未带/带错 Bearer | 加 `Authorization: Bearer <token>`；确认没有多余空格 |
| `403 admin_disabled` | `HEARTLOG_ADMIN_TOKEN` 未设置，**日记物理删除**被禁用（记忆/人物遗忘不受影响） | 如确需物理删除日记，显式设置管理员令牌并重启 |
| `403 admin_required` | 已设置管理员令牌但 `X-Admin-Token` 缺失/错误 | 检查头名称与值 |
| `422 confirmation_required` | 永久删除/遗忘缺少或错误的确认头 | 日记：`X-Confirm-Permanent-Delete`；记忆：`X-Confirm-Memory-Delete`；人物：`X-Confirm-Person-Delete`。值可为实体 ID / `"true"` / `"confirm"` |
| `409 entry_has_references` | 日记被记忆/记忆来源/人物引用 | v0.2 起可解除：`GET /diaries/{id}/references` 看计数 → 对引用记忆 `DELETE /memories/{id}?mode=purge`（确认头）→ 对人物 `DELETE /persons/{id}`（确认头）→ 计数归零后重试物理删除。**revoke 不会解除引用**；仅软删除也不行 |
| `429 rate_limited` | 应用内限流触发 | 见响应 `Retry-After` / `X-RateLimit-*`；确认是否误开多重限流（代理 + 应用）；必要时调高 `HEARTLOG_RATE_LIMIT_REQUESTS` 或关闭 `HEARTLOG_RATE_LIMIT_ENABLED` |
| 所有人同时 429 / IP 相同 | `HEARTLOG_TRUST_PROXY_HEADERS` 与代理 XFF 配置不匹配 | 代理必须**覆盖写** `X-Forwarded-For`（如 Nginx `$remote_addr`）；否则关闭 `trust_proxy_headers` |
| `409 version_conflict` | `expected_version` 过期、并发写入或陈旧读快照 | 重新 `GET` 日记，用最新 `current_version` 重试 |
| `422 validation_error` | 字段缺失/类型/长度/未知字段/非法 `mode` | 看 `error.details.fields`；注意 `extra="forbid"`；遗忘 `mode` 只能是 `purge`/`anonymize` |
| `503 ai_not_configured` | AI 未启用/未配置 | 见 §10；不需要 AI 时这是预期行为 |
| `502 ai_service_error` / `ai_invalid_response` | provider 超时/HTTP 错误/输出不合 schema | 检查 base URL、key、模型名、网络；**不会写入半成品数据** |
| `500 database_error` | 数据库异常（锁、约束、磁盘） | 查看服务日志中的异常类型；检查磁盘空间/权限/是否并发写入 |
| `unable to open database file` | 启动目录不对（相对路径）、目录不存在/无权限 | 在项目根启动；检查 `HEARTLOG_DATABASE_URL` 与 `data/` 目录权限 |
| `database is locked` | 长时间写事务/其他进程占用 | 确认没有第二个实例；避免运行中直接操作数据库；重启让 WAL 收尾 |
| `alembic upgrade` 报 "table ... already exists" | 混用了 `create_all` 建表路径 | 用全新库或先备份后人工对齐；固定流程见 §2 |
| `restore.py` 报 "Active SQLite sidecar found" | 服务未停/仍有 WAL 写入 | 停止服务；必要时正常启动一次再停，确认 sidecar 收尾 |
| `restore.py` 报 "Target database exists" | 目标库存在但未加 `--force` | 确认要覆盖后加 `--force`；先确保已停服务 |
| `backup.py` 报 "Refusing to overwrite existing backup" | 目标已存在（含同一秒重名） | 换路径、稍后重试或使用 `--output` |
| 加密备份报 "Backup passphrase is not set" / "Failed to decrypt backup" | 未设置/错误口令，或文件损坏 | 口令必须放**进程环境变量**（不是 `.env`）；确认备份文件未被修改，用 `.sha256` 校验 |
| `--retention` 没删除旧备份 | 文件名不是自动命名 / sidecar 损坏 / 未超过 N | 属预期保护；查看 warning 日志后人工确认删除 |
| `restore_drill.py` 报 checksum/decryption/业务不变量错误 | 备份损坏/口令错误/数据不一致 | 不要用它恢复覆盖现网；换其它备份并复验 |
| 端口被占用 | 另一个实例在运行 | 换端口或停止旧进程 |
| `/docs` 打不开且无外网 | Swagger UI 从 CDN 加载静态资源 | 属预期；可直接用 `/openapi.json` 或本地化静态资源（当前未提供） |

查看日志：前台运行时直接看 stdout/stderr；后台运行时看重定向文件（如 `data/uvicorn.log`）。HeartLog 自身日志不主动记录日记正文、query string 或请求体；数据库异常处理器只记录异常类名（不记录 SQL/绑定参数/traceback 文本），但**未处理异常**的中间件仍会记录 Python traceback（内容取决于异常类型）。日志文件应按敏感数据保护。备份/限流/部署问题的更完整排查表见 [备份文档 §11](backup.md#11-常见问题排查) 与 [部署安全指南 §15](deployment_security.md#15-故障排查)。

---

## 12. 测试

测试使用 `tmp_path` 临时 SQLite，不会触碰 `data/heartlog.db`，也不会调用外部 AI。

```bash
# 通用环境
pytest -q                       # 全部测试
pytest tests/test_diaries.py -q # 单文件
pytest -q -k "memory"           # 关键字筛选
pytest --collect-only -q        # 只收集，不执行
```

v0.2 增量对应的测试文件：`tests/test_forgetting.py`（遗忘/派生可见性/解除阻塞）、`tests/test_backup_productization.py`（加密/保留/调度/恢复/演练）、`tests/test_rate_limit.py`（限流与部署告警）；其余为既有功能测试。

> 测试数量会随迭代变化；以仓库当前实际运行结果为准。

单独验证迁移（临时库，不碰真实数据）：

```bash
HEARTLOG_DATABASE_URL="sqlite:///$(mktemp -d)/mig.db" python -m alembic upgrade head
```

v0.2 增量**不需要新迁移**：遗忘/可见性/限流/备份都在既有 schema 与文件层实现（见 [数据库设计 §7](database_design.md#7-迁移工作流)）。

---

## 13. 安全操作清单

- [ ] 服务只监听 `127.0.0.1`（或已部署在受控反向代理之后）；**不要**把 uvicorn 直接绑定 `0.0.0.0` 暴露到公网。
- [ ] 设置 `HEARTLOG_API_TOKEN`；需要物理删除时再设置 `HEARTLOG_ADMIN_TOKEN`。
- [ ] 有网络暴露时：反向代理终止 TLS + 代理层限流 + 应用内限流；参考配置需自行验证（未联调）。
- [ ] `.env`、`data/`、`backups/`、`exports/`、`certs/` 权限最小化（可先 dry-run `scripts/harden_permissions.py`）；磁盘开启全盘加密。
- [ ] 迁移/升级/启用 AI/批量删除前先执行一次 `backup.py`（离开本机磁盘的备份用 `--encrypt`）。
- [ ] 定期（建议 6–24 小时）用 `backup_scheduler.py --once` + 计划任务备份，并配置保留策略。
- [ ] 定期做恢复演练（`restore_drill.py`）并接入你能看到的告警；只备份不演练 = 没有备份。
- [ ] 定期运行 `verify_integrity.py`，退出码非 0 时按 §7 处理。
- [ ] 备份/导出加密后再移动；不要把明文文件放进公共同步目录；加密备份口令由密码管理器保管。
- [ ] 不需要 AI 时保持关闭；开启前阅读隐私文档并确认 provider 条款。
- [ ] 怀疑密钥/备份口令泄漏时立即轮换（§8）并检查备份/日志副本。
- [ ] 升级代码/依赖前备份数据库，升级后跑迁移 + 冒烟测试（健康检查 + 创建/读取一条日记）。
- [ ] 删除/遗忘数据时同步处理历史备份/导出（HeartLog 不会自动清理旧备份，也不会让备份"遗忘"）。
