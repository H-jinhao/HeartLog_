# HeartLog API 参考

本文档描述当前版本 `0.1.0` 已实现的 HTTP API（含本轮 v0.2 增量：记忆/人物遗忘、日记引用检查、派生数据默认隐藏、429 限流响应），并给出基于真实运行（临时数据库）的请求/响应示例。**当文档与代码/OpenAPI 不一致时，以代码与 `/openapi.json` 为准。**

相关文档：[README](../README.md) · [架构](architecture.md) · [数据库设计](database_design.md) · [隐私](privacy.md) · [运维](operations.md) · [备份与恢复](backup.md) · [部署安全](deployment_security.md)

---

## 1. 基础约定

| 项目 | 值 |
| --- | --- |
| Base URL | `http://127.0.0.1:8000`（按实际启动参数） |
| 版本前缀 | `/api/v1`（`HEARTLOG_API_V1_PREFIX` 可改） |
| 数据格式 | JSON（`Content-Type: application/json`）；导出接口返回 `application/json; charset=utf-8` 附件 |
| 文档 | `GET /docs`（Swagger UI）、`GET /redoc`、`GET /openapi.json` |
| 健康检查 | `GET /health`（无需认证） |
| 请求 ID | 服务端回写 `X-Request-ID`；客户端可自带该头，否则生成 UUID |
| 时间格式 | ISO 8601 UTC，例如 `"2026-10-29T07:26:29.212607Z"` |
| ID 格式 | UUID 字符串（`String(36)`） |
| 字符集 | UTF-8；`ensure_ascii=False` 输出中文原文 |

### 1.1 认证（可选）

| 请求头 | 何时需要 | 说明 |
| --- | --- | --- |
| `Authorization: Bearer <api_token>` | 设置了 `HEARTLOG_API_TOKEN` 时，**所有 `/api/v1/*` 请求**都必需 | 常量时间比较；缺失/错误 → `401 unauthorized` |
| `X-Admin-Token: <admin_token>` | 设置了 `HEARTLOG_ADMIN_TOKEN` 时的**日记物理删除**操作 | 未设置管理员令牌时日记物理删除整体禁用（`403 admin_disabled`） |
| `X-Confirm-Permanent-Delete: <diary_id>` / `"true"` / `"confirm"` | 日记物理删除操作 | 缺失/不匹配 → `422 confirmation_required` |
| `X-Confirm-Memory-Delete: <memory_id>` / `"true"` / `"confirm"` | `DELETE /api/v1/memories/{memory_id}`（遗忘） | 缺失/不匹配 → `422 confirmation_required`；**不需要** `HEARTLOG_ADMIN_TOKEN` |
| `X-Confirm-Person-Delete: <person_id>` / `"true"` / `"confirm"` | `DELETE /api/v1/persons/{person_id}`（遗忘） | 缺失/不匹配 → `422 confirmation_required`；**不需要** `HEARTLOG_ADMIN_TOKEN` |

无需认证的端点：`GET /`、`GET /health`、`GET /docs`、`GET /redoc`、`GET /openapi.json`。设置 API Token 后，Swagger UI 中调用接口需要手动添加 Authorization 头（页面本身不提供登录）。

### 1.2 错误模型

所有非 2xx 响应（业务错误、校验错误、HTTP 错误、数据库错误）统一为：

```json
{
  "error": {
    "code": "版本冲突的稳定错误码",
    "message": "Human-readable message (usually English)",
    "details": {}
  }
}
```

状态码与通用错误码：

| HTTP | `code` | 含义 |
| --- | --- | --- |
| 400 | `bad_request` | `AppError` 基类默认（当前业务路径很少直接使用） |
| 401 | `unauthorized` | 缺少/错误 Bearer Token |
| 403 | `forbidden` / `admin_disabled` / `admin_required` | 权限不足；日记物理删除未启用；缺少/错误管理员令牌 |
| 404 | `not_found` / `revision_missing` / `revision_not_found` | 资源不存在 |
| 409 | `conflict` / `version_conflict` / `not_deleted` / `entry_has_references` / `protected_record` / `invalid_state_transition` / `already_confirmed` / `already_revoked` / `duplicate_memory` / `missing_sources` / `invalid_source_evidence` / `source_integrity_error` / `missing_revision` / `diary_deleted` | 状态/并发/不可变/引用冲突 |
| 422 | `validation_error` / `confirmation_required` / `no_valid_candidates` / `revision_mismatch` / `content_too_long` / `correction_unchanged` | 请求或业务校验失败 |
| 429 | `rate_limited` | 应用内限流触发（仅当 `HEARTLOG_RATE_LIMIT_ENABLED=true`；响应头见 §1.6） |
| 500 | `database_error` / `export_failed` | 服务端错误（不泄露 SQL） |
| 502 | `ai_invalid_response` / `ai_service_error` | AI 返回不可用/不可解析，未写入数据 |
| 503 | `ai_not_configured` / `ai_prompt_missing` | AI 未启用/未配置，或提示词缺失 |
| 任意 | `http_error` | Starlette/FastAPI 层 HTTP 错误（404 路由不存在、405 等） |

校验错误（422）不回显原始输入值，只给出字段位置、原因和类型：

```json
{
  "error": {
    "code": "validation_error",
    "message": "Request validation failed",
    "details": {
      "fields": [
        {"loc": "body.content", "msg": "String should have at least 1 character", "type": "string_too_short"}
      ]
    }
  }
}
```

### 1.3 分页

通用分页响应（日记、记忆、人物）：

```json
{"items": [], "total": 0, "limit": 20, "offset": 0, "has_more": false}
```

- `limit` 缺省为 `HEARTLOG_DEFAULT_PAGE_SIZE`（默认 20）；
- 服务层会把 `limit` 收紧到 `min(limit, HEARTLOG_MAX_PAGE_SIZE)`（默认 100）；
- `has_more = offset + len(items) < total`；
- 搜索接口的响应字段略有不同（多 `query`/`scope`/`include_history`/`include_deleted_sources`），见 §5。

### 1.4 枚举

| 枚举 | 值 |
| --- | --- |
| `memory_type` | `explicit_fact` / `subjective_feeling` / `explicit_belief` / `model_inference` |
| `verification_status` | `pending` / `confirmed` / `superseded` / `revoked` |
| `source_type` | `diary_entry` / `user_correction` / `import` |
| `created_by` / `confirmed_by` | `user` / `model` / `import` |
| `role` | `user` / `assistant` / `system` |
| `mode`（消息） | `ai` / `placeholder` |
| `mode`（回顾） | `ai` / `local_statistics` |

不传或传错枚举值 → FastAPI 422 `validation_error`。

### 1.5 端点总览

| 方法与路径 | 说明 |
| --- | --- |
| `GET /` | 应用信息（无需认证） |
| `GET /health` | 健康检查（无需认证） |
| `POST /api/v1/diaries` | 创建日记 + 第 1 版修订 |
| `GET /api/v1/diaries` | 列出未删除日记（分页/关键词/日期过滤） |
| `GET /api/v1/diaries/{diary_id}` | 读取单条日记（原文 + 当前内容 + 当前修订） |
| `PUT /api/v1/diaries/{diary_id}` | 追加一个新修订（原文不变） |
| `GET /api/v1/diaries/{diary_id}/revisions` | 全部修订历史 |
| `GET /api/v1/diaries/{diary_id}/revisions/{version}` | 指定版本修订 |
| `GET /api/v1/diaries/{diary_id}/integrity` | 校验原文哈希与修订哈希链 |
| `GET /api/v1/diaries/{diary_id}/references` | 引用计数：哪些记忆/证据/人物阻塞日记物理删除 |
| `DELETE /api/v1/diaries/{diary_id}` | 软删除（可恢复） |
| `POST /api/v1/diaries/{diary_id}/restore` | 恢复软删除日记 |
| `DELETE /api/v1/diaries/{diary_id}/permanent` | 物理删除（管理员 + 确认头 + 无引用） |
| `POST /api/v1/memories/extract` | 从精确修订中提取候选记忆（需 AI） |
| `GET /api/v1/memories` | 列出记忆（默认仅活跃；默认隐藏已软删除日记的派生记忆） |
| `GET /api/v1/memories/{memory_id}` | 记忆详情（含来源证据） |
| `GET /api/v1/memories/{memory_id}/sources` | 记忆的证据来源列表 |
| `POST /api/v1/memories/{memory_id}/confirm` | 用户确认（pending → confirmed） |
| `POST /api/v1/memories/{memory_id}/correct` | 创建更正（新记忆取代旧记忆） |
| `POST /api/v1/memories/{memory_id}/revoke` | 撤回记忆 |
| `DELETE /api/v1/memories/{memory_id}` | 遗忘：purge/anonymize 删除记忆与全部证据（确认头） |
| `GET /api/v1/search` | 关键词搜索（日记修订 + 活跃记忆；默认隐藏软删除日记的派生记忆） |
| `POST /api/v1/persons` | 创建人物（必须带来源） |
| `GET /api/v1/persons` | 列出人物（默认隐藏已软删除日记的来源人物） |
| `GET /api/v1/persons/{person_id}` | 人物详情 |
| `GET /api/v1/persons/{person_id}/timeline` | 字面提及时间线（不合并身份） |
| `DELETE /api/v1/persons/{person_id}` | 遗忘：永久删除人物行（确认头） |
| `POST /api/v1/conversations` | 创建对话 |
| `GET /api/v1/conversations/{conversation_id}` | 对话详情（含消息） |
| `POST /api/v1/conversations/{conversation_id}/messages` | 发送消息并获取回复（AI 或占位） |
| `GET /api/v1/insights/weekly` | 周回顾（AI 或本地统计） |
| `GET /api/v1/insights/monthly` | 月回顾（AI 或本地统计） |
| `GET /api/v1/export` | 全量 JSON 导出 |

### 1.6 限流（429）

应用内限流**默认关闭**；在 `.env`/环境变量中设置 `HEARTLOG_RATE_LIMIT_ENABLED=true` 后，`/api/v1` 前缀下的请求按客户端 IP 做滑动窗口计数（模型见 [`app/core/rate_limit.py`](../app/core/rate_limit.py)）。超限时返回 `429`，不执行业务逻辑：

```json
{
  "error": {
    "code": "rate_limited",
    "message": "Too many requests. Please retry later.",
    "details": {"limit": 3, "window_seconds": 60, "retry_after_seconds": 17}
  }
}
```

响应头（**仅 429 响应**携带；正常响应不带这些头）：

| 响应头 | 说明 |
| --- | --- |
| `Retry-After` | 建议等待的整秒数（≥1） |
| `X-RateLimit-Limit` | 当前窗口允许的请求数 |
| `X-RateLimit-Remaining` | 固定为 `0` |
| `X-RateLimit-Reset` | 窗口内最早请求过期前的整秒数 |

行为与配置：

- 只作用于 `<HEARTLOG_API_V1_PREFIX>`（默认 `/api/v1`）下的路径；`/health`、`/docs`、`/redoc`、`/openapi.json` 等默认免限流（`HEARTLOG_RATE_LIMIT_EXEMPT_PATHS`，逗号分隔前缀）；
- 限流在鉴权之前执行：**即使请求未带/带错 Bearer Token 也会计数**；429 响应仍会经过 request-id / 隐私响应头 / 访问日志中间件（带 `X-Request-ID`）；
- 窗口内被拒绝的请求不会延长窗口；配置：`HEARTLOG_RATE_LIMIT_REQUESTS`（默认 240）、`HEARTLOG_RATE_LIMIT_WINDOW_SECONDS`（默认 60）、`HEARTLOG_TRUST_PROXY_HEADERS`（默认 `false`）；
- `HEARTLOG_TRUST_PROXY_HEADERS=true` 时，限流键取 `X-Forwarded-For` 的**第一跳**（只在反向代理**覆盖写**该头时安全）；默认忽略客户端提供的转发头，使用 TCP 对端地址；
- 进程内实现：每个 uvicorn worker 各自计数、重启清零；公网部署应同时使用代理层限流/ CDN/WAF。完整部署建议见 [部署安全指南](deployment_security.md#9-限流应用内)。

---

## 2. 系统端点

### 2.1 `GET /`

无需认证。返回应用名、版本与入口。

```json
{
  "app": "HeartLog",
  "version": "0.1.0",
  "docs": "/docs",
  "health": "/health",
  "api": "/api/v1"
}
```

### 2.2 `GET /health`

无需认证（即使设置了 API Token）。`ai_ready` 表示 AI provider 是否完整配置（不是"服务可用"）。

```json
{
  "status": "ok",
  "app": "HeartLog",
  "version": "0.1.0",
  "environment": "local",
  "database": "ok",
  "ai_enabled": false,
  "ai_ready": false,
  "time": "2026-10-29T07:26:29.169816Z"
}
```

| 字段 | 说明 |
| --- | --- |
| `status` | `ok` 或 `degraded`（数据库 `SELECT 1` 失败时） |
| `database` | `ok` / `error` |
| `ai_enabled` | 配置中的 `HEARTLOG_AI_ENABLED` |
| `ai_ready` | `settings.ai_configured and provider is not None` |

`GET /health` 不会调用外部 AI；只检查数据库连通性与配置状态。

### 2.3 `GET /api/v1/export`

导出全部用户数据（JSON 附件；`Cache-Control: no-store`；`Content-Disposition: attachment; filename="heartlog-export-<UTC时间戳>.json"`）。导出动作本身会写一条 `data.exported` 审计事件（在响应生成前提交）。

响应顶层字段：

```json
{
  "schema_version": "heartlog.export.v1",
  "app_version": "0.1.0",
  "exported_at": "2026-10-29T07:26:29.511698Z",
  "note": "This archive contains private diary data. Store and transfer it securely. ...",
  "counts": {
    "diaries": 1, "revisions": 2, "memories": 0, "memory_sources": 0,
    "persons": 1, "conversations": 1, "audit_events": 3
  },
  "diaries": [
    {
      "id": "a3e4448f-3975-4c06-ab5f-f00f445335af",
      "original_text": "今天她还是没有回复，我有点失落。",
      "original_content_hash": "91c0...55e1",
      "current_version": 2,
      "current_revision_id": "ea15...d7b6",
      "metadata": {"mood": "低"},
      "created_at": "2026-10-29T07:26:29.212607Z",
      "updated_at": "2026-10-29T07:26:29.240664Z",
      "deleted_at": null,
      "revisions": [
        {
          "id": "fcba...ecec", "version": 1,
          "content": "今天她还是没有回复，我有点失落。",
          "content_hash": "91c0...55e1",
          "previous_revision_hash": null,
          "change_reason": "Initial version",
          "created_at": "2026-10-29T07:26:29.214607Z"
        }
      ]
    }
  ],
  "memories": [],
  "persons": [],
  "conversations": [],
  "audit_events": []
}
```

说明：

- 导出**包含**软删除的日记、已撤回/已取代的记忆（按数据库内容全量导出），这也是"你的数据"的一部分；
- 已被**遗忘**（purge/anonymize）的记忆、人物行已从数据库删除，**不会**出现在之后的导出中；但**更早的导出/备份文件仍包含旧数据**；
- 不包含配置、Token、API Key；`admin_token`/`api_key` 等字符串不会出现；
- 导出是明文 JSON，请自行加密存储（见 [隐私文档](privacy.md#5-备份导出与恢复的安全)）。

---

## 3. 日记 API

### 3.1 `POST /api/v1/diaries` — 创建日记

请求体：

| 字段 | 类型 | 必填 | 约束 |
| --- | --- | --- | --- |
| `content` | string | 是 | 1–50000 字符，且不能只有空白；**逐字符保存**（不 trim） |
| `metadata` | object | 否 | 任意 JSON 对象，默认 `{}` |

未知字段会因 `extra="forbid"` 被拒绝（422）。创建时服务层还会用 `HEARTLOG_MAX_DIARY_CHARS`（默认 50000）做二次校验，因此有效上限是两者较小值。

成功：`201 Created`，返回 `DiaryDetail`：

```json
{
  "id": "a3e4448f-3975-4c06-ab5f-f00f445335af",
  "original_text": "今天她还是没有回复，我有点失落。",
  "original_content_hash": "91c0d7690d45a16c9fe57f439ea1cf92258f652c3936bdbb6013e76b49bb55e1",
  "current_version": 1,
  "current_revision_id": "fcbaa38f-8af0-489c-9a40-c2a094d5ecec",
  "created_at": "2026-10-29T07:26:29.212607Z",
  "updated_at": "2026-10-29T07:26:29.218595Z",
  "deleted_at": null,
  "is_deleted": false,
  "metadata": {"mood": "低"},
  "current_content": "今天她还是没有回复，我有点失落。",
  "current_revision": {
    "id": "fcbaa38f-8af0-489c-9a40-c2a094d5ecec",
    "entry_id": "a3e4448f-3975-4c06-ab5f-f00f445335af",
    "version": 1,
    "content": "今天她还是没有回复，我有点失落。",
    "content_hash": "91c0d7690d45a16c9fe57f439ea1cf92258f652c3936bdbb6013e76b49bb55e1",
    "previous_revision_hash": null,
    "change_reason": "Initial version",
    "created_at": "2026-10-29T07:26:29.214607Z"
  }
}
```

| 错误 | 说明 |
| --- | --- |
| `422 validation_error` | 空/空白/超长 content、NUL/不支持的控制字符（允许 `\t`/`\n`/`\r`）、缺少 content、未知字段 |
| `401 unauthorized` | 启用了 API Token 但未带/带错 |

### 3.2 `GET /api/v1/diaries` — 列出日记

查询参数：

| 参数 | 类型 | 默认 | 说明 |
| --- | --- | --- | --- |
| `q` | string(≤200) | — | 关键词，匹配**当前修订内容或原文**（LIKE，`%`/`_` 被转义） |
| `date_from` | datetime | — | `created_at >= date_from`（自然时间） |
| `date_to` | datetime | — | `created_at <= date_to`（自然时间，含边界） |
| `limit` | int(1–500) | 配置默认 20 | 服务层再收紧到 `HEARTLOG_MAX_PAGE_SIZE`（默认 100） |
| `offset` | int(≥0) | 0 | |

成功：`200`，返回 `Page[DiaryListItem]`。`preview` / `original_preview` 会截断到 160 字符（超出为前 157 + `...`）：

```json
{
  "items": [
    {
      "id": "a3e4448f-3975-4c06-ab5f-f00f445335af",
      "preview": "今天她还是没有回复，我有点失落。后来我去散步了。",
      "original_preview": "今天她还是没有回复，我有点失落。",
      "current_version": 2,
      "created_at": "2026-10-29T07:26:29.212607Z",
      "updated_at": "2026-10-29T07:26:29.240664Z",
      "deleted_at": null,
      "is_deleted": false,
      "metadata": {"mood": "低"}
    }
  ],
  "total": 1,
  "limit": 20,
  "offset": 0,
  "has_more": false
}
```

软删除的日记不会出现在列表中。`date_from > date_to` → `422 validation_error`。

### 3.3 `GET /api/v1/diaries/{diary_id}` — 日记详情

成功：`200`，返回 `DiaryDetail`（结构同 §3.1）。软删除的日记返回 `404 not_found`。

```json
{"error": {"code": "not_found", "message": "Diary entry not found", "details": {"entry_id": "nope"}}}
```

### 3.4 `PUT /api/v1/diaries/{diary_id}` — 追加修订

请求体：

| 字段 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `content` | string | 是 | 新版本正文（1–50000，不能全空白） |
| `expected_version` | int(≥1) | 否 | 乐观并发保护；与当前 `current_version` 不符 → 409 |
| `change_reason` | string(≤500) | 否 | 编辑理由，存入新修订 |

成功：`200`，返回更新后的 `DiaryDetail`（`original_text` 不变，`current_version + 1`，`current_revision.previous_revision_hash` = 上一版 `content_hash`）。

```json
{
  "id": "a3e4448f-3975-4c06-ab5f-f00f445335af",
  "original_text": "今天她还是没有回复，我有点失落。",
  "original_content_hash": "91c0d7690d45a16c9fe57f439ea1cf92258f652c3936bdbb6013e76b49bb55e1",
  "current_version": 2,
  "current_revision_id": "ea157c58-9f6b-4e14-ba69-f167c9f7d7b6",
  "deleted_at": null,
  "is_deleted": false,
  "metadata": {"mood": "低"},
  "current_content": "今天她还是没有回复，我有点失落。后来我去散步了。",
  "current_revision": {
    "id": "ea157c58-9f6b-4e14-ba69-f167c9f7d7b6",
    "version": 2,
    "content": "今天她还是没有回复，我有点失落。后来我去散步了。",
    "content_hash": "4c5f6212f657cf8961309065e6676f3bab12f0ec6efe2bf7d4ddb8c2e410c46b",
    "previous_revision_hash": "91c0d7690d45a16c9fe57f439ea1cf92258f652c3936bdbb6013e76b49bb55e1",
    "change_reason": "补充后续",
    "created_at": "2026-10-29T07:26:29.240664Z"
  }
}
```

错误：

| 状态 | code | 说明 |
| --- | --- | --- |
| 404 | `not_found` | 日记不存在或已软删除 |
| 409 | `version_conflict` | `expected_version` 过期（details 含 `expected_version`/`current_version`），或并发唯一约束冲突 |
| 422 | `validation_error` | 内容非法/超长/未知字段 |

### 3.5 `GET /api/v1/diaries/{diary_id}/revisions` — 修订历史

成功：`200`：

```json
{
  "entry_id": "a3e4448f-3975-4c06-ab5f-f00f445335af",
  "total": 2,
  "versions": [
    {"id": "fcba...ecec", "entry_id": "a3e4...", "version": 1, "content": "第一版原文。",
     "content_hash": "91c0...", "previous_revision_hash": null,
     "change_reason": "Initial version", "created_at": "..."},
    {"id": "ea15...d7b6", "entry_id": "a3e4...", "version": 2, "content": "第二版内容。",
     "content_hash": "4c5f...", "previous_revision_hash": "91c0...",
     "change_reason": "补充后续", "created_at": "..."}
  ]
}
```

软删除日记返回 404。修订顺序按 version 升序。

### 3.6 `GET /api/v1/diaries/{diary_id}/revisions/{version}` — 单个修订

成功：`200`，返回单个 `RevisionOut`（字段同 `versions[]` 中元素）。日记不存在或版本不存在 → `404 not_found`；`version` 非整数 → 422。

### 3.7 `GET /api/v1/diaries/{diary_id}/integrity` — 完整性校验

成功：`200`：

```json
{
  "entry_id": "a3e4448f-3975-4c06-ab5f-f00f445335af",
  "original_text_matches_hash": true,
  "revision_chain_valid": true,
  "revisions_checked": 2,
  "issues": []
}
```

有问题时 `issues` 非空，可能的 `code`：

| code | 含义 |
| --- | --- |
| `original_hash_mismatch` | 原文与 `original_content_hash` 不一致 |
| `version_sequence_gap` | 修订版本号不连续 |
| `revision_hash_mismatch` | 修订内容与其哈希不一致 |
| `revision_chain_mismatch` | `previous_revision_hash` 与上一修订不一致 |
| `revision_count_mismatch` | 修订条数与 `current_version` 不一致 |
| `current_pointer_mismatch` | `current_revision_id` 未指向最后一条修订 |

注意：该端点只**报告**问题，不自动修复。

### 3.8 `DELETE /api/v1/diaries/{diary_id}` — 软删除

成功：`200`：

```json
{
  "id": "61e4be85-9354-43f4-919a-1042003a23ec",
  "deleted_at": "2026-10-29T07:26:29.599326Z",
  "message": "Soft-deleted. Revisions are retained and the entry can be restored."
}
```

软删除后：列表、详情、修订、搜索默认都看不到；数据与修订仍在数据库中。已删除再删 → `404`。

### 3.9 `POST /api/v1/diaries/{diary_id}/restore` — 恢复

成功：`200`，返回恢复后的 `DiaryDetail`（`deleted_at: null`）。

错误：日记不存在 → 404；日记本来未删除 → `409 not_deleted`。

### 3.10 `DELETE /api/v1/diaries/{diary_id}/permanent` — 物理删除（管理员）

头信息（全部必需，按顺序检查）：

1. `X-Admin-Token`: 必须等于 `HEARTLOG_ADMIN_TOKEN`；未配置该环境变量 → `403 admin_disabled`；缺失/错误 → `403 admin_required`；
2. `X-Confirm-Permanent-Delete`: 必须是日记 ID / `"true"` / `"confirm"`，否则 `422 confirmation_required`。

成功：`200`：

```json
{"deleted": true, "id": "235ed9bb-681c-4954-8e5d-33ca1c653461", "permanent": true}
```

被引用时（存在记忆、记忆来源、人物）→ `409 entry_has_references`，details 给出计数：

```json
{"error": {"code": "entry_has_references",
           "message": "This diary is referenced by memories or people and cannot be permanently deleted. ...",
           "details": {"memories": 0, "memory_sources": 0, "persons": 1}}}
```

该操作会级联删除修订；审计事件保留。**不存在撤销接口。**

**解除引用阻塞的推荐流程**（引用计数可先用 §3.11 的 `references` 查看；**revoke 不会解除引用**）：

1. `GET /api/v1/diaries/{diary_id}/references` 确认 `memories` / `memory_sources` / `persons` 计数；
2. 对每条引用该日记的记忆执行 `DELETE /api/v1/memories/{memory_id}?mode=purge|anonymize` + `X-Confirm-Memory-Delete`（删除记忆与全部证据行）；
3. 对每个引用该日记的人物执行 `DELETE /api/v1/persons/{person_id}` + `X-Confirm-Person-Delete`；
4. 再次查询 `references`，`can_permanently_delete=true` 后重试永久删除。

注意：永久删除**只删除日记与其修订**；已被遗忘的记忆/人物只剩无内容审计事件，不会被恢复。历史备份/导出仍可能保留旧内容（见 [隐私文档 §6](privacy.md#6-删除语义你删的到底是什么) 与 [备份文档 §12](backup.md#12-已知限制请纳入你的威胁模型)）。

### 3.11 `GET /api/v1/diaries/{diary_id}/references` — 引用计数 / 解除阻塞检查

无需管理员令牌；**软删除的日记也可查询**（用于在物理删除前检查是否仍被引用）。

成功：`200`：

```json
{
  "entry_id": "235ed9bb-681c-4954-8e5d-33ca1c653461",
  "is_deleted": true,
  "memories": 1,
  "memory_sources": 2,
  "persons": 1,
  "can_permanently_delete": false,
  "guidance": "Permanent diary deletion is blocked until all referencing memories and persons are purged. Memories can be deleted via DELETE /api/v1/memories/{id}; persons via DELETE /api/v1/persons/{id}. Revoking a memory does not remove its reference."
}
```

| 字段 | 说明 |
| --- | --- |
| `is_deleted` | 该日记当前是否已软删除 |
| `memories` | `memories.source_entry_id` 指向该日记的记忆行数 |
| `memory_sources` | `memory_sources.entry_id` 指向该日记的证据行数（任何把该日记作为证据来源的记忆都算，即使其主来源是别的日记） |
| `persons` | `persons.source_entry_id` 指向该日记的人物行数 |
| `can_permanently_delete` | 上述三个计数全部为 0 时为 `true` |

该端点只读、不写审计。日记不存在 → `404 not_found`（软删除不算不存在）。

---

## 4. 记忆 API

> AI 关闭时，`POST /memories/extract` 返回 503 且不写任何数据；其余读取/审核/遗忘端点不依赖 AI。
>
> **默认隐藏派生记忆**：来源日记被软删除后，该记忆在列表/详情/来源/搜索中默认不可见（可选 `include_deleted_sources=true`）。按 id 的定向操作（`confirm`/`correct`/`revoke`/`DELETE`）**仍然可用**，且遗忘操作会在删除记忆行时一并删除其全部证据来源。

### 4.1 `POST /api/v1/memories/extract` — 从精确修订提取候选记忆

请求体（`extra="forbid"`）：

| 字段 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `entry_id` | string(1–36) | 是 | 日记条目 ID |
| `revision_id` | string(1–36) | 否 | 指定修订；缺省用当前修订 |
| `version` | int(≥1) | 否 | 指定版本；与 `revision_id` 同时给出时必须一致 |

解析顺序：`revision_id` 优先；给了 `version` 会再校验两者一致；都没给用当前修订。提取永远针对**不可变修订内容**，且会先校验该修订的哈希完整性（不一致 → `409 source_integrity_error`）。

AI 未配置时：

```http
HTTP/1.1 503 Service Unavailable
```

```json
{"error": {"code": "ai_not_configured",
           "message": "Memory extraction requires a configured AI provider; nothing was saved.",
           "details": {"reason": "ai_not_configured"}}}
```

AI 可用且成功时（本示例使用进程内 fake AI 验证过字段形状；真实 provider 的候选由模型返回）：

```json
{
  "entry_id": "c82aa2ea-4af4-4b81-a64f-7a055cd9d229",
  "revision_id": "5cdc7ac4-e5be-4ead-8b63-39f15d45c181",
  "version": 1,
  "provider": "fake",
  "model": "fake-1",
  "candidate_count": 2,
  "created": [
    {
      "id": "53e39f09-32b0-4994-bdad-dbe4a612cb08",
      "content": "用户感到失落",
      "content_hash": "75862e...72b4",
      "memory_type": "subjective_feeling",
      "source_type": "diary_entry",
      "confidence": 0.9,
      "verification_status": "pending",
      "is_active": true,
      "created_by": "model",
      "confirmed_by": null,
      "confirmed_at": null,
      "revoked_at": null,
      "supersedes_memory_id": null,
      "source_entry_id": "c82aa2ea-4af4-4b81-a64f-7a055cd9d229",
      "source_revision_id": "5cdc7ac4-e5be-4ead-8b63-39f15d45c181",
      "source_version": 1,
      "source_entry_deleted": false,
      "created_at": "2026-10-29T07:26:43.987861Z",
      "updated_at": "2026-10-29T07:26:43.987861Z",
      "metadata": {
        "extraction": {
          "provider": "fake", "model": "fake-1",
          "revision_id": "5cdc7ac4-e5be-4ead-8b63-39f15d45c181",
          "revision_version": 1, "match_mode": "offsets"
        }
      },
      "sources": [
        {
          "id": "9cdbd095-1bce-42e4-a251-2fa3aec36c84",
          "memory_id": "53e39f09-32b0-4994-bdad-dbe4a612cb08",
          "entry_id": "c82aa2ea-4af4-4b81-a64f-7a055cd9d229",
          "revision_id": "5cdc7ac4-e5be-4ead-8b63-39f15d45c181",
          "evidence_text": "我有点失落",
          "start_offset": 10, "end_offset": 15,
          "created_at": "2026-10-29T07:26:43.990886Z"
        }
      ]
    }
  ],
  "rejected": [
    {"index": 1, "reason": "evidence_not_found",
     "message": "Evidence text is not an exact substring of the diary revision content.",
     "memory_type": "explicit_fact"}
  ],
  "created_count": 1,
  "rejected_count": 1
}
```

拒绝原因码：`content_blank`、`content_too_long`、`evidence_too_long`、`evidence_not_found`、`evidence_offset_mismatch`、`duplicate_memory`（见 [架构文档](architecture.md#6-记忆提取--审核流水线)）。`rejected` 不包含候选/日记正文。

其他错误：

| 状态 | code | 说明 |
| --- | --- | --- |
| 404 | `not_found` | entry 不存在 |
| 404 | `revision_not_found` | 指定 revision_id/version 不属于该 entry |
| 409 | `diary_deleted` | 日记已软删除，不能提取 |
| 409 | `source_integrity_error` | 来源修订哈希校验失败 |
| 409 | `missing_revision` | 日记没有任何修订（异常数据） |
| 422 | `revision_mismatch` | `revision_id` 与 `version` 指向不同修订 |
| 422 | `no_valid_candidates` | 有候选但全部未通过校验；整批不写（details 含 rejected 摘要，≤50 条） |
| 502 | `ai_invalid_response` / `ai_service_error` | 模型输出不可解析/超出 schema，或 provider 失败；不写数据 |
| 503 | `ai_not_configured` / `ai_prompt_missing` | AI 未启用/未配置提示词 |

### 4.2 `GET /api/v1/memories` — 列出记忆

查询参数：

| 参数 | 类型 | 默认 | 说明 |
| --- | --- | --- | --- |
| `memory_type` | enum | — | 按类型过滤 |
| `verification_status` | enum | — | 精确状态过滤；**给出时忽略默认的"仅活跃"规则**（可查 revoked/superseded 历史） |
| `entry_id` | string | — | 按来源日记过滤 |
| `active` | bool | 省略 | `true`/省略 = 默认活跃视图；`false` = 仅非活跃；与 `verification_status` 同时给出时作为附加过滤 |
| `include_deleted_sources` | bool | `false` | 为 `true` 时包含"来源日记已被软删除"的派生记忆；默认隐藏（见下文） |
| `limit` | int(≥1) | 20 | 服务层上限 100 |
| `offset` | int(≥0) | 0 | |

默认视图定义：`is_active = 1` 且 `verification_status NOT IN ('revoked','superseded')`。

**来源日记软删除后的可见性**：默认（`include_deleted_sources=false`）会同时过滤掉来源日记已被软删除的记忆，分页 `total` 也按过滤后的结果统计。显式传 `include_deleted_sources=true` 可查看这些记忆（响应元素的 `source_entry_deleted=true` 标明来源日记已删除）。该过滤独立于 `active`/`verification_status`/`entry_id` 过滤，可组合。

成功：`200`，`Page[MemoryOut]`（字段同 §4.1 的 `created[]` 元素）。

### 4.3 `GET /api/v1/memories/{memory_id}` — 记忆详情

查询参数：`include_deleted_sources`（bool，默认 `false`）。

成功：`200`，单个 `MemoryOut`，包含全部 `sources` 与 `source_version`。撤回/被取代的记忆仍可按 id 获取（用于追溯）。**来源日记已软删除时默认返回 `404 not_found`**；传 `include_deleted_sources=true` 可查看（`source_entry_deleted=true`）。记忆不存在 → `404 not_found`。

### 4.4 `GET /api/v1/memories/{memory_id}/sources` — 证据来源

查询参数：`include_deleted_sources`（bool，默认 `false`；来源日记已软删除时默认 `404`，显式 opt-in 可读）。

成功：`200`：

```json
{
  "memory_id": "53e39f09-32b0-4994-bdad-dbe4a612cb08",
  "total": 1,
  "sources": [
    {
      "id": "9cdbd095-1bce-42e4-a251-2fa3aec36c84",
      "memory_id": "53e39f09-32b0-4994-bdad-dbe4a612cb08",
      "entry_id": "c82aa2ea-4af4-4b81-a64f-7a055cd9d229",
      "revision_id": "5cdc7ac4-e5be-4ead-8b63-39f15d45c181",
      "evidence_text": "我有点失落",
      "start_offset": 10,
      "end_offset": 15,
      "created_at": "2026-10-29T07:26:43.990886Z",
      "revision_version": 1
    }
  ]
}
```

`revision_version` 是来源修订的版本号（不是记忆版本）。不存在 → 404。

### 4.5 `POST /api/v1/memories/{memory_id}/confirm` — 确认

无请求体（发送空 body 或不发均可；带未知字段会 422）。成功：`200`，返回更新后的 `MemoryOut`：

```json
{
  "id": "53e39f09-32b0-4994-bdad-dbe4a612cb08",
  "content": "用户感到失落",
  "memory_type": "subjective_feeling",
  "verification_status": "confirmed",
  "is_active": true,
  "created_by": "model",
  "confirmed_by": "user",
  "confirmed_at": "2026-10-29T07:26:44.065343Z"
}
```

（示例为字段节选；完整字段集合与 §4.1 响应中 `created[]` 的元素相同。）

关键语义：**`memory_type` 不会改变**（`model_inference` 确认后仍是 `model_inference`）。

错误：已是 confirmed → `409 already_confirmed`；其他状态（revoked/superseded）→ `409 invalid_state_transition`；不存在 → 404。

### 4.6 `POST /api/v1/memories/{memory_id}/correct` — 更正

请求体（`extra="forbid"`）：

| 字段 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `content` | string | 是 | 更正后的内容；必须与当前内容不同；≤ `min(4000, HEARTLOG_MAX_EVIDENCE_CHARS)`（默认 2000） |
| `change_reason` | string(≤500) | 否 | 记录到 metadata 与审计 |

成功：`201 Created`，返回**新记忆**：

- `source_type="user_correction"`、`verification_status="confirmed"`、`created_by="user"`、`confirmed_by="user"`；
- `supersedes_memory_id` = 旧记忆 id；
- 复制旧记忆的全部证据来源（重新校验）；
- `metadata.correction` 记录旧 id、旧内容哈希、理由、来源数；
- 旧记忆变为 `superseded` + `is_active=false`，内容不变。

错误：

| 状态 | code | 说明 |
| --- | --- | --- |
| 404 | `not_found` | 记忆不存在 |
| 409 | `invalid_state_transition` | 只能更正 pending/confirmed |
| 422 | `correction_unchanged` | 新内容与当前内容哈希相同 |
| 422 | `content_too_long` | 超过内容上限 |
| 409 | `duplicate_memory` | 同修订已存在相同内容+类型 |
| 409 | `missing_sources` | 记忆没有证据来源（防御性） |
| 409 | `invalid_source_evidence` | 证据与修订文本不再匹配 |

### 4.7 `POST /api/v1/memories/{memory_id}/revoke` — 撤回

请求体可选（`{ "reason": "..." }`，`reason` ≤200 字符；空白会被规范化为 null；无 body 也接受）。成功：`200`，返回 `MemoryOut`：`verification_status="revoked"`、`is_active=false`、`revoked_at` 非空。

撤回后：默认列表/搜索不可见；仍可按 id 查询；证据与内容保留；**没有 un-revoke API**。

错误：已撤回 → `409 already_revoked`；superseded → `409 invalid_state_transition`；不存在 → 404。

### 4.8 `DELETE /api/v1/memories/{memory_id}` — 遗忘（purge / anonymize）

请求参数：

| 位置 | 名称 | 默认 | 说明 |
| --- | --- | --- | --- |
| query | `mode` | `purge` | `purge` 或 `anonymize`；非法值 → `422 validation_error` |
| header | `X-Confirm-Memory-Delete` | **必填** | 必须是 `memory_id` / `"true"` / `"confirm"`，否则 `422 confirmation_required` |

行为（[`app/services/memory_service.py`](../app/services/memory_service.py)）：

- **两种模式删除的数据相同**：记忆行 + 它的全部 `memory_sources` 证据行都被永久删除；来源日记不再被这条记忆引用；
- 唯一区别是追加式审计事件类型：`purge` → `memory.purged`，`anonymize` → `memory.anonymized`（审计 details 只含 ID/类型/计数等结构信息，**不含记忆正文或证据文本**；`anonymize` **不会**保留一条替换后的记忆行）；
- 来源日记已被软删除时，该遗忘操作仍可按 id 执行（用于解除日记永久删除的引用阻塞）；
- 操作不可撤销；**不修改历史备份、导出 JSON 或文件系统快照**；更正链中若有其它记忆 `supersedes_memory_id` 指向被删记忆，该外键会被置为 `NULL`（数据库 `ON DELETE SET NULL`）。

成功：`200`：

```json
{
  "memory_id": "53e39f09-32b0-4994-bdad-dbe4a612cb08",
  "mode": "purge",
  "forgotten_at": "2026-10-29T07:29:03.512345Z",
  "source_entry_id": "c82aa2ea-4af4-4b81-a64f-7a055cd9d229",
  "source_revision_id": "5cdc7ac4-e5be-4ead-8b63-39f15d45c181",
  "memory_type": "subjective_feeling",
  "purged_sources": 1,
  "audit_event_id": "b6d0f6f5-62b2-4e0a-9a6e-2f2c5d6f7a80",
  "note": "Content and evidence were permanently removed. An append-only audit event remains without memory content. Existing backups/exports are not modified."
}
```

错误：

| 状态 | code | 说明 |
| --- | --- | --- |
| 404 | `not_found` | 记忆不存在（已遗忘后再删也是 404） |
| 422 | `confirmation_required` | 缺少/错误的 `X-Confirm-Memory-Delete` |
| 422 | `validation_error` | `mode` 不是 `purge`/`anonymize` |

> **不需要管理员令牌**：遗忘由确认头保护，不检查 `HEARTLOG_ADMIN_TOKEN`；但**日记物理删除**仍需管理员令牌（§3.10）。遗忘后可用 §3.11 检查日记是否已解除引用阻塞。

---

## 5. 搜索 API

### `GET /api/v1/search`

查询参数：

| 参数 | 类型 | 默认 | 说明 |
| --- | --- | --- | --- |
| `q` | string(1–200) | **必填** | 关键词；全空白由服务层拒绝 |
| `scope` | `all`/`diaries`/`memories` | `all` | 搜索范围 |
| `include_history` | bool | `true` | 为 `false` 时只搜当前修订；`true` 时搜索全部历史修订 |
| `include_deleted_sources` | bool | `false` | 为 `true` 时 memory 命中可包含"来源日记已软删除"的派生记忆；默认隐藏 |
| `limit` | int(1–500) | 配置默认 20 | 服务层上限 100 |
| `offset` | int(≥0) | 0 | |

行为：

- 日记命中：仅未软删除日记；可按 `include_history` 决定是否包含历史修订；`is_current` 表示命中是否当前修订。
- 记忆命中：仅 active 且非 revoked/superseded 的记忆；命中自身 `content`；`is_current` 恒为 `false`；`version` 是来源修订版本。**默认排除来源日记已软删除的记忆**；`include_deleted_sources=true` 才会包含（响应回显该标志）。
- 结果是两类命中合并后按 `created_at` 倒序；`total = diary_total + memory_total`。
- 这是 SQL 子串匹配（不区分大小写），不是语义搜索；`%`、`_` 会被转义为字面量。

示例：

```json
{
  "query": "失落",
  "scope": "all",
  "include_history": true,
  "include_deleted_sources": false,
  "total": 2,
  "limit": 20,
  "offset": 0,
  "has_more": false,
  "items": [
    {
      "kind": "diary",
      "snippet": "今天她还是没有回复，我有点失落。后来我去散步了。",
      "created_at": "2026-10-29T07:26:29.240664Z",
      "entry_id": "a3e4448f-3975-4c06-ab5f-f00f445335af",
      "revision_id": "ea157c58-9f6b-4e14-ba69-f167c9f7d7b6",
      "version": 2,
      "is_current": true,
      "memory_id": null,
      "memory_type": null,
      "verification_status": null,
      "confidence": null
    },
    {
      "kind": "diary",
      "snippet": "今天她还是没有回复，我有点失落。",
      "created_at": "2026-10-29T07:26:29.214607Z",
      "entry_id": "a3e4448f-3975-4c06-ab5f-f00f445335af",
      "revision_id": "fcbaa38f-8af0-489c-9a40-c2a094d5ecec",
      "version": 1,
      "is_current": false,
      "memory_id": null,
      "memory_type": null,
      "verification_status": null,
      "confidence": null
    }
  ]
}
```

记忆命中的示例字段（`kind="memory"`）：

```json
{
  "kind": "memory",
  "snippet": "用户后来去散步了",
  "created_at": "2026-10-29T07:26:43.995345Z",
  "entry_id": "c82aa2ea-4af4-4b81-a64f-7a055cd9d229",
  "revision_id": "5cdc7ac4-e5be-4ead-8b63-39f15d45c181",
  "version": 1,
  "is_current": false,
  "memory_id": "239d9415-0d97-424f-b605-a080e8f9e7dc",
  "memory_type": "explicit_fact",
  "verification_status": "confirmed",
  "confidence": 0.8
}
```

错误：缺少 `q` / `q` 超 200 → 422；`scope` 非法 → 422；全空白 → `422 validation_error`（message `q must not be blank`）。

---

## 6. 人物 API

人物记录用于"我发现日记里提到了这个人"；**不自动合并同名人物**，时间线只是字面文本匹配。来源日记被软删除后，人物在默认列表/详情中隐藏（`include_deleted_sources=true` 可查看），但按 id 的遗忘操作仍然可用。

### 6.1 `POST /api/v1/persons`

请求体（`extra="forbid"`）：

| 字段 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `display_name` | string(1–200) | 是 | 会 strip；不能空白 |
| `aliases` | string[]（≤20） | 否 | 自动 strip/去重/丢弃空串 |
| `source_entry_id` | string | 是 | 必须存在且未软删除 |
| `source_revision_id` | string | 是 | 必须属于该 entry |
| `source_evidence` | string(≤500) | 否 | 若给出，必须是该修订正文的精确子串 |

成功：`201 Created`：

```json
{
  "id": "3bd65fb6-9b43-485b-983b-5daebe163373",
  "display_name": "小林",
  "aliases": ["林林"],
  "source_entry_id": "a3e4448f-3975-4c06-ab5f-f00f445335af",
  "source_revision_id": "fcbaa38f-8af0-489c-9a40-c2a094d5ecec",
  "source_evidence": "她",
  "created_at": "2026-10-29T07:26:29.341845Z",
  "updated_at": "2026-10-29T07:26:29.341845Z"
}
```

错误：来源 entry 不存在/已删除 → 404 `not_found`；修订不属于 entry 或证据不是精确子串 → 422 `validation_error`；同一修订同名重复 → `409 person_already_recorded`（details 带已有 person id）。

### 6.2 `GET /api/v1/persons`

| 参数 | 类型 | 默认 | 说明 |
| --- | --- | --- | --- |
| `q` | string(≤200) | — | 仅按 `display_name` 做 LIKE 过滤 |
| `include_deleted_sources` | bool | `false` | 为 `true` 时包含"来源日记已被软删除"的人物；默认隐藏 |
| `limit` | int(1–100) | 20 | |
| `offset` | int(≥0) | 0 | |

成功：`200`，`PersonList`（`items/total/limit/offset/has_more`，元素为 `PersonOut`）。默认会过滤掉来源日记已软删除的人物（`total` 同样按过滤后统计）。

### 6.3 `GET /api/v1/persons/{person_id}`

查询参数：`include_deleted_sources`（bool，默认 `false`）。成功：`200`，`PersonOut`。**来源日记已软删除时默认 `404 not_found`**；显式 `include_deleted_sources=true` 可读。不存在 → 404。

### 6.4 `GET /api/v1/persons/{person_id}/timeline`

| 参数 | 类型 | 默认 | 说明 |
| --- | --- | --- | --- |
| `include_deleted_sources` | bool | `false` | 仅影响人物本身是否可见；timeline 命中始终只来自未删除日记 |
| `limit` | int(1–100) | 50 | |
| `offset` | int(≥0) | 0 | |

在所有未删除日记的**全部修订**中查找该人物显示名/别名的字面出现，返回：

```json
{
  "person_id": "3bd65fb6-9b43-485b-983b-5daebe163373",
  "display_name": "小林",
  "names_used_for_search": ["小林", "林林"],
  "method": "literal_text_match",
  "note": "This timeline finds literal mentions of the person's names. It does not prove identity ...",
  "items": [
    {
      "entry_id": "a3e4...",
      "revision_id": "ea15...",
      "version": 2,
      "created_at": "2026-10-29T07:26:29.240664Z",
      "snippet": "…上下文片段…",
      "matched_name": "小林",
      "is_current": true
    }
  ]
}
```

此接口**不做身份消歧**：同名不同人的出现会一起返回；不自动合并。

### 6.5 `DELETE /api/v1/persons/{person_id}` — 遗忘（永久删除人物行）

请求头：

| 请求头 | 必填 | 说明 |
| --- | --- | --- |
| `X-Confirm-Person-Delete` | **是** | 必须是 `person_id` / `"true"` / `"confirm"`，否则 `422 confirmation_required` |

行为：永久删除 `persons` 行；只追加一条不含内容的 `person.purged` 审计事件（details 含 person/entry/revision id、alias 数量、是否曾有 source_evidence）。**不需要管理员令牌**；来源日记已软删除时仍可按 id 执行（用于解除日记永久删除的引用阻塞）。不修改历史备份/导出。

成功：`200`：

```json
{
  "person_id": "3bd65fb6-9b43-485b-983b-5daebe163373",
  "forgotten_at": "2026-10-29T07:31:12.345678Z",
  "source_entry_id": "a3e4448f-3975-4c06-ab5f-f00f445335af",
  "source_revision_id": "fcbaa38f-8af0-489c-9a40-c2a094d5ecec",
  "audit_event_id": "1c2e3f40-5a6b-4c7d-8e9f-0a1b2c3d4e5f",
  "note": "The person row was permanently removed. An append-only audit event remains without personal notes; earlier backups/exports are not modified."
}
```

错误：不存在（或已遗忘）→ `404 not_found`；缺少/错误确认头 → `422 confirmation_required`。

---

## 7. 对话 API

### 7.1 `POST /api/v1/conversations`

请求体：`{"title": "可选标题"}`（`title` ≤200；空白/缺省 → `null`；`extra="forbid"`）。

成功：`201 Created`：

```json
{
  "id": "06e05bb5-565c-4461-aa26-d5c171ea0795",
  "title": "测试对话",
  "created_at": "2026-10-29T07:26:29.416642Z",
  "updated_at": "2026-10-29T07:26:29.416642Z",
  "message_count": 0
}
```

### 7.2 `GET /api/v1/conversations/{conversation_id}`

成功：`200`，`ConversationDetail`（`ConversationOut` + `messages[]`，按 `created_at` 升序）。不存在 → 404。

### 7.3 `POST /api/v1/conversations/{conversation_id}/messages`

请求体：`{"content": "..."}`（1–50000 字符，不能全空白；`extra="forbid"`）。

**AI 关闭/未配置时**（默认）：返回 `200`，用户消息与助手占位消息都落库：

```json
{
  "conversation_id": "06e05bb5-565c-4461-aa26-d5c171ea0795",
  "user_message": {
    "id": "ae4f3b70-a7ba-4a33-a6b9-a056ba25bdd8",
    "conversation_id": "06e05bb5-565c-4461-aa26-d5c171ea0795",
    "role": "user",
    "content": "我今天有点难过",
    "mode": "placeholder",
    "citations": [],
    "model_name": null,
    "created_at": "2026-10-29T07:26:29.439641Z"
  },
  "assistant_message": {
    "id": "7930df84-ae34-409b-a4c1-3fd04b2a30b7",
    "conversation_id": "06e05bb5-565c-4461-aa26-d5c171ea0795",
    "role": "assistant",
    "content": "【占位模式 / placeholder mode】AI 对话未启用或未配置，本条回复不是由 AI 生成的，也没有任何内容离开本机。……",
    "mode": "placeholder",
    "citations": [],
    "model_name": null,
    "created_at": "2026-10-29T07:26:29.445641Z"
  },
  "mode": "placeholder",
  "ai_used": false,
  "citations": [],
  "provider": null,
  "model": null,
  "notice": "AI disabled or not configured; a labelled local placeholder reply was stored."
}
```

**AI 可用时**（字段形状已用进程内 fake AI 验证；真实外部 provider 未在开发环境验证，其内容质量以实际配置为准，结构以 `/openapi.json` 为准）：

- `mode="ai"`、`ai_used=true`；
- `assistant_message.mode="ai"`、`model_name` 为配置的模型名；
- `citations` 只包含实际发送给模型的上下文中真实存在的记忆（伪造/未知 `memory_id` 被丢弃），字段为 `memory_id/entry_id/revision_id/version/snippet/memory_type/source_created_at`，且 snippet 等元数据由数据库重建；实测 `source_created_at` 形如 `2026-10-29T07:38:34.791705+00:00`（Python `isoformat()`，UTC 偏移）——该字段格式与顶层 `Z` 风格不同；
- `provider`/`model` 非空；`notice=null`；
- provider 调用失败：用户消息已保存，接口返回 `502 ai_service_error` / `ai_invalid_response`（或 503），**不会**伪造助手回复。

该端点没有"列出所有对话"接口；对话内容通过 `GET /conversations/{id}` 读取。

---

## 8. 回顾（Insights）API

### `GET /api/v1/insights/weekly` / `GET /api/v1/insights/monthly`

查询参数：`date`（可选，ISO 日期 `YYYY-MM-DD`，如 `?date=2026-10-01`；缺省为今天 UTC）。周区间为周一起点，月区间为月初起点，均以 UTC 计，左闭右开。

> 回顾只统计未软删除日记与来源日记未软删除的活跃记忆；来源日记已软删除的派生记忆不会计入统计或 sources，且**没有** `include_deleted_sources` opt-in（回顾始终按默认可见性计算）。

**AI 关闭/未配置时**（默认）：`200`，`mode="local_statistics"`、`ai_used=false`、`narrative=null`：

```json
{
  "mode": "local_statistics",
  "ai_used": false,
  "period": {
    "period": "weekly",
    "start": "2026-10-26T00:00:00Z",
    "end": "2026-11-02T00:00:00Z",
    "reference_date": "2026-10-29",
    "timezone": "UTC"
  },
  "statistics": {
    "diary_entries": 1,
    "memories": 0,
    "memory_type_counts": [
      {"memory_type": "explicit_fact", "count": 0},
      {"memory_type": "subjective_feeling", "count": 0},
      {"memory_type": "explicit_belief", "count": 0},
      {"memory_type": "model_inference", "count": 0}
    ]
  },
  "narrative": null,
  "sources": [
    {
      "memory_id": null,
      "entry_id": "a3e4448f-3975-4c06-ab5f-f00f445335af",
      "revision_id": "ea157c58-9f6b-4e14-ba69-f167c9f7d7b6",
      "version": 2,
      "snippet": null,
      "memory_type": null,
      "created_at": "2026-10-29T07:26:29.212607Z"
    }
  ],
  "notes": [
    "AI 未启用或未配置：本次未生成任何 AI 叙事，以上仅为本地统计。",
    "本请求没有向任何外部提供方发送数据。",
    "如需 AI 回顾，请先阅读隐私说明，再启用 AI 并记录同意。"
  ],
  "disclaimer": "HeartLog 不是心理治疗、医疗诊断或危机干预工具；本回顾仅供参考。若你处于危险中，请联系当地紧急服务或可信任的专业心理支持。",
  "provider": null,
  "model": null
}
```

**AI 可用时**（字段形状已用进程内 fake AI 验证；真实外部 provider 未在开发环境验证）：`mode="ai"`、`ai_used=true`、`narrative` 为纯文本回顾，`provider`/`model` 非空，sources 仍来自真实数据库记录；notes 变为 AI 模式说明。若 AI 生成失败（provider 错误/响应不可用），返回 `local_statistics` 并附失败说明，**不会伪造叙事**。

---

## 9. AI 关闭 vs 启用行为矩阵

| 端点 | AI 关闭（默认） | AI 已启用且配置完整 |
| --- | --- | --- |
| `POST /api/v1/memories/extract` | `503 ai_not_configured`，不读不写 | 调用 provider，校验后落库 pending；失败 502/503，不写 |
| `POST /api/v1/conversations/{id}/messages` | `200`，`mode=placeholder`，助手消息为本机固定文案，`ai_used=false` | `200`，`mode=ai`，真实模型回复 + 校验后的引用 |
| `GET /api/v1/insights/weekly`、`/monthly` | `200`，`mode=local_statistics`，只返回真实统计 | `200`，`mode=ai`，基于结构化事实的叙事；失败降级为本地统计 |
| `GET /health` | `ai_enabled=false`, `ai_ready=false` | `ai_enabled=true`；`ai_ready` 取决于 provider 是否完整配置 |
| 其他读取/日记/搜索/人物/导出 | 不受影响（完全本地） | 不受影响（完全本地） |

> 与 AI 无关但影响所有读取端点的可见性规则：来源日记被软删除后，派生记忆/人物默认隐藏，`/search` 的 memory 命中默认排除，`/insights` 始终排除；显式 `include_deleted_sources=true` 只对 memories/persons/search 生效。详见 §4.2、§5、§6.2。

---

## 10. 备注与"以代码为准"的地方

- **真实外部 AI 的响应质量与格式**：HeartLog 只保证"不合法/不合 schema 的输出会被拒绝且不写数据"；具体模型返回什么无法在文档中穷举。相关响应示例仅覆盖本地可验证路径（禁用模式、fake AI），真实 provider 以代码与 `/openapi.json` 为准。
- **时间精度与格式**：示例中的时间为运行时生成（微秒精度，`Z` 后缀）；你的响应会不同。
- **ID 均为示例**：所有 `a3e4448f-...` 等 UUID 只是示例，不可直接复用。
- **分页上限**：路由与 schema 允许的 `limit` 上限（如 500）大于服务层实际上限（默认 100）；以响应中的 `limit` 为准。
- **错误信息文案**：`message` 可能随版本调整，但 `code` 是稳定接口；客户端应基于 `code` 判断。
- **OpenAPI**：运行时 `GET /openapi.json` 是字段与枚举的最终权威（包含每个 schema 的定义）。
- **限流是可选功能**：默认关闭；开启后 429 的行为与响应头见 §1.6，部署层面的代理层限流与 TLS 见 [部署安全指南](deployment_security.md)。
- **遗忘不改变备份**：`DELETE /memories` / `DELETE /persons` 只修改数据库；历史备份、导出 JSON、文件系统快照不会被修改或自动清理，见 [备份文档 §12](backup.md#12-已知限制请纳入你的威胁模型)。
