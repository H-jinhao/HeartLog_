# HeartLog 数据库设计

本文逐一说明 HeartLog 的全部表、字段、约束、索引、触发器、关系与删除/遗忘语义，并明确哪些不变量**不是**数据库强制、只由服务层/测试/校验脚本保证。描述依据当前 `0.1.0` 代码与初始迁移 [`alembic/versions/1b179ca3e706_initial_schema.py`](../alembic/versions/1b179ca3e706_initial_schema.py)。

> **v0.2 增量（遗忘 / 引用检查 / 派生可见性）不需要 schema 迁移**：没有新增表、列、索引或触发器；`memory.purged` / `memory.anonymized` / `person.purged` 复用现有 `audit_events`，删除语义完全由现有外键 `ON DELETE CASCADE` / `SET NULL` / `RESTRICT` 与服务层代码实现。备份/加密/保留策略是**数据库之外的文件层能力**，不改变表结构（见 §9）。

相关文档：[架构](architecture.md) · [隐私](privacy.md) · [API](api.md) · [运维](operations.md) · [备份与恢复](backup.md)

---

## 1. 数据库概览

- 数据库：SQLite（默认 `sqlite:///./data/heartlog.db`），一个数据库文件。
- ORM：SQLAlchemy 2.x，模型在 [`app/models/`](../app/models)。
- 迁移：Alembic 初始版本 `1b179ca3e706`（`alembic_version.version_num` 记录当前版本）。
- 主键：全部业务表使用 `String(36)` 字符串 UUID（`UUIDPrimaryKeyMixin`）。
- 时间：全部为 UTC。ORM 使用自定义 [`UTCDateTime`](../app/db/types.py) 写入时存 naive UTC、读回时标注 UTC；API 输出为 ISO 8601（`Z` 后缀）。
- JSON：别名 `metadata` 的列在 ORM 中映射为 `metadata_json`（`metadata` 是 SQLAlchemy 保留属性名），使用 `MutableDict`/`MutableList` 以便原地变更被追踪。
- 布尔：SQLite 以整数 0/1 存储。

连接 PRAGMA（[`app/db/session.py`](../app/db/session.py)）：

```
PRAGMA foreign_keys = ON
PRAGMA busy_timeout = 30000
PRAGMA journal_mode = WAL
PRAGMA synchronous = NORMAL
```

### 表一览

| 表 | 作用 | 写入语义 |
| --- | --- | --- |
| `diary_entries` | 日记条目（原文 + 当前指针 + 软删除标记） | 原文不可变；指针/删除标记可变 |
| `diary_revisions` | 不可变修订历史 | 只追加；禁止 UPDATE/DELETE（受控永久删除除外） |
| `memories` | 可追溯长期记忆（状态机） | 内容不可变；审核状态可变 |
| `memory_sources` | 记忆的不可变证据行 | 只插入；禁止更新 |
| `persons` | 人物（带来源） | 来源字段不可变 |
| `audit_events` | 追加式审计（含遗忘/删除事件） | 只插入；禁止 UPDATE/DELETE |
| `conversations` | 陪伴对话容器 | 可更新（标题/updated_at） |
| `messages` | 对话消息（真实 AI 或占位） | 只插入（当前无编辑/删除 API） |
| `alembic_version` | 迁移版本 | Alembic 维护 |

### 关系图

```mermaid
erDiagram
    DIARY_ENTRIES ||--o{ DIARY_REVISIONS : "1:n (CASCADE)"
    DIARY_ENTRIES ||--o{ MEMORIES : "source_entry (RESTRICT)"
    DIARY_REVISIONS ||--o{ MEMORIES : "source_revision (RESTRICT)"
    MEMORIES ||--o{ MEMORY_SOURCES : "1:n (CASCADE)"
    DIARY_ENTRIES ||--o{ MEMORY_SOURCES : "entry (RESTRICT)"
    DIARY_REVISIONS ||--o{ MEMORY_SOURCES : "revision (RESTRICT)"
    DIARY_ENTRIES ||--o{ PERSONS : "source_entry (RESTRICT)"
    DIARY_REVISIONS ||--o{ PERSONS : "source_revision (RESTRICT)"
    MEMORIES ||--o| MEMORIES : "supersedes (SET NULL)"
    CONVERSATIONS ||--o{ MESSAGES : "1:n (CASCADE)"
```

> `diary_entries.current_revision_id` **故意没有外键**：它指向 `diary_revisions`，而 revisions 又外键引用 entries；加 FK 会形成循环约束并影响插入顺序。该指针的一致性由服务层与完整性校验保证（见 §7）。

> **备份不在数据库 schema 内**：备份是数据库文件的完整副本（可选 AES-256-GCM 加密容器），`.sha256`/manifest 是文件系统 sidecar；备份/保留/恢复演练不新增或修改任何表，也不在数据库中记录"备份历史"（见 §9）。

---

## 2. 表结构明细

### 2.1 `diary_entries`（日记条目）

| 列 | 类型 | NULL | 默认 | 说明 |
| --- | --- | --- | --- | --- |
| `id` | `String(36)` | 否 | UUID | 主键 |
| `original_text` | `Text` | 否 | — | 用户提交的原始正文，逐字符保存（不 strip） |
| `original_content_hash` | `String(64)` | 否 | — | 原文 UTF-8 的 SHA-256 十六进制 |
| `current_version` | `Integer` | 否 | `1` | 当前修订号（从 1 开始） |
| `current_revision_id` | `String(36)` | 是 | — | 指向当前修订（**无 FK**，有索引） |
| `deleted_at` | `UTCDateTime` | 是 | — | 软删除时间；非空即视为已删除 |
| `metadata` | `JSON` | 否 | `{}` | 用户自定义元数据（任意 JSON 对象） |
| `created_at` | `UTCDateTime` | 否 | `utcnow()` | 创建时间（不可变） |
| `updated_at` | `UTCDateTime` | 否 | `utcnow()` | 最近更新时间（指针变更时由服务更新） |

约束与索引：

- `CHECK (current_version >= 1)` — `ck_diary_entries_current_version`
- `CHECK (length(original_text) > 0)` — `ck_diary_entries_original_not_empty`
- 索引：`ix_diary_entries_created_at`、`ix_diary_entries_deleted_at`、`ix_diary_entries_current_revision_id`
- 关系：`revisions`（1:n，`cascade="all, delete-orphan"`，按 version 排序）

ORM 保护（[`app/models/diary.py`](../app/models/diary.py)）：

- `before_insert`：强制用 `sha256_text(original_text)` 覆盖 `original_content_hash`（即使调用方传入伪造哈希）。
- `before_update`：`id` / `original_text` / `original_content_hash` / `created_at` 任何变更 → `ProtectedRecordError`；`current_version < 1` 也拒绝。
- `before_delete`：默认拒绝；只有 session 标记 `heartlog.allow_permanent_delete` 时才允许（永久删除流程专用）。

### 2.2 `diary_revisions`（不可变修订）

| 列 | 类型 | NULL | 默认 | 说明 |
| --- | --- | --- | --- | --- |
| `id` | `String(36)` | 否 | UUID | 主键 |
| `entry_id` | `String(36)` | 否 | — | FK → `diary_entries.id` `ON DELETE CASCADE` |
| `version` | `Integer` | 否 | — | 从 1 连续递增的版本号 |
| `content` | `Text` | 否 | — | 该版本的正文（创建时逐字符保存） |
| `content_hash` | `String(64)` | 否 | — | 该版本内容的 SHA-256 |
| `previous_revision_hash` | `String(64)` | 是 | — | 上一版本的 `content_hash`；v1 为 NULL |
| `change_reason` | `String(500)` | 是 | — | 本次编辑理由（可选）；v1 为固定字符串 `"Initial version"` |
| `created_at` | `UTCDateTime` | 否 | `utcnow()` | 修订创建时间 |

约束与索引：

- `UNIQUE (entry_id, version)` — `uq_diary_revisions_entry_version`（并发写入的最后防线）
- `CHECK (version >= 1)` — `ck_diary_revisions_version`
- `CHECK (length(content) > 0)` — `ck_diary_revisions_content_not_empty`
- 索引：`ix_diary_revisions_entry_version (entry_id, version)`、`ix_diary_revisions_created_at`
- 关系：`entry`（多对一）

保护：

- `before_insert`：哈希总是由 content 重新计算。
- `before_update`：**无条件抛错**；`before_delete`：只有永久删除流程（session 标记）可删。
- SQLite 触发器 `trg_diary_revisions_immutable` / `trg_diary_revision_identity_immutable` 对裸 SQL 更新 `RAISE(ABORT)`。

### 2.3 `memories`（长期记忆）

| 列 | 类型 | NULL | 默认 | 说明 |
| --- | --- | --- | --- | --- |
| `id` | `String(36)` | 否 | UUID | 主键 |
| `content` | `Text` | 否 | — | 记忆陈述（自包含、保留原意）；创建后不可变 |
| `content_hash` | `String(64)` | 否 | — | `sha256(content)`，用于查重/追溯 |
| `memory_type` | `String(32)` | 否 | — | `explicit_fact` / `subjective_feeling` / `explicit_belief` / `model_inference` |
| `source_type` | `String(32)` | 否 | `diary_entry` | `diary_entry` / `user_correction` / `import` |
| `source_entry_id` | `String(36)` | 否 | — | FK → `diary_entries.id` `ON DELETE RESTRICT` |
| `source_revision_id` | `String(36)` | 否 | — | FK → `diary_revisions.id` `ON DELETE RESTRICT` |
| `confidence` | `Float` | 是 | — | 模型自评 0–1；用户更正沿用原值；**不能代替确认** |
| `verification_status` | `String(32)` | 否 | `pending` | `pending` / `confirmed` / `superseded` / `revoked` |
| `is_active` | `Boolean` | 否 | `true` | 是否出现在默认列表/搜索中 |
| `created_by` | `String(16)` | 否 | `model` | `user` / `model` / `import` |
| `confirmed_by` | `String(16)` | 是 | — | 确认者（当前为 `user`） |
| `confirmed_at` | `UTCDateTime` | 是 | — | 确认时间 |
| `revoked_at` | `UTCDateTime` | 是 | — | 撤回时间 |
| `supersedes_memory_id` | `String(36)` | 是 | — | FK → `memories.id` `ON DELETE SET NULL`；更正链 |
| `metadata` | `JSON` | 否 | `{}` | 提取信息（provider/model/修订版本/匹配方式）、更正信息等 |
| `created_at` / `updated_at` | `UTCDateTime` | 否 | `utcnow()` | 创建/更新时间 |

约束：

| 名称 | 定义 |
| --- | --- |
| `ck_memories_type` | `memory_type IN ('explicit_fact','subjective_feeling','explicit_belief','model_inference')` |
| `ck_memories_source_type` | `source_type IN ('diary_entry','user_correction','import')` |
| `ck_memories_verification_status` | `verification_status IN ('pending','confirmed','superseded','revoked')` |
| `ck_memories_created_by` | `created_by IN ('user','model','import')` |
| `ck_memories_confidence` | `confidence IS NULL OR (confidence >= 0 AND confidence <= 1)` |
| `ck_memories_source_required` | `source_type <> 'diary_entry' OR (source_entry_id IS NOT NULL AND source_revision_id IS NOT NULL)`（两列本身即 NOT NULL，此约束为语义兜底） |
| `ck_memories_revoked_inactive` | `verification_status <> 'revoked' OR is_active = 0` |
| `ck_memories_superseded_inactive` | `verification_status <> 'superseded' OR is_active = 0` |
| `uq_memories_revision_content_type` | `UNIQUE (source_revision_id, content_hash, memory_type)` |

索引：`ix_memories_type`、`ix_memories_status`、`ix_memories_active`、`ix_memories_source_entry`、`ix_memories_source_revision`、`ix_memories_created_at`。

关系：`sources`（1:n，`cascade="all, delete-orphan"`，按 created_at 排序）；`source_entry`；`source_revision`。

保护：`before_insert` 重算 `content_hash`；`before_update` 禁止修改 `content`、`content_hash`、`memory_type`、`created_by`、`source_type`、`source_entry_id`、`source_revision_id`。触发器 `trg_memory_content_immutable` 与 `trg_memory_confirmation_requires_reviewer` 提供同等的数据库级防线。

### 2.4 `memory_sources`（不可变证据）

| 列 | 类型 | NULL | 默认 | 说明 |
| --- | --- | --- | --- | --- |
| `id` | `String(36)` | 否 | UUID | 主键 |
| `memory_id` | `String(36)` | 否 | — | FK → `memories.id` `ON DELETE CASCADE` |
| `entry_id` | `String(36)` | 否 | — | FK → `diary_entries.id` `ON DELETE RESTRICT` |
| `revision_id` | `String(36)` | 否 | — | FK → `diary_revisions.id` `ON DELETE RESTRICT` |
| `evidence_text` | `Text` | 否 | — | 来源修订正文的**精确子串** |
| `start_offset` | `Integer` | 是 | — | 0 起始的切片起点（可选） |
| `end_offset` | `Integer` | 是 | — | 切片终点（可选，必须 > start） |
| `created_at` | `UTCDateTime` | 否 | `utcnow()` | 证据写入时间 |

约束与索引：

- `CHECK (start_offset IS NULL OR start_offset >= 0)` — `ck_memory_sources_start_offset`
- `CHECK (end_offset IS NULL OR end_offset >= 0)` — `ck_memory_sources_end_offset`
- `CHECK (start_offset IS NULL OR end_offset IS NULL OR end_offset >= start_offset)` — `ck_memory_sources_offsets_order`
- 索引：`ix_memory_sources_memory`、`ix_memory_sources_revision`
- 关系：`memory`（多对一）

保护：`before_update` **无条件抛错**；触发器 `trg_memory_sources_immutable` 阻止对 `memory_id/entry_id/revision_id/evidence_text/start_offset/end_offset` 的裸 SQL 更新。

**遗忘（v0.2）的数据库语义**：

- `DELETE /api/v1/memories/{id}` 由服务层 `session.delete(memory)` 删除记忆行；`Memory.sources` 关系声明了 `cascade="all, delete-orphan"`，数据库外键也是 `ON DELETE CASCADE`，因此**证据行随记忆一起删除**（遗忘后 `memory_sources` 不再有该 memory 的记录）；
- 记忆的 `supersedes_memory_id` 外键是 `ON DELETE SET NULL`：删除更正链中的父记忆时，子记忆的该列会被置为 `NULL`（不会级联删除子记忆，也不会阻止删除）；
- 审计事件在同一事务中先 flush 取得稳定 ID，再删除记忆；`audit_events` 的 append-only 保护不受影响（删除的是 memory 行，不是审计行）。

> 注意：数据库没有 `(entry_id, revision_id)` 复合外键来保证"revision 属于该 entry"；该不变量由服务层校验与 `scripts/verify_integrity.py` 检查（见 §8 与 [运维文档 §7](operations.md#7-完整性校验)）。

### 2.5 `persons`（人物）

| 列 | 类型 | NULL | 默认 | 说明 |
| --- | --- | --- | --- | --- |
| `id` | `String(36)` | 否 | UUID | 主键 |
| `display_name` | `String(200)` | 否 | — | 显示名 |
| `aliases` | `JSON` (list) | 否 | `[]` | 别名列表（最多 20 个，去重去空白由 schema 处理） |
| `source_entry_id` | `String(36)` | 否 | — | FK → `diary_entries.id` `ON DELETE RESTRICT` |
| `source_revision_id` | `String(36)` | 否 | — | FK → `diary_revisions.id` `ON DELETE RESTRICT` |
| `source_evidence` | `String(500)` | 是 | — | 来源修订中的精确片段（可选） |
| `created_at` / `updated_at` | `UTCDateTime` | 否 | `utcnow()` | 时间戳 |

索引：`ix_persons_display_name`、`ix_persons_source_entry`。无 UNIQUE 约束（同名人物可以出现在不同日记/修订中；"不自动合并"是产品行为）。保护：`before_update` 禁止修改 `id`/`source_entry_id`/`source_revision_id`/`source_evidence`/`created_at`（`display_name`/`aliases` 在 ORM 层可改，但当前没有对应更新 API）。

### 2.6 `audit_events`（追加式审计）

| 列 | 类型 | NULL | 默认 | 说明 |
| --- | --- | --- | --- | --- |
| `id` | `String(36)` | 否 | UUID | 主键 |
| `event_type` | `String(64)` | 否 | — | 如 `diary.created`、`memory.confirmed`、`data.exported` |
| `entity_type` | `String(32)` | 否 | — | 如 `diary_entry`、`memory`、`person`、`system` |
| `entity_id` | `String(36)` | 是 | — | 关联实体 id；系统事件为 NULL |
| `actor` | `String(16)` | 否 | `user` | `user` / `system` / `model` |
| `details` | `JSON` | 否 | `{}` | 仅结构信息（ID、版本、数量、理由码） |
| `created_at` | `UTCDateTime` | 否 | `utcnow()` | 事件时间 |

索引：`ix_audit_events_entity (entity_type, entity_id)`、`ix_audit_events_event_type`、`ix_audit_events_created_at`。

保护：`before_update` / `before_delete` 抛错；触发器 `trg_audit_events_no_update` / `trg_audit_events_no_delete` 阻止裸 SQL 修改。**注意**：审计是应用层追加式，不是密码学防篡改；有数据库文件写权限的人仍可篡改。

### 2.7 `conversations` / `messages`（陪伴对话）

`conversations`：

| 列 | 类型 | NULL | 默认 |
| --- | --- | --- | --- |
| `id` | `String(36)` | 否 | UUID (PK) |
| `title` | `String(200)` | 是 | — |
| `created_at` / `updated_at` | `UTCDateTime` | 否 | `utcnow()` |

索引：`ix_conversations_updated_at`。关系：`messages`（1:n，`cascade="all, delete-orphan"`，按 created_at 排序）。

`messages`：

| 列 | 类型 | NULL | 默认 | 说明 |
| --- | --- | --- | --- | --- |
| `id` | `String(36)` | 否 | UUID (PK) | |
| `conversation_id` | `String(36)` | 否 | — | FK → `conversations.id` `ON DELETE CASCADE` |
| `role` | `String(16)` | 否 | — | `user` / `assistant` / `system` |
| `content` | `Text` | 否 | — | 消息正文 |
| `mode` | `String(16)` | 否 | `ai` | `ai` / `placeholder`（占位模式明确标注非 AI） |
| `citations` | `JSON` (list) | 否 | `[]` | 引用列表；写入前由服务从数据库重建 |
| `model_name` | `String(200)` | 是 | — | 真实 AI 的模型名；占位为 NULL |
| `created_at` | `UTCDateTime` | 否 | `utcnow()` | |

- `CHECK (role IN ('user','assistant','system'))` — `ck_messages_role`
- `CHECK (mode IN ('ai','placeholder'))` — `ck_messages_mode`
- 索引：`ix_messages_conversation_created (conversation_id, created_at)`
- 关系：`conversation`（多对一）

### 2.8 `alembic_version`

Alembic 维护的单列表 `version_num VARCHAR(32) PRIMARY KEY`，记录当前迁移版本（当前为 `1b179ca3e706`）。`auto_create_schema=true` 时应用启动的 `create_all()` 不会创建/更新这张表。

---

## 3. SQLite 触发器（数据库级防线）

触发器由初始迁移安装，也由应用启动时 [`install_sqlite_guards`](../app/db/guards.py) 幂等安装（`CREATE TRIGGER IF NOT EXISTS`）。共 9 个：

| 触发器 | 作用 |
| --- | --- |
| `trg_diary_original_text_immutable` | 禁止 UPDATE `diary_entries.original_text` |
| `trg_diary_original_hash_immutable` | 禁止 UPDATE `diary_entries.original_content_hash` |
| `trg_diary_revisions_immutable` | 禁止对 `diary_revisions` 的任何 UPDATE |
| `trg_diary_revision_identity_immutable` | 禁止 UPDATE 修订的 `entry_id/version/content/content_hash/previous_revision_hash`（冗余防线） |
| `trg_audit_events_no_update` | 禁止 UPDATE `audit_events` |
| `trg_audit_events_no_delete` | 禁止 DELETE `audit_events` |
| `trg_memory_sources_immutable` | 禁止 UPDATE 证据的关键字段 |
| `trg_memory_confirmation_requires_reviewer` | 状态从非 `confirmed` 变成 `confirmed` 时必须已有 `confirmed_by` |
| `trg_memory_content_immutable` | 禁止 UPDATE 记忆的 `content/content_hash/memory_type/created_by` |

触发器触发时 `RAISE(ABORT, '<code>')`，当前事务回滚；ORM 层监听器抛 `ProtectedRecordError`。在非 SQLite 数据库上安装函数为 no-op（ORM 监听器仍生效）。

> 触发器是"防误操作/防回归"的额外防线，不是不可篡改保证：能直接改数据库文件或删掉触发器的人可以绕过。

---

## 4. 哈希与修订链

- 原文：`original_content_hash = sha256(UTF-8(original_text))`（newline 原样保留）。
- 修订：`content_hash = sha256(UTF-8(content))`。
- 修订链：`revision_k.previous_revision_hash = revision_{k-1}.content_hash`，v1 为 NULL。
- 哈希写入由 ORM `before_insert` 强制重算，调用方无法注入伪造哈希。
- 校验入口：`GET /api/v1/diaries/{id}/integrity`（在线）与 `scripts/verify_integrity.py`（离线）。检查项：原文哈希、版本连续性、每条修订内容哈希、previous 链、修订数 vs `current_version`、`current_revision_id` 指针。

任何一项不符只说明"数据与记录不一致"，不自动修复；请从可信备份恢复或人工排查。

---

## 5. 删除、撤回与遗忘语义

| 操作 | 影响 | 是否可恢复 | 备注 |
| --- | --- | --- | --- |
| `DELETE /diaries/{id}`（软删除） | 设置 `deleted_at`；列表/详情/修订/搜索默认隐藏；**派生记忆/人物默认隐藏** | ✅ `POST /restore` | 修订全部保留；记忆/人物引用不变（数据未删） |
| `DELETE /memories/{id}?mode=purge\|anonymize`（遗忘） | 物理删除该 memory 行；级联删除其全部 `memory_sources` 证据行 | ❌ | 只追加一条无内容审计（`memory.purged` / `memory.anonymized`）；`X-Confirm-Memory-Delete`；**不需要管理员令牌**；删除后不再阻塞来源日记的永久删除 |
| `DELETE /persons/{id}`（遗忘人物） | 物理删除 person 行 | ❌ | 只追加无内容 `person.purged` 审计；`X-Confirm-Person-Delete`；不需要管理员令牌 |
| `DELETE /diaries/{id}/permanent`（物理删除） | 物理删除 entry，级联删除其 revisions | ❌ | 需 `HEARTLOG_ADMIN_TOKEN` + `X-Admin-Token` + `X-Confirm-Permanent-Delete`；且有 memories/memory_sources/persons 引用时拒绝（`409 entry_has_references`） |
| `POST /memories/{id}/revoke`（撤回） | `revoked` + `is_active=false` | ❌（无 un-revoke API） | 行与证据仍保留，**不解除**永久删除的引用阻塞；不会删除内容 |
| `POST /memories/{id}/correct`（更正） | 旧行 `superseded` + 新行 confirmed | ❌（旧行不删） | 历史仍可追溯；旧行可按 `verification_status=superseded` 查询 |
| `GET /diaries/{id}/references`（引用检查） | 只读计数 | — | 返回 `memories` / `memory_sources` / `persons` 与 `can_permanently_delete`；**软删除日记也可查**；不写审计 |
| 对话/消息 | 当前**没有**删除 API | — | 只能通过数据库层操作（不推荐） |

### 5.1 遗忘（forget）的数据库细节

- **purge 与 anonymize 对数据库的删除结果完全相同**：删除 `memories` 行 + 级联删除 `memory_sources` 行；区别只在 `audit_events.event_type`。不会保留"匿名化后的记忆行"，也不会修改日记修订；
- 外键行为：`memory_sources.memory_id → memories.id` 为 `ON DELETE CASCADE`（证据行一并删除）；`memories.supersedes_memory_id → memories.id` 为 `ON DELETE SET NULL`（删除父记忆会把子记忆的该列置 NULL，子记忆保留）；`memories.source_entry_id/source_revision_id` 为 `RESTRICT`，但它们指向日记而非记忆，因此不是删除记忆的障碍；
- 遗忘后，来源日记的引用计数下降；当三类引用全部归零，`GET /diaries/{id}/references` 的 `can_permanently_delete=true`，管理员可执行物理删除（§5.2）；
- 审计事件在同一事务中先 flush 取得稳定 `id` 再删除记忆行；`audit_events` 仍是 append-only，遗忘审计 details 只含 ID/类型/计数/模式等结构字段，不含正文或证据；
- 数据库中的 SQLite 页面/空闲块/WAL 以及**历史备份/导出**不会被这一操作抹除（见 [隐私文档 §6](privacy.md#6-删除语义你删的到底是什么)）。

### 5.2 日记引用检查与永久删除的解除阻塞

`GET /api/v1/diaries/{id}/references` 由 [`DiaryRepository.count_references`](../app/repositories/diary_repository.py) 统计三张表的引用（软删除日记同样可查）：

| 字段 | SQL 统计口径 |
| --- | --- |
| `memories` | `COUNT(*) FROM memories WHERE source_entry_id = ?` |
| `memory_sources` | `COUNT(*) FROM memory_sources WHERE entry_id = ?` |
| `persons` | `COUNT(*) FROM persons WHERE source_entry_id = ?` |
| `can_permanently_delete` | 以上三者全部为 0 |

解除阻塞顺序：先对引用记忆执行遗忘（删除记忆与证据）、对引用人物执行遗忘，再重查 references；计数全为 0 后物理删除才不会被 `entry_has_references` 拒绝。

永久删除的保护顺序（[`app/services/diary_service.py`](../app/services/diary_service.py)）：

1. 管理员 Token 校验（未配置 → `403 admin_disabled`；缺失/错误 → `403 admin_required`）；
2. 确认头必须是日记 ID / `"true"` / `"confirm"`，否则 `422 confirmation_required`；
3. 统计 `memories`、`memory_sources`、`persons` 引用，任一非零 → `409 entry_has_references`（响应 details 给出计数）。**v0.2 起可以用遗忘接口归零引用**（revoke 仍不解除引用）；
4. 写审计 `diary.permanently_deleted` 后，在 session 标记下删除 entry（revisions 关系 cascade 删除）。

即使永久删除成功，**审计事件不会删除**（append-only），且备份/导出文件、WAL 文件、文件系统快照仍可能保留旧数据。详见 [隐私文档的删除章节](privacy.md#6-删除语义你删的到底是什么)。

---

## 6. 审计事件类型

代码中出现的事件类型（`event_type`）：

| 事件 | actor | entity | 关键 details |
| --- | --- | --- | --- |
| `diary.created` | user | diary_entry | version |
| `diary.revision_created` | user | diary_entry | from_version/to_version/has_change_reason |
| `diary.soft_deleted` | user | diary_entry | current_version |
| `diary.restored` | user | diary_entry | current_version |
| `diary.permanently_deleted` | user | diary_entry | current_version |
| `memory.created` | model（提取）/ user（更正） | memory | memory_type/source_type/status/来源 ID/source_count |
| `memories.extracted` | model | diary_entry | entry/revision/version/provider/model/候选与创建/拒绝数量、拒绝原因集合、创建 ID 列表 |
| `memory.confirmed` | user | memory | 前后状态、confirmed_by、来源 ID |
| `memory.corrected` | user | memory | superseded_by_memory_id、前后状态 |
| `memory.revoked` | user | memory | 前后状态、source_count、reason |
| `memory.purged` | user | memory | memory_id/mode/memory_type/status/source_entry_id/source_revision_id/source_count/had_supersedes_link（**不含正文/证据**） |
| `memory.anonymized` | user | memory | 同 `memory.purged`；`mode="anonymize"` |
| `person.created` | user | person | source_entry_id |
| `person.purged` | user | person | person_id/source_entry_id/source_revision_id/alias_count/had_source_evidence（**不含姓名、别名或证据文本**） |
| `data.exported` | user | system | counts、format |

约束：`details` 只放结构信息；代码明确不复制日记正文与模型证据全文。审计由 ORM 和触发器双重禁止修改/删除。

> `GET /api/v1/diaries/{id}/references` 是**只读**端点，不写审计事件；它统计的引用与永久删除的 `409 entry_has_references` 使用同一套口径（见 §5.2）。

---

## 7. 迁移工作流

配置文件 [`alembic.ini`](../alembic.ini)；`alembic/env.py` 从 `HEARTLOG_*` 设置（即 `HEARTLOG_DATABASE_URL` / `.env`）读取真实 URL，`alembic.ini` 里的 `sqlalchemy.url` 只是占位。迁移使用 `render_as_batch=True`（SQLite 批处理重建表）与 `compare_type=True`。

```bash
# 升级到最新
python -m alembic upgrade head
# 查看当前版本
python -m alembic current
# 回退一个版本（会先显式 DROP 触发器，再删表）
python -m alembic downgrade -1
# 生成新迁移（开发时）
python -m alembic revision --autogenerate -m "describe change"
```

初始迁移 `1b179ca3e706` 完成：8 张业务表 + 索引 + CHECK/UNIQUE 约束 + 外键 + 9 个触发器；`downgrade()` 先删除全部触发器，再按依赖顺序删表。迁移测试 [`tests/test_migrations.py`](../tests/test_migrations.py) 会在临时库上以进程内 Alembic `command.upgrade(config, "head")` 执行升级，并检查表/触发器/版本表存在（该测试只证明升级路径，不证明真实数据上的降级往返）。

**不要混用建表路径**：默认 `HEARTLOG_AUTO_CREATE_SCHEMA=true` 时应用启动会 `create_all()`；它不会写 `alembic_version`，且对已存在表是 no-op。若先启动应用建表、再执行 `alembic upgrade head`，迁移会因表已存在而失败。推荐：**新库先迁移，再启动应用**；或显式设置 `HEARTLOG_AUTO_CREATE_SCHEMA=false` 完全依赖迁移。

**v0.2 增量无新迁移**：遗忘、引用检查、派生可见性、限流、加密/保留/定时备份、部署配置都没有新增表/列/索引/触发器，因此 `alembic upgrade head` 仍只执行初始迁移 `1b179ca3e706`；已有 v0.1 数据库无需迁移即可兼容本轮代码（删除/遗忘只使用既有外键与服务层逻辑）。如果你从更早的自定义 schema 升级，仍应先备份再按本节流程迁移。

---

## 8. 已知限制（数据库层面）

1. **"每条记忆至少一条 `memory_sources`"不是数据库约束。** 数据库只强制 `source_entry_id/source_revision_id` 非空（主来源指针）及 `source_type` 枚举；一条 memory 行理论上可以没有任何 `memory_sources` 证据行（例如裸 SQL 插入）。该不变量由 `MemoryService` 的写入路径、测试与 `scripts/verify_integrity.py` 保证（校验脚本会把 `no_evidence_sources` 报为问题）。
2. **"证据必须是来源修订的精确子串"不是数据库约束。** 只能由服务层在写入/更正时校验，以及校验脚本离线检查。
3. **"来源修订必须属于来源日记"不是复合外键。** 数据库分别校验两个外键存在，但不保证 `diary_revisions.entry_id == memories.source_entry_id`；服务层与校验脚本负责。
4. **`diary_entries.current_revision_id` 无外键**；`current_version` 与修订数量的一致性、指针指向最后一条修订，均由服务/完整性检查维护，单条 CHECK 只保证 `current_version >= 1`。
5. **没有不可篡改存储保证。** 触发器可被删除；数据库文件可被替换/覆盖；哈希不是签名、不是加密。备份、导出、WAL/SHM、磁盘快照都可能保留旧数据。
6. **没有静态加密（encryption at rest）。** SQLite 文件、WAL、导出 JSON 与默认备份均为明文；`scripts/backup.py --encrypt` 只加密**新生成的备份容器**，不加密在线数据库，也不加密已有备份。
7. **没有多用户/租户字段。** 无法在数据库层区分数据归属；可选 Token 是"整个实例"级别的访问控制。
8. **JSON 列没有数据库级 schema 校验。** `metadata`、`aliases`、`citations` 的内容合法性由 Pydantic schema/服务层保证。
9. **SQLite 特性依赖。** 触发器与 PRAGMA 仅 SQLite 生效；换用其他数据库需要重新实现等价保护（当前代码未验证其他数据库）。
10. **并发写模型简单。** WAL + `busy_timeout`，没有写重试队列；高并发下可能 `database is locked`。个人单机使用足够，但不适合多进程高写负载。
11. **同名人物不唯一。** `persons.display_name` 没有唯一约束；"同一修订 + 同名"冲突由服务层检查（`person_already_recorded`），跨修订同名是允许且不自动合并的。
12. **对话/消息没有删除或编辑 API**；只能读/追加。
13. **永久删除的引用检查是应用层 + 外键 `RESTRICT` 双重保护**；审计事件与删除在同一事务中提交，但引用计数与真正删除之间存在常规并发窗口（检查后、提交前若有新记忆写入，仍由外键 `RESTRICT` 在提交时兜底拒绝）。v0.2 的遗忘接口可以归零引用，但同样不是跨请求的事务性"先检查后删除"原子操作。
14. **遗忘不可回滚、也不追溯备份。** purge/anonymize 只删除当前数据库中的记忆与证据行；历史备份/导出、WAL 残留、磁盘快照、同步盘副本仍可能保留旧内容，数据库本身没有"备份版本"记录可用于追溯（见 §9）。
15. **引用计数是即时值。** `GET /diaries/{id}/references` 返回查询时刻的计数；之后新增记忆/人物会重新阻塞永久删除。删除前应重新查询，外键 `RESTRICT` 是最后防线。

---

## 9. 备份文件与数据库的关系（不在 schema 内）

备份/加密/保留策略是**数据库之外的文件层能力**（[`app/services/backup_service.py`](../app/services/backup_service.py)、`scripts/backup.py` 等），不新增表、不记录"备份历史"：

- 备份是数据库文件的一致性副本（SQLite 在线备份 API），可整体替换数据库文件用于恢复；`HEARTLOG_DATABASE_URL` 指向的路径是恢复目标；
- 每个备份可附带 `.sha256` 与 JSON manifest（路径/大小/行数/哈希/KDF 参数等元数据，**不含日记或记忆正文**）；manifest 不是数据库表；
- `--encrypt` 只改变备份**容器**的格式（AES-256-GCM 密文 + 版本化文件头），解密后仍是同一个 SQLite schema；加密/解密不修改表结构；
- `--retention` 只按文件名时间戳清理**自动命名**的备份文件，不理解"删除语义"，也不与 `audit_events` 联动；
- 恢复演练（`scripts/restore_drill.py`）在临时目录对备份副本做只读检查（`PRAGMA integrity_check`、表存在性、日记哈希链、记忆证据不变量），**不会**写在线数据库；正式恢复（`scripts/restore.py`）是文件级替换，恢复后数据库回到备份时刻的状态——备份之后发生的遗忘/删除自然"丢失"，需要重新执行。

因此：数据库内的遗忘/删除与数据库外的备份保留是**两套独立机制**；要减少历史副本中的敏感数据，必须自行清理旧备份/导出（见 [备份文档](backup.md#12-已知限制请纳入你的威胁模型)）。
