# HeartLog · 心迹

> 安静地记录，诚实地记得。

HeartLog 是一个**本地优先的情绪日记与长期记忆系统**。它不只保存“今天发生了什么”，也保存你如何理解自己：日记原文与后续修订分开存放，每一条长期记忆都保留具体日记版本和证据片段；事实、感受、观点与 AI 推断彼此区分，不互相冒充。

它默认单用户、本地运行，不要求账号，也不把私人情绪上传到云端。AI 是可选能力：未启用时只呈现本地统计，不编造回顾；启用后，每条结论仍应能回到真实来源。

前端是 React SPA，已适配 PWA，可安装到手机主屏幕；后端是 FastAPI + SQLAlchemy + SQLite。

---

## 为什么是 HeartLog

很多日记工具只关心“写下来”，但时间久了，真正难的是**重新理解**：

- 当时写下的原文，会不会在后来被悄悄改写？
- 一条“长期记忆”到底来自哪一天、哪一句话？
- 哪些是事实，哪些只是当时的感受，哪些是模型猜的？
- 当我们不再需要一段记忆时，能不能真的让它离开？

HeartLog 围绕这些问题设计：原文不可变、修订可追溯、记忆有来源、推断不冒充事实、删除有明确语义。

## 特性

- **原文与修订分离**：正文可以编辑，但首次保存的原文不会被覆盖；每次保存都会追加修订版本。
- **可追溯的长期记忆**：记忆分为明确事实、主观感受、明确观点、模型推断，并保留来源日记、版本和证据片段。
- **来源可跳转**：从记忆回到原日记当时的历史版本；人物时间线也保留证据。
- **本地优先**：数据默认存放在本机 SQLite，不依赖云账号、云同步或第三方数据库。
- **AI 可选**：记忆候选提取、陪伴对话、周/月回顾可接入外部模型；未配置时明确降级，不伪造 AI 输出。
- **PWA**：包含 manifest、Service Worker、主屏幕图标，可像普通 App 一样打开。
- **隐私与遗忘**：支持撤回、更正、软删除、永久遗忘，以及完整数据导出。
- **克制的界面**：暖白纸张感、低饱和情绪色、编辑体引言和少量 Liquid Glass，而不是传统后台 Dashboard。

## 技术栈

| 层 | 技术 |
| --- | --- |
| 前端 | React 19、TypeScript、Vite 6、Tailwind CSS、Motion、Lucide React、React Router |
| PWA | `vite-plugin-pwa` / Workbox（manifest、Service Worker、主屏幕图标） |
| 后端 | Python 3.11+、FastAPI、Uvicorn、Pydantic v2 |
| 数据 | SQLAlchemy 2、SQLite、Alembic |
| 数据完整性 | SQLite 触发器、不可变原文/修订、哈希链 |
| 测试与质量 | pytest、ruff；前端 `tsc --noEmit` + Vite build |
| 运维 | 备份/恢复/加密脚本、限流、可选 API Token、Nginx/Caddy/systemd 参考配置 |

## 快速开始

### 1. 后端

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp env.example .env              # 按需修改；不要把 .env 提交到 GitHub
python -m alembic upgrade head
uvicorn "app.main:create_app" --factory --host 127.0.0.1 --port 8000
```

后端 API 文档：<http://127.0.0.1:8000/docs>  
健康检查：<http://127.0.0.1:8000/health>

> 建议新库先执行 `alembic upgrade head`，再启动应用。`HEARTLOG_AUTO_CREATE_SCHEMA` 仅作为临时库/测试的兜底，不应与 Alembic 混用。

### 2. 前端

```bash
cd frontend
npm install
cp env.example .env.local        # 可选
npm run dev                      # http://127.0.0.1:5173
```

开发服务器会把 `/api`、`/health`、`/docs` 等请求代理到 `http://127.0.0.1:8000`，因此本地开发不需要后端额外开启 CORS。

### 3. PWA / 手机安装

```bash
cd frontend
npm run build
npm run preview:lan              # 监听 0.0.0.0:4173
```

手机与电脑连接同一 Wi-Fi，打开 `http://<电脑局域网 IP>:4173`：

- iPhone / Safari：分享 → 添加到主屏幕
- Android / Chrome：菜单 → 安装应用 / 添加到主屏幕
- 页面“我的 → PWA · 本地安装”也提供安装步骤

> Service Worker 和完整 PWA 离线安装通常要求 HTTPS（`localhost` 例外）。局域网 HTTP 可以添加到主屏幕并正常打开界面；完整离线缓存需要 TLS/HTTPS。PWA 只缓存前端静态资源，不缓存日记/记忆 API 响应。

## 配置

后端配置从 `.env` 读取，模板见 [`env.example`](env.example)。复制后按需修改：

```bash
cp env.example .env
```

常用配置：

| 变量 | 默认 | 说明 |
| --- | --- | --- |
| `HEARTLOG_DATABASE_URL` | `sqlite:///./data/heartlog.db` | 本地 SQLite 路径 |
| `HEARTLOG_ENVIRONMENT` | `local` | `local` / `test` / `staging` / `production` |
| `HEARTLOG_API_TOKEN` | 空 | 设置后 API 需要 Bearer Token |
| `HEARTLOG_ADMIN_TOKEN` | 空 | 永久删除管理令牌；未设置时永久删除禁用 |
| `HEARTLOG_AI_ENABLED` | `false` | 外部 AI 总开关 |
| `HEARTLOG_AI_CONSENT` | `false` | 必须显式同意后才会发送私人文本 |
| `HEARTLOG_AI_PROVIDER` | `disabled` | 可选 `openai_compatible` / `mock` / `disabled` |
| `HEARTLOG_RATE_LIMIT_ENABLED` | `false` | 应用内限流 |

前端配置见 [`frontend/env.example`](frontend/env.example)：`VITE_API_BASE_URL` 留空表示同源，`VITE_API_PROXY_TARGET` 是开发代理目标。

> 不要提交真实的 `.env`、API Key、Token 或数据库文件。

## 目录结构

```text
heartlog/
├── app/                  # FastAPI 应用、路由、服务、仓储、模型
├── alembic/              # 数据库迁移
├── tests/                # pytest 测试
├── scripts/              # 备份、恢复、导出、校验、证书等脚本
├── deploy/               # Nginx / Caddy / systemd 参考配置
├── docs/                 # 架构、数据库、隐私、API、运维、部署文档
├── frontend/             # React + TypeScript + PWA
│   ├── src/
│   │   ├── pages/        # Dashboard、日记、记忆、回顾、我的
│   │   ├── components/   # UI、布局、PWA 安装入口
│   │   ├── api/          # 同源 API Client
│   │   └── lib/           # 日期、心情、演示数据
│   ├── public/icons/     # PWA 图标
│   └── vite.config.ts    # 开发/预览代理与 PWA 配置
├── env.example
├── requirements.txt
└── pyproject.toml
```

## 设计与事实边界

- **原文不可变**：数据库层面保护首次保存的正文和哈希；编辑只会产生新修订。
- **记忆不是事实**：`model_inference` 始终以推断形式展示，即使被用户确认，也不会自动变成客观事实。
- **AI 默认关闭**：未配置时，记忆提取不可用，周/月回顾使用本地统计，陪伴对话显示占位说明。
- **删除有边界**：软删除、撤回、永久遗忘是不同语义；遗忘不会自动清理历史备份/导出文件。
- **单用户、本地优先**：没有云账号、云同步或多用户隔离；API Token 只是可选的访问控制，不等同于完整多用户认证。
- **不是医疗工具**：HeartLog 不提供心理诊断或治疗建议。

## 文档

- [架构设计](docs/architecture.md)
- [数据库设计](docs/database_design.md)
- [API 参考](docs/api.md)
- [隐私说明](docs/privacy.md)
- [备份与恢复](docs/backup.md)
- [运维说明](docs/operations.md)
- [部署安全](docs/deployment_security.md)
- [前端说明](frontend/README.md)

## 状态

前后端已经完成基础实现并本地跑通：日记/修订、记忆/来源、人物时间线、搜索、周月回顾、导出、遗忘、备份脚本、PWA 外壳与安装入口。

尚未覆盖：真实外部 AI 调用的端到端验证、真实生产 Nginx/Caddy/systemd 联调、自动化前端 E2E 测试。欢迎在这些方向上继续完善。

## 说明

这个项目是一个本地优先的个人工具，不是一套面向公网的多租户 SaaS。若部署到局域网或公网，请先阅读隐私与部署安全文档，并自行配置 TLS、认证和防火墙。
