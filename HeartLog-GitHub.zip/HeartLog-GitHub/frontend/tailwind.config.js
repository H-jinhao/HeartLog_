/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ["class", '[data-theme="dark"]'],
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        canvas: "rgb(var(--canvas) / <alpha-value>)",
        surface: "rgb(var(--surface) / <alpha-value>)",
        elevated: "rgb(var(--elevated) / <alpha-value>)",
        ink: "rgb(var(--ink) / <alpha-value>)",
        muted: "rgb(var(--muted) / <alpha-value>)",
        subtle: "rgb(var(--subtle) / <alpha-value>)",
        line: "rgb(var(--line) / <alpha-value>)",
        lavender: "rgb(var(--lavender) / <alpha-value>)",
        rose: "rgb(var(--rose) / <alpha-value>)",
        sage: "rgb(var(--sage) / <alpha-value>)",
        champagne: "rgb(var(--champagne) / <alpha-value>)",
        mist: "rgb(var(--mist) / <alpha-value>)",
      },
      fontFamily: {
        sans: [
          "-apple-system",
          "BlinkMacSystemFont",
          "SF Pro Display",
          "SF Pro Text",
          "PingFang SC",
          "Hiragino Sans GB",
          "Microsoft YaHei",
          "sans-serif",
        ],
        editorial: [
          "Iowan Old Style",
          "Palatino Linotype",
          "Book Antiqua",
          "Songti SC",
          "STSong",
          "Noto Serif CJK SC",
          "serif",
        ],
        mono: ["SFMono-Regular", "Cascadia Code", "Menlo", "monospace"],
      },
      borderRadius: {
        "4xl": "28px",
        "3xl": "24px",
        "2xl": "20px",
        "1.5xl": "18px",
      },
      boxShadow: {
        glass:
          "0 18px 50px -18px rgba(35, 30, 42, 0.22), 0 2px 8px rgba(35, 30, 42, 0.04), inset 0 1px 0 rgba(255,255,255,0.72)",
        "glass-sm":
          "0 8px 24px -10px rgba(35, 30, 42, 0.18), inset 0 1px 0 rgba(255,255,255,0.7)",
        lift: "0 24px 70px -28px rgba(35, 30, 42, 0.32)",
        soft: "0 10px 30px -18px rgba(35, 30, 42, 0.2)",
        "inner-soft": "inset 0 1px 1px rgba(255,255,255,0.7)",
      },
      transitionTimingFunction: {
        silk: "cubic-bezier(0.22, 1, 0.36, 1)",
      },
      keyframes: {
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
        "soft-pulse": {
          "0%, 100%": { opacity: "0.55" },
          "50%": { opacity: "0.9" },
        },
      },
      animation: {
        shimmer: "shimmer 1.8s linear infinite",
        "soft-pulse": "soft-pulse 3.2s ease-in-out infinite",
      },
    },
  },
  plugins: [],
};
