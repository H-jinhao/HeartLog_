import clsx, { type ClassValue } from "clsx";

export function cn(...values: ClassValue[]): string {
  return clsx(values);
}

const CHINESE_WEEKDAYS = ["日", "一", "二", "三", "四", "五", "六"];

export function toDate(value: string | Date): Date {
  return value instanceof Date ? value : new Date(value);
}

export function isSameDay(a: Date, b: Date): boolean {
  return (
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  );
}

export function isToday(value: string | Date): boolean {
  return isSameDay(toDate(value), new Date());
}

export function isYesterday(value: string | Date): boolean {
  const date = new Date();
  date.setDate(date.getDate() - 1);
  return isSameDay(toDate(value), date);
}

export function formatDate(
  value: string | Date,
  options: Intl.DateTimeFormatOptions = {},
): string {
  return new Intl.DateTimeFormat("zh-CN", {
    year: "numeric",
    month: "long",
    day: "numeric",
    ...options,
  }).format(toDate(value));
}

export function formatDateShort(value: string | Date): string {
  return new Intl.DateTimeFormat("zh-CN", {
    month: "2-digit",
    day: "2-digit",
  }).format(toDate(value));
}

export function formatDateNumeric(value: string | Date): string {
  return new Intl.DateTimeFormat("zh-CN", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  })
    .format(toDate(value))
    .replaceAll("/", ".");
}

export function formatWeekday(value: string | Date): string {
  return `星期${CHINESE_WEEKDAYS[toDate(value).getDay()]}`;
}

export function formatTime(value: string | Date): string {
  return new Intl.DateTimeFormat("zh-CN", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(toDate(value));
}

export function formatMonthDay(value: string | Date): string {
  return new Intl.DateTimeFormat("zh-CN", {
    month: "long",
    day: "numeric",
  }).format(toDate(value));
}

export function formatRelativeDay(value: string | Date): string {
  const date = toDate(value);
  if (isToday(date)) return "今天";
  if (isYesterday(date)) return "昨天";
  const diff = Date.now() - date.getTime();
  if (diff >= 0 && diff < 7 * 24 * 60 * 60 * 1000) {
    return formatWeekday(date);
  }
  return formatDate(date, { year: "numeric" });
}

export function formatDateGroup(value: string | Date): string {
  const date = toDate(value);
  if (isToday(date)) return "今天";
  if (isYesterday(date)) return "昨天";
  return formatDate(date, { year: "numeric" });
}

export function dayNumber(value: string | Date): string {
  return String(toDate(value).getDate()).padStart(2, "0");
}

export function getGreeting(date = new Date()): string {
  const hour = date.getHours();
  if (hour < 6) return "夜深了。";
  if (hour < 11) return "早上好。";
  if (hour < 14) return "中午好。";
  if (hour < 18) return "下午好。";
  return "晚上好。";
}

export function getGreetingSubline(date = new Date()): string {
  const hour = date.getHours();
  if (hour < 6) return "把还没睡着的念头，轻轻放在这里。";
  if (hour < 11) return "给今天的自己，留一点时间。";
  if (hour < 14) return "慢一点，也没关系。";
  if (hour < 18) return "今天已经走了很远，停一停吧。";
  return "把今天收好，再交给夜晚。";
}

export function countCharacters(value: string): number {
  return value.replace(/\s/g, "").length;
}

export function collapseWhitespace(value: string): string {
  return value.replace(/\s+/g, " ").trim();
}

export function truncate(value: string, max = 90): string {
  if (value.length <= max) return value;
  return `${value.slice(0, max).trimEnd()}…`;
}

export function initials(name: string): string {
  const trimmed = name.trim();
  if (!trimmed) return "你";
  return Array.from(trimmed)[0] ?? "你";
}

export function startOfWeek(date = new Date()): Date {
  const copy = new Date(date);
  const day = copy.getDay() || 7;
  copy.setHours(0, 0, 0, 0);
  copy.setDate(copy.getDate() - day + 1);
  return copy;
}

export function addDays(date: Date, amount: number): Date {
  const copy = new Date(date);
  copy.setDate(copy.getDate() + amount);
  return copy;
}

export function isoDate(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function relativeTimeLabel(value: string | Date): string {
  const date = toDate(value);
  const diff = Date.now() - date.getTime();
  if (diff < 60_000) return "刚刚";
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)} 分钟前`;
  if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)} 小时前`;
  const days = Math.floor(diff / 86_400_000);
  if (days < 7) return `${days} 天前`;
  return formatDateShort(date);
}

export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function getInitialTheme(): "light" | "dark" {
  if (typeof document === "undefined") return "light";
  return document.documentElement.dataset.theme === "dark" ? "dark" : "light";
}

export function smoothScrollToTop(): void {
  window.scrollTo({ top: 0, behavior: "smooth" });
}
