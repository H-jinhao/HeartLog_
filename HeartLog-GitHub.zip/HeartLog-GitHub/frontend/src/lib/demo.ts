import type {
  DiaryDetail,
  DiaryListItem,
  InsightResponse,
  MemoryOut,
  MemorySourceOut,
  MemoryType,
  MoodKey,
  PersonOut,
  RevisionOut,
  SearchResponse,
  VerificationStatus,
} from "@/types/api";
import { MOODS } from "@/lib/moods";

const now = new Date();

function atDaysAgo(days: number, hour = 21, minute = 18): Date {
  const date = new Date(now);
  date.setDate(date.getDate() - days);
  date.setHours(hour, minute, 0, 0);
  return date;
}

function iso(date: Date): string {
  return date.toISOString();
}

function hash(seed: string): string {
  // Demo-only placeholder hash. Real data always comes from the backend.
  return `demo${seed.replace(/[^a-z0-9]/gi, "").padEnd(60, "0")}`.slice(0, 64);
}

const moodMap = new Map(MOODS.map((mood) => [mood.key, mood]));

function makeRevision(
  entryId: string,
  version: number,
  content: string,
  createdAt: Date,
  previousHash: string | null,
  changeReason: string | null = null,
): RevisionOut {
  return {
    id: `${entryId}-rev-${version}`,
    entry_id: entryId,
    version,
    content,
    content_hash: hash(`${entryId}-${version}-${content}`),
    previous_revision_hash: previousHash,
    change_reason: changeReason,
    created_at: iso(createdAt),
  };
}

interface DemoDiaryInput {
  id: string;
  daysAgo: number;
  hour?: number;
  content: string;
  originalContent?: string;
  changeReason?: string;
  mood: MoodKey;
}

function makeDiary(input: DemoDiaryInput): DiaryDetail {
  const createdAt = atDaysAgo(input.daysAgo, input.hour ?? 21);
  const original = input.originalContent ?? input.content;
  const version = input.originalContent ? 2 : 1;
  const rev1 = makeRevision(input.id, 1, original, createdAt, null, "初始版本");
  const revisions = [rev1];
  let current = rev1;
  if (version === 2) {
    current = makeRevision(
      input.id,
      version,
      input.content,
      new Date(createdAt.getTime() + 12 * 60 * 1000),
      rev1.content_hash,
      input.changeReason ?? "补充了后来的感受",
    );
    revisions.push(current);
  }
  const metadata = {
    mood: input.mood,
    moodScore: moodMap.get(input.mood)?.score,
  };
  return {
    id: input.id,
    original_text: original,
    original_content_hash: rev1.content_hash,
    current_version: version,
    current_revision_id: current.id,
    created_at: iso(createdAt),
    updated_at: current.created_at,
    deleted_at: null,
    is_deleted: false,
    metadata,
    current_content: input.content,
    current_revision: current,
  };
}

const diarySeeds: DemoDiaryInput[] = [
  {
    id: "demo-diary-today",
    daysAgo: 0,
    hour: 8,
    mood: "calm",
    content:
      "今天醒得比闹钟早。窗帘缝里有一小条很淡的阳光，落在书脊上。\n\n没有急着起来，听了一会儿楼下推着车卖早餐的声音。心里很安静。最近总在想，所谓把生活过好，也许不是什么宏大的事，而是记得给自己倒一杯温水，记得在出门前看一眼天空。\n\n晚上想早点回来，把昨天没读完的那几页读完。",
  },
  {
    id: "demo-diary-yesterday",
    daysAgo: 1,
    mood: "tender",
    originalContent:
      "傍晚沿着河边走了很久。风有点凉，水面被吹出很细的皱纹。\n\n想起一些很久以前的事情。",
    content:
      "傍晚沿着河边走了很久。风有点凉，水面被吹出很细的皱纹。\n\n想起一些很久以前的事情。那时候总以为长大以后会变得很笃定，后来才发现，所谓成长可能只是学会和自己的犹豫一起走路。\n\n回来的路上买了一束白色的小花，插在厨房的玻璃杯里。房间忽然有了一点春天。",
    changeReason: "散步回来，又想起了一些",
  },
  {
    id: "demo-diary-two",
    daysAgo: 2,
    hour: 20,
    mood: "bright",
    content:
      "和小林吃了顿很慢的晚饭。她讲起最近在学陶艺，手上还沾着一点干掉的泥。\n\n我们笑得很没有内容，但那种松弛很难得。回家的地铁上，我把窗户上的倒影看了很久。原来被朋友记得，是一件会让人悄悄变得有力量的事。",
  },
  {
    id: "demo-diary-four",
    daysAgo: 4,
    hour: 23,
    mood: "low",
    content:
      "今天效率很低。上午的会开得有些长，下午对着文档发了很久的呆。\n\n有一瞬间觉得自己在原地打转。但晚上把桌子收拾干净，洗了杯子，忽然又觉得，至少今天没有完全被浪费。\n\n先睡吧。明天再想。",
  },
  {
    id: "demo-diary-week",
    daysAgo: 7,
    hour: 18,
    mood: "calm",
    content:
      "把夏天的衣服收进箱子，翻出去年的一件薄外套。口袋里有一张已经褪色的电影票。\n\n记不清那天看了什么，只记得散场以后下过雨。时间大概就是这样，把一些细节弄丢，又留下一些没有用的小东西。",
  },
  {
    id: "demo-diary-ten",
    daysAgo: 10,
    hour: 22,
    mood: "tired",
    content:
      "连续加了几天班，脑子像一块吸满水的海绵。\n\n没有力气做晚饭，只热了一杯牛奶。坐在窗边的时候，忽然很想给妈妈打个电话，但看看时间又放下了。\n\n周末一定要好好睡一觉。",
  },
  {
    id: "demo-diary-old",
    daysAgo: 18,
    hour: 16,
    mood: "bright",
    content:
      "下午请了半天假，去看了那个一直想看的展。展厅里人不多，有一面墙全是蓝色的画。\n\n站在那面墙前面的时候，突然想起小时候很喜欢把天空画成一整块没有云的蓝。后来不知道为什么，画画这件事就被放下了。\n\n出来的时候买了一支铅笔。也许重新开始，不用等到一个特别好的日子。",
  },
  {
    id: "demo-diary-older",
    daysAgo: 27,
    hour: 20,
    mood: "tender",
    content:
      "给家里打了电话。妈妈说院子里的桂花开了。\n\n我们聊了二十多分钟，都是很小的事情：邻居家的猫、最近降价的菜、她新学会的一道汤。挂掉电话以后，房间显得格外安静。\n\n有些想念，是挂掉电话那一刻才慢慢浮上来的。",
  },
];

const initialDiaries = diarySeeds.map(makeDiary);

const diaryById = new Map(initialDiaries.map((diary) => [diary.id, diary]));

function revisionFor(diaryId: string, version: number): RevisionOut {
  const diary = diaryById.get(diaryId) ?? initialDiaries[0];
  if (version === 2 && diary.current_version >= 2 && diary.current_revision) {
    return diary.current_revision;
  }
  return makeRevision(
    diary.id,
    1,
    diary.original_text,
    new Date(diary.created_at),
    null,
    "初始版本",
  );
}

function source(
  memoryId: string,
  entryId: string,
  version: number,
  evidence: string,
): MemorySourceOut {
  const revision = revisionFor(entryId, version);
  return {
    id: `${memoryId}-source`,
    memory_id: memoryId,
    entry_id: entryId,
    revision_id: revision.id,
    evidence_text: evidence,
    start_offset: null,
    end_offset: null,
    created_at: revision.created_at,
  };
}

function memory(
  id: string,
  content: string,
  memoryType: MemoryType,
  entryId: string,
  evidence: string,
  status: VerificationStatus,
  version = 1,
  createdAt = atDaysAgo(1),
): MemoryOut {
  const mapped = moodMap.get("calm");
  return {
    id,
    content,
    content_hash: hash(`${id}-${content}`),
    memory_type: memoryType,
    source_type: memoryType === "model_inference" ? "diary_entry" : "diary_entry",
    confidence: memoryType === "model_inference" ? 0.72 : 0.9,
    verification_status: status,
    is_active: !["revoked", "superseded"].includes(status),
    created_by: memoryType === "model_inference" ? "model" : "model",
    confirmed_by: status === "confirmed" ? "user" : null,
    confirmed_at: status === "confirmed" ? iso(createdAt) : null,
    revoked_at: null,
    supersedes_memory_id: null,
    source_entry_id: entryId,
    source_revision_id: revisionFor(entryId, version).id,
    source_version: version,
    source_entry_deleted: false,
    created_at: iso(createdAt),
    updated_at: iso(createdAt),
    metadata: {
      demo: true,
      mood: mapped?.label,
    },
    sources: [source(id, entryId, version, evidence)],
  };
}

const initialMemories: MemoryOut[] = [
  memory(
    "demo-memory-river",
    "傍晚沿着河边散步时，用户留意到风、水面和旧日的回忆，并为成长中的不确定感找到了一种更温和的理解。",
    "subjective_feeling",
    "demo-diary-yesterday",
    "想起一些很久以前的事情",
    "pending",
    2,
    atDaysAgo(1, 23),
  ),
  memory(
    "demo-memory-lin",
    "小林正在学陶艺。",
    "explicit_fact",
    "demo-diary-two",
    "她讲起最近在学陶艺",
    "confirmed",
    1,
    atDaysAgo(2, 22),
  ),
  memory(
    "demo-memory-friend",
    "被朋友记得，会让用户感到有力量。",
    "subjective_feeling",
    "demo-diary-two",
    "被朋友记得，是一件会让人悄悄变得有力量的事",
    "confirmed",
    1,
    atDaysAgo(2, 22),
  ),
  memory(
    "demo-memory-growth",
    "用户倾向于认为，成长不是变得笃定，而是学会和不确定一起生活。",
    "explicit_belief",
    "demo-diary-yesterday",
    "所谓成长可能只是学会和自己的犹豫一起走路",
    "pending",
    2,
    atDaysAgo(1, 23),
  ),
  memory(
    "demo-memory-blues",
    "用户小时候喜欢把天空画成没有云的蓝色。",
    "explicit_fact",
    "demo-diary-old",
    "小时候很喜欢把天空画成一整块没有云的蓝",
    "confirmed",
    1,
    atDaysAgo(18, 18),
  ),
  memory(
    "demo-memory-call",
    "给家里打电话后，用户在安静里感到想念。",
    "subjective_feeling",
    "demo-diary-older",
    "有些想念，是挂掉电话那一刻才慢慢浮上来的",
    "confirmed",
    1,
    atDaysAgo(27, 22),
  ),
  memory(
    "demo-memory-inference",
    "用户可能更在意关系中的细微信号与被回应的感觉，但这一点尚未由用户确认，只是基于近期记录的推断。",
    "model_inference",
    "demo-diary-today",
    "心里很安静",
    "pending",
    1,
    atDaysAgo(0, 8),
  ),
  memory(
    "demo-memory-rain",
    "那年散场以后下过雨（具体日期已无法从记录确认）。",
    "explicit_fact",
    "demo-diary-week",
    "只记得散场以后下过雨",
    "pending",
    1,
    atDaysAgo(7, 20),
  ),
];

const initialPersons: PersonOut[] = [
  {
    id: "demo-person-lin",
    display_name: "小林",
    aliases: ["林林"],
    source_entry_id: "demo-diary-two",
    source_revision_id: revisionFor("demo-diary-two", 1).id,
    source_evidence: "和小林吃了顿很慢的晚饭",
    created_at: iso(atDaysAgo(2, 22)),
    updated_at: iso(atDaysAgo(2, 22)),
  },
  {
    id: "demo-person-mom",
    display_name: "妈妈",
    aliases: [],
    source_entry_id: "demo-diary-older",
    source_revision_id: revisionFor("demo-diary-older", 1).id,
    source_evidence: "妈妈说院子里的桂花开了",
    created_at: iso(atDaysAgo(27, 22)),
    updated_at: iso(atDaysAgo(27, 22)),
  },
];

let diaries = structuredClone(initialDiaries);
let memories = structuredClone(initialMemories);
let persons = structuredClone(initialPersons);

export function resetDemoStore(): void {
  diaries = structuredClone(initialDiaries);
  memories = structuredClone(initialMemories);
  persons = structuredClone(initialPersons);
}

export function getDemoDiaries(): DiaryDetail[] {
  return [...diaries].sort(
    (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime(),
  );
}

export function getDemoDiary(id: string): DiaryDetail | undefined {
  return diaries.find((diary) => diary.id === id);
}

export function demoDiaryToListItem(diary: DiaryDetail): DiaryListItem {
  return {
    id: diary.id,
    preview: diary.current_content,
    original_preview: diary.original_text,
    current_version: diary.current_version,
    created_at: diary.created_at,
    updated_at: diary.updated_at,
    deleted_at: diary.deleted_at,
    is_deleted: diary.is_deleted,
    metadata: diary.metadata,
  };
}

export function getDemoDiaryList(): DiaryListItem[] {
  return getDemoDiaries().map(demoDiaryToListItem);
}

export function createDemoDiary(content: string, metadata: Record<string, unknown>): DiaryDetail {
  const createdAt = new Date();
  const id = `demo-diary-${Date.now()}`;
  const revision = makeRevision(id, 1, content, createdAt, null, "初始版本");
  const diary: DiaryDetail = {
    id,
    original_text: content,
    original_content_hash: revision.content_hash,
    current_version: 1,
    current_revision_id: revision.id,
    created_at: iso(createdAt),
    updated_at: iso(createdAt),
    deleted_at: null,
    is_deleted: false,
    metadata,
    current_content: content,
    current_revision: revision,
  };
  diaries.unshift(diary);
  diaryById.set(id, diary);
  return diary;
}

export function updateDemoDiary(
  id: string,
  content: string,
  metadata?: Record<string, unknown>,
): DiaryDetail {
  const diary = diaries.find((item) => item.id === id);
  if (!diary) throw new Error("演示日记不存在");
  const nextVersion = diary.current_version + 1;
  const previousHash = diary.current_revision?.content_hash ?? diary.original_content_hash;
  const revision = makeRevision(id, nextVersion, content, new Date(), previousHash, "编辑");
  diary.current_version = nextVersion;
  diary.current_revision_id = revision.id;
  diary.current_revision = revision;
  diary.current_content = content;
  diary.updated_at = revision.created_at;
  if (metadata) diary.metadata = metadata;
  diaryById.set(id, diary);
  return diary;
}

export function deleteDemoDiary(id: string): void {
  diaries = diaries.filter((diary) => diary.id !== id);
}

export function getDemoRevisions(id: string): RevisionOut[] {
  const diary = diaries.find((item) => item.id === id);
  if (!diary) return [];
  const current = diary.current_revision;
  if (!current) return [];
  if (current.version === 1) return [current];
  return [
    makeRevision(
      diary.id,
      1,
      diary.original_text,
      new Date(diary.created_at),
      null,
      "初始版本",
    ),
    current,
  ];
}

export function getDemoMemories(): MemoryOut[] {
  return [...memories];
}

export function getDemoPersons(): PersonOut[] {
  return [...persons];
}

export function updateDemoMemoryStatus(id: string, status: VerificationStatus): MemoryOut | null {
  const found = memories.find((item) => item.id === id);
  if (!found) return null;
  found.verification_status = status;
  found.is_active = !["revoked", "superseded"].includes(status);
  found.confirmed_by = status === "confirmed" ? "user" : null;
  found.confirmed_at = status === "confirmed" ? iso(new Date()) : null;
  found.revoked_at = status === "revoked" ? iso(new Date()) : null;
  return found;
}

export function updateDemoMemoryContent(id: string, content: string): MemoryOut | null {
  const found = memories.find((item) => item.id === id);
  if (!found) return null;
  found.content = content;
  found.content_hash = hash(`${found.id}-${content}-${Date.now()}`);
  found.verification_status = "confirmed";
  found.confirmed_by = "user";
  found.confirmed_at = iso(new Date());
  return found;
}

export function removeDemoMemory(id: string): void {
  memories = memories.filter((item) => item.id !== id);
}

export function getDemoSearch(query: string): SearchResponse {
  const normalised = query.trim().toLowerCase();
  const diaryHits = diaries
    .filter((diary) => diary.current_content.toLowerCase().includes(normalised))
    .map((diary) => ({
      kind: "diary" as const,
      snippet: diary.current_content.slice(0, 120),
      created_at: diary.created_at,
      entry_id: diary.id,
      revision_id: diary.current_revision_id ?? "",
      version: diary.current_version,
      is_current: true,
      memory_id: null,
      memory_type: null,
      verification_status: null,
      confidence: null,
    }));
  const memoryHits = memories
    .filter((item) => item.content.toLowerCase().includes(normalised))
    .map((item) => ({
      kind: "memory" as const,
      snippet: item.content.slice(0, 120),
      created_at: item.created_at,
      entry_id: item.source_entry_id,
      revision_id: item.source_revision_id,
      version: item.source_version ?? 1,
      is_current: true,
      memory_id: item.id,
      memory_type: item.memory_type,
      verification_status: item.verification_status,
      confidence: item.confidence,
    }));
  const items = [...diaryHits, ...memoryHits].sort(
    (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime(),
  );
  return {
    query: query.trim(),
    scope: "all",
    include_history: true,
    include_deleted_sources: false,
    total: items.length,
    limit: 20,
    offset: 0,
    has_more: false,
    items,
  };
}

export function getDemoInsight(period: "weekly" | "monthly"): InsightResponse {
  const days = period === "weekly" ? 7 : 30;
  const start = new Date();
  start.setDate(start.getDate() - days);
  const inPeriod = diaries.filter((diary) => new Date(diary.created_at) >= start);
  const counts = new Map<MemoryType, number>();
  for (const item of memories) {
    counts.set(item.memory_type, (counts.get(item.memory_type) ?? 0) + 1);
  }
  const end = new Date();
  return {
    mode: "local_statistics",
    ai_used: false,
    period: {
      period,
      start: start.toISOString(),
      end: end.toISOString(),
      reference_date: end.toISOString().slice(0, 10),
      timezone: "UTC",
    },
    statistics: {
      diary_entries: inPeriod.length,
      memories: memories.length,
      memory_type_counts: [...counts.entries()].map(([memory_type, count]) => ({
        memory_type,
        count,
      })),
    },
    narrative: null,
    sources: [],
    notes: [
      "演示模式：这些统计来自固定演示数据，不是你的真实记录。",
      "AI 回顾未启用时，HeartLog 只展示本地统计，不会编造回顾。",
    ],
    disclaimer:
      "HeartLog 不是心理治疗、医疗诊断或危机干预工具；本回顾仅供参考。若你处于危险中，请联系当地紧急服务或可信任的专业心理支持。",
    provider: null,
    model: null,
  };
}

export const demoProfile = {
  name: "林深",
  signature: "把日子慢慢过成自己的样子",
};
