import type { DiaryMetadata, MoodKey, MoodMeta } from "@/types/api";

export const MOODS: MoodMeta[] = [
  {
    key: "bright",
    label: "明亮",
    shortLabel: "明亮",
    description: "轻盈、有光、愿意靠近世界",
    score: 5,
    color: "rgb(var(--champagne))",
  },
  {
    key: "calm",
    label: "平静",
    shortLabel: "平静",
    description: "像一杯放温的水，安稳而清晰",
    score: 4,
    color: "rgb(var(--sage))",
  },
  {
    key: "tender",
    label: "柔软",
    shortLabel: "柔软",
    description: "有些触动，也有很多感受",
    score: 3,
    color: "rgb(var(--lavender))",
  },
  {
    key: "low",
    label: "低落",
    shortLabel: "低落",
    description: "情绪有些沉，需要被轻轻接住",
    score: 2,
    color: "rgb(var(--rose))",
  },
  {
    key: "tired",
    label: "疲惫",
    shortLabel: "疲惫",
    description: "身体和心都想慢下来",
    score: 1,
    color: "rgb(var(--mist))",
  },
];

const MOOD_MAP = new Map(MOODS.map((mood) => [mood.key, mood]));

export function isMoodKey(value: unknown): value is MoodKey {
  return typeof value === "string" && MOOD_MAP.has(value as MoodKey);
}

export function getMood(key: MoodKey | null | undefined): MoodMeta | undefined {
  return key ? MOOD_MAP.get(key) : undefined;
}

export function getMoodFromMetadata(metadata?: DiaryMetadata | null): MoodMeta | undefined {
  if (!metadata) return undefined;
  return isMoodKey(metadata.mood) ? MOOD_MAP.get(metadata.mood) : undefined;
}

export function moodScore(key: MoodKey | null | undefined): number | undefined {
  return key ? getMood(key)?.score : undefined;
}

export function moodLabel(key: MoodKey | null | undefined): string {
  return key ? getMood(key)?.label ?? "" : "";
}

export const MOOD_KEYS = MOODS.map((mood) => mood.key);
