import { lazy, Suspense } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { AppShell } from "@/components/layout/AppShell";
import { PageSkeleton } from "@/components/ui/Skeleton";

const DashboardPage = lazy(() => import("@/pages/DashboardPage"));
const DiaryPage = lazy(() => import("@/pages/DiaryPage"));
const DiaryDetailPage = lazy(() => import("@/pages/DiaryDetailPage"));
const MemoriesPage = lazy(() => import("@/pages/MemoriesPage"));
const InsightsPage = lazy(() => import("@/pages/InsightsPage"));
const ProfilePage = lazy(() => import("@/pages/ProfilePage"));
const NotFoundPage = lazy(() => import("@/pages/NotFoundPage"));

export default function App() {
  return (
    <BrowserRouter>
      <Suspense fallback={<div className="px-1 pt-6"><PageSkeleton /></div>}>
        <Routes>
          <Route element={<AppShell />}>
            <Route index element={<DashboardPage />} />
            <Route path="diary" element={<DiaryPage />} />
            <Route path="diary/:id" element={<DiaryDetailPage />} />
            <Route path="memories" element={<MemoriesPage />} />
            <Route path="insights" element={<InsightsPage />} />
            <Route path="profile" element={<ProfilePage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Route>
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
}
