import { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowRight,
  ArrowUpRight,
  CalendarDays,
  ChartNoAxesColumn,
  Check,
  MessageCircle,
  PenLine,
  Sparkles,
} from "lucide-react";
import { useApp } from "@/context/AppContext";
import { listDiaries } from "@/api/diaries";
import { listMemories } from "@/api/memories";
import { getDemoDiaries, getDemoMemories, demoDiaryToListItem } from "@/lib/demo";
import type { DiaryListItem, MemoryOut, MoodKey } from "@/types/api";
import { getMood, getMoodFromMetadata, MOODS } from "@/lib/moods";
import {
  collapseWhitespace,
  countCharacters,
  formatDate,
  formatRelativeDay,
  formatWeekday,
  getGreeting,
  getGreetingSubline,
  isSameDay,
  startOfWeek,
  toDate,
} from "@/lib/utils";
import { GlassPanel } from "@/components/ui/GlassPanel";
import { SurfaceCard } from "@/components/ui/SurfaceCard";
import { Button } from "@/components/ui/Button";
import { MoodPicker } from "@/components/diary/MoodPicker";
import { MoodChart, type MoodPoint } from "@/components/insights/MoodChart";
import { PageSkeleton } from "@/components/ui/Skeleton";
import { ErrorState } from "@/components/ui/ErrorState";
import { EmptyState } from "@/components/ui/EmptyState";
import { CompanionSheet } from "@/components/common/CompanionSheet";
import { MemoryTypeBadge } from "@/components/memory/MemoryBadges";
import { cn } from "@/lib/utils";

interface DashboardData {
  diaries: DiaryListItem[];
  memories: MemoryOut[];
  totalDiaries: number;
  totalMemories: number;
}

export default function DashboardPage() {
  const {
    demoMode,
    backend,
    dataVersion,
    profileName,
    openComposer,
    notify,
  } = useApp();
  const navigate = useNavigate();
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedMood, setSelectedMood] = useState<MoodKey | null>(null);
  const [companionOpen, setCompanionOpen] = useState(false);

  const load = useCallback(async () => {
    if (demoMode) {
      const diaries = getDemoDiaries().map(demoDiaryToListItem);
      setData({
        diaries,
        memories: getDemoMemories(),
        totalDiaries: diaries.length,
        totalMemories: getDemoMemories().length,
      });
      setLoading(false);
      setError(null);
      return;
    }
    if (backend.state === "checking") {
      setLoading(true);
      return;
    }
    if (backend.state === "offline") {
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const [diaryPage, memoryPage] = await Promise.all([
        listDiaries({ limit: 40 }),
        listMemories({ limit: 100 }),
      ]);
      setData({
        diaries: diaryPage.items,
        memories: memoryPage.items,
        totalDiaries: diaryPage.total,
        totalMemories: memoryPage.total,
      });
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "无法加载今日内容");
    } finally {
      setLoading(false);
    }
  }, [demoMode, backend.state, dataVersion]);

  useEffect(() => {
    void load();
  }, [load]);

  const diaries = data?.diaries ?? [];
  const memories = data?.memories ?? [];
  const now = new Date();
  const greeting = getGreeting(now);
  const todayDiary = diaries.find((diary) => isSameDay(toDate(diary.created_at), now));
  const todayMoodFromRecord = getMoodFromMetadata(todayDiary?.metadata);
  const displayedMood = selectedMood ?? todayMoodFromRecord?.key ?? null;

  useEffect(() => {
    if (selectedMood) return;
    if (todayMoodFromRecord?.key) setSelectedMood(todayMoodFromRecord.key);
  }, [selectedMood, todayMoodFromRecord?.key]);

  const recent = diaries.slice(0, 3);
  const moodPoints = useMemo(() => buildMoodPoints(diaries, 7), [diaries]);
  const validScores = moodPoints
    .map((point) => point.score)
    .filter((score): score is number => typeof score === "number");
  const average =
    validScores.length > 0
      ? validScores.reduce((sum, score) => sum + score, 0) / validScores.length
      : null;
  const streak = calculateStreak(diaries);
  const pendingMemories = memories.filter((memory) => memory.verification_status === "pending");
  const aiReady = backend.health?.ai_ready ?? false;

  if (loading && !data) {
    return <PageSkeleton />;
  }

  if (error) {
    return (
      <div className="pt-8">
        <ErrorState
          title="今天的内容暂时没有加载出来"
          description={error}
          onRetry={() => void load()}
        />
      </div>
    );
  }

  return (
    <div className="space-y-5 pb-2 sm:space-y-6">
      <header className="flex flex-col gap-5 pt-2 sm:pt-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <div className="eyebrow mb-3 flex items-center gap-2">
            <CalendarDays className="h-3 w-3" />
            {formatDate(now, { year: "numeric" })} · {formatWeekday(now)}
          </div>
          <h1 className="text-[38px] font-semibold leading-[1.06] tracking-[-0.055em] text-ink sm:text-[50px]">
            {greeting}
            {profileName ? (
              <span className="ml-2 font-editorial text-[0.82em] font-normal text-ink/60">
                {profileName}
              </span>
            ) : null}
          </h1>
          <p className="mt-3 max-w-[470px] text-[13.5px] leading-6 text-muted sm:text-[14px]">
            {getGreetingSubline(now)}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="glass-quiet inline-flex h-10 items-center gap-2 rounded-full border border-white/40 px-3.5 text-[11px] text-muted dark:border-white/10">
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-sage/20 text-[#5e7565] dark:text-sage">
              <Check className="h-3 w-3" />
            </span>
            <span>
              连续记录 <span className="font-medium text-ink">{streak}</span> 天
            </span>
          </div>
          <button
            type="button"
            onClick={() => navigate("/insights")}
            className="glass-quiet focus-ring press hidden h-10 items-center gap-2 rounded-full border border-white/40 px-3.5 text-[11px] text-muted hover:text-ink sm:inline-flex dark:border-white/10"
          >
            <ChartNoAxesColumn className="h-3.5 w-3.5" />
            本周回顾
          </button>
        </div>
      </header>

      <section className="grid gap-4 lg:grid-cols-12">
        <GlassPanel
          tone="strong"
          className="relative overflow-hidden rounded-[30px] p-6 sm:p-8 lg:col-span-8 lg:min-h-[318px]"
        >
          <div className="pointer-events-none absolute -right-16 -top-24 h-72 w-72 rounded-full bg-[radial-gradient(circle,rgb(var(--rose)/0.4),rgb(var(--lavender)/0.12)_52%,transparent_70%)] blur-2xl" />
          <div className="pointer-events-none absolute -bottom-16 -left-10 h-52 w-52 rounded-full bg-[radial-gradient(circle,rgb(var(--sage)/0.3),transparent_70%)] blur-2xl" />
          <div className="relative flex h-full flex-col">
            <div className="flex items-center justify-between gap-4">
              <span className="eyebrow">今日思考</span>
              <span className="inline-flex items-center gap-1.5 text-[10px] tracking-[0.08em] text-subtle">
                <Sparkles className="h-3 w-3" />
                写给此刻
              </span>
            </div>

            <blockquote className="serif-quote mt-7 max-w-[610px] text-[26px] leading-[1.65] tracking-[0.01em] text-ink/90 sm:text-[33px] sm:leading-[1.6]">
              “生活不必时时刻刻都有答案，
              <br className="hidden sm:block" />
              有些感受，值得被好好记录。”
            </blockquote>

            <div className="mt-8 flex flex-col gap-3 sm:mt-auto sm:flex-row sm:items-center">
              <button
                type="button"
                onClick={() => openComposer(displayedMood ?? undefined)}
                className="focus-ring press group flex min-h-[58px] w-full items-center gap-3 rounded-[18px] border border-white/55 bg-white/30 px-4 text-left text-[12.5px] text-muted shadow-[inset_0_1px_0_rgb(255_255_255/0.6)] transition-colors hover:bg-white/45 hover:text-ink sm:max-w-[350px] dark:border-white/10 dark:bg-white/[0.045] dark:hover:bg-white/[0.075]"
              >
                <span className="flex h-8 w-8 items-center justify-center rounded-[11px] bg-ink/[0.07] text-ink/55 dark:bg-white/[0.07]">
                  <PenLine className="h-3.5 w-3.5" />
                </span>
                <span className="flex-1">此刻，你想记下什么？</span>
                <ArrowUpRight className="h-4 w-4 text-subtle transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
              </button>
              <span className="hidden text-[10px] leading-5 text-subtle sm:block">
                原样保存 · 之后可继续修订
              </span>
            </div>
          </div>
        </GlassPanel>

        <SurfaceCard className="relative flex flex-col justify-between overflow-hidden rounded-[30px] p-6 lg:col-span-4">
          <div className="flex items-center justify-between">
            <span className="eyebrow">今天</span>
            <span className="h-1.5 w-1.5 rounded-full bg-champagne/80" />
          </div>
          <div className="mt-6 flex items-end gap-3">
            <span className="font-editorial text-[72px] leading-[0.8] tracking-[-0.08em] text-ink/85">
              {String(now.getDate()).padStart(2, "0")}
            </span>
            <div className="pb-1.5">
              <div className="text-[12px] font-medium text-ink/70">
                {now.getMonth() + 1} 月
              </div>
              <div className="text-[10px] text-subtle">{formatWeekday(now)}</div>
            </div>
          </div>
          <p className="mt-4 max-w-[210px] font-editorial text-[12.5px] leading-6 text-muted">
            {todayDiary
              ? `今天已经写下 ${countCharacters(todayDiary.preview)} 个字。`
              : "今天还没有留下文字。"}
            <br />
            留一点时间给自己。
          </p>
          <div className="hairline my-6" />
          <div>
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-muted">今天的心情</span>
              {displayedMood ? (
                <span className="inline-flex items-center gap-1.5 text-[10.5px] text-ink/60">
                  <span
                    className="h-1.5 w-1.5 rounded-full"
                    style={{ backgroundColor: getMood(displayedMood)?.color }}
                  />
                  {getMood(displayedMood)?.label}
                </span>
              ) : (
                <span className="text-[10px] text-subtle">还未选择</span>
              )}
            </div>
            <div className="mt-3 flex items-center gap-1.5">
              {MOODS.map((mood) => (
                <button
                  key={mood.key}
                  type="button"
                  aria-label={`选择${mood.label}`}
                  aria-pressed={displayedMood === mood.key}
                  onClick={() => setSelectedMood(mood.key)}
                  className={cn(
                    "focus-ring h-7 flex-1 rounded-full border transition-all",
                    displayedMood === mood.key
                      ? "border-ink/20 opacity-100 ring-2 ring-ink/10"
                      : "border-white/20 opacity-60 hover:opacity-100 dark:border-white/10",
                  )}
                  style={{ backgroundColor: mood.color }}
                />
              ))}
            </div>
            <button
              type="button"
              onClick={() => openComposer(displayedMood ?? undefined)}
              className="focus-ring mt-3 inline-flex items-center gap-1.5 text-[10.5px] font-medium text-muted transition-colors hover:text-ink"
            >
              {displayedMood ? "把此刻写下来" : "记录今天的心情"}
              <ArrowRight className="h-3 w-3" />
            </button>
          </div>
        </SurfaceCard>
      </section>

      <section className="grid gap-4 lg:grid-cols-12">
        <SurfaceCard className="overflow-hidden rounded-[26px] p-0 lg:col-span-7">
          <div className="flex items-center justify-between px-5 pb-2 pt-5 sm:px-6 sm:pt-6">
            <div>
              <div className="eyebrow mb-1.5">最近的记录</div>
              <h2 className="text-[18px] font-semibold tracking-[-0.03em] text-ink">
                这几天，你写下的
              </h2>
            </div>
            <button
              type="button"
              onClick={() => navigate("/diary")}
              className="focus-ring inline-flex items-center gap-1 rounded-full px-2 py-1 text-[10.5px] text-muted hover:text-ink"
            >
              全部日记
              <ArrowUpRight className="h-3 w-3" />
            </button>
          </div>

          {recent.length ? (
            <div className="mt-2 divide-y divide-line/45 dark:divide-white/[0.06]">
              {recent.map((diary) => {
                const mood = getMoodFromMetadata(diary.metadata);
                return (
                  <button
                    key={diary.id}
                    type="button"
                    onClick={() => navigate(`/diary/${diary.id}`)}
                    className="group flex w-full items-start gap-4 px-5 py-4 text-left transition-colors hover:bg-white/25 sm:px-6 dark:hover:bg-white/[0.025]"
                  >
                    <div className="w-[42px] shrink-0 pt-0.5 text-center">
                      <div className="text-[19px] font-medium leading-none tracking-[-0.05em] text-ink/75">
                        {String(toDate(diary.created_at).getDate()).padStart(2, "0")}
                      </div>
                      <div className="mt-1 text-[9px] text-subtle">
                        {formatWeekday(diary.created_at).replace("星期", "周")}
                      </div>
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-subtle">
                          {formatRelativeDay(diary.created_at)}
                        </span>
                        {mood ? (
                          <span className="inline-flex items-center gap-1 text-[9.5px] text-muted">
                            <span
                              className="h-1 w-1 rounded-full"
                              style={{ backgroundColor: mood.color }}
                            />
                            {mood.label}
                          </span>
                        ) : null}
                        {diary.current_version > 1 ? (
                          <span className="rounded-full border border-line/60 px-1.5 py-0.5 text-[8.5px] text-subtle dark:border-white/10">
                            v{diary.current_version}
                          </span>
                        ) : null}
                      </div>
                      <p className="mt-1.5 line-clamp-2 text-[12.5px] leading-6 text-ink/75">
                        {collapseWhitespace(diary.preview)}
                      </p>
                    </div>
                    <ArrowUpRight className="mt-1 h-3.5 w-3.5 shrink-0 text-subtle opacity-0 transition-opacity group-hover:opacity-100" />
                  </button>
                );
              })}
            </div>
          ) : (
            <div className="px-5 pb-6 pt-3 sm:px-6">
              <EmptyState
                compact
                icon={PenLine}
                title="还没有日记"
                description="今天可以从一句话开始。你说下的每一件小事，都会成为以后可以回来的地方。"
                action={
                  <Button size="sm" variant="secondary" onClick={() => openComposer()}>
                    写下第一篇
                  </Button>
                }
              />
            </div>
          )}
        </SurfaceCard>

        <SurfaceCard className="rounded-[26px] p-5 sm:p-6 lg:col-span-5">
          <div className="flex items-start justify-between">
            <div>
              <div className="eyebrow mb-1.5">此刻的心情</div>
              <h2 className="text-[18px] font-semibold tracking-[-0.03em] text-ink">
                今天，感觉如何？
              </h2>
            </div>
            <span className="text-[10px] text-subtle">不必准确</span>
          </div>
          <MoodPicker
            value={displayedMood}
            onChange={(mood) => {
              setSelectedMood(mood);
              notify(`今天的心情：${getMood(mood)?.label}`, {
                tone: "info",
                description: "心情会随你接下来的记录一起保存。",
              });
            }}
            compact
            className="mt-5"
          />
          <div className="mt-5 flex items-center justify-between rounded-[16px] border border-line/50 bg-surface/35 px-3.5 py-3 dark:border-white/10 dark:bg-white/[0.025]">
            <div className="flex items-center gap-2 text-[10.5px] text-muted">
              <span
                className="h-2 w-2 rounded-full"
                style={{
                  backgroundColor: displayedMood ? getMood(displayedMood)?.color : "rgb(var(--line))",
                }}
              />
              {displayedMood
                ? `已选择「${getMood(displayedMood)?.label}」`
                : "选择一种感受，给今天留一个坐标"}
            </div>
            <button
              type="button"
              onClick={() => openComposer(displayedMood ?? undefined)}
              className="focus-ring text-[10.5px] font-medium text-ink/70 hover:text-ink"
            >
              记录
            </button>
          </div>
        </SurfaceCard>
      </section>

      <section className="grid gap-4 lg:grid-cols-12">
        <SurfaceCard className="rounded-[26px] p-5 sm:p-6 lg:col-span-7">
          <div className="flex items-start justify-between">
            <div>
              <div className="eyebrow mb-1.5">情绪趋势</div>
              <h2 className="text-[18px] font-semibold tracking-[-0.03em] text-ink">
                最近七天
              </h2>
            </div>
            <button
              type="button"
              onClick={() => navigate("/insights")}
              className="focus-ring inline-flex items-center gap-1 rounded-full px-2 py-1 text-[10.5px] text-muted hover:text-ink"
            >
              更完整的回顾
              <ArrowUpRight className="h-3 w-3" />
            </button>
          </div>
          <div className="mt-4 flex items-end justify-between gap-4">
            <div className="flex items-baseline gap-2">
              <span className="font-editorial text-[38px] leading-none tracking-[-0.06em] text-ink/85">
                {average ? average.toFixed(1) : "—"}
              </span>
              <span className="pb-1 text-[10px] text-subtle">/ 5 平均心情</span>
            </div>
            <span className="pb-1 text-[10px] text-subtle">
              {validScores.length ? `${validScores.length} 天有标记` : "记录后自动出现"}
            </span>
          </div>
          <MoodChart points={moodPoints} height={138} className="mt-4" />
        </SurfaceCard>

        <GlassPanel
          tone="default"
          className="relative overflow-hidden rounded-[26px] p-5 sm:p-6 lg:col-span-5"
        >
          <div className="pointer-events-none absolute -right-12 -top-14 h-48 w-48 rounded-full bg-[radial-gradient(circle,rgb(var(--lavender)/0.4),transparent_70%)] blur-2xl" />
          <div className="pointer-events-none absolute -bottom-16 -left-8 h-40 w-40 rounded-full bg-[radial-gradient(circle,rgb(var(--rose)/0.25),transparent_70%)] blur-2xl" />
          <div className="relative flex h-full flex-col">
            <div className="flex items-center justify-between">
              <span className="eyebrow">AI 陪伴</span>
              <span
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-full border px-2 py-1 text-[9px] font-medium",
                  aiReady
                    ? "border-sage/35 bg-sage/10 text-[#5e7565] dark:text-sage"
                    : "border-champagne/35 bg-champagne/10 text-[#806b43] dark:text-champagne",
                )}
              >
                <span className="h-1 w-1 rounded-full bg-current" />
                {aiReady ? "可用" : "未配置 · 占位"}
              </span>
            </div>
            <h2 className="mt-5 max-w-[280px] text-[23px] font-semibold leading-[1.35] tracking-[-0.04em] text-ink">
              想和过去的自己
              <br />
              说说话吗？
            </h2>
            <p className="mt-3 max-w-[310px] text-[11.5px] leading-6 text-muted">
              {aiReady
                ? "它可以结合你保存的记忆，和你一起回看最近的感受。所有来源仍会指回原日记。"
                : "AI 还没有在服务端配置。你仍然可以打开对话，但只会看到明确标注的占位回复。"}
            </p>
            <div className="mt-auto flex items-center gap-3 pt-7">
              <Button
                size="sm"
                variant="secondary"
                onClick={() => setCompanionOpen(true)}
                leadingIcon={<MessageCircle className="h-3.5 w-3.5" />}
              >
                打开对话
              </Button>
              <span className="text-[9.5px] text-subtle">
                {pendingMemories.length
                  ? `${pendingMemories.length} 条记忆待你确认`
                  : "不替你编造记忆"}
              </span>
            </div>
          </div>
        </GlassPanel>
      </section>

      <section className="grid gap-4 lg:grid-cols-12">
        <SurfaceCard className="rounded-[26px] p-5 sm:p-6 lg:col-span-4">
          <div className="eyebrow mb-3">你的记忆</div>
          <div className="flex items-end gap-2">
            <span className="font-editorial text-[34px] leading-none tracking-[-0.05em] text-ink/85">
              {data?.totalMemories ?? 0}
            </span>
            <span className="pb-0.5 text-[10px] text-subtle">条长期记忆</span>
          </div>
          <div className="mt-4 flex flex-wrap gap-1.5">
            {(["explicit_fact", "subjective_feeling", "explicit_belief", "model_inference"] as const).map(
              (type) => {
                const count = memories.filter((memory) => memory.memory_type === type).length;
                return (
                  <div key={type} className="flex items-center gap-1.5">
                    <MemoryTypeBadge type={type} compact />
                    <span className="text-[10px] text-subtle">{count}</span>
                  </div>
                );
              },
            )}
          </div>
        </SurfaceCard>
        <SurfaceCard className="rounded-[26px] p-5 sm:p-6 lg:col-span-4">
          <div className="eyebrow mb-3">写下的字</div>
          <div className="flex items-end gap-2">
            <span className="font-editorial text-[34px] leading-none tracking-[-0.05em] text-ink/85">
              {diaries.reduce((sum, diary) => sum + countCharacters(diary.preview), 0).toLocaleString()}
            </span>
            <span className="pb-0.5 text-[10px] text-subtle">个字符（当前页）</span>
          </div>
          <p className="mt-4 text-[10.5px] leading-5 text-subtle">
            原文和修订都保存在本机，不会被 AI 改写。
          </p>
        </SurfaceCard>
        <SurfaceCard className="rounded-[26px] p-5 sm:p-6 lg:col-span-4">
          <div className="eyebrow mb-3">本周</div>
          <div className="flex items-end gap-2">
            <span className="font-editorial text-[34px] leading-none tracking-[-0.05em] text-ink/85">
              {diaries.filter((diary) => toDate(diary.created_at) >= startOfWeek(now)).length}
            </span>
            <span className="pb-0.5 text-[10px] text-subtle">篇新记录</span>
          </div>
          <p className="mt-4 text-[10.5px] leading-5 text-subtle">
            不追求频率。偶尔回来，也很好。
          </p>
        </SurfaceCard>
      </section>

      <CompanionSheet open={companionOpen} onClose={() => setCompanionOpen(false)} />
    </div>
  );
}

function buildMoodPoints(diaries: DiaryListItem[], days: number): MoodPoint[] {
  const points: MoodPoint[] = [];
  const now = new Date();
  for (let offset = days - 1; offset >= 0; offset -= 1) {
    const date = new Date(now);
    date.setDate(date.getDate() - offset);
    date.setHours(0, 0, 0, 0);
    const diary = diaries.find(
      (item) => isSameDay(toDate(item.created_at), date),
    );
    const mood = getMoodFromMetadata(diary?.metadata);
    points.push({
      date: date.toISOString(),
      label: `${date.getDate()}`,
      score: mood?.score ?? null,
      mood: mood?.key,
    });
  }
  return points;
}

function calculateStreak(diaries: DiaryListItem[]): number {
  if (!diaries.length) return 0;
  const uniqueDays = new Set(
    diaries.map((diary) => {
      const date = toDate(diary.created_at);
      return `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
    }),
  );
  const cursor = new Date();
  cursor.setHours(0, 0, 0, 0);
  const todayKey = `${cursor.getFullYear()}-${cursor.getMonth()}-${cursor.getDate()}`;
  if (!uniqueDays.has(todayKey)) {
    cursor.setDate(cursor.getDate() - 1);
  }
  let streak = 0;
  while (uniqueDays.has(`${cursor.getFullYear()}-${cursor.getMonth()}-${cursor.getDate()}`)) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}
