import { useCallback, useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowUpRight,
  BookOpenText,
  Check,
  ChevronRight,
  CircleHelp,
  Clock3,
  Pencil,
  RefreshCw,
  Search,
  Sparkles,
  Trash2,
  Undo2,
  UserRound,
} from "lucide-react";
import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/Button";
import { IconButton } from "@/components/ui/IconButton";
import { Input } from "@/components/ui/Field";
import { Chip } from "@/components/ui/Chip";
import { SegmentedControl } from "@/components/ui/SegmentedControl";
import { SurfaceCard } from "@/components/ui/SurfaceCard";
import { PageSkeleton } from "@/components/ui/Skeleton";
import { ErrorState } from "@/components/ui/ErrorState";
import { EmptyState } from "@/components/ui/EmptyState";
import { Modal } from "@/components/ui/Modal";
import {
  MemoryStatusBadge,
  MemoryTypeBadge,
  memoryTypeDescription,
} from "@/components/memory/MemoryBadges";
import { useApp } from "@/context/AppContext";
import {
  confirmMemory,
  correctMemory,
  forgetMemory,
  getPersonTimeline,
  listMemories,
  listPersons,
  revokeMemory,
} from "@/api/memories";
import { listDiaries } from "@/api/diaries";
import {
  getDemoDiaries,
  getDemoMemories,
  getDemoPersons,
  removeDemoMemory,
  updateDemoMemoryContent,
  updateDemoMemoryStatus,
} from "@/lib/demo";
import type {
  DiaryListItem,
  MemoryOut,
  MemoryType,
  PersonOut,
  PersonTimeline,
  TimelineHit,
} from "@/types/api";
import {
  cn,
  formatDate,
  formatDateShort,
  formatRelativeDay,
  toDate,
} from "@/lib/utils";

type Tab = "all" | "pending" | "people" | "timeline";
type TypeFilter = "all" | MemoryType;

const typeFilters: { value: TypeFilter; label: string }[] = [
  { value: "all", label: "全部类型" },
  { value: "explicit_fact", label: "事实" },
  { value: "subjective_feeling", label: "感受" },
  { value: "explicit_belief", label: "观点" },
  { value: "model_inference", label: "AI 推断" },
];

export default function MemoriesPage() {
  const { demoMode, backend, dataVersion, bumpData, notify } = useApp();
  const [memories, setMemories] = useState<MemoryOut[]>([]);
  const [persons, setPersons] = useState<PersonOut[]>([]);
  const [diaries, setDiaries] = useState<DiaryListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>("all");
  const [typeFilter, setTypeFilter] = useState<TypeFilter>("all");
  const [search, setSearch] = useState("");
  const [sourceTarget, setSourceTarget] = useState<MemoryOut | null>(null);
  const [correctTarget, setCorrectTarget] = useState<MemoryOut | null>(null);
  const [correctText, setCorrectText] = useState("");
  const [revokeTarget, setRevokeTarget] = useState<MemoryOut | null>(null);
  const [forgetTarget, setForgetTarget] = useState<MemoryOut | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [selectedPerson, setSelectedPerson] = useState<PersonOut | null>(null);
  const [timeline, setTimeline] = useState<PersonTimeline | null>(null);
  const [timelineLoading, setTimelineLoading] = useState(false);

  const load = useCallback(async () => {
    if (demoMode) {
      setMemories(getDemoMemories());
      setPersons(getDemoPersons());
      setDiaries(getDemoDiaries().map((diary) => ({
        id: diary.id,
        preview: diary.current_content,
        original_preview: diary.original_text,
        current_version: diary.current_version,
        created_at: diary.created_at,
        updated_at: diary.updated_at,
        deleted_at: diary.deleted_at,
        is_deleted: diary.is_deleted,
        metadata: diary.metadata,
      })));
      setLoading(false);
      setError(null);
      return;
    }
    if (backend.state === "checking") {
      setLoading(true);
      return;
    }
    if (backend.state === "offline") {
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const [memoryPage, personPage, diaryPage] = await Promise.all([
        listMemories({ limit: 100 }),
        listPersons({ limit: 100 }),
        listDiaries({ limit: 100 }),
      ]);
      setMemories(memoryPage.items);
      setPersons(personPage.items);
      setDiaries(diaryPage.items);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "记忆加载失败");
    } finally {
      setLoading(false);
    }
  }, [demoMode, backend.state, dataVersion]);

  useEffect(() => {
    void load();
  }, [load]);

  const diaryById = useMemo(() => new Map(diaries.map((diary) => [diary.id, diary])), [diaries]);
  const pendingCount = memories.filter((memory) => memory.verification_status === "pending").length;
  const typeCounts = useMemo(() => {
    const counts = new Map<MemoryType, number>();
    for (const memory of memories) {
      counts.set(memory.memory_type, (counts.get(memory.memory_type) ?? 0) + 1);
    }
    return counts;
  }, [memories]);

  const filtered = useMemo(() => {
    let list = memories;
    if (tab === "pending") list = list.filter((memory) => memory.verification_status === "pending");
    if (typeFilter !== "all") list = list.filter((memory) => memory.memory_type === typeFilter);
    if (search.trim()) {
      const query = search.trim().toLowerCase();
      list = list.filter((memory) => memory.content.toLowerCase().includes(query));
    }
    return list;
  }, [memories, tab, typeFilter, search]);

  const timelineGroups = useMemo(() => {
    const sorted = [...filtered].sort((a, b) => {
      const aDate = diaryById.get(a.source_entry_id)?.created_at ?? a.created_at;
      const bDate = diaryById.get(b.source_entry_id)?.created_at ?? b.created_at;
      return new Date(bDate).getTime() - new Date(aDate).getTime();
    });
    const groups = new Map<string, { label: string; items: MemoryOut[] }>();
    for (const memory of sorted) {
      const raw = diaryById.get(memory.source_entry_id)?.created_at ?? memory.created_at;
      const date = toDate(raw);
      const key = `${date.getFullYear()}-${date.getMonth()}`;
      if (!groups.has(key)) {
        groups.set(key, {
          label: new Intl.DateTimeFormat("zh-CN", {
            year: "numeric",
            month: "long",
          }).format(date),
          items: [],
        });
      }
      groups.get(key)!.items.push(memory);
    }
    return [...groups.values()];
  }, [filtered, diaryById]);

  const confirmOne = async (memory: MemoryOut) => {
    setBusyId(memory.id);
    try {
      if (demoMode) {
        updateDemoMemoryStatus(memory.id, "confirmed");
        bumpData();
        notify("已在演示会话中确认", { tone: "info", description: "演示操作不会写入后端。" });
      } else {
        await confirmMemory(memory.id);
        bumpData();
        notify("记忆已确认", { tone: "success" });
      }
    } catch (caught) {
      notify("确认失败", {
        tone: "error",
        description: caught instanceof Error ? caught.message : "请稍后再试。",
      });
    } finally {
      setBusyId(null);
    }
  };

  const openCorrect = (memory: MemoryOut) => {
    setCorrectTarget(memory);
    setCorrectText(memory.content);
  };

  const saveCorrection = async () => {
    if (!correctTarget) return;
    const trimmed = correctText.trim();
    if (!trimmed) return;
    setBusyId(correctTarget.id);
    try {
      if (demoMode) {
        updateDemoMemoryContent(correctTarget.id, trimmed);
        bumpData();
        notify("已在演示会话中更正", { tone: "info", description: "演示操作不会写入后端。" });
      } else {
        await correctMemory(correctTarget.id, trimmed, "用户更正");
        bumpData();
        notify("已保存新的更正记忆", { tone: "success" });
      }
      setCorrectTarget(null);
    } catch (caught) {
      notify("更正失败", {
        tone: "error",
        description: caught instanceof Error ? caught.message : "请稍后再试。",
      });
    } finally {
      setBusyId(null);
    }
  };

  const revokeOne = async () => {
    if (!revokeTarget) return;
    setBusyId(revokeTarget.id);
    try {
      if (demoMode) {
        updateDemoMemoryStatus(revokeTarget.id, "revoked");
        bumpData();
        notify("已在演示会话中撤回", { tone: "info", description: "演示操作不会写入后端。" });
      } else {
        await revokeMemory(revokeTarget.id);
        bumpData();
        notify("记忆已撤回", { tone: "success", description: "它不会再出现在默认列表和搜索中。" });
      }
      setRevokeTarget(null);
      setSourceTarget(null);
    } catch (caught) {
      notify("撤回失败", {
        tone: "error",
        description: caught instanceof Error ? caught.message : "请稍后再试。",
      });
    } finally {
      setBusyId(null);
    }
  };

  const forgetOne = async () => {
    if (!forgetTarget) return;
    setBusyId(forgetTarget.id);
    try {
      if (demoMode) {
        removeDemoMemory(forgetTarget.id);
        bumpData();
        notify("已从演示会话遗忘", { tone: "info", description: "演示内容不会写入后端。" });
      } else {
        await forgetMemory(forgetTarget.id);
        bumpData();
        notify("记忆已永久遗忘", {
          tone: "success",
          description: "内容与证据已从后端删除，只留下不含内容的审计记录。",
        });
      }
      setForgetTarget(null);
      setSourceTarget(null);
    } catch (caught) {
      notify("遗忘失败", {
        tone: "error",
        description: caught instanceof Error ? caught.message : "请稍后再试。",
      });
    } finally {
      setBusyId(null);
    }
  };

  const openPerson = async (person: PersonOut) => {
    setSelectedPerson(person);
    setTimelineLoading(true);
    setTimeline(null);
    try {
      if (demoMode) {
        setTimeline(buildDemoTimeline(person));
      } else {
        setTimeline(await getPersonTimeline(person.id));
      }
    } catch (caught) {
      notify("人物时间线加载失败", {
        tone: "error",
        description: caught instanceof Error ? caught.message : "请稍后再试。",
      });
    } finally {
      setTimelineLoading(false);
    }
  };

  if (loading && !memories.length && backend.state === "checking") {
    return <PageSkeleton />;
  }

  return (
    <div className="space-y-6 pb-4">
      <PageHeader
        eyebrow="Long-term memory"
        title="长期记忆"
        description="这些不是标签，是你反复回到的地方。每一条都保留来源、版本与当时的证据。"
        actions={
          <>
            <span className="hidden items-center gap-1.5 rounded-full border border-line/60 px-3 py-1.5 text-[10px] text-subtle sm:inline-flex dark:border-white/10">
              <Sparkles className="h-3 w-3" />
              {backend.health?.ai_ready ? "AI 已配置" : "AI 未启用 · 仅审核已存记忆"}
            </span>
            <IconButton
              aria-label="刷新记忆"
              icon={<RefreshCw />}
              variant="glass"
              size="sm"
              onClick={() => void load()}
            />
          </>
        }
      />

      <div className="grid gap-4 lg:grid-cols-12">
        <SurfaceCard className="rounded-[26px] p-5 sm:p-6 lg:col-span-8">
          <div className="flex items-start gap-3">
            <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-[12px] border border-lavender/35 bg-lavender/10 text-[#716080] dark:text-lavender">
              <BookOpenText className="h-4 w-4" strokeWidth={1.6} />
            </div>
            <div>
              <p className="serif-quote max-w-[600px] text-[17px] leading-8 text-ink/80 sm:text-[19px]">
                “你写下的细节，会在以后某一个不经意的时刻，重新成为理解自己的线索。”
              </p>
              <p className="mt-2 text-[10px] text-subtle">
                事实、感受、观点和 AI 推断被分开保存，不互相冒充。
              </p>
            </div>
          </div>
        </SurfaceCard>
        <SurfaceCard className="rounded-[26px] p-5 sm:p-6 lg:col-span-4">
          <div className="grid grid-cols-3 gap-3">
            <div>
              <div className="font-editorial text-[30px] leading-none tracking-[-0.05em] text-ink/85">
                {memories.length}
              </div>
              <div className="mt-1.5 text-[9.5px] text-subtle">条记忆</div>
            </div>
            <div>
              <div className="font-editorial text-[30px] leading-none tracking-[-0.05em] text-[#806b43] dark:text-champagne">
                {pendingCount}
              </div>
              <div className="mt-1.5 text-[9.5px] text-subtle">待确认</div>
            </div>
            <div>
              <div className="font-editorial text-[30px] leading-none tracking-[-0.05em] text-ink/85">
                {persons.length}
              </div>
              <div className="mt-1.5 text-[9.5px] text-subtle">位人物</div>
            </div>
          </div>
        </SurfaceCard>
      </div>

      <div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
        <SegmentedControl
          value={tab}
          onChange={setTab}
          ariaLabel="记忆视图"
          options={[
            { value: "all", label: "全部记忆" },
            { value: "pending", label: `待确认${pendingCount ? ` ${pendingCount}` : ""}` },
            { value: "people", label: "人物" },
            { value: "timeline", label: "时间线" },
          ]}
        />
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-subtle" />
            <Input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="在记忆中搜索…"
              aria-label="搜索记忆"
              className="h-9 w-full border-transparent bg-surface/35 pl-9 pr-3 text-[12px] shadow-none sm:w-[210px]"
            />
          </div>
          <div className="no-scrollbar flex items-center gap-1.5 overflow-x-auto">
            {typeFilters.map((filter) => (
              <Chip
                key={filter.value}
                active={typeFilter === filter.value}
                onClick={() => setTypeFilter(filter.value)}
                tone={
                  filter.value === "explicit_fact"
                    ? "sage"
                    : filter.value === "subjective_feeling"
                      ? "rose"
                      : filter.value === "explicit_belief"
                        ? "champagne"
                        : filter.value === "model_inference"
                          ? "lavender"
                          : "neutral"
                }
              >
                {filter.label}
                {filter.value !== "all" ? (
                  <span className="opacity-50">{typeCounts.get(filter.value) ?? 0}</span>
                ) : null}
              </Chip>
            ))}
          </div>
        </div>
      </div>

      {error ? (
        <ErrorState description={error} onRetry={() => void load()} />
      ) : loading ? (
        <PageSkeleton />
      ) : tab === "people" ? (
        <PeopleView
          persons={persons}
          diaries={diaryById}
          onOpen={openPerson}
          onReset={load}
        />
      ) : tab === "timeline" ? (
        <TimelineView groups={timelineGroups} diaryById={diaryById} onSource={setSourceTarget} />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={tab === "pending" ? Check : BookOpenText}
          title={
            search
              ? "没有找到匹配的记忆"
              : tab === "pending"
                ? "没有待确认的记忆"
                : "还没有被保存的长期记忆"
          }
          description={
            search
              ? "换一个词试试，或清除搜索与类型筛选。"
              : tab === "pending"
                ? "当 AI 从日记中提取候选记忆时，它们会先出现在这里，等待你确认。"
                : "记忆来自你允许的 AI 提取，或未来明确保存的片段。不会凭空生成。"
          }
        />
      ) : (
        <div className="grid gap-3 lg:grid-cols-2">
          {filtered.map((memory) => (
            <MemoryCard
              key={memory.id}
              memory={memory}
              diary={diaryById.get(memory.source_entry_id)}
              busy={busyId === memory.id}
              onSource={() => setSourceTarget(memory)}
              onConfirm={() => void confirmOne(memory)}
              onCorrect={() => openCorrect(memory)}
              onRevoke={() => setRevokeTarget(memory)}
            />
          ))}
        </div>
      )}

      {demoMode && !loading ? (
        <p className="text-center text-[10px] text-subtle">
          当前为演示记忆。确认、更正、撤回只会改变本次演示会话，不会写入后端。
        </p>
      ) : null}

      <SourceModal
        memory={sourceTarget}
        diary={sourceTarget ? diaryById.get(sourceTarget.source_entry_id) : undefined}
        onClose={() => setSourceTarget(null)}
        onCorrect={(memory) => {
          setSourceTarget(null);
          openCorrect(memory);
        }}
        onRevoke={(memory) => {
          setSourceTarget(null);
          setRevokeTarget(memory);
        }}
        onForget={(memory) => {
          setSourceTarget(null);
          setForgetTarget(memory);
        }}
      />

      <Modal
        open={Boolean(correctTarget)}
        onClose={() => setCorrectTarget(null)}
        title="更正这条记忆"
        eyebrow="Correction"
        description="旧记忆不会被改写。保存后会创建一条新的更正记忆，并将旧记录标记为已取代。"
        icon={<Pencil strokeWidth={1.6} />}
        size="md"
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="ghost" size="sm" onClick={() => setCorrectTarget(null)}>
              取消
            </Button>
            <Button
              size="sm"
              loading={busyId === correctTarget?.id}
              disabled={!correctText.trim()}
              onClick={() => void saveCorrection()}
            >
              保存更正
            </Button>
          </div>
        }
      >
        {correctTarget ? (
          <div className="space-y-4">
            <div className="rounded-[16px] border border-line/60 bg-surface/35 px-3.5 py-3 text-[11px] leading-5 text-muted dark:border-white/10 dark:bg-white/[0.025]">
              <div className="mb-1 flex items-center gap-1.5 text-[9.5px] text-subtle">
                <MemoryTypeBadge type={correctTarget.memory_type} compact />
                原记忆
              </div>
              {correctTarget.content}
            </div>
            <label className="block text-[11px] text-muted" htmlFor="memory-correction">
              更准确的表述
            </label>
            <textarea
              id="memory-correction"
              value={correctText}
              onChange={(event) => setCorrectText(event.target.value)}
              className="min-h-[130px] w-full resize-y rounded-[16px] border border-line/70 bg-surface/60 p-3.5 text-[13px] leading-6 text-ink outline-none focus:border-ink/20 dark:border-white/10 dark:bg-white/[0.035]"
              placeholder="写下你更认同的版本"
            />
          </div>
        ) : null}
      </Modal>

      <Modal
        open={Boolean(revokeTarget)}
        onClose={() => setRevokeTarget(null)}
        title="撤回这条记忆？"
        eyebrow="Revoke"
        description="撤回后它不会再出现在默认列表和搜索中，但仍可按 id 追溯。"
        icon={<Undo2 strokeWidth={1.6} />}
        size="sm"
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="ghost" size="sm" onClick={() => setRevokeTarget(null)}>
              取消
            </Button>
            <Button
              variant="danger"
              size="sm"
              loading={busyId === revokeTarget?.id}
              onClick={() => void revokeOne()}
            >
              撤回
            </Button>
          </div>
        }
      >
        <p className="text-[12px] leading-6 text-muted">{revokeTarget?.content}</p>
      </Modal>

      <Modal
        open={Boolean(forgetTarget)}
        onClose={() => setForgetTarget(null)}
        title="永久遗忘这条记忆？"
        eyebrow="Irreversible"
        description="这会删除记忆内容和全部证据来源，只留下一条不含内容的审计事件。历史备份/导出不会被自动清理。"
        icon={<Trash2 strokeWidth={1.6} />}
        size="sm"
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="ghost" size="sm" onClick={() => setForgetTarget(null)}>
              取消
            </Button>
            <Button
              variant="danger"
              size="sm"
              loading={busyId === forgetTarget?.id}
              onClick={() => void forgetOne()}
            >
              确认永久遗忘
            </Button>
          </div>
        }
      >
        <div className="rounded-[16px] border border-rose/25 bg-rose/[0.07] px-3.5 py-3 text-[11.5px] leading-6 text-[#8a4f4f] dark:text-rose">
          {forgetTarget?.content}
        </div>
      </Modal>

      <Modal
        open={Boolean(selectedPerson)}
        onClose={() => {
          setSelectedPerson(null);
          setTimeline(null);
        }}
        title={selectedPerson?.display_name}
        eyebrow="Person timeline"
        description={
          timeline?.note ??
          "按名称字面出现在日记中的时间线，不代表自动确认了身份。"
        }
        icon={<UserRound strokeWidth={1.6} />}
        size="md"
      >
        {timelineLoading ? (
          <div className="flex items-center justify-center py-12 text-[11px] text-subtle">
            <RefreshCw className="mr-2 h-3.5 w-3.5 animate-spin" />
            正在整理时间线…
          </div>
        ) : timeline?.items.length ? (
          <div className="space-y-3">
            {timeline.items.map((hit) => (
              <TimelineHitRow key={`${hit.revision_id}`} hit={hit} />
            ))}
          </div>
        ) : (
          <div className="py-10 text-center text-[12px] text-subtle">
            还没有找到与这个名字相关的日记片段。
          </div>
        )}
        {selectedPerson?.aliases.length ? (
          <p className="mt-4 text-[10px] text-subtle">
            也搜索了别名：{selectedPerson.aliases.join("、")}
          </p>
        ) : null}
      </Modal>
    </div>
  );
}

function MemoryCard({
  memory,
  diary,
  busy,
  onSource,
  onConfirm,
  onCorrect,
  onRevoke,
}: {
  memory: MemoryOut;
  diary?: DiaryListItem;
  busy: boolean;
  onSource: () => void;
  onConfirm: () => void;
  onCorrect: () => void;
  onRevoke: () => void;
}) {
  const isInference = memory.memory_type === "model_inference";
  const isPending = memory.verification_status === "pending";
  const sourceDate = diary ? formatDate(diary.created_at) : formatDate(memory.created_at);
  return (
    <SurfaceCard
      className={cn(
        "flex flex-col rounded-[24px] p-5 transition-colors sm:p-6",
        isInference &&
          "border-lavender/25 bg-[linear-gradient(150deg,rgb(var(--lavender)/0.10),rgb(var(--surface)/0.6))] dark:border-lavender/20",
      )}
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-1.5">
          <MemoryTypeBadge type={memory.memory_type} />
          <MemoryStatusBadge status={memory.verification_status} />
        </div>
        {isInference ? (
          <span className="inline-flex items-center gap-1 text-[9px] text-[#716080] dark:text-lavender">
            <CircleHelp className="h-3 w-3" />
            不是事实
          </span>
        ) : null}
      </div>

      <p className="mt-4 text-[13.5px] leading-7 text-ink/85">{memory.content}</p>

      {isInference ? (
        <p className="mt-3 rounded-[14px] border border-lavender/20 bg-lavender/[0.08] px-3 py-2 text-[10px] leading-5 text-[#716080] dark:text-lavender">
          这是模型根据记录作出的解释，仍属于推断。即使你确认它“像自己”，也不会自动变成客观事实。
        </p>
      ) : null}

      <div className="mt-5 flex flex-wrap items-center gap-2 border-t border-line/50 pt-3.5 text-[9.5px] text-subtle dark:border-white/[0.07]">
        <button
          type="button"
          onClick={onSource}
          className="focus-ring inline-flex items-center gap-1.5 rounded-full px-1.5 py-0.5 transition-colors hover:text-ink"
        >
          <BookOpenText className="h-3 w-3" />
          来源 · {sourceDate} · v{memory.source_version ?? 1}
        </button>
        {diary ? (
          <>
            <span className="opacity-40">·</span>
            <span>{formatRelativeDay(diary.created_at)}</span>
          </>
        ) : null}
        <span className="ml-auto text-[9px]">
          {memory.sources.length ? `${memory.sources.length} 条证据` : "来源已不可用"}
        </span>
      </div>

      <div className="mt-3.5 flex flex-wrap items-center gap-1.5">
        {isPending ? (
          <Button
            size="sm"
            variant="secondary"
            className="h-8 rounded-[12px] px-3 text-[11px]"
            loading={busy}
            onClick={onConfirm}
            leadingIcon={<Check className="h-3 w-3" />}
          >
            确认
          </Button>
        ) : null}
        <button
          type="button"
          onClick={onCorrect}
          className="focus-ring inline-flex h-8 items-center gap-1.5 rounded-[12px] px-2.5 text-[10.5px] text-muted transition-colors hover:bg-ink/[0.04] hover:text-ink"
        >
          <Pencil className="h-3 w-3" />
          更正
        </button>
        {memory.verification_status !== "revoked" ? (
          <button
            type="button"
            onClick={onRevoke}
            className="focus-ring inline-flex h-8 items-center gap-1.5 rounded-[12px] px-2.5 text-[10.5px] text-muted transition-colors hover:bg-ink/[0.04] hover:text-ink"
          >
            <Undo2 className="h-3 w-3" />
            撤回
          </button>
        ) : null}
        <button
          type="button"
          onClick={onSource}
          className="focus-ring ml-auto inline-flex h-8 items-center gap-1 rounded-[12px] px-2 text-[10px] text-subtle transition-colors hover:text-ink"
        >
          查看来源
          <ChevronRight className="h-3 w-3" />
        </button>
      </div>
    </SurfaceCard>
  );
}

function SourceModal({
  memory,
  diary,
  onClose,
  onCorrect,
  onRevoke,
  onForget,
}: {
  memory: MemoryOut | null;
  diary?: DiaryListItem;
  onClose: () => void;
  onCorrect: (memory: MemoryOut) => void;
  onRevoke: (memory: MemoryOut) => void;
  onForget: (memory: MemoryOut) => void;
}) {
  return (
    <Modal
      open={Boolean(memory)}
      onClose={onClose}
      title="记忆的来源"
      eyebrow="Source & evidence"
      description="每一条记忆都指向具体日记与版本。证据片段来自当时的不可变原文。"
      icon={<BookOpenText strokeWidth={1.6} />}
      size="md"
      footer={
        memory ? (
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => onCorrect(memory)}
                className="focus-ring inline-flex h-8 items-center gap-1.5 rounded-[12px] px-2.5 text-[10.5px] text-muted hover:bg-ink/[0.04] hover:text-ink"
              >
                <Pencil className="h-3 w-3" />
                更正
              </button>
              {memory.verification_status !== "revoked" ? (
                <button
                  type="button"
                  onClick={() => onRevoke(memory)}
                  className="focus-ring inline-flex h-8 items-center gap-1.5 rounded-[12px] px-2.5 text-[10.5px] text-muted hover:bg-ink/[0.04] hover:text-ink"
                >
                  <Undo2 className="h-3 w-3" />
                  撤回
                </button>
              ) : null}
            </div>
            <button
              type="button"
              onClick={() => onForget(memory)}
              className="focus-ring inline-flex h-8 items-center gap-1.5 rounded-[12px] px-2.5 text-[10.5px] text-rose hover:bg-rose/10"
            >
              <Trash2 className="h-3 w-3" />
              永久遗忘
            </button>
          </div>
        ) : null
      }
    >
      {memory ? (
        <div className="space-y-5">
          <div className="flex flex-wrap gap-1.5">
            <MemoryTypeBadge type={memory.memory_type} />
            <MemoryStatusBadge status={memory.verification_status} />
            <span className="inline-flex h-7 items-center rounded-full border border-line/60 px-2.5 text-[10px] text-subtle dark:border-white/10">
              {memoryTypeDescription(memory.memory_type)}
            </span>
          </div>
          <p className="text-[14px] leading-7 text-ink/85">{memory.content}</p>
          <div className="hairline" />
          <div>
            <div className="eyebrow mb-3">原文证据</div>
            {memory.sources.length ? (
              <div className="space-y-2">
                {memory.sources.map((source) => (
                  <div
                    key={source.id}
                    className="rounded-[18px] border border-line/60 bg-surface/35 p-4 dark:border-white/10 dark:bg-white/[0.025]"
                  >
                    <div className="mb-2 flex items-center gap-2 text-[9.5px] text-subtle">
                      <Clock3 className="h-3 w-3" />
                      日记版本 v{memory.source_version ?? 1}
                      {source.start_offset !== null ? (
                        <span className="opacity-60">
                          · 偏移 {source.start_offset}-{source.end_offset}
                        </span>
                      ) : null}
                    </div>
                    <blockquote className="serif-quote border-l-2 border-lavender/50 pl-3 text-[14px] leading-7 text-ink/75">
                      “{source.evidence_text}”
                    </blockquote>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-[11px] text-subtle">当前没有可用的证据来源。</p>
            )}
          </div>
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-[16px] border border-line/60 bg-surface/30 px-3.5 py-3 dark:border-white/10 dark:bg-white/[0.02]">
            <div className="min-w-0 text-[10.5px] text-muted">
              <div className="flex items-center gap-1.5">
                <BookOpenText className="h-3 w-3" />
                {diary ? formatDate(diary.created_at) : "来源日记"}
                {diary ? ` · v${memory.source_version ?? 1}` : ""}
              </div>
              {diary?.preview ? (
                <div className="mt-1 line-clamp-1 text-[10px] text-subtle">{diary.preview}</div>
              ) : null}
            </div>
            <Link
              to={`/diary/${memory.source_entry_id}?version=${memory.source_version ?? 1}`}
              onClick={onClose}
              className="focus-ring inline-flex h-8 shrink-0 items-center gap-1 rounded-[12px] border border-line/60 bg-white/20 px-3 text-[10.5px] font-medium text-ink/70 hover:bg-white/40 dark:border-white/10 dark:bg-white/[0.04]"
            >
              打开原日记
              <ArrowUpRight className="h-3 w-3" />
            </Link>
          </div>
          {memory.metadata.demo ? (
            <p className="text-[10px] text-subtle">这是一条演示记忆，来源日记也是演示内容。</p>
          ) : null}
        </div>
      ) : null}
    </Modal>
  );
}

function PeopleView({
  persons,
  diaries,
  onOpen,
  onReset,
}: {
  persons: PersonOut[];
  diaries: Map<string, DiaryListItem>;
  onOpen: (person: PersonOut) => void;
  onReset: () => Promise<void>;
}) {
  if (!persons.length) {
    return (
      <EmptyState
        icon={UserRound}
        title="还没有人物档案"
        description="人物档案必须从一段明确的日记来源创建。HeartLog 不会自动合并同名人物。"
        action={
          <Button variant="secondary" size="sm" onClick={() => void onReset()}>
            刷新
          </Button>
        }
      />
    );
  }
  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {persons.map((person) => {
        const diary = diaries.get(person.source_entry_id);
        return (
          <SurfaceCard
            key={person.id}
            interactive
            role="button"
            tabIndex={0}
            aria-label={`查看 ${person.display_name} 的时间线`}
            className="rounded-[24px] p-5"
            onClick={() => onOpen(person)}
            onKeyDown={(event) => {
              if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                onOpen(person);
              }
            }}
          >
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-[15px] border border-white/50 bg-gradient-to-br from-lavender/30 to-rose/20 text-[15px] font-medium text-ink/65 dark:border-white/10">
                {person.display_name.slice(0, 1)}
              </span>
              <div className="min-w-0">
                <div className="truncate text-[14px] font-medium text-ink">{person.display_name}</div>
                <div className="mt-0.5 text-[10px] text-subtle">
                  {person.aliases.length ? person.aliases.join("、") : "无别名"}
                </div>
              </div>
              <ArrowUpRight className="ml-auto h-3.5 w-3.5 text-subtle" />
            </div>
            {person.source_evidence ? (
              <p className="mt-4 line-clamp-2 border-l-2 border-line pl-3 text-[11px] leading-5 text-muted dark:border-white/10">
                “{person.source_evidence}”
              </p>
            ) : null}
            <div className="mt-4 flex items-center gap-1.5 text-[9.5px] text-subtle">
              <BookOpenText className="h-3 w-3" />
              {diary ? formatDate(diary.created_at) : "来源日记"}
              <span className="ml-auto">查看时间线 →</span>
            </div>
          </SurfaceCard>
        );
      })}
    </div>
  );
}

function TimelineView({
  groups,
  diaryById,
  onSource,
}: {
  groups: { label: string; items: MemoryOut[] }[];
  diaryById: Map<string, DiaryListItem>;
  onSource: (memory: MemoryOut) => void;
}) {
  if (!groups.length) {
    return (
      <EmptyState
        icon={Clock3}
        title="时间线还是空的"
        description="当记忆被保存后，会按照来源日记的时间出现在这里。"
      />
    );
  }
  return (
    <div className="relative pl-4 sm:pl-6">
      <div className="absolute bottom-2 left-[7px] top-2 w-px bg-gradient-to-b from-line via-line/60 to-transparent sm:left-[11px] dark:from-white/15 dark:via-white/10" />
      <div className="space-y-8">
        {groups.map((group) => (
          <section key={group.label} className="relative">
            <div className="absolute -left-4 top-1 flex h-3 w-3 items-center justify-center rounded-full border-2 border-canvas bg-lavender sm:-left-6 dark:border-canvas" />
            <h2 className="mb-3 text-[11px] font-medium tracking-[0.06em] text-muted">{group.label}</h2>
            <div className="space-y-2">
              {group.items.map((memory) => {
                const diary = diaryById.get(memory.source_entry_id);
                return (
                  <button
                    key={memory.id}
                    type="button"
                    onClick={() => onSource(memory)}
                    className="focus-ring flex w-full items-start gap-3 rounded-[18px] border border-line/60 bg-surface/30 px-4 py-3.5 text-left transition-colors hover:bg-surface/65 dark:border-white/10 dark:bg-white/[0.02]"
                  >
                    <span className="w-11 shrink-0 pt-0.5 text-[9.5px] text-subtle">
                      {diary ? formatDateShort(diary.created_at) : "—"}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex flex-wrap items-center gap-1.5">
                        <MemoryTypeBadge type={memory.memory_type} compact />
                        <MemoryStatusBadge status={memory.verification_status} />
                      </span>
                      <span className="mt-1.5 block line-clamp-2 text-[12px] leading-5 text-ink/75">
                        {memory.content}
                      </span>
                    </span>
                    <ArrowUpRight className="mt-1 h-3 w-3 shrink-0 text-subtle" />
                  </button>
                );
              })}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}

function TimelineHitRow({ hit }: { hit: TimelineHit }) {
  return (
    <Link
      to={`/diary/${hit.entry_id}?version=${hit.version}`}
      className="focus-ring flex items-start gap-3 rounded-[16px] border border-line/60 bg-surface/30 px-4 py-3 transition-colors hover:bg-surface/65 dark:border-white/10 dark:bg-white/[0.02]"
    >
      <span className="mt-0.5 text-[9.5px] text-subtle">
        {formatDateShort(hit.created_at)}
      </span>
      <span className="min-w-0 flex-1">
        <span className="block text-[11.5px] leading-6 text-ink/75">{hit.snippet}</span>
        <span className="mt-1 block text-[9px] text-subtle">
          匹配「{hit.matched_name}」· 版本 v{hit.version} {hit.is_current ? "· 当前" : "· 历史"}
        </span>
      </span>
      <ArrowUpRight className="h-3 w-3 text-subtle" />
    </Link>
  );
}

function buildDemoTimeline(person: PersonOut): PersonTimeline {
  const names = [person.display_name, ...person.aliases];
  const items = getDemoDiaries()
    .filter((diary) => names.some((name) => diary.current_content.includes(name)))
    .map((diary) => {
      const matched = names.find((name) => diary.current_content.includes(name)) ?? names[0];
      const index = diary.current_content.indexOf(matched);
      const start = Math.max(0, index - 40);
      const end = Math.min(diary.current_content.length, index + matched.length + 80);
      return {
        entry_id: diary.id,
        revision_id: diary.current_revision_id ?? "",
        version: diary.current_version,
        created_at: diary.created_at,
        snippet: diary.current_content.slice(start, end),
        matched_name: matched,
        is_current: true,
      };
    });
  return {
    person_id: person.id,
    display_name: person.display_name,
    names_used_for_search: names,
    method: "literal_text_match",
    note: "演示模式：按名称字面出现整理的时间线；不代表自动确认了身份。",
    items,
  };
}
