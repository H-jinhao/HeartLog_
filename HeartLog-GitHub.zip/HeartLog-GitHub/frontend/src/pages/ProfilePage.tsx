import { useEffect, useState } from "react";
import {
  ArrowUpRight,
  Check,
  Database,
  Download,
  Eye,
  EyeOff,
  KeyRound,
  Laptop,
  LockKeyhole,
  LogOut,
  Moon,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  Sun,
  Trash2,
  UserRound,
} from "lucide-react";
import { PageHeader } from "@/components/ui/PageHeader";
import { InstallPwaCard } from "@/components/common/InstallPwaCard";
import { Button } from "@/components/ui/Button";
import { Input, Field } from "@/components/ui/Field";
import { SegmentedControl } from "@/components/ui/SegmentedControl";
import { SurfaceCard } from "@/components/ui/SurfaceCard";
import { Modal } from "@/components/ui/Modal";
import { useApp } from "@/context/AppContext";
import { exportAllData } from "@/api/diaries";
import { cn, initials } from "@/lib/utils";

export default function ProfilePage() {
  const {
    profileName,
    setProfileName,
    themeMode,
    setThemeMode,
    effectiveTheme,
    backend,
    refreshBackend,
    demoMode,
    setDemoMode,
    apiToken,
    setApiToken,
    notify,
  } = useApp();
  const [nameDraft, setNameDraft] = useState(profileName);
  const [tokenDraft, setTokenDraft] = useState(apiToken);
  const [showToken, setShowToken] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [clearOpen, setClearOpen] = useState(false);

  useEffect(() => setNameDraft(profileName), [profileName]);
  useEffect(() => setTokenDraft(apiToken), [apiToken]);

  const saveName = () => {
    setProfileName(nameDraft.trim());
    notify("名字已保存在本机", {
      tone: "info",
      description: "这是本地称呼，不会写入后端，也不会上传。",
    });
  };

  const saveToken = () => {
    setApiToken(tokenDraft.trim());
    void refreshBackend({ explicit: false });
    notify(tokenDraft.trim() ? "API Token 已写入本次会话" : "API Token 已清除", {
      tone: "info",
      description: "只保存在当前浏览器会话；刷新页面后需要重新填写。",
    });
  };

  const handleExport = async () => {
    if (demoMode || backend.state !== "online") {
      notify("当前无法导出真实数据", {
        tone: "error",
        description: "请先连接后端并退出演示模式。",
      });
      return;
    }
    setExporting(true);
    try {
      await exportAllData();
      notify("导出已开始下载", {
        tone: "success",
        description: "导出文件包含完整私人内容，请妥善保管。",
      });
    } catch (caught) {
      notify("导出失败", {
        tone: "error",
        description: caught instanceof Error ? caught.message : "请稍后再试。",
      });
    } finally {
      setExporting(false);
    }
  };

  const clearLocal = () => {
    try {
      ["heartlog.quickDraft", "heartlog.reflections", "heartlog.profileName"].forEach((key) =>
        localStorage.removeItem(key),
      );
    } catch {
      // ignore
    }
    setProfileName("");
    setNameDraft("");
    setClearOpen(false);
    notify("本机偏好已清除", {
      tone: "info",
      description: "主题与 API Token 不在这次清除范围内；后端记录没有被修改。",
    });
  };

  const aiReady = backend.health?.ai_ready ?? false;
  const version = backend.health?.version ?? "—";

  return (
    <div className="space-y-6 pb-4">
      <PageHeader
        eyebrow="Profile"
        title="我的空间"
        description="这里保存一些只属于你的偏好。没有账号体系，没有云端同步；记录留在本机。"
        actions={
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-line/60 px-3 py-1.5 text-[10px] text-subtle dark:border-white/10">
              <ShieldCheck className="h-3 w-3" />
              本地优先
            </span>
          </div>
        }
      />

      <SurfaceCard className="relative overflow-hidden rounded-[30px] p-6 sm:p-8">
        <div className="pointer-events-none absolute -right-12 -top-20 h-52 w-52 rounded-full bg-[radial-gradient(circle,rgb(var(--lavender)/0.4),transparent_70%)] blur-2xl" />
        <div className="relative flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-4">
            <div className="flex h-[68px] w-[68px] items-center justify-center rounded-[22px] border border-white/60 bg-gradient-to-br from-lavender/40 via-rose/20 to-champagne/20 font-editorial text-[27px] text-ink/60 shadow-inner-soft dark:border-white/10">
              {initials(profileName || "你")}
            </div>
            <div>
              <div className="text-[23px] font-semibold tracking-[-0.04em] text-ink">
                {profileName || "还没有名字"}
              </div>
              <div className="mt-1 text-[10.5px] text-subtle">
                {profileName ? "这个名字只存在本机浏览器" : "给自己起一个喜欢的称呼"}
              </div>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <div className="glass-quiet inline-flex items-center gap-2 rounded-full border border-white/40 px-3 py-1.5 text-[10px] text-muted dark:border-white/10">
              <span className={cn("h-1.5 w-1.5 rounded-full", effectiveTheme === "dark" ? "bg-lavender" : "bg-champagne")} />
              {effectiveTheme === "dark" ? "深色模式" : "浅色模式"}
            </div>
            <Button
              size="sm"
              variant="secondary"
              onClick={() => document.getElementById("profile-name")?.focus()}
            >
              编辑资料
            </Button>
          </div>
        </div>

        <div className="mt-6 grid gap-4 border-t border-line/50 pt-5 sm:grid-cols-[1fr_auto] sm:items-end dark:border-white/[0.07]">
          <Field label="本机称呼" hint="不会上传">
            <Input
              id="profile-name"
              value={nameDraft}
              onChange={(event) => setNameDraft(event.target.value)}
              placeholder="比如：林深，或一个只有你知道的名字"
              maxLength={40}
              className="max-w-[360px]"
            />
          </Field>
          <Button
            size="sm"
            onClick={saveName}
            leadingIcon={<Check className="h-3.5 w-3.5" />}
          >
            保存称呼
          </Button>
        </div>
      </SurfaceCard>

      <div className="grid gap-4 lg:grid-cols-12">
        <SurfaceCard className="rounded-[26px] p-5 sm:p-6 lg:col-span-7">
          <div className="eyebrow mb-1.5">外观与感受</div>
          <h2 className="text-[18px] font-semibold tracking-[-0.03em] text-ink">让它像你的空间</h2>
          <div className="mt-5 flex flex-col gap-4 rounded-[20px] border border-line/60 bg-surface/30 p-4 dark:border-white/10 dark:bg-white/[0.02] sm:flex-row sm:items-center sm:justify-between">
            <div>
              <div className="text-[12px] font-medium text-ink/80">主题</div>
              <div className="mt-1 text-[10px] text-subtle">跟随系统，或保持一个安静的选择。</div>
            </div>
            <SegmentedControl
              value={themeMode}
              onChange={setThemeMode}
              ariaLabel="主题模式"
              options={[
                { value: "light", label: "浅色", icon: <Sun className="h-3 w-3" /> },
                { value: "dark", label: "深色", icon: <Moon className="h-3 w-3" /> },
                { value: "system", label: "系统", icon: <Laptop className="h-3 w-3" /> },
              ]}
            />
          </div>
          <div className="mt-3 flex items-start gap-2.5 rounded-[16px] border border-dashed border-line/60 px-3.5 py-3 text-[10px] leading-5 text-subtle dark:border-white/10">
            <Sparkles className="mt-0.5 h-3 w-3 shrink-0" />
            玻璃材质会尊重系统的“减少动态效果”设置；不支持 backdrop-filter 的浏览器会使用不透明回退。
          </div>
        </SurfaceCard>

        <SurfaceCard className="rounded-[26px] p-5 sm:p-6 lg:col-span-5">
          <div className="eyebrow mb-1.5">AI 状态</div>
          <div className="flex items-start justify-between gap-3">
            <h2 className="text-[18px] font-semibold tracking-[-0.03em] text-ink">
              {aiReady ? "已配置" : "未启用"}
            </h2>
            <span
              className={cn(
                "inline-flex items-center gap-1 rounded-full border px-2 py-1 text-[9px] font-medium",
                aiReady
                  ? "border-sage/35 bg-sage/10 text-[#5e7565] dark:text-sage"
                  : "border-champagne/35 bg-champagne/10 text-[#806b43] dark:text-champagne",
              )}
            >
              <span className="h-1 w-1 rounded-full bg-current" />
              {aiReady ? "ready" : "local only"}
            </span>
          </div>
          <p className="mt-3 text-[11px] leading-6 text-muted">
            AI 由后端环境变量控制，前端不会保存模型密钥，也不提供伪造的开关。
          </p>
          <div className="mt-4 space-y-2 rounded-[16px] border border-line/60 bg-surface/30 p-3.5 text-[10px] leading-5 text-subtle dark:border-white/10 dark:bg-white/[0.02]">
            <div className="flex justify-between gap-2">
              <span>HEARTLOG_AI_ENABLED</span>
              <span>{backend.health?.ai_enabled ? "true" : "false"}</span>
            </div>
            <div className="flex justify-between gap-2">
              <span>HEARTLOG_AI_READY</span>
              <span>{aiReady ? "true" : "false"}</span>
            </div>
            <div className="flex justify-between gap-2">
              <span>当前模式</span>
              <span>{demoMode ? "演示" : "真实数据"}</span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => void refreshBackend()}
            className="focus-ring mt-3 inline-flex items-center gap-1.5 text-[10px] text-muted hover:text-ink"
          >
            <RefreshCw className={cn("h-3 w-3", backend.state === "checking" && "animate-spin")} />
            刷新后端状态
          </button>
        </SurfaceCard>
      </div>

      <InstallPwaCard />

      <div className="grid gap-4 lg:grid-cols-12">
        <SurfaceCard className="rounded-[26px] p-5 sm:p-6 lg:col-span-7">
          <div className="eyebrow mb-1.5">数据与隐私</div>
          <h2 className="text-[18px] font-semibold tracking-[-0.03em] text-ink">你的数据，你决定</h2>
          <div className="mt-5 space-y-2">
            <div className="flex flex-col gap-3 rounded-[18px] border border-line/60 bg-surface/25 p-4 dark:border-white/10 dark:bg-white/[0.02] sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-[12px] border border-sage/30 bg-sage/10 text-[#5e7565] dark:text-sage">
                  <Database className="h-4 w-4" />
                </span>
                <div>
                  <div className="text-[12px] font-medium text-ink/80">导出全部数据</div>
                  <div className="mt-1 text-[10px] leading-5 text-subtle">
                    下载后端完整 JSON：日记、修订、记忆、来源、人物、对话与审计。文件包含私人内容。
                  </div>
                </div>
              </div>
              <Button
                size="sm"
                variant="secondary"
                loading={exporting}
                disabled={demoMode || backend.state !== "online"}
                onClick={() => void handleExport()}
                leadingIcon={<Download className="h-3.5 w-3.5" />}
              >
                导出
              </Button>
            </div>

            <div className="flex flex-col gap-3 rounded-[18px] border border-line/60 bg-surface/25 p-4 dark:border-white/10 dark:bg-white/[0.02] sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-[12px] border border-lavender/30 bg-lavender/10 text-[#716080] dark:text-lavender">
                  <Laptop className="h-4 w-4" />
                </span>
                <div>
                  <div className="text-[12px] font-medium text-ink/80">演示模式</div>
                  <div className="mt-1 text-[10px] leading-5 text-subtle">
                    使用明确标注的示例内容预览界面，不会写入后端。关闭后回到真实记录。
                  </div>
                </div>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={demoMode}
                disabled={backend.state !== "online"}
                onClick={() => setDemoMode(!demoMode)}
                className={cn(
                  "focus-ring relative h-7 w-12 shrink-0 rounded-full border transition-colors disabled:opacity-40",
                  demoMode
                    ? "border-ink/20 bg-ink text-canvas"
                    : "border-line bg-elevated dark:border-white/10",
                )}
              >
                <span
                  className={cn(
                    "absolute top-1/2 h-5 w-5 -translate-y-1/2 rounded-full bg-surface shadow-sm transition-transform",
                    demoMode ? "left-[25px]" : "left-[3px]",
                  )}
                />
              </button>
            </div>

            <div className="flex flex-col gap-3 rounded-[18px] border border-line/60 bg-surface/25 p-4 dark:border-white/10 dark:bg-white/[0.02] sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-[12px] border border-rose/30 bg-rose/10 text-[#8a5a5a] dark:text-rose">
                  <Trash2 className="h-4 w-4" />
                </span>
                <div>
                  <div className="text-[12px] font-medium text-ink/80">清除本机偏好</div>
                  <div className="mt-1 text-[10px] leading-5 text-subtle">
                    删除本机草稿、自评与称呼；不删除后端日记、记忆或导出文件。
                  </div>
                </div>
              </div>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setClearOpen(true)}
                leadingIcon={<Trash2 className="h-3.5 w-3.5" />}
              >
                清除
              </Button>
            </div>
          </div>
        </SurfaceCard>

        <SurfaceCard className="rounded-[26px] p-5 sm:p-6 lg:col-span-5">
          <div className="eyebrow mb-1.5">访问控制</div>
          <h2 className="text-[18px] font-semibold tracking-[-0.03em] text-ink">可选 API Token</h2>
          <p className="mt-2 text-[10.5px] leading-5 text-subtle">
            如果后端设置了 `HEARTLOG_API_TOKEN`，在这里填写。只保存在当前浏览器会话。
          </p>
          <div className="mt-4 space-y-3">
            <Field label="Bearer Token" hint="session only">
              <div className="relative">
                <KeyRound className="pointer-events-none absolute left-3.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-subtle" />
                <Input
                  type={showToken ? "text" : "password"}
                  value={tokenDraft}
                  onChange={(event) => setTokenDraft(event.target.value)}
                  placeholder="未设置"
                  autoComplete="off"
                  className="pl-9 pr-10"
                />
                <button
                  type="button"
                  aria-label={showToken ? "隐藏 Token" : "显示 Token"}
                  onClick={() => setShowToken((show) => !show)}
                  className="focus-ring absolute right-2.5 top-1/2 -translate-y-1/2 rounded-lg p-1 text-subtle hover:text-ink"
                >
                  {showToken ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                </button>
              </div>
            </Field>
            <div className="flex items-center gap-2">
              <Button size="sm" variant="secondary" onClick={saveToken}>
                保存到本次会话
              </Button>
              {apiToken ? (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    setTokenDraft("");
                    setApiToken("");
                    notify("API Token 已清除", { tone: "info" });
                  }}
                  leadingIcon={<LogOut className="h-3.5 w-3.5" />}
                >
                  清除
                </Button>
              ) : null}
            </div>
            <div className="rounded-[14px] border border-line/60 bg-surface/30 p-3 text-[9.5px] leading-5 text-subtle dark:border-white/10 dark:bg-white/[0.02]">
              前端不会把 Token 写入 localStorage，也不会放进日志。更推荐在本机使用或通过反向代理认证。
            </div>
          </div>
        </SurfaceCard>
      </div>

      <SurfaceCard className="rounded-[26px] p-6 sm:p-8">
        <div className="flex flex-col gap-5 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <div className="eyebrow mb-3">About HeartLog</div>
            <h2 className="text-[24px] font-semibold tracking-[-0.04em] text-ink">
              安静地记录，诚实地记得。
            </h2>
            <p className="mt-3 max-w-[560px] text-[11.5px] leading-6 text-muted">
              HeartLog 是一个本地优先的情感日记与长期记忆系统。原文不可变，修订只追加，每条记忆都能回到来源；
              AI 默认关闭，不替你编造过去。
            </p>
          </div>
          <div className="shrink-0 text-right text-[10px] leading-5 text-subtle">
            <div>Frontend 0.2.0</div>
            <div>Backend {version}</div>
            <div>{backend.health?.environment ?? "local"}</div>
          </div>
        </div>
        <div className="mt-6 grid gap-3 border-t border-line/50 pt-5 text-[10px] leading-5 text-subtle sm:grid-cols-3 dark:border-white/[0.07]">
          <div className="inline-flex items-start gap-2">
            <LockKeyhole className="mt-0.5 h-3 w-3 shrink-0" />
            原文与证据留在本机 SQLite；数据不默认上传。
          </div>
          <div className="inline-flex items-start gap-2">
            <UserRound className="mt-0.5 h-3 w-3 shrink-0" />
            单用户本地系统；没有云端账号与同步服务。
          </div>
          <div className="inline-flex items-start gap-2">
            <ArrowUpRight className="mt-0.5 h-3 w-3 shrink-0" />
            后端 API 文档：<code className="text-[9px]">{"/docs"}</code>（服务启动后）。
          </div>
        </div>
      </SurfaceCard>

      <Modal
        open={clearOpen}
        onClose={() => setClearOpen(false)}
        title="清除本机偏好？"
        description="这只会删除浏览器中的草稿、自评和称呼，不会动后端数据库、记忆、日记或导出文件。"
        icon={<Trash2 strokeWidth={1.6} />}
        size="sm"
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="ghost" size="sm" onClick={() => setClearOpen(false)}>
              取消
            </Button>
            <Button variant="danger" size="sm" onClick={clearLocal}>
              清除本机偏好
            </Button>
          </div>
        }
      >
        <p className="text-[12px] leading-6 text-muted">
          主题与 API Token 不会被清除；如果你需要，可以分别在对应位置修改。
        </p>
      </Modal>
    </div>
  );
}
