import { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowUpRight, PenLine, Search, SlidersHorizontal, X } from "lucide-react";
import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/Button";
import { Chip } from "@/components/ui/Chip";
import { Input } from "@/components/ui/Field";
import { SurfaceCard } from "@/components/ui/SurfaceCard";
import { PageSkeleton } from "@/components/ui/Skeleton";
import { ErrorState } from "@/components/ui/ErrorState";
import { EmptyState } from "@/components/ui/EmptyState";
import { useApp } from "@/context/AppContext";
import { useDebounce } from "@/hooks/useDebounce";
import { listDiaries } from "@/api/diaries";
import { getDemoDiaryList } from "@/lib/demo";
import { getMoodFromMetadata, MOODS } from "@/lib/moods";
import type { DiaryListItem, MoodKey } from "@/types/api";
import {
  collapseWhitespace,
  formatDate,
  formatRelativeDay,
  formatWeekday,
  toDate,
} from "@/lib/utils";

function groupDiaries(items: DiaryListItem[]): { key: string; label: string; items: DiaryListItem[] }[] {
  const groups = new Map<string, { key: string; label: string; items: DiaryListItem[] }>();
  for (const item of items) {
    const date = toDate(item.created_at);
    const key = `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
    if (!groups.has(key)) {
      groups.set(key, {
        key,
        label: `${formatDate(date, { year: "numeric" })} · ${formatWeekday(date)}`,
        items: [],
      });
    }
    groups.get(key)!.items.push(item);
  }
  return [...groups.values()];
}

export default function DiaryPage() {
  const { demoMode, backend, dataVersion, openComposer } = useApp();
  const navigate = useNavigate();
  const [items, setItems] = useState<DiaryListItem[]>([]);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState("");
  const [moodFilter, setMoodFilter] = useState<MoodKey | "all">("all");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const debouncedSearch = useDebounce(search, 350);

  const load = useCallback(async () => {
    if (demoMode) {
      let list = getDemoDiaryList();
      setTotal(list.length);
      if (moodFilter !== "all") {
        list = list.filter((item) => getMoodFromMetadata(item.metadata)?.key === moodFilter);
      }
      if (debouncedSearch.trim()) {
        const query = debouncedSearch.trim().toLowerCase();
        list = list.filter(
          (item) =>
            item.preview.toLowerCase().includes(query) ||
            item.original_preview.toLowerCase().includes(query),
        );
      }
      setItems(list);
      setLoading(false);
      setError(null);
      return;
    }

    if (backend.state === "checking") {
      setLoading(true);
      return;
    }
    if (backend.state === "offline") {
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const page = await listDiaries({
        limit: 100,
        q: debouncedSearch.trim() || undefined,
      });
      setTotal(page.total);
      setItems(page.items);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "日记列表加载失败");
    } finally {
      setLoading(false);
    }
  }, [demoMode, backend.state, debouncedSearch, moodFilter, dataVersion]);

  useEffect(() => {
    void load();
  }, [load]);

  const visibleItems = useMemo(() => {
    if (moodFilter === "all") return items;
    return items.filter(
      (item) => getMoodFromMetadata(item.metadata)?.key === moodFilter,
    );
  }, [items, moodFilter]);

  const groups = useMemo(() => groupDiaries(visibleItems), [visibleItems]);
  const moodCounts = useMemo(() => {
    const counts = new Map<MoodKey, number>();
    for (const item of items) {
      const mood = getMoodFromMetadata(item.metadata);
      if (mood) counts.set(mood.key, (counts.get(mood.key) ?? 0) + 1);
    }
    return counts;
  }, [items]);

  if (loading && !items.length && backend.state === "checking") {
    return <PageSkeleton />;
  }

  return (
    <div className="space-y-6 pb-4">
      <PageHeader
        eyebrow="Diary"
        title="日记"
        description={
          demoMode
            ? "演示模式下的日记列表。每条内容都可以打开阅读，但不会写入后端。"
            : "每一篇原文都被完整保留。修改不会覆盖过去，只会多一个版本。"
        }
        actions={
          <Button
            size="sm"
            onClick={() => openComposer()}
            leadingIcon={<PenLine className="h-3.5 w-3.5" />}
          >
            写日记
          </Button>
        }
      />

      <div className="glass-quiet rounded-[24px] p-3 sm:p-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-subtle" />
            <Input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="搜索日记内容…"
              aria-label="搜索日记"
              className="h-10 border-transparent bg-transparent pl-10 pr-10 shadow-none hover:border-transparent focus:border-line/50 focus:bg-surface/60 dark:border-transparent"
            />
            {search ? (
              <button
                type="button"
                aria-label="清空搜索"
                onClick={() => setSearch("")}
                className="focus-ring absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-1 text-subtle hover:bg-ink/5 hover:text-ink"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            ) : null}
          </div>
          <div className="flex items-center gap-2 text-[10.5px] text-subtle">
            <SlidersHorizontal className="h-3.5 w-3.5" />
            {total} 篇记录
          </div>
        </div>
        <div className="no-scrollbar mt-3 flex items-center gap-1.5 overflow-x-auto pb-0.5">
          <Chip
            active={moodFilter === "all"}
            onClick={() => setMoodFilter("all")}
            tone="neutral"
          >
            全部
          </Chip>
          {MOODS.map((mood) => {
            const count = moodCounts.get(mood.key) ?? 0;
            return (
              <Chip
                key={mood.key}
                active={moodFilter === mood.key}
                onClick={() =>
                  setMoodFilter((current) => (current === mood.key ? "all" : mood.key))
                }
                tone={
                  mood.key === "bright"
                    ? "champagne"
                    : mood.key === "calm"
                      ? "sage"
                      : mood.key === "tender"
                        ? "lavender"
                        : mood.key === "low"
                          ? "rose"
                          : "mist"
                }
                icon={
                  <span
                    className="h-1.5 w-1.5 rounded-full"
                    style={{ backgroundColor: mood.color }}
                  />
                }
              >
                {mood.label}
                {count ? <span className="opacity-50">{count}</span> : null}
              </Chip>
            );
          })}
        </div>
      </div>

      {error ? (
        <ErrorState description={error} onRetry={() => void load()} />
      ) : loading ? (
        <div className="space-y-3">
          <PageSkeleton />
        </div>
      ) : groups.length === 0 ? (
        <EmptyState
          icon={Search}
          title={search || moodFilter !== "all" ? "没有找到匹配的日记" : "还没有日记"}
          description={
            search || moodFilter !== "all"
              ? "换一个关键词，或清除心情筛选再试一次。"
              : "从今天的一件小事开始。不用写得完整，真实就好。"
          }
          action={
            search || moodFilter !== "all" ? (
              <Button
                variant="secondary"
                size="sm"
                onClick={() => {
                  setSearch("");
                  setMoodFilter("all");
                }}
              >
                清除筛选
              </Button>
            ) : (
              <Button size="sm" onClick={() => openComposer()}>
                写第一篇日记
              </Button>
            )
          }
        />
      ) : (
        <div className="space-y-7">
          {groups.map((group) => (
            <section key={group.key}>
              <div className="mb-3 flex items-center gap-3">
                <h2 className="text-[12px] font-medium text-ink/65">{group.label}</h2>
                <span className="h-px flex-1 bg-line/60 dark:bg-white/[0.06]" />
                <span className="text-[9.5px] text-subtle">{group.items.length} 篇</span>
              </div>
              <div className="space-y-3">
                {group.items.map((diary) => (
                  <DiaryRow
                    key={diary.id}
                    diary={diary}
                    onOpen={() => navigate(`/diary/${diary.id}`)}
                  />
                ))}
              </div>
            </section>
          ))}
        </div>
      )}

      <div className="flex items-center justify-between pt-2 text-[10px] text-subtle">
        <span>原文与修订历史保存在本地数据库中。</span>
        <button
          type="button"
          onClick={() => openComposer()}
          className="focus-ring inline-flex items-center gap-1 rounded-full px-2 py-1 hover:text-ink"
        >
          新建一篇
          <ArrowUpRight className="h-3 w-3" />
        </button>
      </div>
    </div>
  );
}

function DiaryRow({ diary, onOpen }: { diary: DiaryListItem; onOpen: () => void }) {
  const mood = getMoodFromMetadata(diary.metadata);
  return (
    <SurfaceCard
      interactive
      padded={false}
      role="button"
      tabIndex={0}
      aria-label={`打开日记：${collapseWhitespace(diary.preview).slice(0, 40)}`}
      onClick={onOpen}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          onOpen();
        }
      }}
      className="group flex items-start gap-4 rounded-[22px] px-4 py-4 sm:gap-5 sm:px-5 sm:py-5"
    >
      <div className="w-10 shrink-0 text-center">
        <div className="text-[20px] font-medium leading-none tracking-[-0.05em] text-ink/70">
          {String(toDate(diary.created_at).getDate()).padStart(2, "0")}
        </div>
        <div className="mt-1.5 text-[9px] text-subtle">
          {formatWeekday(diary.created_at).replace("星期", "周")}
        </div>
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[10px] text-subtle">{formatRelativeDay(diary.created_at)}</span>
          {mood ? (
            <span className="inline-flex items-center gap-1 text-[9.5px] text-muted">
              <span
                className="h-1.5 w-1.5 rounded-full"
                style={{ backgroundColor: mood.color }}
              />
              {mood.label}
            </span>
          ) : null}
          {diary.current_version > 1 ? (
            <span className="rounded-full border border-line/60 px-1.5 py-0.5 text-[8.5px] text-subtle dark:border-white/10">
              v{diary.current_version}
            </span>
          ) : null}
        </div>
        <p className="mt-1.5 line-clamp-2 text-[13.5px] leading-7 text-ink/80 sm:text-[14px]">
          {collapseWhitespace(diary.preview)}
        </p>
        <div className="mt-2 flex items-center gap-2 text-[9.5px] text-subtle">
          <span>{formatDate(diary.created_at, { year: "numeric" })}</span>
          {diary.updated_at !== diary.created_at ? (
            <>
              <span className="opacity-40">·</span>
              <span>最后编辑 {formatRelativeDay(diary.updated_at)}</span>
            </>
          ) : null}
        </div>
      </div>
      <span className="mt-1 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-transparent text-subtle transition-all group-hover:border-line/60 group-hover:bg-white/25 group-hover:text-ink dark:group-hover:border-white/10 dark:group-hover:bg-white/[0.04]">
        <ArrowUpRight className="h-3.5 w-3.5" />
      </span>
    </SurfaceCard>
  );
}
