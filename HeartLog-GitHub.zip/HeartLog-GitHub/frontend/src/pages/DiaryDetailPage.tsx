import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate, useParams, useSearchParams } from "react-router-dom";
import {
  ArrowLeft,
  Check,
  Clock3,
  History,
  LoaderCircle,
  LockKeyhole,
  Pencil,
  Save,
  Trash2,
} from "lucide-react";
import { useApp } from "@/context/AppContext";
import { deleteDiary, getDiary, listRevisions, updateDiary } from "@/api/diaries";
import { getDemoDiary, getDemoRevisions, updateDemoDiary, deleteDemoDiary } from "@/lib/demo";
import type { DiaryDetail, MoodKey, RevisionOut } from "@/types/api";
import { getMood, getMoodFromMetadata } from "@/lib/moods";
import { PageSkeleton } from "@/components/ui/Skeleton";
import { ErrorState } from "@/components/ui/ErrorState";
import { Button } from "@/components/ui/Button";
import { IconButton } from "@/components/ui/IconButton";
import { Modal } from "@/components/ui/Modal";
import { MoodPicker } from "@/components/diary/MoodPicker";
import {
  cn,
  countCharacters,
  formatDate,
  formatRelativeDay,
  formatTime,
  formatWeekday,
  toDate,
} from "@/lib/utils";

type SaveStatus = "idle" | "dirty" | "saving" | "saved" | "error" | "demo";

export default function DiaryDetailPage() {
  const { id = "" } = useParams();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const { demoMode, backend, bumpData, notify } = useApp();

  const [diary, setDiary] = useState<DiaryDetail | null>(null);
  const [revisions, setRevisions] = useState<RevisionOut[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [viewVersion, setViewVersion] = useState<number | null>(null);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState("");
  const [mood, setMood] = useState<MoodKey | null>(null);
  const [baseMood, setBaseMood] = useState<MoodKey | null>(null);
  const [saveStatus, setSaveStatus] = useState<SaveStatus>("idle");
  const [saveError, setSaveError] = useState<string | null>(null);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [originalOpen, setOriginalOpen] = useState(false);
  const savingRef = useRef(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const draftRef = useRef(draft);
  const moodRef = useRef(mood);

  useEffect(() => {
    draftRef.current = draft;
    moodRef.current = mood;
  }, [draft, mood]);

  const requestedVersion = Number(searchParams.get("version") ?? "");
  const displayedRevision = useMemo(() => {
    if (!diary) return null;
    if (viewVersion === null) return revisions.find((item) => item.version === diary.current_version) ?? diary.current_revision;
    return revisions.find((item) => item.version === viewVersion) ?? null;
  }, [diary, revisions, viewVersion]);
  const isHistorical = Boolean(diary && displayedRevision && displayedRevision.version !== diary.current_version);
  const displayContent = displayedRevision?.content ?? diary?.current_content ?? "";

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      if (demoMode) {
        const found = getDemoDiary(id);
        if (!found) {
          setError("没有找到这篇演示日记。");
          return;
        }
        setDiary(found);
        setRevisions(getDemoRevisions(id));
        setViewVersion(
          Number.isFinite(requestedVersion) && requestedVersion > 0 ? requestedVersion : null,
        );
        setDraft(found.current_content);
        setMood(getMoodFromMetadata(found.metadata)?.key ?? null);
        setBaseMood(getMoodFromMetadata(found.metadata)?.key ?? null);
        return;
      }
      if (backend.state === "checking") return;
      if (backend.state === "offline") {
        setError("后端当前不可用，无法打开真实日记。");
        return;
      }
      const [found, revisionList] = await Promise.all([getDiary(id), listRevisions(id)]);
      setDiary(found);
      setRevisions(revisionList.versions);
      const hasRequested =
        Number.isFinite(requestedVersion) &&
        requestedVersion > 0 &&
        revisionList.versions.some((item) => item.version === requestedVersion);
      setViewVersion(hasRequested ? requestedVersion : null);
      setDraft(found.current_content);
      setMood(getMoodFromMetadata(found.metadata)?.key ?? null);
      setBaseMood(getMoodFromMetadata(found.metadata)?.key ?? null);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "无法打开这篇日记");
    } finally {
      setLoading(false);
    }
  }, [id, demoMode, backend.state, requestedVersion]);

  useEffect(() => {
    setEditing(false);
    setSaveStatus("idle");
    setSaveError(null);
    void load();
  }, [id, demoMode, backend.state]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!editing) return;
    const timer = window.setTimeout(() => {
      const el = textareaRef.current;
      if (!el) return;
      el.style.height = "auto";
      el.style.height = `${Math.max(280, el.scrollHeight)}px`;
    }, 60);
    return () => window.clearTimeout(timer);
  }, [editing, draft]);

  const persist = useCallback(
    async (manual = false) => {
      if (!diary || savingRef.current) return;
      const trimmed = draft.trim();
      if (!trimmed) {
        setSaveError("正文不能为空。");
        setSaveStatus("error");
        return;
      }
      if (trimmed.length > 50_000) {
        setSaveError("单篇最多 50,000 字。");
        setSaveStatus("error");
        return;
      }

      if (demoMode) {
        const nextMetadata: Record<string, unknown> = { ...diary.metadata };
        if (mood) {
          nextMetadata.mood = mood;
          nextMetadata.moodScore = getMood(mood)?.score;
        } else {
          delete nextMetadata.mood;
          delete nextMetadata.moodScore;
        }
        const updated = updateDemoDiary(diary.id, draft, nextMetadata);
        setDiary(updated);
        setRevisions(getDemoRevisions(diary.id));
        setDraft(updated.current_content);
        setBaseMood(mood);
        setSaveStatus("demo");
        setSaveError(null);
        bumpData();
        notify("已更新演示会话", {
          tone: "info",
          description: "演示内容只存在本次会话，不会写入后端。",
        });
        return;
      }

      if (backend.state !== "online") {
        setSaveError("后端不可用，无法保存到 HeartLog。");
        setSaveStatus("error");
        return;
      }
      const draftAtSave = draft;
      const moodAtSave = mood;
      savingRef.current = true;
      setSaveStatus("saving");
      setSaveError(null);
      try {
        const nextMetadata: Record<string, unknown> = { ...diary.metadata };
        if (mood) {
          nextMetadata.mood = mood;
          nextMetadata.moodScore = getMood(mood)?.score;
        } else {
          delete nextMetadata.mood;
          delete nextMetadata.moodScore;
        }
        const updated = await updateDiary(diary.id, {
          content: draft,
          expectedVersion: diary.current_version,
          changeReason: manual ? "手动保存" : "自动保存",
        });
        setDiary(updated);
        setBaseMood(moodAtSave);
        setLastSaved(new Date());
        setSaveError(null);
        // Keep the text the user typed while the request was in flight.  Only
        // claim "saved" if nothing changed after the request snapshot.
        const stillCurrent =
          draftRef.current === draftAtSave && (moodRef.current ?? null) === (moodAtSave ?? null);
        if (stillCurrent) {
          setDraft(updated.current_content);
          setSaveStatus("saved");
        } else {
          setSaveStatus("dirty");
        }
        const revisionList = await listRevisions(diary.id);
        setRevisions(revisionList.versions);
        setViewVersion(null);
        bumpData();
      } catch (caught) {
        const message =
          caught instanceof Error ? caught.message : "保存失败，请稍后再试。";
        setSaveError(message);
        setSaveStatus("error");
        notify("没有保存成功", { tone: "error", description: message });
      } finally {
        savingRef.current = false;
      }
    },
    [diary, draft, mood, demoMode, backend.state, bumpData, notify],
  );

  const isDirty = Boolean(
    diary &&
      (draft !== diary.current_content ||
        (mood ?? null) !== (baseMood ?? null)),
  );

  useEffect(() => {
    if (!editing || !isDirty || demoMode) return;
    if (saveStatus === "saving" || saveStatus === "error") return;
    setSaveStatus("dirty");
    const timer = window.setTimeout(() => {
      void persist(false);
    }, 1300);
    return () => window.clearTimeout(timer);
  }, [editing, isDirty, draft, mood, demoMode, saveStatus, persist]);

  const startEditing = () => {
    if (!diary) return;
    setViewVersion(null);
    setDraft(diary.current_content);
    setMood(getMoodFromMetadata(diary.metadata)?.key ?? null);
    setBaseMood(getMoodFromMetadata(diary.metadata)?.key ?? null);
    setEditing(true);
    setSaveStatus("idle");
    setSaveError(null);
    window.setTimeout(() => {
      textareaRef.current?.focus();
    }, 80);
  };

  const cancelEditing = () => {
    if (!diary) return;
    setEditing(false);
    setDraft(diary.current_content);
    setMood(getMoodFromMetadata(diary.metadata)?.key ?? null);
    setBaseMood(getMoodFromMetadata(diary.metadata)?.key ?? null);
    setSaveStatus("idle");
    setSaveError(null);
  };

  const handleDelete = async () => {
    if (!diary) return;
    setDeleting(true);
    try {
      if (demoMode) {
        deleteDemoDiary(diary.id);
        bumpData();
        notify("已从演示会话删除", { tone: "info" });
      } else {
        await deleteDiary(diary.id);
        bumpData();
        notify("日记已软删除", {
          tone: "success",
          description: "修订历史仍保留，可以在后端恢复。",
        });
      }
      setDeleteOpen(false);
      navigate("/diary");
    } catch (caught) {
      notify("删除失败", {
        tone: "error",
        description: caught instanceof Error ? caught.message : "请稍后再试。",
      });
    } finally {
      setDeleting(false);
    }
  };

  const selectVersion = (version: number | null) => {
    setViewVersion(version);
    if (version !== null) {
      setSearchParams({ version: String(version) }, { replace: true });
    } else {
      setSearchParams({}, { replace: true });
    }
    setHistoryOpen(false);
    setEditing(false);
  };

  if (loading) return <PageSkeleton />;
  if (error || !diary || !displayedRevision) {
    return (
      <div className="space-y-4 pt-4">
        <Link
          to="/diary"
          className="focus-ring inline-flex items-center gap-1.5 text-[11px] text-muted hover:text-ink"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          返回日记
        </Link>
        <ErrorState
          title="没有找到这篇日记"
          description={error ?? "它可能已被删除，或链接不完整。"}
          onRetry={() => void load()}
        />
      </div>
    );
  }

  const date = toDate(diary.created_at);
  const moodMeta = getMoodFromMetadata(diary.metadata);
  const displayMood = getMoodFromMetadata(diary.metadata) ?? null;

  return (
    <div className="mx-auto max-w-[1120px] space-y-6 pb-4">
      <div className="flex items-center justify-between gap-3">
        <Link
          to="/diary"
          className="focus-ring inline-flex items-center gap-1.5 rounded-full px-1 py-1 text-[11px] text-muted transition-colors hover:text-ink"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          所有日记
        </Link>
        <div className="flex items-center gap-1.5">
          {!editing ? (
            <Button
              variant="secondary"
              size="sm"
              onClick={startEditing}
              disabled={isHistorical}
              leadingIcon={<Pencil className="h-3.5 w-3.5" />}
            >
              编辑
            </Button>
          ) : (
            <>
              <Button variant="ghost" size="sm" onClick={cancelEditing}>
                取消
              </Button>
              <Button
                size="sm"
                onClick={() => void persist(true)}
                loading={saveStatus === "saving"}
                leadingIcon={<Save className="h-3.5 w-3.5" />}
              >
                {demoMode ? "保存到演示" : "保存"}
              </Button>
            </>
          )}
          <IconButton
            aria-label="查看修订历史"
            icon={<History />}
            variant="glass"
            size="sm"
            onClick={() => setHistoryOpen(true)}
          />
          <IconButton
            aria-label="删除日记"
            icon={<Trash2 />}
            variant="ghost"
            size="sm"
            onClick={() => setDeleteOpen(true)}
          />
        </div>
      </div>

      <header className="flex flex-col gap-5 border-b border-line/50 pb-6 sm:flex-row sm:items-end sm:justify-between dark:border-white/[0.07]">
        <div>
          <div className="eyebrow mb-3 flex flex-wrap items-center gap-2">
            <span>{formatDate(date, { year: "numeric" })}</span>
            <span className="opacity-40">·</span>
            <span>{formatWeekday(date)}</span>
            <span className="opacity-40">·</span>
            <span>{formatRelativeDay(date)}</span>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="font-editorial text-[38px] leading-none tracking-[-0.04em] text-ink/90 sm:text-[48px]">
              {date.getDate()} 日
            </h1>
            {displayMood ? (
              <span className="inline-flex h-8 items-center gap-1.5 rounded-full border border-white/40 bg-white/25 px-3 text-[10.5px] text-muted dark:border-white/10 dark:bg-white/[0.04]">
                <span
                  className="h-1.5 w-1.5 rounded-full"
                  style={{ backgroundColor: displayMood.color }}
                />
                {displayMood.label}
              </span>
            ) : null}
            <span className="rounded-full border border-line/60 px-2 py-1 text-[9.5px] text-subtle dark:border-white/10">
              当前 v{diary.current_version}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2 text-[10px] text-subtle">
          <span>{countCharacters(displayContent)} 字</span>
          <span className="opacity-40">·</span>
          <span>{revisions.length} 个版本</span>
          {saveStatus === "saving" ? (
            <span className="inline-flex items-center gap-1 text-muted">
              <LoaderCircle className="h-3 w-3 animate-spin" />
              保存中
            </span>
          ) : saveStatus === "saved" ? (
            <span className="inline-flex items-center gap-1 text-sage">
              <Check className="h-3 w-3" />
              已保存 {lastSaved ? formatTime(lastSaved) : ""}
            </span>
          ) : null}
        </div>
      </header>

      {isHistorical ? (
        <div className="flex flex-col gap-2 rounded-[18px] border border-champagne/35 bg-champagne/10 px-4 py-3 text-[11.5px] leading-5 text-[#806b43] sm:flex-row sm:items-center sm:justify-between dark:text-champagne">
          <span>
            你正在查看历史版本 v{displayedRevision.version}，它不会被修改。
          </span>
          <button
            type="button"
            onClick={() => selectVersion(null)}
            className="focus-ring text-left font-medium underline decoration-current/30 underline-offset-4"
          >
            回到当前版本
          </button>
        </div>
      ) : null}

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_280px]">
        <article className="surface-card relative min-h-[420px] rounded-[28px] p-5 sm:p-8 lg:p-10">
          {editing ? (
            <div className="space-y-5">
              <div className="flex items-center justify-between">
                <span className="eyebrow">编辑当前版本</span>
                <span className="text-[10px] text-subtle">原文保持不变</span>
              </div>
              <textarea
                ref={textareaRef}
                value={draft}
                onChange={(event) => {
                  setDraft(event.target.value);
                  setSaveStatus("dirty");
                  setSaveError(null);
                }}
                onKeyDown={(event) => {
                  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "s") {
                    event.preventDefault();
                    void persist(true);
                  }
                }}
                className="editor-textarea block min-h-[300px] w-full resize-none bg-transparent text-[16px] leading-[2] text-ink outline-none placeholder:text-subtle"
                placeholder="写点什么…"
                aria-label="编辑日记正文"
              />
              <div className="hairline" />
              <div>
                <div className="mb-2.5 flex items-center justify-between">
                  <span className="text-[11px] font-medium text-muted">心情标记</span>
                  <span className="text-[10px] text-subtle">可选</span>
                </div>
                <MoodPicker value={mood} onChange={setMood} compact />
              </div>
              <div className="flex flex-col gap-2 text-[10px] text-subtle sm:flex-row sm:items-center sm:justify-between">
                <span>
                  {saveStatus === "dirty"
                    ? "有未保存的修改，停止输入后会自动保存。"
                    : saveStatus === "error"
                      ? "自动保存已暂停，请手动重试。"
                      : "自动保存会新增一个修订版本，旧版本仍可查看。"}
                </span>
                {saveStatus === "demo" ? (
                  <span className="text-champagne">演示模式 · 未写入后端</span>
                ) : null}
              </div>
              {saveError ? (
                <div className="rounded-[16px] border border-rose/30 bg-rose/10 px-3.5 py-2.5 text-[11.5px] leading-5 text-[#8a4f4f] dark:text-rose">
                  {saveError}
                </div>
              ) : null}
            </div>
          ) : (
            <div>
              <div className="mb-7 flex items-center justify-between">
                <div className="flex items-center gap-2 text-[10px] text-subtle">
                  <Clock3 className="h-3 w-3" />
                  写于 {formatTime(diary.created_at)}
                  {diary.updated_at !== diary.created_at
                    ? ` · 更新于 ${formatRelativeDay(diary.updated_at)} ${formatTime(diary.updated_at)}`
                    : ""}
                </div>
                {isHistorical ? (
                  <span className="rounded-full border border-champagne/40 bg-champagne/15 px-2 py-1 text-[9px] text-[#806b43] dark:text-champagne">
                    v{displayedRevision.version} · 历史
                  </span>
                ) : null}
              </div>
              <div className="whitespace-pre-wrap text-[16px] leading-[2.05] tracking-[0.005em] text-ink/88 sm:text-[17px] sm:leading-[2.1]">
                {displayContent}
              </div>
              <div className="mt-10 flex flex-wrap items-center gap-2 text-[9.5px] text-subtle">
                <span className="inline-flex items-center gap-1.5">
                  <LockKeyhole className="h-3 w-3" />
                  原文永久保留
                </span>
                <span className="opacity-40">·</span>
                <span>修订只追加，不覆盖</span>
              </div>
            </div>
          )}
        </article>

        <aside className="space-y-3">
          <div className="surface-card rounded-[22px] p-5">
            <div className="eyebrow mb-3">这篇记录</div>
            <dl className="space-y-3 text-[11px]">
              <div className="flex items-start justify-between gap-3">
                <dt className="text-subtle">首次保存</dt>
                <dd className="text-right text-ink/70">
                  {formatDate(diary.created_at)}
                  <br />
                  <span className="text-[9.5px] text-subtle">{formatTime(diary.created_at)}</span>
                </dd>
              </div>
              <div className="flex items-start justify-between gap-3">
                <dt className="text-subtle">当前版本</dt>
                <dd className="text-ink/70">v{diary.current_version}</dd>
              </div>
              <div className="flex items-start justify-between gap-3">
                <dt className="text-subtle">心情</dt>
                <dd className="text-ink/70">{moodMeta?.label ?? "未标记"}</dd>
              </div>
              <div className="flex items-start justify-between gap-3">
                <dt className="text-subtle">内容哈希</dt>
                <dd className="max-w-[150px] break-all text-right font-mono text-[9px] text-subtle">
                  {diary.current_revision?.content_hash.slice(0, 16)}…
                </dd>
              </div>
            </dl>
            <button
              type="button"
              onClick={() => setHistoryOpen(true)}
              className="focus-ring mt-4 flex w-full items-center justify-between rounded-[14px] border border-line/60 bg-surface/35 px-3 py-2.5 text-[10.5px] text-muted transition-colors hover:bg-surface/65 hover:text-ink dark:border-white/10 dark:bg-white/[0.025]"
            >
              <span className="inline-flex items-center gap-1.5">
                <History className="h-3 w-3" />
                查看 {revisions.length} 个修订版本
              </span>
              <span>→</span>
            </button>
          </div>

          {diary.original_text !== displayContent ? (
            <div className="surface-card rounded-[22px] p-5">
              <button
                type="button"
                onClick={() => setOriginalOpen((open) => !open)}
                className="focus-ring flex w-full items-center justify-between text-left"
              >
                <span className="inline-flex items-center gap-2 text-[11px] font-medium text-muted">
                  <LockKeyhole className="h-3 w-3" />
                  首次保存的原文
                </span>
                <span className="text-[10px] text-subtle">{originalOpen ? "收起" : "展开"}</span>
              </button>
              {originalOpen ? (
                <div className="mt-3 whitespace-pre-wrap border-t border-line/50 pt-3 text-[11.5px] leading-6 text-muted dark:border-white/10">
                  {diary.original_text}
                </div>
              ) : (
                <p className="mt-2 text-[10px] leading-5 text-subtle">
                  原文不可变，编辑只会产生新版本。
                </p>
              )}
            </div>
          ) : null}

          <div className="rounded-[22px] border border-dashed border-line/70 p-4 text-[10px] leading-5 text-subtle dark:border-white/10">
            这篇日记可能被长期记忆引用。每条记忆都会保留具体版本与证据片段。
            <Link
              to="/memories"
              className="mt-2 inline-flex font-medium text-muted underline decoration-line underline-offset-4 hover:text-ink"
            >
              去看看记忆
            </Link>
          </div>
        </aside>
      </div>

      <Modal
        open={historyOpen}
        onClose={() => setHistoryOpen(false)}
        title="修订历史"
        eyebrow="Revisions"
        description="每次保存都会追加一个版本；旧版本不会被覆盖。"
        icon={<History strokeWidth={1.6} />}
        size="md"
      >
        <div className="space-y-2">
          {[...revisions].reverse().map((revision) => {
            const current = revision.version === diary.current_version;
            const selected = revision.version === displayedRevision.version;
            return (
              <button
                key={revision.id}
                type="button"
                onClick={() => selectVersion(current ? null : revision.version)}
                className={cn(
                  "focus-ring flex w-full items-start gap-3 rounded-[18px] border px-4 py-3 text-left transition-colors",
                  selected
                    ? "border-ink/15 bg-ink/[0.05] dark:border-white/15 dark:bg-white/[0.06]"
                    : "border-line/60 bg-surface/30 hover:bg-surface/60 dark:border-white/10 dark:bg-white/[0.02]",
                )}
              >
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[12px] border border-line/60 bg-white/30 text-[11px] font-medium text-ink/60 dark:border-white/10 dark:bg-white/[0.04]">
                  v{revision.version}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2 text-[10px] text-subtle">
                    <span>{formatDate(revision.created_at)}</span>
                    <span>·</span>
                    <span>{formatTime(revision.created_at)}</span>
                    {current ? (
                      <span className="rounded-full border border-sage/30 bg-sage/10 px-1.5 py-0.5 text-[8.5px] text-[#5e7565] dark:text-sage">
                        当前
                      </span>
                    ) : null}
                  </div>
                  <p className="mt-1 line-clamp-2 text-[12px] leading-5 text-ink/75">
                    {revision.content}
                  </p>
                  {revision.change_reason ? (
                    <p className="mt-1 text-[9.5px] text-subtle">{revision.change_reason}</p>
                  ) : null}
                </div>
              </button>
            );
          })}
        </div>
      </Modal>

      <Modal
        open={deleteOpen}
        onClose={() => setDeleteOpen(false)}
        title="删除这篇日记？"
        eyebrow="Delete"
        description="这是软删除：记录和全部修订仍保留在数据库中，可以在后端恢复。"
        icon={<Trash2 strokeWidth={1.6} />}
        size="sm"
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="ghost" size="sm" onClick={() => setDeleteOpen(false)}>
              取消
            </Button>
            <Button
              variant="danger"
              size="sm"
              loading={deleting}
              onClick={() => void handleDelete()}
            >
              软删除
            </Button>
          </div>
        }
      >
        <p className="text-[12.5px] leading-6 text-muted">
          这篇日记共有 {revisions.length} 个修订版本。删除后默认列表将不再显示它，但原文不会被永久抹除。
        </p>
      </Modal>
    </div>
  );
}
