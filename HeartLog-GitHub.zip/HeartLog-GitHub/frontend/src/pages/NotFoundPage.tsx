import { Link } from "react-router-dom";
import { ArrowLeft, Feather } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { GlassPanel } from "@/components/ui/GlassPanel";

export default function NotFoundPage() {
  return (
    <div className="flex min-h-[60vh] items-center justify-center pt-10">
      <GlassPanel className="max-w-[460px] rounded-[30px] p-8 text-center sm:p-10">
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl border border-white/50 bg-white/30 text-ink/45 dark:border-white/10 dark:bg-white/[0.05]">
          <Feather className="h-5 w-5" strokeWidth={1.5} />
        </div>
        <div className="eyebrow mt-5">404 · Not found</div>
        <h1 className="mt-2 font-editorial text-[30px] leading-tight tracking-[-0.04em] text-ink">
          这一页还没有被写下。
        </h1>
        <p className="mt-3 text-[12px] leading-6 text-muted">
          可能是链接不完整，也可能是这篇内容已经被移动。
        </p>
        <Link to="/" className="mt-6 inline-flex">
          <Button
            variant="secondary"
            size="sm"
            leadingIcon={<ArrowLeft className="h-3.5 w-3.5" />}
          >
            回到首页
          </Button>
        </Link>
      </GlassPanel>
    </div>
  );
}
