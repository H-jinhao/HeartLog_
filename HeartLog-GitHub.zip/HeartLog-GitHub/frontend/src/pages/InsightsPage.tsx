import { useCallback, useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowUpRight,
  BrainCircuit,
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Feather,
  LockKeyhole,
  NotebookPen,
  Sparkles,
} from "lucide-react";
import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/Button";
import { IconButton } from "@/components/ui/IconButton";
import { SegmentedControl } from "@/components/ui/SegmentedControl";
import { SurfaceCard } from "@/components/ui/SurfaceCard";
import { PageSkeleton } from "@/components/ui/Skeleton";
import { ErrorState } from "@/components/ui/ErrorState";
import { EmptyState } from "@/components/ui/EmptyState";
import { MoodChart, type MoodPoint } from "@/components/insights/MoodChart";
import { MemoryTypeBadge } from "@/components/memory/MemoryBadges";
import { useApp } from "@/context/AppContext";
import { getInsight } from "@/api/misc";
import { listDiaries } from "@/api/diaries";
import { listMemories } from "@/api/memories";
import { getDemoDiaries, getDemoInsight, getDemoMemories, demoDiaryToListItem } from "@/lib/demo";
import { getMoodFromMetadata, MOODS } from "@/lib/moods";
import type {
  DiaryListItem,
  InsightResponse,
  MemoryOut,
  MemoryType,
} from "@/types/api";
import {
  addDays,
  formatDate,
  formatDateShort,
  isoDate,
  isSameDay,
  toDate,
} from "@/lib/utils";

type Period = "weekly" | "monthly";
type ReflectionMap = Record<string, string>;

const REFLECTION_KEY = "heartlog.reflections";

function readReflections(): ReflectionMap {
  try {
    return JSON.parse(localStorage.getItem(REFLECTION_KEY) ?? "{}") as ReflectionMap;
  } catch {
    return {};
  }
}

export default function InsightsPage() {
  const { demoMode, backend, dataVersion, notify } = useApp();
  const [period, setPeriod] = useState<Period>("weekly");
  const [referenceDate, setReferenceDate] = useState(new Date());
  const [insight, setInsight] = useState<InsightResponse | null>(null);
  const [diaries, setDiaries] = useState<DiaryListItem[]>([]);
  const [memories, setMemories] = useState<MemoryOut[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reflection, setReflection] = useState("");
  const [reflectionSaved, setReflectionSaved] = useState(false);

  const reflectionKey = `${period}:${isoDate(referenceDate)}`;

  const load = useCallback(async () => {
    if (demoMode) {
      const demoDiaries = getDemoDiaries().map(demoDiaryToListItem);
      setInsight(getDemoInsight(period));
      setDiaries(demoDiaries);
      setMemories(getDemoMemories());
      setLoading(false);
      setError(null);
      return;
    }
    if (backend.state === "checking") {
      setLoading(true);
      return;
    }
    if (backend.state === "offline") {
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const [insightData, diaryPage, memoryPage] = await Promise.all([
        getInsight(period, isoDate(referenceDate)),
        listDiaries({ limit: 100 }),
        listMemories({ limit: 100 }),
      ]);
      setInsight(insightData);
      setDiaries(diaryPage.items);
      setMemories(memoryPage.items);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "回顾加载失败");
    } finally {
      setLoading(false);
    }
  }, [demoMode, backend.state, period, referenceDate, dataVersion]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    const reflections = readReflections();
    setReflection(reflections[reflectionKey] ?? "");
    setReflectionSaved(false);
  }, [reflectionKey]);

  const points = useMemo(
    () => buildMoodPoints(diaries, period, referenceDate),
    [diaries, period, referenceDate],
  );
  const validScores = points
    .map((point) => point.score)
    .filter((score): score is number => typeof score === "number");
  const average =
    validScores.length > 0
      ? validScores.reduce((sum, score) => sum + score, 0) / validScores.length
      : null;
  const memoryTypeCounts = useMemo(() => {
    const counts = new Map<MemoryType, number>();
    for (const type of ["explicit_fact", "subjective_feeling", "explicit_belief", "model_inference"] as const) {
      counts.set(type, 0);
    }
    for (const item of insight?.statistics.memory_type_counts ?? []) {
      counts.set(item.memory_type, item.count);
    }
    return counts;
  }, [insight]);

  const periodMemories = useMemo(() => {
    if (!insight) return memories.slice(0, 5);
    const start = new Date(insight.period.start).getTime();
    const end = new Date(insight.period.end).getTime();
    return memories
      .filter((memory) => {
        const time = toDate(memory.created_at).getTime();
        return time >= start && time < end;
      })
      .slice(0, 6);
  }, [memories, insight]);

  const movePeriod = (direction: -1 | 1) => {
    setReferenceDate((current) =>
      addDays(current, (period === "weekly" ? 7 : 30) * direction),
    );
  };

  const saveReflection = () => {
    const reflections = readReflections();
    if (reflection.trim()) reflections[reflectionKey] = reflection.trim();
    else delete reflections[reflectionKey];
    try {
      localStorage.setItem(REFLECTION_KEY, JSON.stringify(reflections));
    } catch {
      notify("无法保存本地自评", { tone: "error", description: "浏览器禁用了本地存储。" });
      return;
    }
    setReflectionSaved(true);
    notify("自评已保存在本机", {
      tone: "info",
      description: "它只是本机浏览器草稿，不会提交给 AI 或后端。",
    });
  };

  if (loading && !insight) return <PageSkeleton />;
  if (error) {
    return <ErrorState title="回顾加载失败" description={error} onRetry={() => void load()} />;
  }

  const startLabel = insight ? formatDate(insight.period.start) : formatDate(referenceDate);
  const endLabel = insight
    ? formatDate(new Date(new Date(insight.period.end).getTime() - 86400000))
    : formatDate(referenceDate);

  return (
    <div className="space-y-6 pb-4">
      <PageHeader
        eyebrow="Insights"
        title="情绪分析"
        description="不是评分，也不是诊断。只是把你留下的心情标记与记录，安静地放在一起看。"
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <SegmentedControl
              value={period}
              onChange={(value) => {
                setPeriod(value);
                setReflectionSaved(false);
              }}
              ariaLabel="回顾周期"
              options={[
                { value: "weekly", label: "本周" },
                { value: "monthly", label: "本月" },
              ]}
            />
            <div className="glass-quiet inline-flex items-center gap-0.5 rounded-full border border-white/40 p-1 dark:border-white/10">
              <IconButton
                aria-label="上一个周期"
                icon={<ChevronLeft />}
                variant="ghost"
                size="sm"
                onClick={() => movePeriod(-1)}
              />
              <span className="min-w-[96px] px-1 text-center text-[10px] text-muted">
                {formatDateShort(referenceDate)}
              </span>
              <IconButton
                aria-label="下一个周期"
                icon={<ChevronRight />}
                variant="ghost"
                size="sm"
                onClick={() => movePeriod(1)}
              />
            </div>
          </div>
        }
      />

      <div className="flex flex-wrap items-center justify-between gap-3 rounded-[20px] border border-white/40 bg-white/20 px-4 py-3 dark:border-white/10 dark:bg-white/[0.025]">
        <div className="flex items-center gap-2 text-[11px] text-muted">
          <CalendarDays className="h-3.5 w-3.5" />
          {startLabel} — {endLabel}
          <span className="opacity-40">·</span>
          <span>{insight?.mode === "ai" ? "AI 回顾" : "本地统计"}</span>
        </div>
        <div className="flex items-center gap-2">
          <span
            className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[9px] font-medium ${
              insight?.ai_used
                ? "border-sage/35 bg-sage/10 text-[#5e7565] dark:text-sage"
                : "border-champagne/35 bg-champagne/10 text-[#806b43] dark:text-champagne"
            }`}
          >
            {insight?.ai_used ? <BrainCircuit className="h-3 w-3" /> : <LockKeyhole className="h-3 w-3" />}
            {insight?.ai_used ? "AI 已生成回顾" : "AI 未启用 · 仅本地统计"}
          </span>
          <button
            type="button"
            onClick={() => setReferenceDate(new Date())}
            className="focus-ring text-[10px] text-subtle hover:text-ink"
          >
            回到今天
          </button>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <MetricCard
          label="这段日子的记录"
          value={insight?.statistics.diary_entries ?? 0}
          unit="篇日记"
          icon={<NotebookPen className="h-4 w-4" />}
          tone="sage"
        />
        <MetricCard
          label="被保存的记忆"
          value={insight?.statistics.memories ?? 0}
          unit="条长期记忆"
          icon={<Sparkles className="h-4 w-4" />}
          tone="lavender"
        />
        <MetricCard
          label="平均心情"
          value={average ? average.toFixed(1) : "—"}
          unit={average ? "/ 5" : "尚未标记"}
          icon={<Feather className="h-4 w-4" />}
          tone="rose"
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-12">
        <SurfaceCard className="rounded-[26px] p-5 sm:p-6 lg:col-span-8">
          <div className="flex items-start justify-between">
            <div>
              <div className="eyebrow mb-1.5">心情轨迹</div>
              <h2 className="text-[18px] font-semibold tracking-[-0.03em] text-ink">
                {period === "weekly" ? "这一周的起伏" : "这个月的起伏"}
              </h2>
              <p className="mt-1 text-[9.5px] text-subtle">
                {period === "weekly" ? "按天记录 · 最近 7 天" : "按周聚合 · 最近 5 段"}
              </p>
            </div>
            <div className="text-right">
              <div className="font-editorial text-[32px] leading-none tracking-[-0.05em] text-ink/85">
                {average ? average.toFixed(1) : "—"}
              </div>
              <div className="mt-1 text-[9px] text-subtle">平均心情 / 5</div>
            </div>
          </div>
          <MoodChart
            points={points}
            height={190}
            className="mt-5"
            emptyLabel="这段时间还没有心情标记"
          />
          <div className="mt-2 flex flex-wrap gap-2">
            {MOODS.map((mood) => (
              <span key={mood.key} className="inline-flex items-center gap-1.5 text-[9px] text-subtle">
                <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: mood.color }} />
                {mood.label}
              </span>
            ))}
          </div>
        </SurfaceCard>

        <SurfaceCard className="rounded-[26px] p-5 sm:p-6 lg:col-span-4">
          <div className="eyebrow mb-1.5">记忆构成</div>
          <h2 className="text-[18px] font-semibold tracking-[-0.03em] text-ink">
            被保留下来的部分
          </h2>
          <div className="mt-6 space-y-4">
            {(["explicit_fact", "subjective_feeling", "explicit_belief", "model_inference"] as const).map(
              (type) => {
                const count = memoryTypeCounts.get(type) ?? 0;
                const total = insight?.statistics.memories || 1;
                const percent = Math.round((count / total) * 100);
                return (
                  <div key={type}>
                    <div className="mb-1.5 flex items-center justify-between gap-2">
                      <MemoryTypeBadge type={type} compact />
                      <span className="text-[10px] text-subtle">
                        {count} <span className="opacity-60">· {percent}%</span>
                      </span>
                    </div>
                    <div className="h-1.5 overflow-hidden rounded-full bg-line/50 dark:bg-white/[0.07]">
                      <div
                        className="h-full rounded-full bg-lavender/70"
                        style={{ width: `${Math.min(100, percent)}%` }}
                      />
                    </div>
                  </div>
                );
              },
            )}
          </div>
        </SurfaceCard>
      </div>

      <div className="grid gap-4 lg:grid-cols-12">
        <SurfaceCard className="rounded-[26px] p-5 sm:p-6 lg:col-span-7">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="eyebrow mb-1.5">AI 回顾</div>
              <h2 className="text-[18px] font-semibold tracking-[-0.03em] text-ink">
                {insight?.ai_used ? "来自这段时间的回望" : "AI 回顾尚未启用"}
              </h2>
            </div>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-line/60 px-2.5 py-1 text-[9px] text-subtle dark:border-white/10">
              {insight?.mode === "local_statistics" ? "local_statistics" : "ai"}
            </span>
          </div>
          {insight?.narrative ? (
            <div className="mt-5">
              <blockquote className="serif-quote text-[17px] leading-8 text-ink/80">
                “{insight.narrative}”
              </blockquote>
              {insight.sources.length ? (
                <div className="mt-4 flex flex-wrap gap-1.5">
                  {insight.sources.slice(0, 5).map((source) => (
                    <Link
                      key={`${source.entry_id}-${source.revision_id}`}
                      to={`/diary/${source.entry_id}?version=${source.version ?? 1}`}
                      className="focus-ring inline-flex items-center gap-1 rounded-full border border-line/60 px-2.5 py-1 text-[9px] text-subtle hover:text-ink dark:border-white/10"
                    >
                      来源 · v{source.version ?? 1}
                      <ArrowUpRight className="h-2.5 w-2.5" />
                    </Link>
                  ))}
                </div>
              ) : null}
            </div>
          ) : (
            <div className="mt-5 rounded-[20px] border border-dashed border-line/70 bg-surface/25 p-5 dark:border-white/10 dark:bg-white/[0.02]">
              <div className="flex items-start gap-3">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[12px] border border-champagne/30 bg-champagne/10 text-[#806b43] dark:text-champagne">
                  <LockKeyhole className="h-4 w-4" />
                </span>
                <div>
                  <p className="text-[12px] font-medium text-ink/80">
                    没有调用外部模型，也没有编造一段回顾。
                  </p>
                  <p className="mt-1.5 text-[11px] leading-6 text-muted">
                    周/月回顾目前基于后端真实统计。启用 AI 后，叙事会基于记忆片段生成，并保留真实来源。
                  </p>
                  {insight?.notes?.length ? (
                    <ul className="mt-3 space-y-1.5">
                      {insight.notes.map((note) => (
                        <li key={note} className="text-[10px] leading-5 text-subtle">
                          · {note}
                        </li>
                      ))}
                    </ul>
                  ) : null}
                </div>
              </div>
            </div>
          )}
          <p className="mt-5 text-[9.5px] leading-5 text-subtle">{insight?.disclaimer}</p>
        </SurfaceCard>

        <SurfaceCard className="rounded-[26px] p-5 sm:p-6 lg:col-span-5">
          <div className="eyebrow mb-1.5">自我评价</div>
          <h2 className="text-[18px] font-semibold tracking-[-0.03em] text-ink">
            这一段时间，你想怎样形容自己？
          </h2>
          <p className="mt-2 text-[10.5px] leading-5 text-subtle">
            这不是 AI 评分。只保存在本机浏览器，不会上传，也不影响你的记忆。
          </p>
          <textarea
            value={reflection}
            onChange={(event) => {
              setReflection(event.target.value);
              setReflectionSaved(false);
            }}
            placeholder="比如：更愿意停下来，也更诚实了一点。"
            className="mt-4 min-h-[120px] w-full resize-y rounded-[18px] border border-line/70 bg-surface/50 p-3.5 text-[12.5px] leading-6 text-ink outline-none placeholder:text-subtle focus:border-ink/20 dark:border-white/10 dark:bg-white/[0.03]"
          />
          <div className="mt-3 flex items-center justify-between gap-3">
            <span className="text-[9.5px] text-subtle">
              {reflectionSaved ? "已保存在本机" : "本地草稿"}
            </span>
            <Button size="sm" variant="secondary" onClick={saveReflection}>
              保存自评
            </Button>
          </div>
        </SurfaceCard>
      </div>

      <SurfaceCard className="rounded-[26px] p-5 sm:p-6">
        <div className="flex items-start justify-between">
          <div>
            <div className="eyebrow mb-1.5">时间里的片段</div>
            <h2 className="text-[18px] font-semibold tracking-[-0.03em] text-ink">
              这段时间留下的记忆
            </h2>
          </div>
          <Link
            to="/memories"
            className="focus-ring inline-flex items-center gap-1 rounded-full px-2 py-1 text-[10.5px] text-muted hover:text-ink"
          >
            查看全部
            <ArrowUpRight className="h-3 w-3" />
          </Link>
        </div>
        {periodMemories.length ? (
          <div className="relative mt-5 space-y-2 pl-4">
            <div className="absolute bottom-3 left-[5px] top-3 w-px bg-gradient-to-b from-lavender/50 via-line to-transparent dark:via-white/10" />
            {periodMemories.map((memory) => (
              <div
                key={memory.id}
                className="relative flex items-start gap-3 rounded-[18px] border border-line/60 bg-surface/25 px-4 py-3.5 dark:border-white/10 dark:bg-white/[0.02]"
              >
                <span className="absolute -left-[15px] top-4 h-2.5 w-2.5 rounded-full border-2 border-canvas bg-lavender dark:border-canvas" />
                <span className="w-10 shrink-0 pt-0.5 text-[9.5px] text-subtle">
                  {formatDateShort(memory.created_at)}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <MemoryTypeBadge type={memory.memory_type} compact />
                    <span className="text-[9px] text-subtle">{formatDate(memory.created_at)}</span>
                  </div>
                  <p className="mt-2 line-clamp-3 text-[11.5px] leading-5 text-ink/70">
                    {memory.content}
                  </p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="mt-4">
            <EmptyState
              compact
              icon={Sparkles}
              title="这段时间还没有记忆片段"
              description="当你确认或保存记忆后，这里会出现它们与来源时间。"
            />
          </div>
        )}
      </SurfaceCard>
    </div>
  );
}

function MetricCard({
  label,
  value,
  unit,
  icon,
  tone,
}: {
  label: string;
  value: number | string;
  unit: string;
  icon: React.ReactNode;
  tone: "sage" | "lavender" | "rose";
}) {
  const toneClass = {
    sage: "border-sage/30 bg-sage/10 text-[#5e7565] dark:text-sage",
    lavender: "border-lavender/30 bg-lavender/10 text-[#716080] dark:text-lavender",
    rose: "border-rose/30 bg-rose/10 text-[#8a5a5a] dark:text-rose",
  }[tone];
  return (
    <SurfaceCard className="rounded-[24px] p-5">
      <div className="flex items-start justify-between">
        <span className="text-[10.5px] text-muted">{label}</span>
        <span className={`flex h-8 w-8 items-center justify-center rounded-[11px] border ${toneClass}`}>
          {icon}
        </span>
      </div>
      <div className="mt-4 flex items-baseline gap-1.5">
        <span className="font-editorial text-[34px] leading-none tracking-[-0.05em] text-ink/85">
          {value}
        </span>
        <span className="text-[9.5px] text-subtle">{unit}</span>
      </div>
    </SurfaceCard>
  );
}

function buildMoodPoints(
  diaries: DiaryListItem[],
  period: Period,
  referenceDate: Date,
): MoodPoint[] {
  if (period === "weekly") {
    const points: MoodPoint[] = [];
    for (let offset = 6; offset >= 0; offset -= 1) {
      const date = addDays(referenceDate, -offset);
      date.setHours(0, 0, 0, 0);
      const diary = diaries.find((item) => isSameDay(toDate(item.created_at), date));
      const mood = getMoodFromMetadata(diary?.metadata);
      points.push({
        date: isoDate(date),
        label: String(date.getDate()),
        score: mood?.score ?? null,
        mood: mood?.key,
      });
    }
    return points;
  }

  const points: MoodPoint[] = [];
  for (let bucket = 4; bucket >= 0; bucket -= 1) {
    const end = addDays(referenceDate, -bucket * 6);
    const start = addDays(end, -6);
    const scores = diaries
      .filter((diary) => {
        const date = toDate(diary.created_at);
        return date >= start && date <= end;
      })
      .map((diary) => getMoodFromMetadata(diary.metadata)?.score)
      .filter((score): score is number => typeof score === "number");
    const mood = scores.length
      ? getMoodFromMetadata(
          diaries.find((diary) => {
            const date = toDate(diary.created_at);
            return date >= start && date <= end && getMoodFromMetadata(diary.metadata)?.score;
          })?.metadata,
        )?.key
      : undefined;
    points.push({
      date: isoDate(end),
      label: `${end.getMonth() + 1}/${end.getDate()}`,
      score: scores.length
        ? scores.reduce((sum, score) => sum + score, 0) / scores.length
        : null,
      mood,
    });
  }
  return points;
}
