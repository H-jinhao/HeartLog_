import { useId } from "react";
import { motion, useReducedMotion } from "motion/react";
import type { MoodKey } from "@/types/api";
import { getMood } from "@/lib/moods";
import { cn } from "@/lib/utils";

export interface MoodPoint {
  date: string;
  label: string;
  score: number | null;
  mood?: MoodKey;
}

export function MoodChart({
  points,
  className,
  height = 148,
  showDots = true,
  emptyLabel = "还没有足够的心情记录",
}: {
  points: MoodPoint[];
  className?: string;
  height?: number;
  showDots?: boolean;
  emptyLabel?: string;
}) {
  const gradientId = useId().replace(/:/g, "");
  const reduce = useReducedMotion();
  const valid = points.filter((point) => typeof point.score === "number");
  const width = 360;
  const paddingX = 12;
  const paddingY = 16;
  const innerW = width - paddingX * 2;
  const innerH = height - paddingY * 2;
  const maxScore = 5;
  const minScore = 1;
  const xFor = (index: number) =>
    paddingX + (points.length <= 1 ? innerW / 2 : (index / (points.length - 1)) * innerW);
  const yFor = (score: number) =>
    paddingY + innerH - ((score - minScore) / (maxScore - minScore)) * innerH;

  if (!valid.length) {
    return (
      <div
        className={cn(
          "flex flex-col items-center justify-center rounded-[20px] border border-dashed border-line/70 bg-surface/25 px-4 text-center dark:border-white/10 dark:bg-white/[0.02]",
          className,
        )}
        style={{ height }}
      >
        <span className="text-[12px] text-muted">{emptyLabel}</span>
        <span className="mt-1 text-[10px] text-subtle">为日记选择心情后，趋势会在这里出现</span>
      </div>
    );
  }

  const validWithIndex = points
    .map((point, index) => ({ point, index }))
    .filter(({ point }) => point.score !== null) as { point: MoodPoint; index: number }[];

  const linePath = validWithIndex
    .map(({ point, index }, i) => {
      const command = i === 0 ? "M" : "L";
      return `${command}${xFor(index).toFixed(2)},${yFor(point.score as number).toFixed(2)}`;
    })
    .join(" ");

  const first = validWithIndex[0];
  const last = validWithIndex[validWithIndex.length - 1];
  const areaPath =
    first && last
      ? `${linePath} L${xFor(last.index).toFixed(2)},${height - paddingY} L${xFor(first.index).toFixed(
          2,
        )},${height - paddingY} Z`
      : "";

  return (
    <div className={cn("w-full", className)}>
      <svg
        viewBox={`0 0 ${width} ${height}`}
        role="img"
        aria-label="心情趋势图"
        className="w-full overflow-visible"
        style={{ height }}
        preserveAspectRatio="none"
      >
        <defs>
          <linearGradient id={`${gradientId}-area`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="rgb(var(--lavender))" stopOpacity="0.34" />
            <stop offset="100%" stopColor="rgb(var(--lavender))" stopOpacity="0" />
          </linearGradient>
          <linearGradient id={`${gradientId}-line`} x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="rgb(var(--sage))" />
            <stop offset="48%" stopColor="rgb(var(--lavender))" />
            <stop offset="100%" stopColor="rgb(var(--rose))" />
          </linearGradient>
        </defs>

        {[1, 2, 3, 4, 5].map((score) => (
          <line
            key={score}
            x1={paddingX}
            x2={width - paddingX}
            y1={yFor(score)}
            y2={yFor(score)}
            stroke="rgb(var(--line))"
            strokeOpacity={score === 3 ? 0.55 : 0.28}
            strokeDasharray={score === 3 ? "2 5" : "1 7"}
            strokeWidth="0.8"
          />
        ))}

        <motion.path
          d={areaPath}
          fill={`url(#${gradientId}-area)`}
          initial={reduce ? false : { opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.15 }}
        />
        <motion.path
          d={linePath}
          fill="none"
          stroke={`url(#${gradientId}-line)`}
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          initial={reduce ? false : { pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: 1 }}
          transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
        />

        {showDots
          ? validWithIndex.map(({ point, index }) => {
              const meta = getMood(point.mood);
              return (
                <g key={`${point.date}-${point.score}`}>
                  <circle
                    cx={xFor(index)}
                    cy={yFor(point.score as number)}
                    r="6.5"
                    fill="rgb(var(--canvas))"
                    opacity="0.9"
                  />
                  <circle
                    cx={xFor(index)}
                    cy={yFor(point.score as number)}
                    r="3"
                    fill={meta?.color ?? "rgb(var(--lavender))"}
                    stroke="rgb(var(--surface))"
                    strokeWidth="1.2"
                  >
                    <title>{`${point.label} · ${meta?.label ?? "心情"}`}</title>
                  </circle>
                </g>
              );
            })
          : null}
      </svg>
      <div className="mt-1 flex items-center justify-between text-[9px] text-subtle/80">
        {points.map((point) => (
          <span key={point.date}>{point.label}</span>
        ))}
      </div>
    </div>
  );
}
