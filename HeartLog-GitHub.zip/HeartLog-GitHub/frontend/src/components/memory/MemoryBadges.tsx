import { Bookmark, Compass, HeartPulse, Sparkles } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import type { MemoryType, VerificationStatus } from "@/types/api";
import { cn } from "@/lib/utils";

const typeMeta: Record<
  MemoryType,
  { label: string; shortLabel: string; icon: LucideIcon; tone: string; dot: string }
> = {
  explicit_fact: {
    label: "明确事实",
    shortLabel: "事实",
    icon: Bookmark,
    tone: "border-sage/35 bg-sage/12 text-[#5e7565] dark:text-sage",
    dot: "bg-sage",
  },
  subjective_feeling: {
    label: "主观感受",
    shortLabel: "感受",
    icon: HeartPulse,
    tone: "border-rose/35 bg-rose/12 text-[#8a5a5a] dark:text-rose",
    dot: "bg-rose",
  },
  explicit_belief: {
    label: "明确观点",
    shortLabel: "观点",
    icon: Compass,
    tone: "border-champagne/45 bg-champagne/14 text-[#7f6a42] dark:text-champagne",
    dot: "bg-champagne",
  },
  model_inference: {
    label: "AI 推断",
    shortLabel: "推断",
    icon: Sparkles,
    tone: "border-lavender/40 bg-lavender/13 text-[#6f5e82] dark:text-lavender",
    dot: "bg-lavender",
  },
};

const statusMeta: Record<
  VerificationStatus,
  { label: string; className: string; dot: string }
> = {
  pending: {
    label: "待确认",
    className: "border-champagne/40 bg-champagne/10 text-[#806b43] dark:text-champagne",
    dot: "bg-champagne",
  },
  confirmed: {
    label: "已确认",
    className: "border-sage/35 bg-sage/10 text-[#5e7565] dark:text-sage",
    dot: "bg-sage",
  },
  superseded: {
    label: "已取代",
    className: "border-line bg-ink/[0.035] text-muted",
    dot: "bg-muted",
  },
  revoked: {
    label: "已撤回",
    className: "border-rose/30 bg-rose/[0.07] text-[#8a5a5a] dark:text-rose",
    dot: "bg-rose",
  },
};

export function MemoryTypeBadge({
  type,
  compact = false,
  className,
}: {
  type: MemoryType;
  compact?: boolean;
  className?: string;
}) {
  const meta = typeMeta[type];
  const Icon = meta.icon;
  return (
    <span
      className={cn(
        "inline-flex h-7 items-center gap-1.5 rounded-full border px-2.5 text-[10.5px] font-medium tracking-[0.01em]",
        meta.tone,
        className,
      )}
    >
      <Icon className="h-3 w-3" strokeWidth={1.8} />
      {compact ? meta.shortLabel : meta.label}
    </span>
  );
}

export function MemoryStatusBadge({
  status,
  className,
}: {
  status: VerificationStatus;
  className?: string;
}) {
  const meta = statusMeta[status];
  return (
    <span
      className={cn(
        "inline-flex h-7 items-center gap-1.5 rounded-full border px-2.5 text-[10.5px] font-medium",
        meta.className,
        className,
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", meta.dot)} />
      {meta.label}
    </span>
  );
}

export function memoryTypeLabel(type: MemoryType): string {
  return typeMeta[type].label;
}

export function memoryStatusLabel(status: VerificationStatus): string {
  return statusMeta[status].label;
}

export function memoryTypeDescription(type: MemoryType): string {
  switch (type) {
    case "explicit_fact":
      return "你在原文中明确陈述的事实";
    case "subjective_feeling":
      return "你当时真实感受到的情绪";
    case "explicit_belief":
      return "你明确表达过的价值观或判断";
    case "model_inference":
      return "模型根据记录作出的解释，不是事实";
  }
}
