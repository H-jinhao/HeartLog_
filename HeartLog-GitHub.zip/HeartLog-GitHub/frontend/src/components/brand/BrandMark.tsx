import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";

export function BrandMark({
  compact = false,
  className,
}: {
  compact?: boolean;
  className?: string;
}) {
  return (
    <Link
      to="/"
      aria-label="HeartLog 首页"
      className={cn("focus-ring group inline-flex items-center gap-2.5 rounded-2xl", className)}
    >
      <span className="relative flex h-9 w-9 items-center justify-center overflow-hidden rounded-[13px] border border-white/60 bg-white/40 shadow-[0_6px_18px_-8px_rgb(var(--glass-shadow)),inset_0_1px_0_rgb(255_255_255/0.8)] dark:border-white/10 dark:bg-white/[0.06]">
        <span className="absolute inset-0 bg-[radial-gradient(circle_at_30%_25%,rgb(var(--lavender)/0.55),transparent_60%),radial-gradient(circle_at_75%_80%,rgb(var(--rose)/0.42),transparent_65%)]" />
        <svg
          viewBox="0 0 32 32"
          className="relative h-[19px] w-[19px]"
          fill="none"
          aria-hidden="true"
        >
          <path
            d="M9 10.5c0 6.4 3.8 11.6 11.4 11.6-7.6 0-11.4 5.2-11.4 11.6"
            stroke="rgb(var(--ink))"
            strokeWidth="2.2"
            strokeLinecap="round"
            opacity="0.82"
          />
          <circle cx="22.4" cy="10.4" r="2.1" fill="rgb(var(--rose))" />
        </svg>
      </span>
      {!compact ? (
        <span className="flex items-baseline gap-2">
          <span className="text-[16px] font-semibold tracking-[-0.045em] text-ink">HeartLog</span>
          <span className="hidden text-[10px] font-medium tracking-[0.22em] text-subtle sm:inline">
            心迹
          </span>
        </span>
      ) : null}
    </Link>
  );
}
