import { useEffect } from "react";
import { Outlet, useLocation } from "react-router-dom";
import { Sidebar } from "@/components/layout/Sidebar";
import { MobileNav } from "@/components/layout/MobileNav";
import { TopBar } from "@/components/layout/TopBar";
import { PageTransition } from "@/components/layout/PageTransition";
import { SearchDialog } from "@/components/layout/SearchDialog";
import { DemoBanner } from "@/components/common/DemoBanner";
import { QuickComposer } from "@/components/diary/QuickComposer";
import { ToastViewport } from "@/components/ui/Toast";
import { useApp } from "@/context/AppContext";

export function AppShell() {
  const location = useLocation();
  const { openComposer, openSearch, searchOpen, composer } = useApp();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "auto" });
  }, [location.pathname]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing =
        target?.tagName === "INPUT" ||
        target?.tagName === "TEXTAREA" ||
        target?.isContentEditable;

      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        openSearch();
        return;
      }

      if (typing || searchOpen || composer.open) return;
      if (
        event.key.toLowerCase() === "n" &&
        !event.metaKey &&
        !event.ctrlKey &&
        !event.altKey
      ) {
        event.preventDefault();
        openComposer();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [composer.open, openComposer, openSearch, searchOpen]);

  return (
    <div className="relative min-h-dvh bg-canvas text-ink">
      <div className="ambient-stage" aria-hidden="true">
        <div className="ambient-orb ambient-orb--one" />
        <div className="ambient-orb ambient-orb--two" />
        <div className="ambient-orb ambient-orb--three" />
      </div>
      <div className="grain-layer" aria-hidden="true" />

      <Sidebar />

      <div className="relative min-h-dvh md:pl-[268px]">
        <div className="mx-auto w-full max-w-[1240px] px-3 pb-32 sm:px-5 md:px-8 md:pb-12">
          <TopBar />
          <DemoBanner className="mb-4" />
          <main>
            <PageTransition>
              <Outlet />
            </PageTransition>
          </main>
          <footer className="mt-16 hidden items-center justify-between border-t border-line/40 pt-5 text-[10px] tracking-[0.08em] text-subtle md:flex dark:border-white/[0.06]">
            <span>HeartLog · 只属于你的记录</span>
            <span>原文不可变 · 记忆可追溯 · 数据留在本机</span>
          </footer>
        </div>
      </div>

      <MobileNav />
      <QuickComposer />
      <SearchDialog />
      <ToastViewport />
    </div>
  );
}
