import { NavLink, useNavigate } from "react-router-dom";
import { motion } from "motion/react";
import {
  BookOpenText,
  ChartNoAxesColumn,
  Home,
  Moon,
  NotebookPen,
  Plus,
  Sparkles,
  Sun,
  UserRound,
} from "lucide-react";
import { BrandMark } from "@/components/brand/BrandMark";
import { useApp } from "@/context/AppContext";
import { cn, initials } from "@/lib/utils";

const navItems = [
  { to: "/", label: "首页", icon: Home, end: true },
  { to: "/diary", label: "日记", icon: NotebookPen },
  { to: "/memories", label: "长期记忆", icon: BookOpenText },
  { to: "/insights", label: "情绪分析", icon: ChartNoAxesColumn },
  { to: "/profile", label: "我的", icon: UserRound },
];

export function Sidebar() {
  const { openComposer, profileName, effectiveTheme, toggleTheme } = useApp();
  const navigate = useNavigate();

  return (
    <aside className="fixed bottom-4 left-4 top-4 z-40 hidden w-[236px] md:block">
      <div className="glass-strong flex h-full flex-col rounded-[32px] p-3">
        <div className="px-3 pb-5 pt-3">
          <BrandMark />
        </div>

        <button
          type="button"
          onClick={() => openComposer()}
          className="focus-ring press mb-5 flex h-11 w-full items-center justify-between rounded-2xl border border-white/50 bg-white/30 px-3.5 text-[12.5px] font-medium text-ink/85 shadow-[inset_0_1px_0_rgb(255_255_255/0.55)] transition-colors hover:bg-white/45 dark:border-white/10 dark:bg-white/[0.05] dark:hover:bg-white/[0.08]"
        >
          <span className="inline-flex items-center gap-2">
            <Plus className="h-4 w-4" strokeWidth={1.8} />
            写一笔
          </span>
          <kbd className="rounded-md border border-line/70 bg-white/20 px-1.5 py-0.5 font-sans text-[9px] font-normal text-subtle dark:border-white/10 dark:bg-white/[0.04]">
            N
          </kbd>
        </button>

        <nav aria-label="主导航" className="flex flex-col gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) =>
                  cn(
                    "nav-pill focus-ring group relative flex h-11 items-center gap-3 rounded-[15px] px-3.5 text-[12.5px] transition-colors",
                    isActive
                      ? "font-medium text-ink"
                      : "text-muted hover:bg-ink/[0.045] hover:text-ink/85",
                  )
                }
              >
                {({ isActive }) => (
                  <>
                    {isActive ? (
                      <motion.span
                        layoutId="sidebar-active"
                        className="absolute inset-0 rounded-[15px] border border-white/50 bg-white/35 shadow-[inset_0_1px_0_rgb(255_255_255/0.7),0_8px_20px_-18px_rgb(var(--glass-shadow))] dark:border-white/10 dark:bg-white/[0.075]"
                        transition={{ type: "spring", stiffness: 380, damping: 32 }}
                      />
                    ) : null}
                    <Icon
                      className={cn(
                        "relative h-[17px] w-[17px] transition-transform duration-300 group-hover:scale-[1.04]",
                        isActive ? "text-ink/80" : "text-muted/80",
                      )}
                      strokeWidth={1.7}
                    />
                    <span className="relative">{item.label}</span>
                    {isActive ? (
                      <span className="relative ml-auto h-1 w-1 rounded-full bg-ink/55" />
                    ) : null}
                  </>
                )}
              </NavLink>
            );
          })}
        </nav>

        <div className="mt-auto">
          <div className="mb-3 rounded-[20px] border border-white/35 bg-white/20 p-3.5 dark:border-white/10 dark:bg-white/[0.035]">
            <div className="flex items-center gap-1.5 text-[10px] font-medium tracking-[0.12em] text-subtle">
              <Sparkles className="h-3 w-3" />
              安静地记住
            </div>
            <p className="mt-2 text-[10.5px] leading-[1.7] text-muted">
              原文不变。每一段记忆，都能回到你写下它的那一刻。
            </p>
          </div>

          <div className="flex items-center gap-2 rounded-[18px] px-1 py-1">
            <button
              type="button"
              onClick={() => navigate("/profile")}
              className="focus-ring flex min-w-0 flex-1 items-center gap-2.5 rounded-[14px] p-1.5 text-left hover:bg-ink/[0.04]"
            >
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[12px] border border-white/50 bg-gradient-to-br from-lavender/35 to-rose/25 text-[12px] font-medium text-ink/70 dark:border-white/10">
                {initials(profileName || "你")}
              </span>
              <span className="min-w-0">
                <span className="block truncate text-[12px] font-medium text-ink/85">
                  {profileName || "你的空间"}
                </span>
                <span className="block text-[10px] text-subtle">本地 · 私密</span>
              </span>
            </button>
            <button
              type="button"
              onClick={toggleTheme}
              aria-label={effectiveTheme === "dark" ? "切换到浅色模式" : "切换到深色模式"}
              className="focus-ring press flex h-9 w-9 shrink-0 items-center justify-center rounded-[12px] text-muted transition-colors hover:bg-ink/[0.05] hover:text-ink"
            >
              {effectiveTheme === "dark" ? (
                <Sun className="h-4 w-4" strokeWidth={1.6} />
              ) : (
                <Moon className="h-4 w-4" strokeWidth={1.6} />
              )}
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
}
