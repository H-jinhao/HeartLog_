import { NavLink, useLocation } from "react-router-dom";
import { motion } from "motion/react";
import { BookOpenText, Home, NotebookPen, Plus, UserRound } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { cn } from "@/lib/utils";

const items = [
  { to: "/", label: "首页", icon: Home, end: true },
  { to: "/diary", label: "日记", icon: NotebookPen, end: false },
  { to: "/memories", label: "记忆", icon: BookOpenText, end: false },
  { to: "/profile", label: "我的", icon: UserRound, end: false },
];

export function MobileNav() {
  const { openComposer } = useApp();
  const location = useLocation();
  if (/^\/diary\/[^/]+$/.test(location.pathname)) return null;
  return (
    <>
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-x-0 bottom-0 z-40 h-32 bg-gradient-to-t from-canvas via-canvas/80 to-transparent md:hidden"
      />
      <nav
        aria-label="移动端主导航"
        className="glass-strong fixed bottom-nav-offset left-3 right-3 z-50 rounded-[26px] px-2 py-2 md:hidden"
      >
      <div className="grid grid-cols-5 items-center">
        {items.slice(0, 2).map((item) => (
          <MobileItem key={item.to} {...item} />
        ))}
        <div className="flex items-center justify-center">
          <button
            type="button"
            onClick={() => openComposer()}
            aria-label="新建日记"
            className="press focus-ring -mt-5 flex h-[52px] w-[52px] items-center justify-center rounded-[19px] border border-white/20 bg-ink text-canvas shadow-[0_14px_28px_-14px_rgb(var(--ink)/0.6),inset_0_1px_0_rgb(255_255_255/0.2)] transition-transform hover:scale-[1.015]"
          >
            <Plus className="h-5 w-5" strokeWidth={1.8} />
          </button>
        </div>
        {items.slice(2).map((item) => (
          <MobileItem key={item.to} {...item} />
        ))}
      </div>
      </nav>
    </>
  );
}

function MobileItem({
  to,
  label,
  icon: Icon,
  end,
}: {
  to: string;
  label: string;
  icon: typeof Home;
  end: boolean;
}) {
  return (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) =>
        cn(
          "focus-ring relative flex h-[48px] flex-col items-center justify-center gap-0.5 rounded-[17px] text-[9.5px] font-medium transition-colors",
          isActive ? "text-ink" : "text-muted/80 hover:text-ink",
        )
      }
    >
      {({ isActive }) => (
        <>
          {isActive ? (
            <motion.span
              layoutId="mobile-active"
              className="absolute inset-x-1 inset-y-0 -z-10 rounded-[16px] bg-ink/[0.065] dark:bg-white/[0.065]"
              transition={{ type: "spring", stiffness: 380, damping: 32 }}
            />
          ) : null}
          <Icon className="h-[19px] w-[19px]" strokeWidth={isActive ? 2 : 1.65} />
          <span>{label}</span>
        </>
      )}
    </NavLink>
  );
}
