import { useLocation, useNavigate } from "react-router-dom";
import { CalendarDays, Moon, Search, Sun, Plus } from "lucide-react";
import { BrandMark } from "@/components/brand/BrandMark";
import { ConnectionPill } from "@/components/common/ConnectionPill";
import { IconButton } from "@/components/ui/IconButton";
import { useApp } from "@/context/AppContext";
import { formatDate, formatWeekday } from "@/lib/utils";

const pageLabels: Record<string, string> = {
  "/": "首页",
  "/diary": "日记",
  "/memories": "长期记忆",
  "/insights": "情绪分析",
  "/profile": "我的",
};

export function TopBar() {
  const { openSearch, effectiveTheme, toggleTheme, openComposer } = useApp();
  const location = useLocation();
  const navigate = useNavigate();
  const section = location.pathname.startsWith("/diary/")
    ? "日记"
    : pageLabels[location.pathname] ?? "HeartLog";

  return (
    <div className="sticky top-0 z-30 -mx-3 px-3 pb-3 pt-[calc(env(safe-area-inset-top)+0.75rem)] sm:-mx-5 sm:px-5 md:pt-3">
      <div className="glass-quiet mx-auto flex h-[54px] max-w-[1240px] items-center gap-3 rounded-[22px] px-3 sm:px-4">
        <div className="flex min-w-0 items-center gap-3 md:hidden">
          <BrandMark />
        </div>
        <div className="hidden items-center gap-2.5 md:flex">
          <button
            type="button"
            onClick={() => navigate("/")}
            className="focus-ring rounded-xl p-1"
            aria-label="回到首页"
          >
            <BrandMark />
          </button>
          <span className="h-4 w-px bg-line/80" />
          <span className="text-[12px] font-medium tracking-[-0.01em] text-ink/70">
            {section}
          </span>
          <span className="hidden items-center gap-1.5 text-[10.5px] text-subtle lg:flex">
            <CalendarDays className="h-3 w-3" />
            {formatDate(new Date())} · {formatWeekday(new Date())}
          </span>
        </div>

        <div className="ml-auto flex items-center gap-1.5">
          <button
            type="button"
            onClick={openSearch}
            className="focus-ring press group flex h-9 items-center gap-2 rounded-[14px] border border-line/60 bg-surface/45 px-2.5 text-[11.5px] text-muted transition-colors hover:border-line hover:bg-surface/70 hover:text-ink sm:min-w-[190px] dark:border-white/10 dark:bg-white/[0.035]"
          >
            <Search className="h-3.5 w-3.5" strokeWidth={1.7} />
            <span className="hidden flex-1 text-left sm:inline">搜索日记与记忆</span>
            <span className="hidden items-center gap-0.5 rounded-md border border-line/60 px-1 py-0.5 text-[8.5px] text-subtle sm:inline-flex dark:border-white/10">
              <span className="text-[9px]">⌘</span>K
            </span>
          </button>
          <ConnectionPill className="hidden sm:inline-flex" />
          <IconButton
            aria-label={effectiveTheme === "dark" ? "切换到浅色模式" : "切换到深色模式"}
            icon={
              effectiveTheme === "dark" ? (
                <Sun strokeWidth={1.6} />
              ) : (
                <Moon strokeWidth={1.6} />
              )
            }
            variant="ghost"
            size="sm"
            onClick={toggleTheme}
          />
          <button
            type="button"
            onClick={() => openComposer()}
            aria-label="新建日记"
            className="press focus-ring hidden h-9 items-center gap-1.5 rounded-[14px] bg-ink px-3.5 text-[11.5px] font-medium text-canvas shadow-[0_8px_20px_-12px_rgb(var(--ink)/0.55)] md:inline-flex"
          >
            <Plus className="h-3.5 w-3.5" />
            写一笔
          </button>
        </div>
      </div>
    </div>
  );
}
