import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowUpRight, BookOpenText, LoaderCircle, Search, Sparkles } from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { Input } from "@/components/ui/Field";
import { useApp } from "@/context/AppContext";
import { searchHeartLog } from "@/api/misc";
import { getDemoSearch } from "@/lib/demo";
import type { SearchHit } from "@/types/api";
import { MemoryTypeBadge } from "@/components/memory/MemoryBadges";
import { cn, formatDate } from "@/lib/utils";

const suggestions = ["小林", "散步", "成长", "想念", "书"];

export function SearchDialog() {
  const { searchOpen, closeSearch, demoMode, backend } = useApp();
  const [query, setQuery] = useState("");
  const [hits, setHits] = useState<SearchHit[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!searchOpen) return;
    window.setTimeout(() => inputRef.current?.focus(), 80);
  }, [searchOpen]);

  useEffect(() => {
    if (!searchOpen) return;
    const trimmed = query.trim();
    if (!trimmed) {
      setHits([]);
      setError(null);
      setLoading(false);
      return;
    }
    let cancelled = false;
    setLoading(true);
    setError(null);
    const timer = window.setTimeout(async () => {
      try {
        if (demoMode || backend.state !== "online") {
          const response = getDemoSearch(trimmed);
          if (!cancelled) setHits(response.items);
        } else {
          const response = await searchHeartLog(trimmed, { limit: 12 });
          if (!cancelled) setHits(response.items);
        }
      } catch (caught) {
        if (!cancelled) {
          setHits([]);
          setError(caught instanceof Error ? caught.message : "搜索失败");
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }, 260);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [query, searchOpen, demoMode, backend.state]);

  const openHit = (hit: SearchHit) => {
    closeSearch();
    if (hit.kind === "diary") {
      navigate(`/diary/${hit.entry_id}?version=${hit.version}`);
    } else if (hit.memory_id) {
      navigate(`/memories?focus=${hit.memory_id}`);
    }
  };

  return (
    <Modal
      open={searchOpen}
      onClose={closeSearch}
      title="在记忆里找一找"
      eyebrow="Search"
      description={
        demoMode
          ? "演示模式：搜索固定示例数据，不会访问你的真实记录。"
          : "搜索日记原文、修订与已保存的记忆；结果保留来源版本。"
      }
      size="lg"
      panelClassName="sm:mt-[-8vh]"
    >
      <div className="space-y-5">
        <div className="relative">
          <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-subtle" />
          <Input
            ref={inputRef}
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="搜索一段话、一个人、一种感受…"
            aria-label="搜索日记与记忆"
            className="h-[52px] rounded-[18px] pl-11 pr-12 text-[14px]"
          />
          {loading ? (
            <LoaderCircle className="absolute right-4 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-subtle" />
          ) : null}
        </div>

        {!query.trim() ? (
          <div className="rounded-[20px] border border-line/60 bg-surface/35 p-5 dark:border-white/10 dark:bg-white/[0.02]">
            <div className="mb-3 flex items-center gap-2 text-[10.5px] font-medium tracking-[0.14em] text-subtle">
              <Sparkles className="h-3 w-3" />
              可以试着搜索
            </div>
            <div className="flex flex-wrap gap-2">
              {suggestions.map((suggestion) => (
                <button
                  key={suggestion}
                  type="button"
                  onClick={() => setQuery(suggestion)}
                  className="focus-ring press rounded-full border border-line/70 bg-white/25 px-3 py-1.5 text-[12px] text-muted transition-colors hover:bg-white/45 hover:text-ink dark:border-white/10 dark:bg-white/[0.03]"
                >
                  {suggestion}
                </button>
              ))}
            </div>
            <p className="mt-4 text-[11px] leading-5 text-subtle">
              搜索使用后端的关键词匹配，不会编造你没有写过的内容。
            </p>
          </div>
        ) : null}

        {error ? (
          <div className="rounded-[18px] border border-rose/30 bg-rose/10 px-4 py-3 text-[12px] text-rose">
            {error}
          </div>
        ) : null}

        {query.trim() && !loading && !error && hits.length === 0 ? (
          <div className="py-10 text-center">
            <Search className="mx-auto h-6 w-6 text-subtle" strokeWidth={1.4} />
            <p className="mt-3 text-[14px] font-medium text-ink">没有找到对应记录</p>
            <p className="mt-1.5 text-[12px] text-muted">换一个词试试，或回到日记里慢慢翻看。</p>
          </div>
        ) : null}

        {hits.length > 0 ? (
          <div className="space-y-2">
            <div className="flex items-center justify-between px-1 text-[10.5px] text-subtle">
              <span>{hits.length} 条结果</span>
              <span>按时间排序</span>
            </div>
            {hits.map((hit) => (
              <button
                key={`${hit.kind}-${hit.revision_id}-${hit.memory_id ?? ""}`}
                type="button"
                onClick={() => openHit(hit)}
                className="focus-ring group flex w-full items-start gap-3 rounded-[18px] border border-transparent px-3.5 py-3 text-left transition-colors hover:border-line/60 hover:bg-white/30 dark:hover:border-white/10 dark:hover:bg-white/[0.035]"
              >
                <span
                  className={cn(
                    "mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-[11px] border",
                    hit.kind === "diary"
                      ? "border-sage/30 bg-sage/10 text-[#617a69] dark:text-sage"
                      : "border-lavender/30 bg-lavender/10 text-[#716080] dark:text-lavender",
                  )}
                >
                  {hit.kind === "diary" ? (
                    <BookOpenText className="h-3.5 w-3.5" />
                  ) : (
                    <Sparkles className="h-3.5 w-3.5" />
                  )}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex flex-wrap items-center gap-2 text-[10.5px] text-subtle">
                    <span>{hit.kind === "diary" ? "日记" : "记忆"}</span>
                    <span>·</span>
                    <span>{formatDate(hit.created_at)}</span>
                    <span>·</span>
                    <span>版本 {hit.version}</span>
                    {hit.memory_type ? <MemoryTypeBadge type={hit.memory_type} compact /> : null}
                  </span>
                  <span className="mt-1 block text-[13px] leading-6 text-ink/85">
                    {hit.snippet}
                  </span>
                </span>
                <ArrowUpRight className="mt-1 h-3.5 w-3.5 shrink-0 text-subtle opacity-0 transition-opacity group-hover:opacity-100" />
              </button>
            ))}
          </div>
        ) : null}
      </div>
    </Modal>
  );
}
