import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from "react";
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

type Variant = "primary" | "secondary" | "ghost" | "danger" | "soft";
type Size = "sm" | "md" | "lg";

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  leadingIcon?: ReactNode;
  trailingIcon?: ReactNode;
  fullWidth?: boolean;
}

const variantClasses: Record<Variant, string> = {
  primary:
    "bg-ink text-canvas shadow-[0_12px_28px_-16px_rgb(var(--ink)/0.55)] hover:bg-ink/90 border border-ink/10",
  secondary:
    "glass-quiet text-ink hover:bg-elevated/85 border border-white/35 dark:border-white/10",
  ghost: "text-ink/75 hover:bg-ink/[0.055] hover:text-ink border border-transparent",
  danger:
    "border border-rose/45 bg-rose/15 text-[#8b5151] hover:bg-rose/25 dark:text-rose",
  soft: "surface-card text-ink hover:border-line/80 hover:bg-elevated/80",
};

const sizeClasses: Record<Size, string> = {
  sm: "h-9 rounded-[13px] px-3.5 text-[12.5px] gap-1.5",
  md: "h-11 rounded-2xl px-5 text-[13.5px] gap-2",
  lg: "h-[52px] rounded-[18px] px-6 text-[14.5px] gap-2.5",
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  {
    className,
    variant = "primary",
    size = "md",
    loading = false,
    leadingIcon,
    trailingIcon,
    fullWidth,
    disabled,
    children,
    type = "button",
    ...props
  },
  ref,
) {
  return (
    <button
      ref={ref}
      type={type}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={cn(
        "press focus-ring inline-flex select-none items-center justify-center whitespace-nowrap font-medium tracking-[-0.01em] disabled:cursor-not-allowed disabled:opacity-45",
        variantClasses[variant],
        sizeClasses[size],
        fullWidth && "w-full",
        className,
      )}
      {...props}
    >
      {loading ? (
        <Loader2 className="h-[1.05em] w-[1.05em] animate-spin" aria-hidden />
      ) : (
        leadingIcon
      )}
      <span>{children}</span>
      {!loading && trailingIcon}
    </button>
  );
});
