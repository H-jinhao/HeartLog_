import { forwardRef, type HTMLAttributes } from "react";
import { cn } from "@/lib/utils";

type Tone = "default" | "quiet" | "strong";

export interface GlassPanelProps extends HTMLAttributes<HTMLDivElement> {
  tone?: Tone;
}

const tones: Record<Tone, string> = {
  default: "glass",
  quiet: "glass-quiet",
  strong: "glass-strong",
};

export const GlassPanel = forwardRef<HTMLDivElement, GlassPanelProps>(function GlassPanel(
  { className, tone = "default", ...props },
  ref,
) {
  return <div ref={ref} className={cn(tones[tone], "rounded-[28px]", className)} {...props} />;
});
