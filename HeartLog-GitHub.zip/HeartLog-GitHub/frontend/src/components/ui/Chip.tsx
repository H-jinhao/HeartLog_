import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/utils";

type Tone = "neutral" | "rose" | "lavender" | "sage" | "champagne" | "mist";

const tones: Record<Tone, string> = {
  neutral: "border-line/80 bg-elevated/60 text-muted",
  rose: "border-rose/35 bg-rose/12 text-[#8a5a5a] dark:text-rose",
  lavender: "border-lavender/40 bg-lavender/14 text-[#6f5e82] dark:text-lavender",
  sage: "border-sage/40 bg-sage/14 text-[#5e7565] dark:text-sage",
  champagne: "border-champagne/45 bg-champagne/16 text-[#7f6a42] dark:text-champagne",
  mist: "border-mist/40 bg-mist/14 text-[#5c6d82] dark:text-mist",
};

export interface ChipProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  tone?: Tone;
  active?: boolean;
  icon?: ReactNode;
}

export function Chip({ className, tone = "neutral", active, icon, children, ...props }: ChipProps) {
  return (
    <button
      type="button"
      aria-pressed={props.onClick ? Boolean(active) : undefined}
      className={cn(
        "press focus-ring inline-flex h-8 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full border px-3 text-[11.5px] font-medium tracking-[0.01em]",
        tones[tone],
        active && "border-ink/20 bg-ink/[0.08] text-ink shadow-inner-soft",
        className,
      )}
      {...props}
    >
      {icon}
      {children}
    </button>
  );
}
