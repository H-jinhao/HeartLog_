import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from "react";
import { cn } from "@/lib/utils";

type Variant = "glass" | "ghost" | "solid" | "danger";
type Size = "sm" | "md" | "lg";

export interface IconButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  "aria-label": string;
  icon: ReactNode;
  variant?: Variant;
  size?: Size;
  active?: boolean;
}

const variants: Record<Variant, string> = {
  glass:
    "glass-quiet text-ink/80 hover:bg-elevated/80 hover:text-ink border border-white/40 dark:border-white/10",
  ghost: "text-muted hover:bg-ink/[0.055] hover:text-ink border border-transparent",
  solid: "bg-ink text-canvas hover:bg-ink/90 border border-ink/10",
  danger:
    "border border-rose/40 bg-rose/10 text-[#8a4e4e] hover:bg-rose/20 dark:text-rose",
};

const sizes: Record<Size, string> = {
  sm: "h-9 w-9 rounded-[13px]",
  md: "h-11 w-11 rounded-2xl",
  lg: "h-12 w-12 rounded-[18px]",
};

export const IconButton = forwardRef<HTMLButtonElement, IconButtonProps>(function IconButton(
  { className, icon, variant = "glass", size = "md", active, type = "button", ...props },
  ref,
) {
  return (
    <button
      ref={ref}
      type={type}
      data-active={active || undefined}
      className={cn(
        "press focus-ring inline-flex shrink-0 items-center justify-center transition-colors [&_svg]:h-[18px] [&_svg]:w-[18px]",
        variants[variant],
        sizes[size],
        active && "bg-ink text-canvas hover:bg-ink",
        className,
      )}
      {...props}
    >
      {icon}
    </button>
  );
});
