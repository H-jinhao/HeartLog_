import {
  forwardRef,
  type InputHTMLAttributes,
  type ReactNode,
  type TextareaHTMLAttributes,
} from "react";
import { cn } from "@/lib/utils";

export function Field({
  label,
  hint,
  error,
  htmlFor,
  children,
  className,
}: {
  label?: ReactNode;
  hint?: ReactNode;
  error?: ReactNode;
  htmlFor?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("space-y-2", className)}>
      {label ? (
        <label
          htmlFor={htmlFor}
          className="flex items-center justify-between text-[12px] font-medium tracking-wide text-muted"
        >
          <span>{label}</span>
          {hint ? <span className="font-normal text-subtle">{hint}</span> : null}
        </label>
      ) : null}
      {children}
      {error ? (
        <p role="alert" className="text-[12px] leading-5 text-rose">
          {error}
        </p>
      ) : null}
    </div>
  );
}

const fieldClasses =
  "focus-ring w-full rounded-2xl border border-line/80 bg-surface/70 px-4 text-ink placeholder:text-subtle/80 transition-colors hover:border-line focus:border-ink/20 focus:bg-surface dark:border-white/10 dark:bg-white/[0.035] dark:focus:bg-white/[0.055]";

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(
  function Input({ className, ...props }, ref) {
    return <input ref={ref} className={cn(fieldClasses, "h-11 text-[13.5px]", className)} {...props} />;
  },
);

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaHTMLAttributes<HTMLTextAreaElement>>(
  function Textarea({ className, ...props }, ref) {
    return (
      <textarea
        ref={ref}
        className={cn(fieldClasses, "min-h-[120px] resize-y py-3 text-[14px] leading-7", className)}
        {...props}
      />
    );
  },
);
