import { AlertCircle, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/Button";

export function ErrorState({
  title = "暂时无法加载",
  description,
  onRetry,
  retryLabel = "重新加载",
}: {
  title?: string;
  description?: string;
  onRetry?: () => void;
  retryLabel?: string;
}) {
  return (
    <div className="surface-card flex flex-col items-center rounded-[24px] px-6 py-14 text-center">
      <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl border border-rose/30 bg-rose/10 text-rose">
        <AlertCircle className="h-5 w-5" />
      </div>
      <h3 className="text-[16px] font-medium tracking-[-0.02em] text-ink">{title}</h3>
      {description ? (
        <p className="mt-2 max-w-[360px] text-[12.5px] leading-6 text-muted">{description}</p>
      ) : null}
      {onRetry ? (
        <Button
          variant="secondary"
          size="sm"
          className="mt-5"
          onClick={onRetry}
          leadingIcon={<RefreshCw className="h-3.5 w-3.5" />}
        >
          {retryLabel}
        </Button>
      ) : null}
    </div>
  );
}
