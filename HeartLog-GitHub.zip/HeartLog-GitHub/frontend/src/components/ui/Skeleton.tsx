import { cn } from "@/lib/utils";

export function Skeleton({ className }: { className?: string }) {
  return <div aria-hidden className={cn("skeleton rounded-xl", className)} />;
}

export function PageSkeleton() {
  return (
    <div className="space-y-6" aria-label="正在加载" role="status">
      <div className="space-y-3">
        <Skeleton className="h-3 w-24" />
        <Skeleton className="h-10 w-2/3 max-w-[360px]" />
        <Skeleton className="h-4 w-1/2 max-w-[280px]" />
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Skeleton className="h-52 rounded-[24px]" />
        <Skeleton className="h-52 rounded-[24px]" />
      </div>
      <Skeleton className="h-40 rounded-[24px]" />
    </div>
  );
}
