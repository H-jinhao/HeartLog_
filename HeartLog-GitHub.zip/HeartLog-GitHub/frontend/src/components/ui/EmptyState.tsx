import type { LucideIcon } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
  className,
  compact = false,
}: {
  icon: LucideIcon;
  title: string;
  description: ReactNode;
  action?: ReactNode;
  className?: string;
  compact?: boolean;
}) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center rounded-[24px] border border-dashed border-line/80 bg-surface/30 px-6 text-center dark:border-white/10 dark:bg-white/[0.02]",
        compact ? "py-10" : "py-16",
        className,
      )}
    >
      <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl border border-white/50 bg-white/35 text-ink/45 shadow-inner-soft dark:border-white/10 dark:bg-white/[0.05]">
        <Icon className="h-[21px] w-[21px]" strokeWidth={1.5} />
      </div>
      <h3 className="text-[16px] font-medium tracking-[-0.02em] text-ink">{title}</h3>
      <p className="mt-2 max-w-[330px] text-[12.5px] leading-6 text-muted">{description}</p>
      {action ? <div className="mt-5">{action}</div> : null}
    </div>
  );
}
