import { forwardRef, type HTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export interface SurfaceCardProps extends HTMLAttributes<HTMLDivElement> {
  interactive?: boolean;
  padded?: boolean;
}

export const SurfaceCard = forwardRef<HTMLDivElement, SurfaceCardProps>(function SurfaceCard(
  { className, interactive, padded = true, ...props },
  ref,
) {
  return (
    <div
      ref={ref}
      className={cn(
        "surface-card rounded-[24px]",
        padded && "p-5 sm:p-6",
        interactive && "lift cursor-pointer",
        className,
      )}
      {...props}
    />
  );
});
