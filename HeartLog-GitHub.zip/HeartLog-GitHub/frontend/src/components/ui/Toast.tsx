import { AnimatePresence, motion } from "motion/react";
import { AlertCircle, CheckCircle2, Info, X } from "lucide-react";
import { useApp, type ToastTone } from "@/context/AppContext";
import { cn } from "@/lib/utils";

const toneStyles: Record<ToastTone, string> = {
  default: "text-ink",
  success: "text-[#4f6d58] dark:text-sage",
  error: "text-[#8b5050] dark:text-rose",
  info: "text-[#5c6d82] dark:text-mist",
};

function ToastIcon({ tone }: { tone: ToastTone }) {
  if (tone === "success") return <CheckCircle2 className="h-[18px] w-[18px]" />;
  if (tone === "error") return <AlertCircle className="h-[18px] w-[18px]" />;
  if (tone === "info") return <Info className="h-[18px] w-[18px]" />;
  return <Info className="h-[18px] w-[18px]" />;
}

export function ToastViewport() {
  const { toasts, dismissToast } = useApp();
  return (
    <div
      aria-live="polite"
      aria-atomic="false"
      className="pointer-events-none fixed left-1/2 top-[calc(env(safe-area-inset-top)+1rem)] z-[100] flex w-[min(92vw,430px)] -translate-x-1/2 flex-col gap-2"
    >
      <AnimatePresence initial={false} mode="popLayout">
        {toasts.map((toast) => (
          <motion.div
            key={toast.id}
            layout
            initial={{ opacity: 0, y: -12, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.98 }}
            transition={{ duration: 0.24, ease: [0.22, 1, 0.36, 1] }}
            className="glass-strong pointer-events-auto flex items-start gap-3 rounded-[20px] px-4 py-3 text-ink shadow-lift"
          >
            <span className={cn("mt-0.5 shrink-0", toneStyles[toast.tone])}>
              <ToastIcon tone={toast.tone} />
            </span>
            <div className="min-w-0 flex-1">
              <div className="text-[13px] font-medium leading-5">{toast.title}</div>
              {toast.description ? (
                <div className="mt-0.5 text-[12px] leading-5 text-muted">{toast.description}</div>
              ) : null}
            </div>
            <button
              type="button"
              aria-label="关闭提示"
              onClick={() => dismissToast(toast.id)}
              className="focus-ring -mr-1 mt-0.5 rounded-full p-1 text-subtle transition-colors hover:bg-ink/5 hover:text-ink"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
