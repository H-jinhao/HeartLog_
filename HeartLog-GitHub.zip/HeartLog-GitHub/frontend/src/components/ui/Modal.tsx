import {
  useEffect,
  useId,
  useRef,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";
import { IconButton } from "@/components/ui/IconButton";

type ModalSize = "sm" | "md" | "lg" | "xl";

export interface ModalProps {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  description?: ReactNode;
  eyebrow?: string;
  icon?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  size?: ModalSize;
  className?: string;
  panelClassName?: string;
  showClose?: boolean;
  initialFocus?: boolean;
}

const sizes: Record<ModalSize, string> = {
  sm: "sm:max-w-[440px]",
  md: "sm:max-w-[600px]",
  lg: "sm:max-w-[780px]",
  xl: "sm:max-w-[980px]",
};

export function Modal({
  open,
  onClose,
  title,
  description,
  eyebrow,
  icon,
  children,
  footer,
  size = "md",
  className,
  panelClassName,
  showClose = true,
  initialFocus = true,
}: ModalProps) {
  const titleId = useId();
  const descriptionId = useId();
  const panelRef = useRef<HTMLDivElement>(null);
  const previousActive = useRef<HTMLElement | null>(null);
  const onCloseRef = useRef(onClose);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    onCloseRef.current = onClose;
  }, [onClose]);

  useEffect(() => {
    if (!open) return;
    previousActive.current = document.activeElement as HTMLElement | null;
    const body = document.body;
    const previousOverflow = body.style.overflow;
    body.style.overflow = "hidden";

    const timer = window.setTimeout(() => {
      if (!initialFocus) return;
      const panel = panelRef.current;
      if (!panel) return;
      const focusable = panel.querySelector<HTMLElement>(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])',
      );
      focusable?.focus();
    }, 60);

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        onCloseRef.current();
        return;
      }
      if (event.key !== "Tab" || !panelRef.current) return;
      const focusable = Array.from(
        panelRef.current.querySelectorAll<HTMLElement>(
          'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
        ),
      ).filter((element) => element.offsetParent !== null);
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };

    document.addEventListener("keydown", onKeyDown);
    return () => {
      window.clearTimeout(timer);
      document.removeEventListener("keydown", onKeyDown);
      body.style.overflow = previousOverflow;
      previousActive.current?.focus?.();
    };
  }, [open, initialFocus]);

  if (typeof document === "undefined") return null;

  return createPortal(
    <AnimatePresence>
      {open ? (
        <motion.div
          className={cn(
            "fixed inset-0 z-[80] flex items-end justify-center overflow-y-auto px-0 pb-0 pt-[calc(env(safe-area-inset-top)+1rem)] sm:items-center sm:p-6",
            className,
          )}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: prefersReducedMotion ? 0 : 0.2 }}
        >
          <button
            type="button"
            aria-label="关闭弹窗"
            className="fixed inset-0 cursor-default bg-[#1e1a22]/25 backdrop-blur-[7px] dark:bg-black/55"
            onClick={() => onCloseRef.current()}
            tabIndex={-1}
          />
          <motion.div
            ref={panelRef}
            role="dialog"
            aria-modal="true"
            aria-labelledby={title ? titleId : undefined}
            aria-describedby={description ? descriptionId : undefined}
            initial={
              prefersReducedMotion
                ? false
                : { opacity: 0, y: 28, scale: 0.985 }
            }
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={prefersReducedMotion ? { opacity: 0 } : { opacity: 0, y: 20, scale: 0.985 }}
            transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
            className={cn(
              "glass-strong relative z-10 flex max-h-[92dvh] w-full flex-col overflow-hidden rounded-t-[32px] border-white/50 sm:rounded-[30px]",
              sizes[size],
              panelClassName,
            )}
          >
            {(title || eyebrow || showClose) && (
              <div className="flex items-start gap-4 px-5 pb-4 pt-5 sm:px-7 sm:pt-6">
                {icon ? (
                  <div className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl border border-white/40 bg-white/25 text-ink/75 dark:border-white/10 dark:bg-white/[0.06]">
                    {icon}
                  </div>
                ) : null}
                <div className="min-w-0 flex-1">
                  {eyebrow ? <div className="eyebrow mb-1.5">{eyebrow}</div> : null}
                  {title ? (
                    <h2
                      id={titleId}
                      className="text-[22px] font-semibold leading-tight tracking-[-0.035em] text-ink sm:text-[26px]"
                    >
                      {title}
                    </h2>
                  ) : null}
                  {description ? (
                    <p id={descriptionId} className="mt-2 text-[13px] leading-6 text-muted">
                      {description}
                    </p>
                  ) : null}
                </div>
                {showClose ? (
                  <IconButton
                    aria-label="关闭"
                    icon={<X />}
                    size="sm"
                    variant="ghost"
                    onClick={() => onCloseRef.current()}
                    className="-mr-1 -mt-1"
                  />
                ) : null}
              </div>
            )}
            <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-5 pb-5 sm:px-7 sm:pb-6">
              {children}
            </div>
            {footer ? (
              <div className="border-t border-line/50 bg-white/15 px-5 py-4 pb-[calc(1rem+env(safe-area-inset-bottom))] sm:rounded-b-[30px] sm:px-7 sm:pb-5 dark:bg-black/10">
                {footer}
              </div>
            ) : null}
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>,
    document.body,
  );
}
