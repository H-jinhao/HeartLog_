import { useId, type ReactNode } from "react";
import { motion } from "motion/react";
import { cn } from "@/lib/utils";

export interface SegmentOption<T extends string> {
  value: T;
  label: string;
  icon?: ReactNode;
}

export function SegmentedControl<T extends string>({
  value,
  options,
  onChange,
  className,
  ariaLabel,
}: {
  value: T;
  options: SegmentOption<T>[];
  onChange: (value: T) => void;
  className?: string;
  ariaLabel: string;
}) {
  const layoutId = useId();
  return (
    <div
      role="tablist"
      aria-label={ariaLabel}
      className={cn(
        "glass-quiet inline-flex items-center gap-1 rounded-full border border-white/40 p-1 dark:border-white/10",
        className,
      )}
    >
      {options.map((option) => {
        const active = option.value === value;
        return (
          <button
            key={option.value}
            type="button"
            role="tab"
            aria-selected={active}
            onClick={() => onChange(option.value)}
            className={cn(
              "focus-ring relative inline-flex h-8 items-center gap-1.5 rounded-full px-3.5 text-[12px] font-medium transition-colors",
              active ? "text-ink" : "text-muted hover:text-ink",
            )}
          >
            {active ? (
              <motion.span
                layoutId={`segment-${layoutId}`}
                className="absolute inset-0 -z-10 rounded-full bg-surface/85 shadow-[0_2px_10px_rgb(var(--glass-shadow)/0.12),inset_0_1px_0_rgb(255_255_255/0.45)] dark:bg-white/[0.08]"
                transition={{ type: "spring", stiffness: 420, damping: 34 }}
              />
            ) : null}
            {option.icon}
            <span>{option.label}</span>
          </button>
        );
      })}
    </div>
  );
}
