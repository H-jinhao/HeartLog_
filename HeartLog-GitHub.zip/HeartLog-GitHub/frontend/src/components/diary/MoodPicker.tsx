import { Cloud, CloudRain, Feather, Moon, Sun } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import type { MoodKey } from "@/types/api";
import { MOODS } from "@/lib/moods";
import { cn } from "@/lib/utils";

const moodIcons: Record<MoodKey, LucideIcon> = {
  bright: Sun,
  calm: Feather,
  tender: Cloud,
  low: CloudRain,
  tired: Moon,
};

export function MoodPicker({
  value,
  onChange,
  compact = false,
  showDescription = false,
  className,
}: {
  value?: MoodKey | null;
  onChange: (mood: MoodKey) => void;
  compact?: boolean;
  showDescription?: boolean;
  className?: string;
}) {
  return (
    <div
      className={cn(
        compact
          ? "flex flex-wrap items-center gap-2"
          : "grid grid-cols-2 gap-2 sm:grid-cols-5",
        className,
      )}
      role="group"
      aria-label="选择今日心情"
    >
      {MOODS.map((mood) => {
        const Icon = moodIcons[mood.key];
        const active = value === mood.key;
        return (
          <button
            key={mood.key}
            type="button"
            aria-pressed={active}
            onClick={() => onChange(mood.key)}
            className={cn(
              "press focus-ring group relative flex flex-col items-start gap-2 overflow-hidden rounded-[18px] border p-3 text-left transition-colors",
              active
                ? "border-white/70 bg-white/45 shadow-[inset_0_1px_0_rgb(255_255_255/0.85),0_10px_24px_-18px_rgb(var(--glass-shadow))] dark:border-white/15 dark:bg-white/[0.09]"
                : "border-line/60 bg-surface/35 hover:border-line hover:bg-surface/60 dark:border-white/[0.07] dark:bg-white/[0.025] dark:hover:bg-white/[0.045]",
            )}
          >
            <span
              className="absolute -right-5 -top-6 h-16 w-16 rounded-full opacity-35 blur-xl transition-opacity group-hover:opacity-50"
              style={{ backgroundColor: mood.color }}
            />
            <span className="relative flex w-full items-center justify-between gap-2">
              <span
                className="flex h-8 w-8 items-center justify-center rounded-[11px] border border-white/50 text-ink/70 opacity-30 dark:border-white/10"
                style={{ backgroundColor: mood.color }}
                data-tone="mood-icon"
              >
                <Icon className="h-[15px] w-[15px]" strokeWidth={1.7} />
              </span>
              {active ? (
                <span className="h-1.5 w-1.5 rounded-full bg-ink/60" aria-hidden />
              ) : null}
            </span>
            <span className="relative">
              <span className="block text-[12.5px] font-medium text-ink">{mood.label}</span>
              {showDescription ? (
                <span className="mt-0.5 block text-[10.5px] leading-4 text-muted">
                  {mood.description}
                </span>
              ) : null}
            </span>
          </button>
        );
      })}
    </div>
  );
}
