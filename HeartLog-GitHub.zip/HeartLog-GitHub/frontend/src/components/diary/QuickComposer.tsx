import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Feather, LoaderCircle, Sparkles } from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { Button } from "@/components/ui/Button";
import { MoodPicker } from "@/components/diary/MoodPicker";
import { useApp } from "@/context/AppContext";
import { createDiary } from "@/api/diaries";
import { createDemoDiary } from "@/lib/demo";
import type { MoodKey } from "@/types/api";
import { countCharacters } from "@/lib/utils";
import { getMood } from "@/lib/moods";

const DRAFT_KEY = "heartlog.quickDraft";

interface QuickDraft {
  content: string;
  mood?: MoodKey;
}

function readDraft(): QuickDraft {
  try {
    const raw = localStorage.getItem(DRAFT_KEY);
    if (!raw) return { content: "" };
    const parsed = JSON.parse(raw) as QuickDraft;
    return {
      content: typeof parsed.content === "string" ? parsed.content : "",
      mood: parsed.mood,
    };
  } catch {
    return { content: "" };
  }
}

export function QuickComposer() {
  const { composer, closeComposer, demoMode, backend, bumpData, notify } = useApp();
  const navigate = useNavigate();
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const draft = useMemo(readDraft, [composer.open]);
  const [content, setContent] = useState(draft.content);
  const [mood, setMood] = useState<MoodKey | undefined>(draft.mood);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!composer.open) return;
    setError(null);
    if (composer.mood) setMood(composer.mood);
    window.setTimeout(() => {
      textareaRef.current?.focus();
      const el = textareaRef.current;
      if (el) {
        el.style.height = "auto";
        el.style.height = `${Math.min(380, Math.max(190, el.scrollHeight))}px`;
      }
    }, 80);
  }, [composer.open, composer.mood]);

  useEffect(() => {
    if (!composer.open) return;
    const timer = window.setTimeout(() => {
      try {
        localStorage.setItem(DRAFT_KEY, JSON.stringify({ content, mood }));
      } catch {
        // ignore
      }
    }, 300);
    return () => window.clearTimeout(timer);
  }, [content, mood, composer.open]);

  const resize = () => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(380, Math.max(190, el.scrollHeight))}px`;
  };

  const close = () => {
    if (saving) return;
    closeComposer();
  };

  const save = async () => {
    const trimmed = content.trim();
    if (!trimmed) {
      setError("先写下一点点吧，哪怕只有一句话。");
      return;
    }
    if (trimmed.length > 50_000) {
      setError("这段文字太长，HeartLog 单篇上限为 50,000 字。");
      return;
    }

    setSaving(true);
    setError(null);
    const metadata: Record<string, unknown> = {};
    if (mood) {
      metadata.mood = mood;
      metadata.moodScore = getMood(mood)?.score;
    }

    try {
      if (demoMode || backend.state !== "online") {
        const diary = createDemoDiary(trimmed, metadata);
        bumpData();
        try {
          localStorage.removeItem(DRAFT_KEY);
        } catch {
          // ignore
        }
        notify("已加入演示会话", {
          tone: "info",
          description: "演示模式不会把内容写入后端，刷新页面后会重置。",
        });
        closeComposer();
        navigate(`/diary/${diary.id}`);
        return;
      }

      const diary = await createDiary(trimmed, metadata);
      try {
        localStorage.removeItem(DRAFT_KEY);
      } catch {
        // ignore
      }
      bumpData();
      notify("已经保存到 HeartLog", {
        tone: "success",
        description: "原文与初始版本已写入本地数据库。",
      });
      closeComposer();
      navigate(`/diary/${diary.id}`);
    } catch (caught) {
      const message =
        caught instanceof Error ? caught.message : "保存失败，请稍后再试。";
      setError(message);
      notify("没有保存成功", { tone: "error", description: message });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal
      open={composer.open}
      onClose={close}
      title="写下一段"
      eyebrow="New entry"
      description="不必组织得很好。原样保存，之后每一次修改都会成为新的版本。"
      icon={<Feather strokeWidth={1.6} />}
      size="lg"
      footer={
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2 text-[10.5px] text-subtle">
            <Sparkles className="h-3 w-3" />
            {demoMode
              ? "演示模式：内容只存在于本次演示会话"
              : "草稿自动保存在此浏览器；点击保存后才会提交到后端"}
          </div>
          <div className="flex items-center justify-end gap-2">
            <Button variant="ghost" size="sm" onClick={close} disabled={saving}>
              取消
            </Button>
            <Button
              size="sm"
              onClick={() => void save()}
              loading={saving}
              leadingIcon={saving ? <LoaderCircle className="h-3.5 w-3.5" /> : undefined}
            >
              {demoMode ? "保存到演示会话" : "保存日记"}
            </Button>
          </div>
        </div>
      }
    >
      <div className="space-y-5">
        <div className="relative overflow-hidden rounded-[24px] border border-white/45 bg-surface/55 p-1 shadow-[inset_0_1px_0_rgb(255_255_255/0.65)] dark:border-white/10 dark:bg-white/[0.03]">
          <div className="pointer-events-none absolute -right-10 -top-16 h-36 w-36 rounded-full bg-[radial-gradient(circle,rgb(var(--lavender)/0.28),transparent_68%)]" />
          <textarea
            ref={textareaRef}
            value={content}
            onChange={(event) => {
              setContent(event.target.value);
              setError(null);
              resize();
            }}
            onKeyDown={(event) => {
              if ((event.metaKey || event.ctrlKey) && event.key === "Enter") {
                event.preventDefault();
                void save();
              }
            }}
            placeholder="今天，发生了什么？&#10;&#10;也可以只写下一个感受。"
            aria-label="日记正文"
            className="relative block min-h-[190px] w-full resize-none bg-transparent px-5 py-5 font-editorial text-[18px] leading-9 text-ink outline-none placeholder:text-subtle/70 sm:px-7 sm:py-7 sm:text-[20px] sm:leading-10"
          />
          <div className="relative flex items-center justify-between px-4 pb-3 text-[10px] text-subtle sm:px-6">
            <span>{countCharacters(content)} 字</span>
            <span>⌘ / Ctrl + Enter 保存</span>
          </div>
        </div>

        <div>
          <div className="mb-2.5 flex items-center justify-between">
            <span className="text-[11px] font-medium tracking-wide text-muted">此刻的心情</span>
            <span className="text-[10px] text-subtle">可选</span>
          </div>
          <MoodPicker value={mood} onChange={setMood} compact />
        </div>

        {error ? (
          <p
            role="alert"
            className="rounded-[16px] border border-rose/30 bg-rose/10 px-4 py-3 text-[12px] leading-5 text-[#8a4f4f] dark:text-rose"
          >
            {error}
          </p>
        ) : null}

        <p className="text-[10.5px] leading-5 text-subtle">
          原始文本保存后不可被覆盖；之后的编辑会新增修订版本，并保留完整历史。
        </p>
      </div>
    </Modal>
  );
}
