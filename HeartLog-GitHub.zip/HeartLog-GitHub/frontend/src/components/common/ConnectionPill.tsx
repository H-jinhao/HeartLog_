import { CircleAlert, CircleCheck, LoaderCircle } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { cn } from "@/lib/utils";

export function ConnectionPill({ className }: { className?: string }) {
  const { backend, refreshBackend } = useApp();
  const online = backend.state === "online";
  const checking = backend.state === "checking";
  return (
    <button
      type="button"
      onClick={() => void refreshBackend()}
      aria-label={online ? "后端已连接，点击刷新" : "后端未连接，点击重试"}
      className={cn(
        "focus-ring press glass-quiet inline-flex h-8 items-center gap-1.5 rounded-full border border-white/40 px-3 text-[10.5px] font-medium tracking-[0.03em] text-muted hover:text-ink dark:border-white/10",
        className,
      )}
    >
      {checking ? (
        <LoaderCircle className="h-3 w-3 animate-spin" />
      ) : online ? (
        <CircleCheck className="h-3 w-3 text-sage" />
      ) : (
        <CircleAlert className="h-3 w-3 text-champagne" />
      )}
      <span className="hidden sm:inline">
        {checking ? "连接中" : online ? "本地已连接" : "离线演示"}
      </span>
      <span className="sm:hidden">{checking ? "…" : online ? "在线" : "离线"}</span>
    </button>
  );
}
