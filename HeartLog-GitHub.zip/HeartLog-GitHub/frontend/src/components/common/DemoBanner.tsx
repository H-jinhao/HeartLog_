import { FlaskConical, RefreshCw, WifiOff } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { cn } from "@/lib/utils";

export function DemoBanner({ className }: { className?: string }) {
  const { demoMode, backend, refreshBackend, setDemoMode, notify } = useApp();
  if (!demoMode) return null;

  const retry = async () => {
    const ok = await refreshBackend({ explicit: true });
    if (ok) {
      notify("已连接后端", { tone: "success", description: "现在显示的是你的真实记录。" });
    } else {
      notify("仍然无法连接后端", {
        tone: "error",
        description: "请确认 FastAPI 服务已在 127.0.0.1:8000 启动。",
      });
    }
  };

  return (
    <div
      className={cn(
        "flex flex-col gap-3 rounded-[20px] border border-champagne/40 bg-champagne/[0.11] px-4 py-3 text-[12px] leading-5 text-[#75613c] shadow-[inset_0_1px_0_rgb(255_255_255/0.35)] sm:flex-row sm:items-center sm:justify-between dark:border-champagne/20 dark:text-champagne",
        className,
      )}
      role="status"
    >
      <div className="flex items-start gap-2.5">
        <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-champagne/30 bg-champagne/15">
          {backend.state === "offline" ? (
            <WifiOff className="h-3 w-3" />
          ) : (
            <FlaskConical className="h-3 w-3" />
          )}
        </span>
        <p>
          <span className="font-medium">演示模式</span>
          <span className="mx-1.5 opacity-40">·</span>
          当前显示的是明确标注的示例内容，不会写入后端，也不会被当作你的真实历史。
          {backend.state === "offline" ? " 后端连接不可用。" : ""}
        </p>
      </div>
      <div className="flex shrink-0 items-center gap-2 pl-[34px] sm:pl-0">
        <button
          type="button"
          onClick={() => void retry()}
          disabled={backend.state === "checking"}
          className="focus-ring press inline-flex h-8 items-center gap-1.5 rounded-full border border-champagne/35 bg-white/25 px-3 text-[11px] font-medium hover:bg-white/40 disabled:opacity-50 dark:bg-white/[0.04]"
        >
          <RefreshCw className={cn("h-3 w-3", backend.state === "checking" && "animate-spin")} />
          重试连接
        </button>
        {backend.state === "online" ? (
          <button
            type="button"
            onClick={() => setDemoMode(false)}
            className="focus-ring press inline-flex h-8 items-center rounded-full px-2.5 text-[11px] font-medium opacity-80 hover:bg-white/20 hover:opacity-100"
          >
            返回真实数据
          </button>
        ) : null}
      </div>
    </div>
  );
}
