import { Component, type ErrorInfo, type ReactNode } from "react";
import { AlertCircle, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/Button";

interface ErrorBoundaryState {
  error: Error | null;
}

export class AppErrorBoundary extends Component<{ children: ReactNode }, ErrorBoundaryState> {
  state: ErrorBoundaryState = { error: null };

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    // Keep this metadata-only. Do not log diary/user content from the DOM.
    console.error("HeartLog UI error", error.name, info.componentStack?.split("\n")[0]);
  }

  render() {
    if (this.state.error) {
      return (
        <div className="flex min-h-dvh items-center justify-center bg-canvas px-6 text-ink">
          <div className="glass max-w-[460px] rounded-[28px] p-8 text-center">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl border border-rose/30 bg-rose/10 text-rose">
              <AlertCircle className="h-5 w-5" />
            </div>
            <h1 className="mt-5 text-[22px] font-semibold tracking-[-0.03em]">
              界面遇到了一点问题
            </h1>
            <p className="mt-2 text-[12.5px] leading-6 text-muted">
              你的记录没有被修改。刷新页面可以重新加载界面。
            </p>
            <Button
              className="mt-5"
              size="sm"
              variant="secondary"
              leadingIcon={<RefreshCw className="h-3.5 w-3.5" />}
              onClick={() => window.location.reload()}
            >
              刷新页面
            </Button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
