import { useEffect, useState, type ReactNode } from "react";
import {
  Check,
  Download,
  MoreHorizontal,
  Share,
  Smartphone,
} from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Modal } from "@/components/ui/Modal";
import { SurfaceCard } from "@/components/ui/SurfaceCard";
import { useApp } from "@/context/AppContext";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }>;
}

function isStandalone(): boolean {
  if (typeof window === "undefined") return false;
  const navigatorWithStandalone = navigator as Navigator & { standalone?: boolean };
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    navigatorWithStandalone.standalone === true
  );
}

function isIosDevice(): boolean {
  if (typeof navigator === "undefined") return false;
  return (
    /iphone|ipad|ipod/i.test(navigator.userAgent) ||
    (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1)
  );
}

export function InstallPwaCard() {
  const { notify } = useApp();
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(isStandalone);
  const [helpOpen, setHelpOpen] = useState(false);
  const [installing, setInstalling] = useState(false);
  const ios = isIosDevice();

  useEffect(() => {
    const onBeforeInstall = (event: Event) => {
      event.preventDefault();
      setDeferredPrompt(event as BeforeInstallPromptEvent);
    };
    const onInstalled = () => {
      setInstalled(true);
      setDeferredPrompt(null);
      notify("HeartLog 已安装到主屏幕", {
        tone: "success",
        description: "下次可以从主屏幕直接打开。",
      });
    };
    const media = window.matchMedia("(display-mode: standalone)");
    const onDisplayMode = () => setInstalled(isStandalone());

    window.addEventListener("beforeinstallprompt", onBeforeInstall);
    window.addEventListener("appinstalled", onInstalled);
    media.addEventListener?.("change", onDisplayMode);
    return () => {
      window.removeEventListener("beforeinstallprompt", onBeforeInstall);
      window.removeEventListener("appinstalled", onInstalled);
      media.removeEventListener?.("change", onDisplayMode);
    };
  }, [notify]);

  const install = async () => {
    if (!deferredPrompt) {
      setHelpOpen(true);
      return;
    }
    setInstalling(true);
    try {
      await deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === "accepted") {
        setInstalled(true);
        setDeferredPrompt(null);
        notify("正在安装 HeartLog", {
          tone: "success",
          description: "安装完成后可以从主屏幕直接打开。",
        });
      }
    } catch {
      setHelpOpen(true);
    } finally {
      setInstalling(false);
    }
  };

  return (
    <>
      <SurfaceCard className="relative overflow-hidden rounded-[26px] p-5 sm:p-6">
        <div className="pointer-events-none absolute -right-10 -top-14 h-40 w-40 rounded-full bg-[radial-gradient(circle,rgb(var(--lavender)/0.35),transparent_70%)] blur-2xl" />
        <div className="relative flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-[13px] border border-lavender/30 bg-lavender/10 text-[#716080] dark:text-lavender">
              <Smartphone className="h-4 w-4" />
            </span>
            <div>
              <div className="eyebrow mb-1.5">PWA · 本地安装</div>
              <h2 className="text-[18px] font-semibold tracking-[-0.03em] text-ink">
                {installed ? "已经在这台设备上" : "把 HeartLog 放到主屏幕"}
              </h2>
              <p className="mt-1.5 max-w-[560px] text-[10.5px] leading-5 text-subtle">
                {installed
                  ? "当前正以独立应用方式运行。打开它，就像打开一个安静的本子。"
                  : "安装后可以全屏打开、保留应用外壳，网络不好时也能回到界面。数据仍由本机后端保存。"}
              </p>
            </div>
          </div>
          {installed ? (
            <span className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-full border border-sage/35 bg-sage/10 px-3 text-[10.5px] font-medium text-[#5e7565] dark:text-sage">
              <Check className="h-3.5 w-3.5" />
              已安装
            </span>
          ) : (
            <Button
              size="sm"
              variant="secondary"
              loading={installing}
              onClick={() => void install()}
              leadingIcon={<Download className="h-3.5 w-3.5" />}
            >
              {deferredPrompt ? "安装到手机" : "查看安装步骤"}
            </Button>
          )}
        </div>
      </SurfaceCard>

      <Modal
        open={helpOpen}
        onClose={() => setHelpOpen(false)}
        title="安装到手机"
        eyebrow="Add to home screen"
        description="HeartLog 是一个 PWA，可以像普通 App 一样从主屏幕打开。"
        icon={<Smartphone strokeWidth={1.6} />}
        size="sm"
        footer={
          <div className="flex justify-end">
            <Button variant="secondary" size="sm" onClick={() => setHelpOpen(false)}>
              知道了
            </Button>
          </div>
        }
      >
        <div className="space-y-4">
          {ios ? (
            <InstallStep
              icon={<Share className="h-4 w-4" />}
              title="Safari：分享 → 添加到主屏幕"
              body="用 Safari 打开 HeartLog，点击底部工具栏的分享按钮，向下找到“添加到主屏幕”，确认名称后添加。"
            />
          ) : (
            <InstallStep
              icon={<MoreHorizontal className="h-4 w-4" />}
              title="浏览器菜单 → 安装应用"
              body="在 Chrome / Edge 中打开 HeartLog，点击右上角菜单，选择“安装应用”或“添加到主屏幕”。"
            />
          )}
          <div className="rounded-[16px] border border-champagne/30 bg-champagne/[0.08] px-3.5 py-3 text-[10px] leading-5 text-[#806b43] dark:text-champagne">
            iPhone / Android 的完整 PWA 离线缓存通常需要 HTTPS。局域网 HTTP 访问时，部分浏览器只会在桌面创建快捷方式；
            如果只是日常记录，主屏幕图标已经可以直接打开界面。
          </div>
          <p className="text-[10px] leading-5 text-subtle">
            安装不会复制或上传你的数据；数据仍来自当前连接的后端。
          </p>
        </div>
      </Modal>
    </>
  );
}

function InstallStep({
  icon,
  title,
  body,
}: {
  icon: ReactNode;
  title: string;
  body: string;
}) {
  return (
    <div className="flex gap-3 rounded-[18px] border border-line/60 bg-surface/30 p-4 dark:border-white/10 dark:bg-white/[0.025]">
      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-[10px] border border-line/60 bg-white/30 text-muted dark:border-white/10 dark:bg-white/[0.04]">
        {icon}
      </span>
      <div>
        <div className="text-[12px] font-medium text-ink/80">{title}</div>
        <p className="mt-1 text-[10.5px] leading-5 text-muted">{body}</p>
      </div>
    </div>
  );
}
