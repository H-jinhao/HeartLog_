import { useEffect, useRef, useState } from "react";
import { ArrowUp, LoaderCircle, MessageCircle, ShieldCheck, Sparkles } from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { Button } from "@/components/ui/Button";
import { useApp } from "@/context/AppContext";
import {
  createConversation,
  sendConversationMessage,
} from "@/api/misc";
import type { MessageExchange } from "@/types/api";
import { cn } from "@/lib/utils";

interface ChatMessage {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  mode?: "ai" | "placeholder" | "demo";
  citations?: MessageExchange["citations"];
}

export function CompanionSheet({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const { backend, demoMode, notify } = useApp();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [content, setContent] = useState("");
  const [sending, setSending] = useState(false);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    if (!messages.length) {
      setMessages([
        {
          id: "system-intro",
          role: "system",
          content: demoMode
            ? "演示模式：这里的对话只用于展示界面，不会把内容发送到任何模型或后端。"
            : "这里可以结合你保存的记忆聊聊近况。AI 未启用时，回复会明确标注为占位模式；不会伪装成模型生成。",
          mode: "placeholder",
        },
      ]);
    }
  }, [open, demoMode, messages.length]);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages, sending]);

  const send = async () => {
    const trimmed = content.trim();
    if (!trimmed || sending) return;
    setContent("");
    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      content: trimmed,
    };
    setMessages((items) => [...items, userMessage]);
    setSending(true);
    try {
      if (demoMode || backend.state !== "online") {
        await new Promise((resolve) => window.setTimeout(resolve, 460));
        setMessages((items) => [
          ...items,
          {
            id: `demo-${Date.now()}`,
            role: "assistant",
            mode: "demo",
            content:
              "【演示模式】这是一条本地占位回复。演示环境不会调用 AI，也不会读取或写入你的真实记忆。连接后端并在服务端启用 AI 后，这里才会出现真实回复。",
            citations: [],
          },
        ]);
        return;
      }

      let activeConversation = conversationId;
      if (!activeConversation) {
        const conversation = await createConversation("陪伴对话");
        activeConversation = conversation.id;
        setConversationId(conversation.id);
      }
      const exchange = await sendConversationMessage(activeConversation, trimmed);
      setMessages((items) => [
        ...items,
        {
          id: exchange.assistant_message.id,
          role: "assistant",
          content: exchange.assistant_message.content,
          mode: exchange.mode,
          citations: exchange.citations,
        },
      ]);
    } catch (error) {
      const message = error instanceof Error ? error.message : "消息发送失败";
      notify("陪伴对话没有完成", { tone: "error", description: message });
      setMessages((items) => [
        ...items,
        {
          id: `error-${Date.now()}`,
          role: "system",
          content: `这次没有成功：${message}`,
        },
      ]);
    } finally {
      setSending(false);
    }
  };

  const aiReady = backend.health?.ai_ready ?? false;

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="和过去的自己聊聊"
      eyebrow="Companion"
      description="基于你保存的记录，不替你编造记忆。AI 未启用时，回复会保持占位与诚实。"
      icon={<MessageCircle strokeWidth={1.6} />}
      size="md"
      panelClassName="sm:max-h-[78vh]"
      footer={
        <div className="space-y-3">
          <div className="flex items-center gap-2 rounded-[16px] border border-line/60 bg-surface/45 px-3 py-2 dark:border-white/10 dark:bg-white/[0.035]">
            <input
              value={content}
              onChange={(event) => setContent(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter" && !event.shiftKey) {
                  event.preventDefault();
                  void send();
                }
              }}
              placeholder="此刻想说什么？"
              aria-label="陪伴对话输入"
              className="h-9 min-w-0 flex-1 bg-transparent text-[13px] text-ink outline-none placeholder:text-subtle"
            />
            <Button
              size="sm"
              aria-label="发送"
              onClick={() => void send()}
              disabled={!content.trim() || sending}
              className="h-9 w-9 rounded-[12px] px-0"
            >
              {sending ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <ArrowUp className="h-4 w-4" />}
            </Button>
          </div>
          <div className="flex items-center justify-between text-[9.5px] text-subtle">
            <span className="inline-flex items-center gap-1.5">
              <ShieldCheck className="h-3 w-3" />
              这不是心理治疗或诊断
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Sparkles className="h-3 w-3" />
              {aiReady ? "AI 已配置" : "AI 未启用 · 占位模式"}
            </span>
          </div>
        </div>
      }
    >
      <div ref={scrollRef} className="max-h-[42vh] space-y-3 overflow-y-auto pr-1">
        {messages.map((message) => (
          <ChatBubble key={message.id} message={message} />
        ))}
        {sending ? (
          <div className="flex items-center gap-2 px-2 py-2 text-[11px] text-subtle">
            <LoaderCircle className="h-3 w-3 animate-spin" />
            正在整理回复…
          </div>
        ) : null}
      </div>
    </Modal>
  );
}

function ChatBubble({ message }: { message: ChatMessage }) {
  if (message.role === "system") {
    return (
      <div className="rounded-[16px] border border-line/60 bg-surface/35 px-3.5 py-2.5 text-[11px] leading-5 text-muted dark:border-white/10 dark:bg-white/[0.025]">
        {message.content}
      </div>
    );
  }
  const isUser = message.role === "user";
  return (
    <div className={cn("flex", isUser ? "justify-end" : "justify-start")}>
      <div
        className={cn(
          "max-w-[86%] rounded-[20px] px-4 py-3 text-[12.5px] leading-6",
          isUser
            ? "rounded-br-[7px] bg-ink text-canvas"
            : "rounded-bl-[7px] border border-white/40 bg-white/35 text-ink shadow-inner-soft dark:border-white/10 dark:bg-white/[0.06]",
        )}
      >
        {!isUser && message.mode === "placeholder" ? (
          <div className="mb-1.5 inline-flex rounded-full border border-champagne/40 bg-champagne/15 px-2 py-0.5 text-[9px] font-medium text-[#806b43] dark:text-champagne">
            占位模式 · 非 AI 生成
          </div>
        ) : null}
        {!isUser && message.mode === "demo" ? (
          <div className="mb-1.5 inline-flex rounded-full border border-champagne/40 bg-champagne/15 px-2 py-0.5 text-[9px] font-medium text-[#806b43] dark:text-champagne">
            演示模式 · 非真实回复
          </div>
        ) : null}
        <div className="whitespace-pre-wrap">{message.content}</div>
        {message.citations?.length ? (
          <div className="mt-2 flex flex-wrap gap-1.5 border-t border-line/40 pt-2">
            {message.citations.map((citation) => (
              <span
                key={citation.memory_id}
                className="rounded-full border border-line/60 px-2 py-0.5 text-[9px] text-subtle"
              >
                来源 · 日记版本 {citation.version}
              </span>
            ))}
          </div>
        ) : null}
      </div>
    </div>
  );
}
