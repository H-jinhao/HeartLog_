export type MemoryType =
  | "explicit_fact"
  | "subjective_feeling"
  | "explicit_belief"
  | "model_inference";

export type VerificationStatus = "pending" | "confirmed" | "superseded" | "revoked";

export type CreatedBy = "user" | "model" | "import";

export type MemorySourceType = "diary_entry" | "user_correction" | "import";

export type MoodKey = "bright" | "calm" | "tender" | "low" | "tired";

export interface MoodMeta {
  key: MoodKey;
  label: string;
  shortLabel: string;
  description: string;
  score: number;
  color: string;
}

export interface DiaryMetadata {
  mood?: MoodKey;
  moodScore?: number;
  [key: string]: unknown;
}

export interface Page<T> {
  items: T[];
  total: number;
  limit: number;
  offset: number;
  has_more: boolean;
}

export interface DiaryListItem {
  id: string;
  preview: string;
  original_preview: string;
  current_version: number;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  is_deleted: boolean;
  metadata: DiaryMetadata;
}

export interface RevisionOut {
  id: string;
  entry_id: string;
  version: number;
  content: string;
  content_hash: string;
  previous_revision_hash: string | null;
  change_reason: string | null;
  created_at: string;
}

export interface DiaryDetail {
  id: string;
  original_text: string;
  original_content_hash: string;
  current_version: number;
  current_revision_id: string | null;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  is_deleted: boolean;
  metadata: DiaryMetadata;
  current_content: string;
  current_revision: RevisionOut | null;
}

export interface RevisionList {
  entry_id: string;
  total: number;
  versions: RevisionOut[];
}

export interface DiaryReferences {
  entry_id: string;
  is_deleted: boolean;
  memories: number;
  memory_sources: number;
  persons: number;
  can_permanently_delete: boolean;
  guidance: string;
}

export interface DeletedResponse {
  id: string;
  deleted_at: string;
  message: string;
}

export interface MemorySourceOut {
  id: string;
  memory_id: string;
  entry_id: string;
  revision_id: string;
  evidence_text: string;
  start_offset: number | null;
  end_offset: number | null;
  created_at: string;
}

export interface MemoryOut {
  id: string;
  content: string;
  content_hash: string;
  memory_type: MemoryType;
  source_type: MemorySourceType;
  confidence: number | null;
  verification_status: VerificationStatus;
  is_active: boolean;
  created_by: CreatedBy;
  confirmed_by: CreatedBy | null;
  confirmed_at: string | null;
  revoked_at: string | null;
  supersedes_memory_id: string | null;
  source_entry_id: string;
  source_revision_id: string;
  source_version: number | null;
  source_entry_deleted: boolean;
  created_at: string;
  updated_at: string;
  metadata: Record<string, unknown>;
  sources: MemorySourceOut[];
}

export interface PersonOut {
  id: string;
  display_name: string;
  aliases: string[];
  source_entry_id: string;
  source_revision_id: string;
  source_evidence: string | null;
  created_at: string;
  updated_at: string;
}

export interface PersonList {
  items: PersonOut[];
  total: number;
  limit: number;
  offset: number;
  has_more: boolean;
}

export interface TimelineHit {
  entry_id: string;
  revision_id: string;
  version: number;
  created_at: string;
  snippet: string;
  matched_name: string;
  is_current: boolean;
}

export interface PersonTimeline {
  person_id: string;
  display_name: string;
  names_used_for_search: string[];
  method: string;
  note: string;
  items: TimelineHit[];
}

export interface HealthResponse {
  status: string;
  app: string;
  version: string;
  environment: string;
  database: string;
  ai_enabled: boolean;
  ai_ready: boolean;
  time: string;
}

export interface InsightPeriod {
  period: "weekly" | "monthly";
  start: string;
  end: string;
  reference_date: string;
  timezone: string;
}

export interface MemoryTypeCount {
  memory_type: MemoryType;
  count: number;
}

export interface InsightStatistics {
  diary_entries: number;
  memories: number;
  memory_type_counts: MemoryTypeCount[];
}

export interface InsightSource {
  memory_id: string | null;
  entry_id: string;
  revision_id: string | null;
  version: number | null;
  snippet: string | null;
  memory_type: string | null;
  created_at: string | null;
}

export interface InsightResponse {
  mode: "ai" | "local_statistics";
  ai_used: boolean;
  period: InsightPeriod;
  statistics: InsightStatistics;
  narrative: string | null;
  sources: InsightSource[];
  notes: string[];
  disclaimer: string;
  provider: string | null;
  model: string | null;
}

export interface MemoryForgetResponse {
  memory_id: string;
  mode: "purge" | "anonymize";
  forgotten_at: string;
  source_entry_id: string;
  source_revision_id: string;
  memory_type: MemoryType;
  purged_sources: number;
  audit_event_id: string;
  note: string;
}

export interface SearchHit {
  kind: "diary" | "memory";
  snippet: string;
  created_at: string;
  entry_id: string;
  revision_id: string;
  version: number;
  is_current: boolean;
  memory_id: string | null;
  memory_type: MemoryType | null;
  verification_status: VerificationStatus | null;
  confidence: number | null;
}

export interface SearchResponse {
  query: string;
  scope: "all" | "diaries" | "memories";
  include_history: boolean;
  include_deleted_sources: boolean;
  total: number;
  limit: number;
  offset: number;
  has_more: boolean;
  items: SearchHit[];
}

export interface Citation {
  memory_id: string;
  entry_id: string;
  revision_id: string;
  version: number;
  snippet: string;
  memory_type?: string;
  source_created_at?: string | null;
}

export interface ConversationOut {
  id: string;
  title: string | null;
  created_at: string;
  updated_at: string;
  message_count: number;
}

export interface MessageOut {
  id: string;
  conversation_id: string;
  role: "user" | "assistant" | "system";
  content: string;
  mode: "ai" | "placeholder";
  citations: Citation[];
  model_name: string | null;
  created_at: string;
}

export interface MessageExchange {
  conversation_id: string;
  user_message: MessageOut;
  assistant_message: MessageOut;
  mode: "ai" | "placeholder";
  ai_used: boolean;
  citations: Citation[];
  provider: string | null;
  model: string | null;
  notice: string | null;
}

export interface ConversationDetail extends ConversationOut {
  messages: MessageOut[];
}

export interface AuthTokenState {
  token: string;
  setToken: (token: string) => void;
}
