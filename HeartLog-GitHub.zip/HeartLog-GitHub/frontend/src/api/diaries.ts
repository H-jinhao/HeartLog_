import { apiDownload, apiRequest } from "@/api/client";
import type {
  DeletedResponse,
  DiaryDetail,
  DiaryReferences,
  DiaryListItem,
  Page,
  RevisionList,
  RevisionOut,
} from "@/types/api";

export interface DiaryListParams {
  limit?: number;
  offset?: number;
  q?: string;
  dateFrom?: string;
  dateTo?: string;
}

function query(params: Record<string, string | number | boolean | undefined>): string {
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== "") search.set(key, String(value));
  }
  const serialised = search.toString();
  return serialised ? `?${serialised}` : "";
}

export async function listDiaries(params: DiaryListParams = {}): Promise<Page<DiaryListItem>> {
  return apiRequest<Page<DiaryListItem>>(
    `/diaries${query({
      limit: params.limit,
      offset: params.offset,
      q: params.q,
      date_from: params.dateFrom,
      date_to: params.dateTo,
    })}`,
  );
}

export async function getDiary(id: string): Promise<DiaryDetail> {
  return apiRequest<DiaryDetail>(`/diaries/${id}`);
}

export async function createDiary(
  content: string,
  metadata: Record<string, unknown> = {},
): Promise<DiaryDetail> {
  return apiRequest<DiaryDetail>("/diaries", {
    method: "POST",
    body: { content, metadata },
  });
}

export async function updateDiary(
  id: string,
  payload: {
    content: string;
    expectedVersion?: number | null;
    changeReason?: string | null;
  },
): Promise<DiaryDetail> {
  return apiRequest<DiaryDetail>(`/diaries/${id}`, {
    method: "PUT",
    body: {
      content: payload.content,
      expected_version: payload.expectedVersion ?? undefined,
      change_reason: payload.changeReason ?? undefined,
    },
  });
}

export async function deleteDiary(id: string): Promise<DeletedResponse> {
  return apiRequest<DeletedResponse>(`/diaries/${id}`, { method: "DELETE" });
}

export async function restoreDiary(id: string): Promise<DiaryDetail> {
  return apiRequest<DiaryDetail>(`/diaries/${id}/restore`, { method: "POST" });
}

export async function listRevisions(id: string): Promise<RevisionList> {
  return apiRequest<RevisionList>(`/diaries/${id}/revisions`);
}

export async function getRevision(id: string, version: number): Promise<RevisionOut> {
  return apiRequest<RevisionOut>(`/diaries/${id}/revisions/${version}`);
}

export async function getDiaryReferences(id: string): Promise<DiaryReferences> {
  return apiRequest<DiaryReferences>(`/diaries/${id}/references`);
}

export async function exportAllData(): Promise<void> {
  await apiDownload("/api/v1/export", "heartlog-export.json");
}
