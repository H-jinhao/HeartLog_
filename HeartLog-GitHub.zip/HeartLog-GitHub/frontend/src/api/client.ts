const rawBase = (import.meta.env.VITE_API_BASE_URL ?? "").trim().replace(/\/+$/, "");
export const API_BASE_URL = rawBase;
export const API_ROOT = rawBase ? `${rawBase}/api/v1` : "/api/v1";
export const HEALTH_URL = rawBase ? `${rawBase}/health` : "/health";

const TOKEN_KEY = "heartlog.apiToken";

export function getApiToken(): string {
  try {
    return sessionStorage.getItem(TOKEN_KEY) ?? "";
  } catch {
    return "";
  }
}

export function setApiToken(token: string): void {
  try {
    if (token) sessionStorage.setItem(TOKEN_KEY, token);
    else sessionStorage.removeItem(TOKEN_KEY);
  } catch {
    // Session storage can be unavailable in private/embedded contexts.
  }
}

export class ApiError extends Error {
  status: number;
  code: string;
  details: Record<string, unknown>;

  constructor(
    message: string,
    options: {
      status?: number;
      code?: string;
      details?: Record<string, unknown>;
    } = {},
  ) {
    super(message);
    this.name = "ApiError";
    this.status = options.status ?? 0;
    this.code = options.code ?? "unknown_error";
    this.details = options.details ?? {};
  }
}

function buildUrl(path: string): string {
  if (/^https?:\/\//i.test(path)) return path;
  if (path.startsWith("/health")) return HEALTH_URL;
  if (path.startsWith("/api/")) return `${rawBase}${path}`;
  return `${API_ROOT}${path.startsWith("/") ? path : `/${path}`}`;
}

function authHeaders(): HeadersInit {
  const token = getApiToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function parseError(response: Response): Promise<ApiError> {
  let payload: unknown;
  try {
    payload = await response.json();
  } catch {
    payload = undefined;
  }

  const envelope =
    payload && typeof payload === "object" && "error" in payload
      ? (payload as { error?: unknown }).error
      : undefined;

  if (envelope && typeof envelope === "object") {
    const body = envelope as {
      code?: unknown;
      message?: unknown;
      details?: unknown;
    };
    return new ApiError(
      typeof body.message === "string" ? body.message : `请求失败（HTTP ${response.status}）`,
      {
        status: response.status,
        code: typeof body.code === "string" ? body.code : "http_error",
        details:
          body.details && typeof body.details === "object"
            ? (body.details as Record<string, unknown>)
            : {},
      },
    );
  }

  return new ApiError(`请求失败（HTTP ${response.status}）`, {
    status: response.status,
    code: "http_error",
  });
}

interface RequestOptions {
  method?: "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
  body?: unknown;
  headers?: Record<string, string>;
  timeoutMs?: number;
  signal?: AbortSignal;
}

export async function apiRequest<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const controller = new AbortController();
  const timeout = window.setTimeout(
    () => controller.abort(),
    options.timeoutMs ?? 20_000,
  );

  if (options.signal) {
    if (options.signal.aborted) controller.abort();
    else options.signal.addEventListener("abort", () => controller.abort(), { once: true });
  }

  try {
    const headers: Record<string, string> = {
      Accept: "application/json",
      ...options.headers,
      ...(authHeaders() as Record<string, string>),
    };
    const init: RequestInit = {
      method: options.method ?? "GET",
      headers,
      signal: controller.signal,
    };
    if (options.body !== undefined) {
      headers["Content-Type"] = "application/json";
      init.body = JSON.stringify(options.body);
    }

    let response: Response;
    try {
      response = await fetch(buildUrl(path), init);
    } catch (error) {
      if (controller.signal.aborted) {
        throw new ApiError("请求超时，请稍后再试。", {
          code: "timeout",
          details: { timeout_ms: options.timeoutMs ?? 20_000 },
        });
      }
      throw new ApiError("无法连接到 HeartLog 后端。请确认服务已启动。", {
        code: "network_error",
        details: { cause: error instanceof Error ? error.name : "unknown" },
      });
    }

    if (!response.ok) throw await parseError(response);
    if (response.status === 204) return undefined as T;

    const contentType = response.headers.get("content-type") ?? "";
    if (!contentType.includes("application/json")) {
      return (await response.text()) as unknown as T;
    }
    return (await response.json()) as T;
  } finally {
    window.clearTimeout(timeout);
  }
}

import { downloadBlob } from "@/lib/utils";

export async function apiDownload(
  path: string,
  filename = "heartlog-export.json",
): Promise<void> {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), 60_000);
  try {
    let response: Response;
    try {
      response = await fetch(buildUrl(path), {
        headers: { Accept: "application/json", ...(authHeaders() as Record<string, string>) },
        signal: controller.signal,
      });
    } catch {
      throw new ApiError("下载失败：无法连接到 HeartLog 后端。", {
        code: "network_error",
      });
    }
    if (!response.ok) throw await parseError(response);
    const blob = await response.blob();
    const disposition = response.headers.get("content-disposition") ?? "";
    const match = /filename="?([^";]+)"?/i.exec(disposition);
    const name = match?.[1] ?? filename;
    downloadBlob(blob, name);
  } finally {
    window.clearTimeout(timeout);
  }
}
