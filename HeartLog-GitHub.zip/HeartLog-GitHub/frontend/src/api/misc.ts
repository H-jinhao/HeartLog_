import { apiRequest } from "@/api/client";
import type {
  ConversationDetail,
  ConversationOut,
  HealthResponse,
  InsightResponse,
  MessageExchange,
  SearchResponse,
} from "@/types/api";

export async function getHealth(): Promise<HealthResponse> {
  return apiRequest<HealthResponse>("/health", { timeoutMs: 6_000 });
}

export async function searchHeartLog(
  query: string,
  options: {
    scope?: "all" | "diaries" | "memories";
    includeHistory?: boolean;
    includeDeletedSources?: boolean;
    limit?: number;
    offset?: number;
  } = {},
): Promise<SearchResponse> {
  const params = new URLSearchParams({ q: query });
  params.set("scope", options.scope ?? "all");
  params.set("include_history", String(options.includeHistory ?? true));
  if (options.includeDeletedSources) params.set("include_deleted_sources", "true");
  if (options.limit) params.set("limit", String(options.limit));
  if (options.offset) params.set("offset", String(options.offset));
  return apiRequest<SearchResponse>(`/search?${params.toString()}`);
}

export async function getInsight(
  period: "weekly" | "monthly",
  referenceDate?: string,
): Promise<InsightResponse> {
  const params = new URLSearchParams();
  if (referenceDate) params.set("date", referenceDate);
  const suffix = params.toString() ? `?${params.toString()}` : "";
  return apiRequest<InsightResponse>(`/insights/${period}${suffix}`);
}

export async function createConversation(title?: string): Promise<ConversationOut> {
  return apiRequest<ConversationOut>("/conversations", {
    method: "POST",
    body: { title: title || undefined },
  });
}

export async function getConversation(id: string): Promise<ConversationDetail> {
  return apiRequest<ConversationDetail>(`/conversations/${id}`);
}

export async function sendConversationMessage(
  conversationId: string,
  content: string,
): Promise<MessageExchange> {
  return apiRequest<MessageExchange>(`/conversations/${conversationId}/messages`, {
    method: "POST",
    body: { content },
    timeoutMs: 60_000,
  });
}
