import { apiRequest } from "@/api/client";
import type {
  MemoryForgetResponse,
  MemoryOut,
  MemoryType,
  Page,
  PersonList,
  PersonOut,
  PersonTimeline,
  VerificationStatus,
} from "@/types/api";

export interface MemoryListParams {
  memoryType?: MemoryType;
  verificationStatus?: VerificationStatus;
  entryId?: string;
  active?: boolean;
  includeDeletedSources?: boolean;
  limit?: number;
  offset?: number;
}

function query(params: Record<string, string | number | boolean | undefined>): string {
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== "") search.set(key, String(value));
  }
  const serialised = search.toString();
  return serialised ? `?${serialised}` : "";
}

export async function listMemories(params: MemoryListParams = {}): Promise<Page<MemoryOut>> {
  return apiRequest<Page<MemoryOut>>(
    `/memories${query({
      memory_type: params.memoryType,
      verification_status: params.verificationStatus,
      entry_id: params.entryId,
      active: params.active,
      include_deleted_sources: params.includeDeletedSources,
      limit: params.limit,
      offset: params.offset,
    })}`,
  );
}

export async function getMemory(id: string): Promise<MemoryOut> {
  return apiRequest<MemoryOut>(`/memories/${id}`);
}

export async function confirmMemory(id: string): Promise<MemoryOut> {
  return apiRequest<MemoryOut>(`/memories/${id}/confirm`, { method: "POST" });
}

export async function correctMemory(
  id: string,
  content: string,
  changeReason?: string,
): Promise<MemoryOut> {
  return apiRequest<MemoryOut>(`/memories/${id}/correct`, {
    method: "POST",
    body: { content, change_reason: changeReason || undefined },
  });
}

export async function revokeMemory(id: string, reason?: string): Promise<MemoryOut> {
  return apiRequest<MemoryOut>(`/memories/${id}/revoke`, {
    method: "POST",
    body: reason ? { reason } : undefined,
  });
}

export async function forgetMemory(id: string): Promise<MemoryForgetResponse> {
  return apiRequest<MemoryForgetResponse>(`/memories/${id}`, {
    method: "DELETE",
    headers: { "X-Confirm-Memory-Delete": id },
  });
}

export async function listPersons(
  params: { q?: string; limit?: number; offset?: number; includeDeletedSources?: boolean } = {},
): Promise<PersonList> {
  return apiRequest<PersonList>(
    `/persons${query({
      q: params.q,
      limit: params.limit,
      offset: params.offset,
      include_deleted_sources: params.includeDeletedSources,
    })}`,
  );
}

export async function getPerson(id: string): Promise<PersonOut> {
  return apiRequest<PersonOut>(`/persons/${id}`);
}

export async function getPersonTimeline(id: string): Promise<PersonTimeline> {
  return apiRequest<PersonTimeline>(`/persons/${id}/timeline`);
}
