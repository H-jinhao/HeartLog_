import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { getHealth } from "@/api/misc";
import { getApiToken, setApiToken as persistApiToken } from "@/api/client";
import type { HealthResponse, MoodKey } from "@/types/api";

export type ThemeMode = "light" | "dark" | "system";
export type BackendState = "checking" | "online" | "offline";
export type ToastTone = "default" | "success" | "error" | "info";

export interface ToastItem {
  id: string;
  title: string;
  description?: string;
  tone: ToastTone;
}

interface ComposerState {
  open: boolean;
  mood?: MoodKey;
  diaryId?: string;
}

interface BackendStatus {
  state: BackendState;
  health?: HealthResponse;
  error?: string;
  checkedAt?: number;
}

interface AppContextValue {
  themeMode: ThemeMode;
  effectiveTheme: "light" | "dark";
  setThemeMode: (mode: ThemeMode) => void;
  toggleTheme: () => void;

  backend: BackendStatus;
  refreshBackend: (options?: { explicit?: boolean }) => Promise<boolean>;
  demoMode: boolean;
  setDemoMode: (value: boolean) => void;

  toasts: ToastItem[];
  notify: (title: string, options?: { description?: string; tone?: ToastTone }) => void;
  dismissToast: (id: string) => void;

  composer: ComposerState;
  openComposer: (mood?: MoodKey) => void;
  closeComposer: () => void;

  searchOpen: boolean;
  openSearch: () => void;
  closeSearch: () => void;

  dataVersion: number;
  bumpData: () => void;

  profileName: string;
  setProfileName: (name: string) => void;

  apiToken: string;
  setApiToken: (token: string) => void;
}

const AppContext = createContext<AppContextValue | null>(null);

const THEME_KEY = "heartlog.theme";
const NAME_KEY = "heartlog.profileName";

function readTheme(): ThemeMode {
  try {
    const saved = localStorage.getItem(THEME_KEY);
    if (saved === "light" || saved === "dark" || saved === "system") return saved;
  } catch {
    // ignore
  }
  return "system";
}

function resolveTheme(mode: ThemeMode): "light" | "dark" {
  if (mode !== "system") return mode;
  if (typeof window === "undefined") return "light";
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

function applyTheme(mode: ThemeMode): "light" | "dark" {
  const effective = resolveTheme(mode);
  document.documentElement.dataset.theme = effective;
  document.documentElement.style.colorScheme = effective;
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", effective === "dark" ? "#141216" : "#F7F5F0");
  return effective;
}

function uid(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `t-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [themeMode, setThemeModeState] = useState<ThemeMode>(() => readTheme());
  const [effectiveTheme, setEffectiveTheme] = useState<"light" | "dark">(() =>
    typeof document !== "undefined" && document.documentElement.dataset.theme === "dark"
      ? "dark"
      : "light",
  );
  const [backend, setBackend] = useState<BackendStatus>({ state: "checking" });
  const [demoMode, setDemoModeState] = useState(false);
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [composer, setComposer] = useState<ComposerState>({ open: false });
  const [searchOpen, setSearchOpen] = useState(false);
  const [dataVersion, setDataVersion] = useState(0);
  const [profileName, setProfileNameState] = useState<string>(() => {
    try {
      return localStorage.getItem(NAME_KEY) ?? "";
    } catch {
      return "";
    }
  });
  const [apiToken, setApiTokenState] = useState(() => getApiToken());
  const toastTimers = useRef<Map<string, number>>(new Map());
  const initialised = useRef(false);

  useEffect(() => {
    setEffectiveTheme(applyTheme(themeMode));
    try {
      localStorage.setItem(THEME_KEY, themeMode);
    } catch {
      // ignore
    }
    if (themeMode !== "system") return;
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => setEffectiveTheme(applyTheme("system"));
    media.addEventListener("change", onChange);
    return () => media.removeEventListener("change", onChange);
  }, [themeMode]);

  const setThemeMode = useCallback((mode: ThemeMode) => {
    setThemeModeState(mode);
  }, []);

  const toggleTheme = useCallback(() => {
    setThemeModeState((current) => (current === "dark" ? "light" : "dark"));
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((items) => items.filter((toast) => toast.id !== id));
    const timer = toastTimers.current.get(id);
    if (timer) window.clearTimeout(timer);
    toastTimers.current.delete(id);
  }, []);

  const notify = useCallback(
    (
      title: string,
      options: { description?: string; tone?: ToastTone } = {},
    ) => {
      const item: ToastItem = {
        id: uid(),
        title,
        description: options.description,
        tone: options.tone ?? "default",
      };
      setToasts((items) => [...items.slice(-2), item]);
      const timer = window.setTimeout(() => dismissToast(item.id), 4600);
      toastTimers.current.set(item.id, timer);
    },
    [dismissToast],
  );

  const refreshBackend = useCallback(
    async (options: { explicit?: boolean } = {}) => {
      setBackend((current) => ({ ...current, state: "checking" }));
      try {
        const health = await getHealth();
        setBackend({
          state: "online",
          health,
          checkedAt: Date.now(),
        });
        if (options.explicit) setDemoModeState(false);
        return true;
      } catch (error) {
        const message =
          error instanceof Error ? error.message : "无法连接到 HeartLog 后端";
        setBackend({ state: "offline", error: message, checkedAt: Date.now() });
        setDemoModeState(true);
        return false;
      }
    },
    [],
  );

  useEffect(() => {
    if (initialised.current) return;
    initialised.current = true;
    void refreshBackend();
  }, [refreshBackend]);

  useEffect(() => {
    document.body.style.overflow = composer.open || searchOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [composer.open, searchOpen]);

  useEffect(() => {
    return () => {
      for (const timer of toastTimers.current.values()) window.clearTimeout(timer);
      toastTimers.current.clear();
    };
  }, []);

  const setDemoMode = useCallback((value: boolean) => {
    setDemoModeState(value);
    setDataVersion((version) => version + 1);
  }, []);

  const openComposer = useCallback((mood?: MoodKey) => {
    setComposer({ open: true, mood });
  }, []);

  const closeComposer = useCallback(() => setComposer((current) => ({ ...current, open: false })), []);
  const openSearch = useCallback(() => setSearchOpen(true), []);
  const closeSearch = useCallback(() => setSearchOpen(false), []);
  const bumpData = useCallback(() => setDataVersion((version) => version + 1), []);

  const setProfileName = useCallback((name: string) => {
    setProfileNameState(name);
    try {
      if (name) localStorage.setItem(NAME_KEY, name);
      else localStorage.removeItem(NAME_KEY);
    } catch {
      // ignore
    }
  }, []);

  const setApiToken = useCallback((token: string) => {
    persistApiToken(token);
    setApiTokenState(token);
  }, []);

  const value = useMemo<AppContextValue>(
    () => ({
      themeMode,
      effectiveTheme,
      setThemeMode,
      toggleTheme,
      backend,
      refreshBackend,
      demoMode,
      setDemoMode,
      toasts,
      notify,
      dismissToast,
      composer,
      openComposer,
      closeComposer,
      searchOpen,
      openSearch,
      closeSearch,
      dataVersion,
      bumpData,
      profileName,
      setProfileName,
      apiToken,
      setApiToken,
    }),
    [
      themeMode,
      effectiveTheme,
      setThemeMode,
      toggleTheme,
      backend,
      refreshBackend,
      demoMode,
      setDemoMode,
      toasts,
      notify,
      dismissToast,
      composer,
      openComposer,
      closeComposer,
      searchOpen,
      openSearch,
      closeSearch,
      dataVersion,
      bumpData,
      profileName,
      setProfileName,
      apiToken,
      setApiToken,
    ],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppContextValue {
  const value = useContext(AppContext);
  if (!value) throw new Error("useApp must be used within AppProvider");
  return value;
}
