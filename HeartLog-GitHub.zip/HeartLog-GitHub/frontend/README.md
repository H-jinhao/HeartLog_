# HeartLog Frontend

HeartLog 的 React Web 界面。设计方向是 **Apple Liquid Glass × Minimalism × Editorial**：暖白纸张感、克制的玻璃层、低饱和情绪色和较宽的留白。

## 技术栈

- React 19 + TypeScript 5.8
- Vite 6
- Tailwind CSS 3.4
- Motion（`motion/react`）
- Lucide React
- React Router 7
- `vite-plugin-pwa` / Workbox

## 开发

```bash
cd frontend
npm install
cp env.example .env.local    # 可选
npm run dev                  # http://127.0.0.1:5173
```

开发服务器默认把 `/api`、`/health`、`/docs`、`/openapi.json` 代理到 `http://127.0.0.1:8000`，本地开发不需要后端额外开启 CORS。

## 环境变量

| 变量 | 默认 | 说明 |
| --- | --- | --- |
| `VITE_API_BASE_URL` | 空 | 留空表示同源请求；填写后直接访问该 API 源（需要 CORS） |
| `VITE_API_PROXY_TARGET` | `http://127.0.0.1:8000` | Vite 开发/预览代理目标 |

## 构建与预览

```bash
npm run typecheck
npm run build
npm run preview
```

构建产物在 `dist/`。路由按页面懒加载。

## 手机安装（PWA）

```bash
npm run build
npm run preview:lan        # 监听 0.0.0.0:4173
```

手机与电脑连同一个 Wi-Fi，打开 `http://<电脑局域网 IP>:4173`：

- iPhone / Safari：分享 → 添加到主屏幕
- Android / Chrome：菜单 → 安装应用 / 添加到主屏幕
- 页面“我的 → PWA · 本地安装”提供安装步骤

`npm run build` 会生成 `manifest.webmanifest`、`sw.js`、`registerSW.js` 和主屏幕图标。Service Worker 只缓存前端静态资源，**不缓存日记/记忆 API 响应**。

> 完整 PWA 离线安装和 Android 的“安装应用”提示通常要求 HTTPS（`localhost` 例外）。局域网 HTTP 下可以先添加到主屏幕；完整离线缓存需要 TLS 反向代理或 HTTPS 静态站点。

## 页面

| 路由 | 页面 |
| --- | --- |
| `/` | Dashboard：今日思考、快速记录、心情、最近日记、趋势、AI 入口 |
| `/diary` | 日记列表：日期分组、搜索、心情筛选 |
| `/diary/:id` | 日记详情：阅读、编辑、自动保存、修订历史、原文对照 |
| `/memories` | 长期记忆：类型/状态筛选、人物、时间线、证据来源、确认、更正、撤回、遗忘 |
| `/insights` | 情绪分析：周/月趋势、记忆构成、自评、本地统计/AI 回顾 |
| `/profile` | 我的：称呼、主题、PWA 安装、Token、导出、演示模式、AI 状态 |

## 演示模式

后端健康检查失败时自动进入明确标注的演示模式：

- 示例内容仅存在于当前浏览器会话；
- 演示中的保存/确认/更正/遗忘不会写入后端；
- 后端在线但没有记录时显示真实空状态，不会自动填充假数据；
- 可在“我的 → 演示模式”手动切换。

## 目录

```text
src/
├── api/            # 同源 API Client
├── components/
│   ├── ui/         # GlassPanel、Modal、Button、Chip 等
│   ├── layout/     # Sidebar、MobileNav、TopBar、SearchDialog
│   ├── diary/      # 心情选择、写作弹窗
│   ├── memory/     # 类型/状态徽章
│   ├── insights/   # SVG 心情趋势图
│   └── common/     # 演示提示、AI 陪伴、PWA 安装、错误边界
├── context/        # 主题、后端状态、Toast、全局写作
├── lib/            # 日期、心情、演示数据、工具
├── pages/          # 五个核心页面 + 日记详情 + 404
└── types/          # 后端 API 类型
public/
└── icons/          # PWA 图标
```

## 说明

- 本机称呼、草稿、自评保存在 `localStorage`；API Token 保存在 `sessionStorage`。
- 前端不保存模型密钥，也不提供伪造的 AI 开关。
- 未附带自动化 E2E 测试套件；开发时使用 `npm run typecheck`、`npm run build` 和浏览器手工检查。
